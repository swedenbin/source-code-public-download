/* Copyright (c) 1995-2000 Microsoft Corporation.  All rights reserved. */
#include <..\..\..\nk\kernel\x86\exsup.c>

