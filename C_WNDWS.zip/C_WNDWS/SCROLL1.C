/*  (c) Marietta Systems, Inc.  1987
*   All rights reserved
*
*   Demonstration program for function scroll 
*/
#include "mtest.h"
void main(){
int a;
char text[20];
clr_scrn("Scroll test");
if (1 > mk_wndw(5, 20, 19, 60, "Scroll test"));
for (a = 1 ; a < 14 ; a++){ 
     sprintf(text, "This is line %d", a);
     display(text, a, a, high); 
     }
/*	*/
disp_msg("To scroll (-1, 2), press a key",1); read_kb(); 
scroll(-1, 2); 
disp_msg("To scroll (0, 2), press a key",1);  read_kb(); 
scroll(0, 2); 
disp_msg("To scroll (2, 0), press a key",1);  read_kb(); 
scroll(2, 0);
disp_msg("To scroll (-1, 0), press a key",1); read_kb(); 
scroll(-1, 0);
disp_msg("To finish program, press a key",1); read_kb(); 
goodbye(0);
}
