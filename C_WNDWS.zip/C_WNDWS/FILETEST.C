/*  (c) Marietta Systems, Inc.  1987
*    All rights reserved
*
*    Demonstration program for filexxxx functions
*/
#include "mtest.h"
void main(){
long loc, rec_nbr = 0L;
int fh1, fh2, z, x, k;
clr_scrn("File access test");
/*
*    Create an ASCII file, write some records to it, and close it
*/ 
fh1 = fileopen("testfile.dat", ascii, recreate);
if (fh1 <= 0) goodbye(101);
display("File opened - records being created", 1, 1, low);
for (z = 1 , loc = 0L, x = 2; z < 21 ; z++, x++){
     sprintf(FN[fh1].record, "This is record %.2u\n", z);
     if (filewrit(fh1, &loc) < 0) goodbye(102); /* write error */
     display(FN[fh1].record, x, 1, reverse);
     }
if (fileclos(fh1) < 1) goodbye(102);
while (!disp_qry(" Ready to read the file"));
/*
*    Reopen the file, and read it until end of file, and close it
*/
fh1 = fileopen("testfile.dat", ascii, readonly);
if (fh1 <= 0) goodbye (103);
display ("File opened - records read", 1, 40, low);   
for (x = 2 ; ; x++){
     if (!(k = fileread(fh1, nextrec, &rec_nbr))) break; /* EOF */
     if (k < 0) goodbye(104); /* read error */
     if (k) display(FN[fh1].record, x, 40, reverse);
     }
if (fileclos(fh1) < 1) goodbye(105);
while (!disp_qry(" Ready to copy the file"));
clr_wndw();
/*
*    reopen file 1, and copy it into a relative file with binary
*    length records, stripping the '\n' symbol.
*/
fh1 = fileopen("testfile.dat", ascii, readonly);
fh2 = fileopen("testfile.rel", binary, recreate);
if (fileinit(fh2, 0, 64, 0L)) goodbye(110);
if (fh1 <= 0 || fh2 <= 0) goodbye (106);
display ("File opened - records read", 1, 1, low);   
for (x = 2 ; ; x++){
     if (!(k = fileread(fh1, nextrec, &rec_nbr))) break; /* EOF */
     if (k < 0) goodbye(107);             /* read error */
     FN[fh1].record[strlen(FN[fh1].record) - 1] = 0; /* strip '\n' */
     justify (left, FN[fh2].record, FN[fh1].record, 35, 0);
     if (filewrit(fh2, &loc) < 0) goodbye(108); /* write error */
     display(FN[fh2].record, x, 1, reverse);
     }
if (fileclos(fh1) < 1 || fileclos(fh2) < 1) goodbye(109);
while (!disp_qry(" Ready to read file backwards"));
/*
*    reopen file 2, and read it backwards
*/
fh2 = fileopen("testfile.rel", binary, readonly);
if (fileinit(fh2, 0, 64, 20L)) goodbye(110);
if (fh1 <= 0 || fh2 <= 0) goodbye (106);
display ("File opened - records read", 1, 40, low);   
k = fileread(fh2, lastrec, &rec_nbr);
for (z = 20 , x = 2 ; z >= 0 ; z--){
     if (k < 0) goodbye(107); /* read error */
     if (!k) break;           /* EOF */
     display(FN[fh2].record, x++, 40, reverse);
     k = fileread(fh2, previous, &rec_nbr);
     }
if (fileclos(fh2) < 1) goodbye(109);
disp_msg(" Press any key to end",1); read_kb();
goodbye(0);
}