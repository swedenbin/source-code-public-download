/*  (c) Marietta Systems, Inc.  1987
*    All rights reserved
*
*    Test program for hashed files functions
*/
#include "mtest.h"
void main(){
long rec_nbr;
int fh2, z, x, k;
byte input[30], key[17];
clr_scrn("Filewrit access test");
KEYMATCH[0] = KEYMATCH[1] = 0;
KEYMATCH[4] = 0XB000; 
disp_err("",1); /* activate AMEND, INSERT, DELETE keys */
/*  
*	Create hashed file 
*/
if (disp_qry(" Create the hashed file"))
	fh2 = hashmake("testfile.hsh", 10, 64, 200L, 5, 16);
	else fh2 = fileopen("testfile.hsh", hashed, update);
if (fh2 <= 0) goodbye (106); /* open error */
while (!disp_qry(" Ready to random read/write"));
/*	
* 	Read the hashed file
*/
display ("File opened - records can be read", 1, 40, low);
display ("Next record key", 4, 1, high);
rec_nbr = 1L; FN[fh2].record[64] = 0; key[0] = 0;
for (;;){
    set_crsr(4, 17);
    if (0 > accept(key, left, alt_reverse, 16, 0)) goodbye(101); 
    if (INCHAR == QUIT) break;
    if (INCHAR == INSERT) x = 1; else x = 0;
    rec_nbr = hashread(fh2, key, x);
    if (rec_nbr < 1L) {disp_err("Press F5 key to insert new record", 1); 
	continue;}
    switch (INCHAR){
        case DELETE: display(&FN[fh2].record[22], 7, 4, alt_low);
            if (disp_qry("Do you want to delete the record"))
                {FN[fh2].record[0] = DELETED;
                filewrit(fh2, &rec_nbr);
                FN[fh2].r_count -= 1L;
                disp_err("Record deleted", 1013);}
            break;
       case INSERT: memset(&FN[fh2].record[1], 32, FN[fh2].rec_len - 1);
            memcpy(&FN[fh2].record[5], key, 16);
            disp_err("Record Insert mode", 1);
       case AMEND: set_crsr(7,4);
            accept(&FN[fh2].record[22], as_typed, alt_reverse, 40, 0);
            if (INCHAR == QUIT) {INCHAR = ENTER; break;}
            if (FN[fh2].record[0] != IN_USE) {FN[fh2].record[0] = IN_USE;
				FN[fh2].r_count += 1L;}
            filewrit(fh2, &rec_nbr);
            break;
       default: display(&FN[fh2].record[22], 7, 4, alt_low);
       	    break;
       } /* end switch */
   } /* end for */
if (fileclos(fh2) < 1) goodbye(109);
/*
* 	Scan through hashed file to analyse usage
*/
while(!disp_qry(" Ready to analyse hashed file"));
clr_wndw(); 
k = x = z = 0;
if (fileclos(fh2) < 0) goodbye (110);
if ((fh2 = fileopen("testfile.hsh", hashed, readonly)) <= 0) goodbye(111);
while(fileread(fh2, nextrec, &rec_nbr) > 0){
	if (FN[fh2].record[0] == EMPTY) {k++; continue;}
	if (FN[fh2].record[0] == DELETED) {z++; continue;}
	if (FN[fh2].record[0] != IN_USE) 
		{disp_err("corrupted record",1); goodbye(2);}
	display(&FN[fh2].record[5],++x,1,alt_low);
	if (!(x & 0XF)) idleloop(36);
	}
mk_wndw(10, 25, 16, 55, "Analysis of file");
sprintf(input, " %3u records in use  ", x); display(input, 1, 4, reverse); 
sprintf(input, " %3u records deleted ", z); display(input, 2, 4, reverse); 
sprintf(input, " %3u records empty   ", k); display(input, 3, 4, reverse); 
sprintf(input, " %3lu r_count value  ", FN[fh2].r_count); 
	display(input, 5, 4, alt_reverse); 
disp_msg(" Press any key to end", 1); read_kb();
goodbye(0);
}