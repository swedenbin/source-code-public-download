/* start of program "window.c"
*    (c) Marietta Systems, Inc 1987
*	 All rights reserved
*/
#include "mtest.h"
/*	*/
void main(){
int a = 1;
clr_scrn("Window test"); 
mk_wndw(5, 5, 20, 75, "First big window");
display(" Notice how all the windows have different color combinations ", 8, 4,
	alt_reverse); 
/*
*   create windows in the top left hand and right hand corners of the screen.
*/
if (1 > mk_wndw(TOP_LINE, 0, 10, 27, "")) goodbye(101);
display("Notice that the top and   left box lines are missing", 1,1,high);
display("Press any key to continue", 8, 1, alt_low); read_kb();
/*        */
if (1 > mk_wndw(TOP_LINE + 1, 54, 11, SCRN_WID, "top window"))  goodbye(103);
display("Notice that all the box  lines are present", 1, 1, high);
display("Press any key to continue", 8, 1, alt_low); read_kb();
/* 
*    create windows at the bottom right and left  
*/
if (1 > mk_wndw(15, 55, SCRN_LEN, SCRN_WID + 1, ""))goodbye(102);
display("Notice that the bottom   and right box lines are  missing", 1,1,high);
display("Press any key to continue", 8, 1, alt_low); read_kb();
/*        */
if (1 > mk_wndw(14, 1, SCRN_LEN - 1, 27, "bottom window")) goodbye(104);
display("Notice that all the box  lines are present", 1, 1, high);
display("Press any key to continue", 8, 1, alt_low); read_kb();
/*
*    Now peel off the windows one by one
*/
while (a) {while(!disp_qry("Ready to peel off a window"));
     a = rm_wndw(); if (a < 0) a = 0;}
goodbye(0);
}