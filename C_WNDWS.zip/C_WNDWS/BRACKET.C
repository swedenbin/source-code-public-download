/*	(c) Marietta Systems, Inc.  1987
	All rights reserved  */
#include "mtest.h"
/*
*
*  	This program reads through a text file to create a map of '{' and '}'
*
*/
void main(){
long rec_nbr = 0L;
int line, fh = 0, tab = 0, x = 1, z;
byte *text, fname[66], *ptr, out[81];
clr_scrn("Examine a program for {}");
strcpy(fname, "marietta\\hashtest.c");
while (fh <= 0){
    display("Enter the file name  ", 19, 1, low);
    accept(fname, left, alt_reverse, 50, 0);
    fh = fileopen(fname, ascii, readonly);
    if (!fh) disp_err("File not found", 1);
    }
mk_wndw(TOP_LINE, 0, SCRN_LEN, SCRN_WID + 1, "");
while (fileread(fh, nextrec, &rec_nbr) > 0){
    text = FN[fh].record;
    line = (int) rec_nbr - 1;
    if ((ptr = strpbrk(text, "}{")) == NULL) continue;
    for (z = 0 ; ptr[z] != 0 ; z++){
        if (ptr[z] == '{') tab++;
        if (ptr[z] == '}') tab--;
        }
    text[strlen(text) - 1] = 0; /* cull out the \n character */
    sprintf(out, "%4u:%u %.72s", line, tab, text);
    if (x == WINDOW[W_NUM].H){ /* halt and scroll at bottom of screen */ 
        disp_msg("Press any key to continue", 1); 
        read_kb();
        x -= 10; scroll(10, 0);
        disp_msg("", 0);
        }
    display(out, x++, 1, high);
    } /* end while */
disp_msg("Press any key to finish", 1);
read_kb();
goodbye(0);
}