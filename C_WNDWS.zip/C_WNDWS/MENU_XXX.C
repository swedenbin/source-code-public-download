/*  (c) Marietta Systems, Inc.  1987
*   All rights reserved
*
*   Demonstration program for functions menu and top_menu
*/
#include "mtest.h"
void main(){
int a = 3, b = 2, k = 1;
static byte disc[] = " :";
TOP_LINE = 2; /* allow for second line at top for menu */
clr_scrn("Menu test");
/* 
*    create a 6 line, 24 column window at location (5,15) 
*/
if ( 1 > mk_wndw(5, 15, 14, 50,"menu")) goodbye(101); 
menu_1: display ("Select your 'C' compiler", 1, 2, high);
/*
*    Use top_menu to select C compiler
*/
a = top_menu("Lattice C&Quick C&Turbo C&",15, a);
if (a < 0) goodbye(102);
switch (a){
     case 0:   goodbye(0);
     case 1:   display("Lattice selected        ",1,2,blink); break;
     case 2:   display("Microsoft selected      ",1,2,blink); break;
     case 3:   display("Borland selected        ",1,2,blink); break;
     }
display("Now select target drive code:",2,2,high);
/*
*     create a 5 line, 2 column window at location (10,40)
*     and create a 5 line menu, highlighting the 2nd item.
*/
menu_2: if (1 > mk_wndw(10, 40, 18, 43, NULL)) goodbye(103);
b = menu("B:&C:&D:&E:&F:&", 2, b, 1);
if (b < 0) goodbye(104);
rm_wndw(); 
if (!b) {scroll (1,1); goto menu_1;}
disc[0] = b + 65; display (disc, 2, 32, high);
display("Target drive code selected is ", 2, 2, low);
/*
*     create a 4 line menu, 1 item per line, starting at line 4,
*     column 3 of the window, and highlight the 1st item.
*/
display("Now select transfer", 3, 2, high);
k =  1;
set_crsr(4, 3);
k = menu("Compact Model&Header File&SMall Model&SOurce&", 15, k, 1);
if (k < 0) goodbye(105); 
scroll(5,2);
if (!k) goto menu_2;
switch (k){
	case 1: display("Compact model selected    ", 3, 2, high); break;
	case 2: display("Header File selected      ", 3, 2, high); break;
	case 3: display("Small model selected      ", 3, 2, high); break;
	case 4: display("Source selected           ", 3, 2, high); break;
	}
if (k && !disp_qry("Around again")) goodbye(0);
scroll(1,2);
goto menu_2;
}