#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <stdarg.h>
#include <time.h>
#include <limits.h>
#include <string.h>

void printinfo(const struct stat sbuf, const char *name);
void pline(const char *desc, const char *fmt, ...);
void pbool(const char *desc, int cond);
char *myctime(const time_t *timep);

int main(int argc, char *argv[]) {
  struct stat sbuf;
 
  if (argc != 2) {
    printf("Syntax: %s filename\n", argv[0]);
    return(1);
  }

  /* First, look at the file.  If it's a link, gives information about
     the link. */

  printf("Information for file %s:\n\n", argv[1]);
  if (lstat(argv[1], &sbuf) == -1) {
    perror("lstat failed");
    return(2);
  }

  printinfo(sbuf, argv[1]);

  if (S_ISLNK(sbuf.st_mode)) {
    printf("\n-----------------------------------\n");
    printf("Information for file pointed to by link\n\n");

    if (stat(argv[1], &sbuf) == -1) {
      perror("stat on link failed");
      return(3);
    }

    printinfo(sbuf, "");
  }
  return 0;
}

void printinfo(const struct stat sbuf, const char *name) {
  pline("Device", "%d", sbuf.st_dev);
  pline("Inode", "%d", sbuf.st_ino);
  pline("Number of hard links", "%d", sbuf.st_nlink);
  pbool("Symbolic link", S_ISLNK(sbuf.st_mode));
  if (S_ISLNK(sbuf.st_mode)) {
    char linkname[PATH_MAX * 2];
    int length;

    length = readlink(name, linkname, sizeof(linkname) - 1);
    if (length == -1) {
      perror("readlink failed");
    }

    linkname[length] = 0;
    pline("Link destination", linkname);
  }
   
  pbool("Regular file", S_ISREG(sbuf.st_mode));
  pbool("Directory", S_ISDIR(sbuf.st_mode));
  pbool("Character device", S_ISCHR(sbuf.st_mode));
  pbool("Block device", S_ISBLK(sbuf.st_mode));
  pbool("FIFO", S_ISFIFO(sbuf.st_mode));
  pbool("Socket", S_ISSOCK(sbuf.st_mode));

  printf("\n");

  pline("Device type", "%d", sbuf.st_rdev);
  pline("File size", "%d", sbuf.st_size);
  pline("Preferred block size", "%d", sbuf.st_blksize);
  pline("Length in blocks", "%d", sbuf.st_blocks);
  pline("Last access", "%s", myctime(&sbuf.st_atime));
  pline("Last modification", "%s", myctime(&sbuf.st_mtime));
  pline("Last change", "%s", myctime(&sbuf.st_ctime));
 
  printf("\n");

  pline("Owner uid", "%d", sbuf.st_uid);
  pline("Group gid", "%d", sbuf.st_gid);
  pline("Permissions", "0%o", sbuf.st_mode &
       (S_ISUID | S_ISGID | S_ISVTX | S_IRWXU | S_IRWXG | S_IRWXO));
  pbool("setuid", sbuf.st_mode & S_ISUID);
  pbool("setgid", sbuf.st_mode & S_ISGID);
  pbool("sticky bit", sbuf.st_mode & S_ISVTX);
  pbool("User     read permission", sbuf.st_mode & S_IRUSR);
  pbool("User    write permission", sbuf.st_mode & S_IWUSR);
  pbool("User  execute permission", sbuf.st_mode & S_IXUSR);
  pbool("Group    read permission", sbuf.st_mode & S_IRGRP);
  pbool("Group   write permission", sbuf.st_mode & S_IWGRP);
  pbool("Group execute permission", sbuf.st_mode & S_IXGRP);
  pbool("Other    read permission", sbuf.st_mode & S_IROTH);
  pbool("Other   write permission", sbuf.st_mode & S_IWOTH);
  pbool("Other execute permission", sbuf.st_mode & S_IXOTH);

}

void pline(const char *desc, const char *fmt, ...) {
  va_list ap;

  va_start(ap, fmt);
  printf("%30s: ", desc);
  vprintf(fmt, ap);
  printf("\n");
}

void pbool(const char *desc, int cond) {
  pline(desc, cond ? "Yes" : "No");
}

char *myctime(const time_t *timep) {
  char *retval;

  retval = ctime(timep);

  retval[strlen(retval) - 1] = 0;	 /* strip off trailing \n */
  return (retval + 4);             /* strip off leading day of week */
}
