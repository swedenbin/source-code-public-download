#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#define ITERATIONS 9000000

int main(void) {
  int number;
  char writestring[100];
  int counter;
  int size;
  int output;

  printf("Please enter a number: ");
  scanf("%d", &number);
 
  number /= 2;
 
  printf("Writing %d copies of %d to a file.\n", ITERATIONS, number);
  output = open("testfile", O_CREAT | O_TRUNC);
  if (!output) {
    perror("Can't open output file");
    exit(255);
  }
 
  sprintf(writestring, "%d", number);
  size = strlen(writestring);
 
  for (counter = 0; counter < ITERATIONS; counter++) {
    write(output, writestring, size);
  }
 
  close(output);
  return 0;
}
