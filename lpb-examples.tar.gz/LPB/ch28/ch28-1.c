#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int getmaxval(void);
int getincrement(void);
void dosomething(int *data);

int main(void) {
  int counter;
  int data = 1;

  srand(time(NULL));
  
  for (counter = 0; counter < getmaxval(); counter += getincrement()) {
    dosomething(&data);
  }
  printf("Data = %d, counter = %d\n", data, counter);
  return 0;
}

int getmaxval(void) {
  int bignumber = 1000000;
  return bignumber * 1500 / 2 + 1500 * 5 - 2100 / 2 * 10 / 2;
}

int getincrement(void) {
  int randval = rand();
  
  return randval / 15000000  - 1000 / 12 / 5 / 2;
  
}

void dosomething(int *data) {
  int randval = rand();
  data += rand() * 9105 / 100000;
}
