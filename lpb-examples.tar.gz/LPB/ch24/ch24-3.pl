#!/usr/bin/perl -w

use Tk;

# Create a hash to hold information about the three different color areas.

my %areas = ('red' => '', 'green' => '', 'blue' => '');

# Create the main window.

my $window = new MainWindow();

$window->title('Color Picker');     # Give it a title.

# Create the top label text.

$window->Label(-text => "You may select your colors here.")
       ->pack(-side => 'top');

# Create each area, pack it, and store it into the hash.

foreach my $name ('red', 'green', 'blue') {
  $areas->{$name} = ColorArea($name, $window->Frame);
  $areas->{$name}->{frame}->pack(-fill => 'x');
}

# Create the label for the bottom of the window.

my $colorlabel =
  $window->Label(-text => 'foo')->pack(-side => 'top', -fill => 'both');

# And update it.

UpdateColorLabel();

# Process events.

MainLoop;

# This is a subroutine to create an area in the window for each
# particular color.  Its arguments are a color name and a frame.
# The subroutine will create all its widgets inside that frame,
# and return a reference to a hash with information about the
# color.

sub ColorArea {
  my ($name, $frame) = @_;

  # Initialize the hash with some useful information.
  my $retval = {'frame' => $frame, 'value' => 128, name => $name};

  # Create a label with the color name.
  $frame->Label(-text => $name)->pack(-side => 'left');

  # Create a horizontal scroll bar.  When the bar is moved, call
  # the scrollit subroutine.
  my $s = $frame->Scrollbar(-orient => 'horiz',
                            -command => sub { scrollit($retval, @_) })
    ->pack(-side => 'left', -fill => 'x', -expand => 1);

  # Create an entry box.  It displays the variable, and will
  # automatically update it when modified.
  $retval->{entry} = $frame->Entry(-width => 3,
                                   -textvariable => \$retval->{value})
    ->pack(-side => 'right');

  # When the Return key is pressed, update everything based on the
  # keypress.
  $retval->{entry}->bind('<Return>', sub { setit($retval) } );

  # Save off the scrollbar into the hash.
  $retval->{scrollbar} = $s;

  # Update things now.
  setit($retval);

  return $retval;
}

# This subroutine is used to handle a scroll request.

sub scrollit {
  my ($hash, $cmd, $arg, $arg2) = @_;
  my $var = \$hash->{value};
 
  if ($cmd eq 'moveto') {      # Move to a specific location.
    $$var = $arg * 255;
  } elsif ($cmd eq 'scroll' && $arg2 eq 'units') {
    $$var += $arg;             # User clicked on arrow, move by 1.
  } elsif ($cmd eq 'scroll' && $arg2 eq 'pages') {
    $$var += 10 * $arg;        # User clicked on bar area, move by 10.
  }
  setit($hash);
}

# Set scrollbars and everything as appropriate.  Takes a hash as an
# argument, processes its value, and sets things up.

sub setit {
  my $hash = shift @_;
  my $value = \$hash->{value};

  # Do some sanity checks.  Strip off a fractional part, make sure
  # between 0 and 255.

  $$value = int $$value;
  $$value = 255 if ($$value > 255);
  $$value = 0 if ($$value < 0);

  # Update the scroll bar.  Note the scrollbar needs its values in
  # fractions.

  $hash->{scrollbar}->set($$value / 255, $$value / 255);
  UpdateColorLabel();
}

# Update the color label at the bottom of the screen.  Show the color
# string, suitable for use in HTML and X, and set the background
# to that color.

sub UpdateColorLabel {
  return unless ($areas->{red} &&
                 $areas->{green} &&
                 $areas->{blue});

  my $colorstring = sprintf('#%02x%02x%02x',
                            $areas->{red}->{value},
                            $areas->{green}->{value},
                            $areas->{blue}->{value});
  $colorlabel->configure(-background => $colorstring,
                         -text => $colorstring);
}
