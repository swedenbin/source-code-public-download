#!/usr/bin/perl -w

use Tk;
use strict;

my $window = new MainWindow();
$window->title('Hi!');
$window->Label(-text => "Hello from Perl/Tk!")->pack;
$window->Button(-text => "Exit",
                -command => \&exitsub)->pack;
MainLoop;

sub exitsub {
  my $w = $window->Toplevel();
  $w->title('Goodbye');
  $w->Label(-text => 'You are now leaving the demonstration program.')->pack;
  $w->Button(-text => "OK", -command => sub { $w->destroy;
                                              $window->destroy; })->pack;
}
