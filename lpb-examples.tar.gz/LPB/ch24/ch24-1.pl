#!/usr/bin/perl -w

use Tk;

my $window = new MainWindow;
$window->title('Hi!');
$window->Label(-text => "Hello from Perl/Tk!")->pack;
$window->Button(-text => "Exit",
                -command => \&exitbutton)->pack;
MainLoop;

sub exitbutton {
  exit(0);
}
