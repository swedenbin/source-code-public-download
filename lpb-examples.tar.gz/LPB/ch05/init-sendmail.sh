#!/bin/sh

# Start or stop sendmail
#
# Robert Leslie <rob@mars.org>
# Johnie Ingram <johnie@netgod.net>
# David Rocher <rocher@mail.dotcom.fr>
# Richard Nelson <cowboy@debain.org>

# How often to run the queue
Q="10m"

PATH=/bin:/usr/bin:/sbin:/usr/sbin
DAEMON=/usr/sbin/sendmail
COMMAND=/usr/sbin/sendmail
PIDFILE=/var/run/sendmail.pid
NAME=sendmail
FLAGS="defaults 50"

test -x $DAEMON -a -d /usr/doc/sendmail || exit 0

case "$1" in
    start)
        ( cd /var/spool/mqueue && rm -f [lnx]f* )
        echo -n "Starting mail transport agent: sendmail"
        start-stop-daemon --start --quiet --pidfile $PIDFILE  --exec $DAEMON --startas $COMMAND -- -bd -q"$Q"
        echo "."
    ;;

    stop)
        echo -n "Stopping mail transport agent: sendmail"
        start-stop-daemon --stop --quiet --pidfile $PIDFILE --exec $DAEMON
        echo "." 
    ;;

    restart)
        $0 stop
        sleep 2
        $0 start
    ;;
    
    reload)
        echo -n "Reloading sendmail configuration..."
        start-stop-daemon --stop --signal 1 --quiet  \
            --pidfile $PIDFILE --exec $DAEMON
        echo "done." 
    ;;

    force-reload)
        $0 reload
    ;;

    debug)
        start-stop-daemon --stop --signal 10 --verbose  \
            --pidfile $PIDFILE --exec $DAEMON
    ;;

    *)
        echo "Usage: /etc/init.d/sendmail {start|stop|restart|reload|force-reload|debug}"
        exit 1
    ;;
esac

exit 0
