#!/usr/bin/perl -Tw

$| = 1;

use CGI qw(:standard);

my $q = new CGI;

print header;
print start_html('Hello World!');

my $count = $q->param('count') ? $q->param('count') : 1;

if ($q->param('mode') eq 'display') {
  print "Hello, World!<P>";
  print "Greetings from process $$\n<P>\n";
  print "Message number $count:\n<FONT COLOR=blue>";
  print $q->param('message');
  print "</FONT>\n<P>\n";
  print <<"EOF";
  <FORM METHOD=POST>
EOF
  print '<input type="hidden" name="count" value="';
  print $count + 1;
  print '">';
  print <<"EOF";

  <input type="submit" name="submit" value="Enter another message">
  </FORM>
EOF
} else { 
  print <<"EOF";
  Please enter message number $count:<P>
  <FORM METHOD=POST>
  <input type="text" name="message" size=30>
  <input type="hidden" name="count" value="$count">
  <input type="hidden" name="mode" value="display">
  <BR>
  <input type="submit" name="submit" value="Go">
  </FORM>
EOF
}


print end_html;
