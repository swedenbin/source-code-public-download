#!/usr/bin/perl -Tw

$| = 1;

use CGI qw(:standard);

my $q = new CGI;

print header;
print start_html('Hello World!');

if ($q->param('message')) {
  print "Hello, World!<P>";
  print "Greetings from process $$\n<P>\n";
  print "Your message was:\n<FONT COLOR=blue>";
  print $q->param('message');
  print "</FONT>\n";
} else { 
  print <<'EOF';
  Please enter a message:<P>
  <FORM METHOD=POST>
  <input type="text" name="message" size=30>
  <BR>
  <input type="submit" name="submit" value="Go">
  </FORM>
EOF
}


print end_html;
