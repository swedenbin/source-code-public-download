#!/usr/bin/perl -Tw

$| = 1;

use CGI qw(:standard);

print header;

print start_html('Hello World!');
print "Hello, World!<P>";
print "Greetings from process $$\n";

print end_html;
