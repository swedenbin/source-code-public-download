#!/usr/bin/perl -Tw

$| = 1;

use CGI qw(:standard);

my $q = new CGI;

print header;
print start_html('Hello World!');

my $count = $q->param('count') ? $q->param('count') : 1;

if ($q->param('mode') eq 'display') {
  print "Hello, World!<P>";
  print "Greetings from process $$\n<P>\n";
  print "Message number $count:\n<FONT COLOR=blue>";
  print $q->param('message');
  print "</FONT>\n<P>\n";
  print $q->startform(-method => 'POST');
  print $q->hidden(-name => 'count', -default => $count + 1,
                   -override => 1), "\n";
  print $q->hidden(-name => 'message'), "\n";
  print $q->submit('submit', 'Enter another message'), "\n";
  print $q->endform;
} else { 
  print "Please enter message number $count:<P>\n";
  print $q->startform(-method => 'POST');
  print $q->textfield(-name => 'message', -size => 30), "\n";
  print $q->hidden(-name => 'count', -value => $count), "\n";
  print $q->hidden(-name => 'mode', -value => 'display'), "\n<BR>\n";
  print $q->submit('submit', 'Go'), "\n";
  print $q->endform;
}


print end_html;
