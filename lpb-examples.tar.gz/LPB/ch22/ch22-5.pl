#!/usr/bin/perl -Tw

# Turn off output buffering.

$| = 1;

# Bring in the CGI library.

use CGI qw(:standard);

# Create a new CGI object.

my $q = new CGI;

# Print the HTTP header.

print header;

# Select a default mode.

my $mode = "mode_" . ($q->param('mode') || 'start');

# Eliminate something invalid.

unless ($mode =~ /^mode_[a-zA-Z]+$/) {
  $mode = 'mode_error';
}

# Call the subroutine that handles that mode.

&$mode();

# End the HTML.

print end_html;

### program exits here ###

sub mode_start {
  print start_html('Welcome to Message Displayer');
  print <<'EOF';
Welcome to the Message Displayer!  Through this program, you will get
to compose a message and select how it will be displayed on-screen.
<P>
EOF
  print ContinueButton('EnterMessage');
}

sub mode_EnterMessage {
  print start_html('Message Displayer: Enter Message');
  print <<'EOF';
Now is the time to enter the message to display.  You will have
options to configure it later.
<P>
EOF

  # Generate a form to use to enter the message.

  print $q->startform(-method => 'POST');
  print "Your message:\n<BR>\n";
  print $q->textarea(-name => 'message',
                     -rows => 10,
                     -columns => 40);
  print "<BR>";
  print ContinueButton('SelectColor', 1);
  print $q->endform;
}

sub mode_SelectColor {
  # If there was no message, jump back to that mode.
  unless ($q->param('message')) {
    return mode_EnterMessage();
  }

  # Now start this one.

  # Here are the colors for the list.

  my @colors = ('red', 'green', 'blue', 'yellow', 'black', 'white',
                'orange', 'pink', '#FFFFFF', '#AC0000', '#FF00FF');

  # Start the HTML and display the existing message.

  print start_html('Message Displayer: Select Color');
  print <<"EOF";
You now need to select the color for your message.  Your message is:
<HR>
EOF
  print $q->param('message');
  print "<HR>\n";

  # Start the form.

  print $q->startform(-method => 'POST');

  # Display the list.
  print $q->scrolling_list(-name => 'color',
                          -values => \@colors,
                          -size => 4,
                          -default => 'blue');
  print "<P>\n";

  # Display the button to use to continue to the next step.
  print ContinueButton('SelectFont', 1);
  print $q->endform;
}

sub mode_SelectFont {
  # If no message or color, jump back a level.
  # This is for error-checking.
  unless ($q->param('message') && $q->param('color')) {
    return mode_SelectColor();
  }

  # Now start this one.

  print <<EOF;
Now that you have selected your message and its color, you get to select some
attributes for it.  You may select none, all, or any number in between.
<P>
Attributes:
<BR>
EOF
  print $q->startform(-method => 'POST');
  print $q->checkbox_group(-name => 'font',
                           -values => ['bold', 'italic', 'underline',
                                       'large', 'small'],
                           -linebreak => 'true');
  print ContinueButton('Confirm', 1);
  print $q->endform;
}

sub mode_Confirm {
  # If no message or color, jump back a level.
  unless ($q->param('message') && $q->param('color')) {
    return mode_SelectColor();
  }

  # Now start this one.

  print <<"EOF";
Here is the data you have submitted for processing.  If you believe this is
correct, click Continue to view your message.
<P>
<TABLE WIDTH="100%" BORDER>
EOF
  print "<TR><TD><B>Message</B><TD>", $q->param('message'), "\n";
  print "<TR><TD><B>Color</B><TD>", $q->param('color'), "\n";
  print "<TR><TD><B>Attributes</B><TD>";
  if ($q->param('font')) {
    print join(', ', $q->param('font'));
  } else {
    print "None";
  }
  print "\n</TABLE>\n";
    

  print ContinueButton('finish');
}

sub mode_finish {
  # If no message or color, jump back a level.
  unless ($q->param('message') && $q->param('color')) {
    return mode_SelectColor();
  }

  # Now start this one.

  my @closetags;

  print <<'EOF';
Here is your message:
<HR>
EOF
  print '<font color="', $q->param('color'), '">';
  unshift @closetags, '</FONT>';

  InsertAttr('bold', '<B>', '</B>', \@closetags);
  InsertAttr('italic', '<I>', '</I>', \@closetags);
  InsertAttr('underline', '<U>', '</U>', \@closetags);
  InsertAttr('large', '<FONT SIZE="+2">', '</FONT>', \@closetags);
  InsertAttr('small', '<FONT SIZE="-2">', '</FONT>', \@closetags);
  print $q->param('message');

  # Display the closing tags.
  print join('', @closetags);

  print "\n<HR>\nThanks for using Message Displayer!\n";
}

sub InsertAttr {
  my ($val, $start, $end, $arr) = @_;

  # unshift is used instead of push below because we want the values
  # to be inserted at the start of the array since they have to be
  # displayed in the inverse order that the were added.

  if (isinarr($val, $q->param('font'))) {
    print $start;
    unshift @$arr, $end;
  }
}


sub mode_error {
  print start_html('Error');

  print "I'm sorry, there was an error.  Please use your browser's back\n";
  print "button and retry the operation.\n";
}

# This sub displays the button that takes the user to the next mode.

sub ContinueButton {
  my ($mode, $suppressform) = @_;
  my $retval = "";

  unless ($suppressform) {
    $retval = $q->startform(-method => 'POST') . "\n";
  }

  # Copy everything except the mode.
  $retval .= CopyParams('mode') . "\n";

  # Insert the item for this mode.
  $retval .= $q->hidden(-name => 'mode', -value => $mode,
                        -override => 1) . "\n";
  $retval .= $q->submit('submit', 'Continue') . "\n";
  unless ($suppressform) {
    $retval .= $q->endform . "\n";
  }
  return $retval;
}
  
# This is used to generate hidden fields to pass along the current values
# to the next invocation.  The parameters are an array of values to *not*
# pass along.

sub CopyParams {
  my @keysToIgnore = @_;
  unshift @keysToIgnore, 'submit';
  my $retval = "";
  my $parameter;

  foreach $parameter ($q->param) {
    if (!isinarr($parameter, @keysToIgnore)) {
      $retval .= $q->hidden(-name => $parameter,
                            -value => [$q->param($parameter)],
                            -override => 1) . "\n";
    }
  }
  
  return $retval;
}

# Returns true if the search term is found as an element in the array, or
# false if not.

sub isinarr {
  my ($search, @array) = @_;
  my $thisvalue;

  foreach $thisvalue (@array) {
    return 1 if ($thisvalue eq $search);
  }
  return 0;
}
