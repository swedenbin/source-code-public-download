#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include "safecalls.h"

/* The union for semctl may or may not be defined for us.  This code, defined
   in Linux's semctl() manpage, is the proper way to attain it if necessary. */

#if defined(__GNU_LIBRARY__) && !defined(_SEM_SEMUN_UNDEFINED)
/* union semun is defined by including <sys/sem.h> */
#else
/* according to X/OPEN we have to define it ourselves */
union semun {
  int val;                    /* value for SETVAL */
  struct semid_ds *buf;       /* buffer for IPC_STAT, IPC_SET */
  unsigned short int *array;  /* array for GETALL, SETALL */
  struct seminfo *__buf;      /* buffer for IPC_INFO */
};
#endif

#define SHMDATASIZE 1000
#define BUFFERSIZE (SHMDATASIZE - sizeof(int))

#define SN_EMPTY 0
#define SN_FULL  1
#define SN_LOCK  2

int DeleteSemid = 0;

void consumer(int shmid);
void producer(int shmid);
int masterinit(void);
char *standardinit(int shmid, int *semid);
void delete(void);
void sigdelete(int signum);
void locksem(int semid, int semnum);
void unlocksem(int semid, int semnum);
void waitzero(int semid, int semnum);
void producerwrite(int shmid, int semid, char *buffer);

int safesemget(key_t key, int nsems, int semflg);
int safesemctl(int semid, int semnum, int cmd, union semun arg);
int safesemop(int semid, struct sembuf *sops, unsigned nsops);
int safeshmget(key_t key, int size, int shmflg);
void *safeshmat(int shmid, const void *shmaddr, int shmflg);
int safeshmctl(int shmid, int cmd, struct shmid_ds *buf);


int main(int argc, char *argv[]) {
char selection[3];
int shmid;
  /* No arguments: "master */
  if (argc < 2) {
    shmid = masterinit();
  } else {
    shmid = atoi(argv[1]);
  }

  printf("Shall I be a [C]onsumer or a [P]roducer process? ");
  fgets(selection, sizeof(selection), stdin);
 
  switch(selection[0]) {
    case 'p':
    case 'P': producer(shmid); break;
    case 'c':
    case 'C': consumer(shmid); break;
    default:  printf("Invalid choice; exiting.\n");
  }
  return 0;
}

void consumer(int shmid) {
  int semid;
  char *buffer;

  buffer = standardinit(shmid, &semid);

  printf("Consumer operational: shm id is %d, sem id is %d\n",
         shmid,
         semid);

  while (1) {
    printf("Waiting until full... ");
    fflush(stdout);
    locksem(semid, SN_FULL);
    printf("done; ");

    printf("waiting for lock... ");
    fflush(stdout);
    locksem(semid, SN_LOCK);
    printf("done.\n");

    printf("Message received: %s\n", buffer);
    unlocksem(semid, SN_LOCK);
    unlocksem(semid, SN_EMPTY);
  }
}

void producer(int shmid) {
  int semid;
  char *buffer;

  buffer = standardinit(shmid, &semid);

  printf("Producer operational: shm id is %d, sem id is %d\n",
         shmid,
         semid);

  while (1) {
    char input[3];

    printf("\n\nMenu\n1. Send a message\n");
    printf("2. Exit\n");

    fgets(input, sizeof(input), stdin);

    switch(input[0]) {
      case '1': producerwrite(shmid, semid, buffer); break;
      case '2': exit(0); break;
    }
  }
}

char *standardinit(int shmid, int *semid) {
  void *shmdata;
  char *buffer;

  shmdata = safeshmat(shmid, 0, 0);
 
  *semid = *(int *)shmdata;
  buffer = shmdata + sizeof(int);

  return buffer;
}

int masterinit(void) {
  union semun sunion;
  int semid, shmid;
  void *shmdata;

  /* First thing: generate the semaphore. */

  semid = safesemget(IPC_PRIVATE, 3, SHM_R | SHM_W);

  DeleteSemid = semid;

  /* Delete the semaphore when exiting. */
  atexit(&delete);
  signal(SIGINT, &sigdelete);

  /* Initially empty should be available and full should not be.
     The lock will also be available initially. */
 
  sunion.val = 1;
  safesemctl(semid, SN_EMPTY, SETVAL, sunion);
  safesemctl(semid, SN_LOCK, SETVAL, sunion);
  sunion.val = 0;
  safesemctl(semid, SN_FULL, SETVAL, sunion);

  /* Now allocate a shared memory segment. */

  shmid = safeshmget(IPC_PRIVATE, SHMDATASIZE, IPC_CREAT | SHM_R | SHM_W);
 
  /* Map it into memory. */

  shmdata = safeshmat(shmid, 0, 0);

  /* Mark it to delete automatically when the last holding process exits. */

  safeshmctl(shmid, IPC_RMID, NULL);

  /* Write the semaphore id to its beginning. */
  *(int *)shmdata = semid;

  printf(" *** The system is running with SHM id %d \n", 
         shmid);

  return shmid;
}


void delete(void) {
  printf("\nMaster exiting; deleting semaphore %d.\n", DeleteSemid);
  if (semctl(DeleteSemid, 0, IPC_RMID, 0) == -1) {
    printf("Error releasing semaphore.\n");
  }
}

void sigdelete(int signum) {
  /* Calling exit will conveniently trigger the normal
     delete item. */

  exit(0);
}

void locksem(int semid, int semnum) {
  struct sembuf sb;

  sb.sem_num = semnum;
  sb.sem_op = -1;
  sb.sem_flg = SEM_UNDO;

  safesemop(semid, &sb, 1);
}

void unlocksem(int semid, int semnum) {
  struct sembuf sb;

  sb.sem_num = semnum;
  sb.sem_op = 1;
  sb.sem_flg = SEM_UNDO;

  safesemop(semid, &sb, 1);
}

void waitzero(int semid, int semnum) {
  struct sembuf sb;

  sb.sem_num = semnum;
  sb.sem_op = 0;
  sb.sem_flg = 0;         /* No modification so no need to undo */
 
  safesemop(semid, &sb, 1);
}

void producerwrite(int shmid, int semid, char *buffer) {
  printf("Waiting until empty... ");
  fflush(stdout);
  locksem(semid, SN_EMPTY);

  printf("done; waiting for lock...\n");
  fflush(stdout);
  locksem(semid, SN_LOCK);
 

  printf("Enter message: ");
  fgets(buffer, BUFFERSIZE, stdin);

  unlocksem(semid, SN_LOCK);
  unlocksem(semid, SN_FULL);
}

int safesemget(key_t key, int nsems, int semflg) {
  int retval;

  retval = semget(key, nsems, semflg);
  if (retval == -1)
    HandleError(errno, "semget", "key %d, nsems %d failed", key, nsems);
  return retval;
}
 
int safesemctl(int semid, int semnum, int cmd, union semun arg) {
  int retval;

  retval = semctl(semid, semnum, cmd, arg);
  if (retval == -1)
    HandleError(errno, "semctl", "semid %d, semnum %d, cmd %d failed",
                semid, semnum, cmd);
  return retval;
}

int safesemop(int semid, struct sembuf *sops, unsigned nsops) {
  int retval;

  retval = semop(semid, sops, nsops);
  if (retval == -1)
    HandleError(errno, "semop", "semid %d (%d operations) failed",
                semid, nsops);
  return retval;
}

int safeshmget(key_t key, int size, int shmflg) {
  int retval;

  retval = shmget(key, size, shmflg);
  if (retval == -1)
    HandleError(errno, "shmget", "key %d, size %d failed", key, size);
  return retval;
}

void *safeshmat(int shmid, const void *shmaddr, int shmflg) {
  void *retval;

  retval = shmat(shmid, shmaddr, shmflg);
  if (retval == (void *) -1)
    HandleError(errno, "shmat", "shmid %d failed", shmid);
  return retval;
}

int safeshmctl(int shmid, int cmd, struct shmid_ds *buf) {
  int retval;

  retval = shmctl(shmid, cmd, buf);
  if (retval == -1)
    HandleError(errno, "shmctl", "shmid %d, cmd %d failed",
                shmid, cmd);
  return retval;
}
