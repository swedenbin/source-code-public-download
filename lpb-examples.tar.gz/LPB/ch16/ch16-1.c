#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

int semheld = 0;

void release(int id);
void request(int id);

/* The union for semctl may or may not be defined for us.  This code, defined
   in Linux's semctl() manpage, is the proper way to attain it if necessary. */

#if defined(__GNU_LIBRARY__) && !defined(_SEM_SEMUN_UNDEFINED)
/* union semun is defined by including <sys/sem.h> */
#else
/* according to X/OPEN we have to define it ourselves */
union semun {
  int val;                    /* value for SETVAL */
  struct semid_ds *buf;       /* buffer for IPC_STAT, IPC_SET */
  unsigned short int *array;  /* array for GETALL, SETALL */
  struct seminfo *__buf;      /* buffer for IPC_INFO */
};
#endif


int main(int argc, char *argv[]) {
  int id;
  union semun sunion;

  /* No arguments: "server". */
  if (argc < 2) {
    /* Request a semaphore. */
    id = semget(IPC_PRIVATE, 1, SHM_R | SHM_W);
   
    /* Initialize its resource count to 1. */
   
    sunion.val = 1;
    semctl(id, 0, SETVAL, sunion);
  } else {
    /* Open up the existing one. */
    id = atoi(argv[1]);
    printf("Using existing semaphore %d.\n", id);
  }

  if (id == -1) {
    printf("Semaphore request failed: %s.\n", strerror(errno));
    return 0;
  }

  printf("Successfully allocated semaphore id %d\n", id);
 
  while (1) {
    int selection;
    printf("\nStatus: %d resources held by this process.\n", semheld);
    printf("Menu:\n");
    printf("1. Release a resource\n");
    printf("2. Request a resource\n");
    printf("3. Exit this process\n");
    printf("Your choice: ");

    scanf("%d", &selection);

    switch(selection) {
      case 1: release(id); break;
      case 2: request(id); break;
      case 3: exit(0); break;
    }
  }

  return 0;
}

void release(int id) {
  struct sembuf sb;

  if (semheld < 1) {
    printf("I don't have any resources; nothing to release.\n");
    return;
  }

  sb.sem_num = 0;
  sb.sem_op = 1;
  sb.sem_flg = 0;
 
  semop(id, &sb, 1);
  semheld--;

  printf("Resource released.\n");
}

void request(int id) {
  struct sembuf sb;

  if (semheld > 0) {
    printf("I already hold the resource; not requesting another one.\n");
    return;
  }

  sb.sem_num = 0;
  sb.sem_op = -1;
  sb.sem_flg = 0;

  printf("Requesting resource...");
  fflush(stdout);

  semop(id, &sb, 1);
  semheld++;

  printf(" done.\n");
}
