#!/usr/bin/perl -w

use DB_File;
require FileObject;

my %dirs = ();

tie(%dirs, "DB_File", "Dirs.hash") or die "Couldn't tie: $!\n";

# Perl's unless is an inverse if.  That is, unless(a) is the same as
# if (!(a)).

unless ($ARGV[0]) {
  print "Displaying saved data:\n";
  printit(\%dirs, 0);
  exit 0;
}

# -d is a Perl shorthand.  It does a stat() on the passed filename and
# then looks at the mode.  If the filename is a directory, it returns true;
# if not, it returns false.

unless (-d $ARGV[0]) {
  die "The filename supplied was not a directory."
}

dircontents($ARGV[0], \%dirs);
printit(\%dirs, 0);

untie(%dirs);

sub dircontents{
  my ($startname, $retval) = @_;
  my $filename;
  $retval = {} unless ($retval);
  local *DH;                # Ensure that the handle is locally scoped

# This is the same as DH = opendir("filename") in C.
# In C, you can use DIR *DH; to declare the variable.

  unless(opendir(DH, $startname)) {
    warn "Couldn't open directory $startname: $!";
    return undef;
  }

  # In C, readdir() returns a pointer to struct dirent, whose members are
  # defined in readdir(3).  In Perl, returns one file in scalar context,
  # or all remaining filenames in list context.

  while ($filename = readdir(DH)) {
    my $object = new FileObject($startname);
    $object->populate($filename);
    if ($object->{isdir}) {
      dircontents("$startname/$filename", $retval);
    }
    $retval->{"$startname/$filename"} = $object->serialize();
  }

  closedir(DH);
  return %$retval;
}

sub printit {
  my ($ref, $count) = @_;
  my $key;
  my $counter = 0;

  foreach $key (sort keys %$ref) {
    my $object = new FileObject($ref->{$key});
    $object->display($count);
  }
}
