#!/usr/bin/perl -w

use DB_File;

my %dirs = ();

tie(%dirs, "DB_File", "Dirs.hash") or die "Couldn't tie: $!\n";

# Perl's unless is an inverse if.  That is, unless(a) is the same as
# if (!(a)).

unless ($ARGV[0]) {
  print "Displaying saved data:\n";
  printit(\%dirs, 0);
  exit 0;
}

# -d is a Perl shorthand.  It does a stat() on the passed filename and
# then looks at the mode.  If the filename is a directory, it returns true;
# if not, it returns false.

unless (-d $ARGV[0]) {
  die "The filename supplied was not a directory."
}

dircontents($ARGV[0], \%dirs);
printit(\%dirs, 0);

untie(%dirs);

sub dircontents{
  my ($startname, $retval) = @_;
  my $filename;
  $retval = {} unless ($retval);
  local *DH;                # Ensure that the handle is locally scoped

# This is the same as DH = opendir("filename") in C.
# In C, you can use DIR *DH; to declare the variable.

  unless(opendir(DH, $startname)) {
    warn "Couldn't open directory $startname: $!";
    return undef;
  }

  # In C, readdir() returns a pointer to struct dirent, whose members are
  # defined in readdir(3).  In Perl, returns one file in scalar context,
  # or all remaining filenames in list context.

  while ($filename = readdir(DH)) {
    if ($filename ne '.' &&
      $filename ne '..' &&
      ! -l "$startname/$filename" &&
      -d "$startname/$filename") {
      dircontents("$startname/$filename", $retval);
    } else {
      $retval->{"$startname/$filename"} = -s "$startname/$filename";
    }
  }

  closedir(DH);
  return %$retval;
}

sub printit {
  my ($ref, $count) = @_;
  my $key;
  my $counter = 0;

  foreach $key (sort keys %$ref) {
    print " " x ($count * 3);
      printf "%3d: %s (%d bytes)\n", $counter, $key, $ref->{$key};  
    $counter++;
  }
}
