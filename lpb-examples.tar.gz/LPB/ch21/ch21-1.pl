#!/usr/bin/perl -w

my $counter = 1;
while (my $line = <STDIN>) {
  chomp $line;
  print "Line $counter: $line\n";
  $counter++;
}
