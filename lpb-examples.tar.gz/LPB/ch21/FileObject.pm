package FileObject;

# Can be invoked with:
#   startfile
#   startfile, filename
#   serialform

sub new {
  my ($class, $startfile, $filename) = @_;
  my $self = {startfile => $startfile};
  bless($self, $class);

  if ($startfile =~ m'^///') {
    $self->deserialize($startfile);
  } elsif ($filename) {
    $self->populate($filename);
  }

  return $self;
}

sub populate {
  my ($self, $filename) = @_;

  $self->{size} = -s $self->{startfile} . "/$filename";
  $self->{age} = -M "$self->{startfile}/$filename";
  $self->{name} = $filename;
  if ($filename ne '.' &&
      $filename ne '..' &&
      ! -l "$self->{startfile}/$filename" &&
      -d "$self->{startfile}/$filename") {
    $self->{isdir} = 1;
  } else {
    $self->{isdir} = 0;
  }
}

sub deserialize {
  my ($self, $serialform) = @_;

  $serialform =~ s'^///'';

  ($self->{startfile},
   $self->{size},
   $self->{age},
   $self->{name},
   $self->{isdir}) = split('\|', $serialform);
}

sub serialize {
  my $self = shift @_;
 
  return "///" . join('|', $self->{startfile},
                           $self->{size},
                           $self->{age},
                           $self->{name},
                           $self->{isdir});
}

sub setsubdir {
  my ($self, $subdir) = @_;
 
  unless ($self->{isdir}) {
    die "Attempt to set subdirectory on non-directory!";
  }
 
  $self->{subdir} = $subdir;
}

sub display {
  my ($self, $level) = @_;
  $level = 0 unless $level;

  print " " x (3 * $level);
  printf "%s%s (%d bytes)\n",
         ($self->{isdir} ? "directory " : ""),
         "$self->{startfile}/$self->{name}",
         $self->{size};
}

1;
