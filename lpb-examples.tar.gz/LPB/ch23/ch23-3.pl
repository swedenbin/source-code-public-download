#!/usr/bin/perl -Tw

# Turn off output buffering.

$| = 1;

# Bring in the CGI library.

use CGI qw(:standard);

# Display errors if possible.

use CGI::Carp qw(fatalsToBrowser);

# Bring in databases and connect.

use DBI;
use DBD::Pg;

my $DBUSER = 'jgoerzen';
my $DBNAME = $DBUSER;

$dbh = DBI->connect("dbi:Pg:dbname=$DBNAME", $DBUSER, "") or die
  "Couldn't connect to database: " . DBI::errstr;
$dbh->{PrintError} = 0;        # Don't print errors.
$dbh->{RaiseError} = 1;        # Die on errors, and display to browser.

# Create a new CGI object.

my $q = new CGI;
my $NAME = $q->url(-relative => 1);

# Print the HTTP header.

print header;

# Select a default mode.

my $mode = "mode_" . ($q->param('mode') || 'start');

# Eliminate something invalid.

unless ($mode =~ /^mode_[a-zA-Z]+$/) {
  $mode = 'mode_error';
}

# Call the subroutine that handles that mode.

&$mode();

# End the HTML.

print end_html;
$dbh->disconnect;

### program exits here ###

sub mode_start {
  print start_html('Welcome to Address Book');

  # Display introductory text.
  print "Welcome to the address book!  With this application, you can\n";
  print "add entries to the address book and look up other entries.\n";
  print "There are currently <B>";

  # Find out the number of items in the database.
  # This is transformed to SELECT COUNT(*) FROM addresses
  print simplequeryval('COUNT (*)', 'addresses');

  print "</B> addresses in the database.\n<P>\n";
  print "Please select an action:";
 
  # Display the menu.

  print $q->startform(-method => 'POST');
  print $q->radio_group(-name => 'mode',
            -values => ['search', 'add', 'browse', 'modify'],
            -default => 'search',
            -linebreak => 1,
            -labels => {'search' => 'Search For Entries',
                'add' => 'Add a new entry',
                'browse' => 'Browse all entries',
                'modify' => 'Modify or delete an entry'}
            );
  print $q->submit('submit', 'Go');
  print $q->endform;
}

## This subroutine displays a list of all the entries in the database.

sub mode_browse {
  my $thisentry;

  print start_html('Address Book: Browse');

  print "Here are all the entries in the address book.  You may\n";
  print "read them here and go back to the <A HREF=\"$NAME";
  print "\">main menu</A> when done.\n<P><HR>\n";

  # Generate the query and perpare it.
 
  my $sth = $dbh->prepare("SELECT id, name, address1, address2, city,
                           fullname, zip FROM addresses, states
                           WHERE addresses.state = states.abbrev
                           ORDER BY name");
 
  $sth->execute();

  # Fetch each row and display it.  Add a line after each one.
  while ($thisentry = $sth->fetchrow_arrayref) {
    print EntryHTML($thisentry, 1);
    print "<HR>\n";
  }

  # Close the statement handle.

  $sth->finish();

  # Add a link back to the main menu.
 
  print "<A HREF=\"$NAME\">Back to main menu</A>\n";
}

# This subroutine is responsible for adding information into the database.

sub mode_add {
  # Implement this a unique way.  Add some dummy information to the
  # database and then re-call this in terms of a modify!  This saves
  # coding effort, since essentially it's the same task anyway.

  my $id = GenerateID();

  $dbh->do("INSERT INTO addresses VALUES ('$id',
            'Put New Name Here',
            'Address line 1',
            NULL,
            'New City',
            'NY',
            '00000')");

  # Shove the id into the CGI object.

  $q->param(-name => 'id', -value => $id);
 
  # Now go over to modify.

  return mode_modify();
}

# Handle the modifications to data.  Need to have an id; if none given,
# ask for one.

sub mode_modify {
  my $id = $q->param('id');
  my $entry;

  print $q->start_html('Address Book: Modify');

  # If there wasn't an id passed along....

  unless ($id) {
    print "Please enter the id of the record you want to modify.  If you\n";
    print "do not know the id, you should use one of the options from\n";
    print "the <A HREF=\"$NAME\">main menu</A> to retrieve records and\n";
    print "click on modify from there.\n<P>\n";
    print $q->startform(-method => 'POST');
    print $q->textfield(-name => 'id',
            -size => 40,
            -maxlength => 40);
    print $q->hidden(-name => 'mode', -value => 'modify');
    print $q->submit('submit', 'Go');
    print $q->endform;
    return;
  }
  # Load it up from the database.  This time, use the 2-character
  # state abbreviation instead of the expanded state name.

  @entry = queryrow("SELECT * FROM addresses WHERE id = '$id'");
  
  print "Here is your chance to make changes.  If you prefer to cancel\n";
  print "the operation, just <A HREF=\"$NAME\">return to the main menu</A>.\n";
  print "<P><HR>\n";

  # Display the original record for reference.

  print "Original record, id <TT>$id</TT>:<P>\n";
  print EntryHTML(\@entry, 0);
  print "<HR>New value: <P>\n";

  # Display the form for the new record.

  print $q->startform(-method => 'POST');
  print EntryHTML(\@entry, 0, 1);
  print $q->hidden(-name => 'mode', -value => 'modifySave', -override => 1);
  print $q->hidden(-name => 'id', -value => $id, -override => 1);
  print "<HR>";
  print $q->submit('submit', 'Change to above values');
  print "<BR>\n";
  print $q->submit('delete', 'Delete the above record');
  print $q->endform;
}
  

# This is called after somebody clicks a Submit button on the modify screen.
# Its responsibility is to issue either an update or a delete as appropriate.

sub mode_modifySave {
  print $q->start_html('Address Book: Saved Changes');
  my $id = $q->param('id');

  if ($q->param('delete')) {
    $dbh->do("DELETE FROM addresses WHERE id = '$id'");
    print "The requested record, with id of <TT>$id</TT>, has been\n";
    print "deleted.\n";
  } else {
    my $queryval = '';
    my $key;
    my $first = 1;

    # Generate the query.

    $queryval .= "UPDATE addresses set ";

    foreach $key ('name', 'address1', 'city', 'state', 'zip') {
      unless ($first) {
    $queryval .= ", ";
      }
      $first = 0;
      $queryval .= "\n $key = " . $dbh->quote($q->param($key));
    }

    if ($q->param('address2')) {
      $queryval .= ", \n address2 = " . $dbh->quote($q->param('address2'));
    } else {
      $queryval .= ", \n address2 = NULL";
    }

    $queryval .= "\n WHERE id = '$id'";
    $dbh->do($queryval);
    print "The requested change has been made.  The query used was:<P>\n";
    print "<PRE>\n";
    print $q->escapeHTML($queryval);
    print "</PRE>\n";
  }
  print "<HR>";
  print "Now go <A HREF=\"$NAME\">back to the main menu</A>.";
}

# This subroutine is used to implement a database search.

sub mode_search {
  print start_html("Address Book: Search");
  my $search = $q->param('search');

  unless ($search) {
    print "You can search through the database of addresses using this\n";
    print "screen.  Type your text below.  I'll search in all the fields\n";
    print "of the database and return any that contain a portion of the\n";
    print "text.  For states, you may use either the 2-letter abbreviation\n";
    print "or the full name.  These searches are case-sensitive.\n<P>\n";
    print "Search text:<BR>\n";
    print $q->startform;
    print $q->textfield(-name => 'search',
            -size => 40);
    print $q->hidden(-name => 'mode', -value => 'search', -override => 1);
    print $q->submit('submit', 'Search');
    print $q->endform;
    return;
  }

  print "<H1>Search Results</H1>\n";
  print "Here are the results for the search for: \n";

  print $q->escapeHTML($search), "\n<P><HR>\n";

  my $querystr = '';
  my $first = 1;
  my $key;
  my $thisentry;

  $querystr .= "SELECT id, name, address1, address2, city, fullname, zip\n";
  $querystr .= "FROM addresses, states\n";
  $querystr .= "WHERE addresses.state = states.abbrev AND (\n";
  foreach $key ('name', 'address1', 'address2', 'city',
        'state', 'fullname', 'zip') {
    unless ($first) {
      $querystr .= " OR\n";
    }
    $first = 0;
    $querystr .= "  $key LIKE " . $dbh->quote('%' . $search . '%') . " ";
  }

  $querystr .= "\n)\nORDER BY name";

  $sth = $dbh->prepare($querystr);
  $sth->execute();
  while ($thisentry = $sth->fetchrow_arrayref) {
    print EntryHTML($thisentry, 1);
    print "<HR>\n";
  }
 
  $sth->finish;

 
  print "My query was:<BR>\n";
  print "<PRE>\n";
  print $q->escapeHTML($querystr);
  print "</PRE>\n";
  print "<HR>Now go back to the <A HREF=\"$NAME\">main menu</A>.";
}
 

sub mode_error {
  print start_html('Error');

  print "I'm sorry, there was an error.  Please use your browser's back\n";
  print "button and retry the operation.\n";
}

# This subroutine displays HTML of a given entry.  Only the first argument
# is required.  The arguments are:
#
# $entry, a reference to an array that DBI might return
#
# $editlink, set to true if there should be a link to the modify page
# for this entry.
#
# $textfields, set to true if the result should be text entry fields
# instead of normal text, such as might be used for modification.
#
# The return value is a string to send to the Web browser.

sub EntryHTML {
  my ($entry, $editlink, $textfields) = @_;
  my $retval = '';

  # Print out the start of the table.
  $retval = "<TABLE><TR><TD><B>Name</B></TD>\n";

  # Name
  $retval .= "<TD>";
  if ($textfields) {
    $retval .= $q->textfield(-name => 'name',
            -default => $entry->[1],
            -override => 1,
            -size => 40);
  } else {
    $retval .= $entry->[1];
  }

  # If there's supposed to be an edit link, show it.
  if ($editlink) {
    # Decrease font size.  Add a bracket.  Start the URL.
    $retval .= " <FONT SIZE=-1>[<A HREF=\"$NAME?mode=modify&id=";

    # Insert a URL-escaped version of the id.
    $retval .= $q->escape($entry->[0]);

    # Close it out.
    $retval .= "\">modify</A>]</FONT>";
  }

  # Print the rest.
  $retval .= "</TD></TR>\n";
  $retval .= "<TR><TD><B>Address</B></TD><TD>";

  if ($textfields) {
    $retval .= $q->textfield(-name => 'address1',
            -default => $entry->[2],
               -override => 1,
                -size => 40);
  } else {
    $retval .= $entry->[2];
  }
  if ($textfields) {
    $retval .= "<BR>\n";
    my $newval = '';

    if ($entry->[3]) {
      $newval = $entry->[3];
    }

    $retval .= $q->textfield(-name => 'address2',
                 -default => $newval,
                -override => 1,
                -size => 40);
  } elsif ($entry->[3]) {
    # If it's a two-line address, combine them with a <BR>.
    $retval .= "<BR>$entry->[3]";
  }
  $retval .= "</TD></TR>\n";
  $retval .= "<TR><TD><B>City, State, Zip</B></TD><TD>";
  if ($textfields) {
    $retval .= $q->textfield(-name => 'city',
                -default => $entry->[4],
                -override => 1,
                -size => 20);
    $retval .= ", ";
    my @states = queryarr("SELECT abbrev FROM states ORDER BY abbrev");
    $retval .= $q->popup_menu('state',
                  \@states,
                  $entry->[5]);
    $retval .= " ";
    $retval .= $q->textfield(-name => 'zip',
                -default => $entry->[6],
                -override => 1,
                -size => 10);
  } else {
    $retval .= "$entry->[4], $entry->[5] $entry->[6]";
  }
  $retval .= "</TD></TR></TABLE>\n";
  return $retval;
}

# This subroutine is used to generate a unique ID.  It does this by
# getting the current time and tacking the current process ID onto
# its end, which should be unique.  Note that many databases have a
# much better way of doing this built in.  PostgreSQL, for instance,
# has a sequence that you can use.  Others have a "serial" designation
# for fields.  If your database has that, you should use it, but beware
# that it is not completely portable.  I chose this because it is
# portable.  $$ is the pid of the current process.

sub GenerateID {
  return time() . ";$$";
}

####################################################################
# Here are some database query functions.  They are around to
# make your life easier.  You can use them in your own programs, too;
# just copy them out of here.
####################################################################

# simplequeryval... a wrapper around queryval

sub simplequeryval {
  my ($colret, $table, $collookfor, $colmatch) = @_;
  my $querystr;

  $querystr = "SELECT $colret FROM $table";
  if ($colmatch) {
    $querystr .= " WHERE $collookfor = $colmatch";
  }

  return queryval($querystr);
}

# Takes a query and returns the single value from the single column
# that the query resulted in.  Useful for things like getting COUNT(*).

sub queryval {
  my ($query) = @_;
  my @retval = queryarr($query);
  return $retval[0];
}

# Takes a query and returns an array of all values in the single
# column that the query returns.

sub queryarr {
  my ($query) = @_;

  return querycolarr(0, $query);
}

# Takes a query for a select and returns an array of
# all the values in the indicated column.

sub querycolarr {
  my ($column, $query) = @_;
  my @retval = ();

  my $sth = $dbh->prepare($query);
  unless ($sth) {
    return @retval;
  }
 
  unless ($sth->execute) {
    return @retval;
  }

  my $result = $sth->fetch;

  while (defined($result)) {
    push @retval, $result->[$column];
    $result = $sth->fetch;
  }

  $sth->finish;

  return @retval;
}

# queryrow takes an arbitrary query and returns the returned row.

sub queryrow {
  my ($query) = @_;
  my @retval = ();

  my $sth = $dbh->prepare($query);
  $sth->execute;

  @retval = $sth->fetchrow;

  $sth->finish;
  return @retval;
}
