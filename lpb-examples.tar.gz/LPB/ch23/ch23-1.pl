#!/usr/bin/perl -w

use DBI;                # DBI library
use DBD::Pg;            # Postgres driver

my $DBUSER = $ENV{USER};
my $DBNAME = $DBUSER;

# Connect to the database.

my $dbh = DBI->connect("dbi:Pg:dbname=$DBNAME", "", "") or die
  "Couldn't connect to database: " . DBI::errstr;

# Loop to read from terminal.

my $input;
my $querystr = '';
printmessage();

while ($input = <STDIN>) {
  chomp $input;                # Strip off trailing CR
  $input =~ s/\s+$//g;         # Strip off other trailing whitespace
  if ($input =~ /;$/) {        # If ends with a semicolon...
    $input =~ s/;$//;          # Strip off the semicolon
    $querystr .= $input;       # Append to the query string
    runquery($querystr);       # Run the query
    $querystr = '';            # Reset querystring for next iteration
    printmessage();            # Print instructions
  } else {
    $querystr .= "$input ";    # Append to query string
  }
}

$dbh->disconnect;

sub printmessage {
  print <<EOF;

Enter your query here.  After each query, enter a semicolon at the end of the
last line or on a line by itself.  When you're finished with the program,
press Ctrl+D.

EOF
}

sub runquery {
  my $querystr = shift @_;
  my $rowcount;

  print "\n";

  my $sth = $dbh->prepare($querystr);
  unless ($sth) {
    print "Prepare FAILED: " . $dbh->errstr . "\n";
    return;
  }

  my $executeresult = $sth->execute();
  if (!$executeresult) {
    print "Execute FAILED: " . $dbh->errstr . "\n";
    return;
  }

  $executeresult = "unknown" if ($executeresult == -1);

  print "SUCCESS.\n";

  # If this was a query, display the results.

  if ($sth->{NUM_OF_FIELDS}) {
    print "Columns: ";
    print join(', ', @{$sth->{NAME}}), "\n";
    $rowcount = $sth->dump_results();
  }

  print "Number of rows returned or modified: ",
         ($rowcount) ? $rowcount : $executeresult, "\n";
}
