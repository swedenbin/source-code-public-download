#!/usr/bin/perl -w

use DBI;                # DBI library
use DBD::Pg;            # Postgres driver

my $DBUSER = $ENV{USER};
my $DBNAME = $DBUSER;

# Connect to the database.

my $dbh = DBI->connect("dbi:Pg:dbname=$DBNAME", "", "") or die
  "Couldn't connect to database: " . DBI::errstr;

$dbh->{PrintError} = 0;

CheckOrCreateTable("states",
                   "CREATE TABLE states (
                    abbrev char(2) NOT NULL PRIMARY KEY,
                    fullname text NOT NULL)");
CheckOrCreateTable("addresses",
                   "CREATE TABLE addresses (
                    id varchar(40) NOT NULL PRIMARY KEY,
                    name text NOT NULL,
                    address1 text NOT NULL,
                    address2 text,
                    city varchar(30) NOT NULL,
                    state char(2) NOT NULL,
                    zip varchar(10) NOT NULL)");

my ($input, $abbrev, $full);

print "Enter states, one per line, with the abbreviation followed by\n";
print "the full name.  Press Ctrl+D when done.\n\n";

while ($input = <STDIN>) {
  chomp $input;

  my ($abbrev, $full) = $input =~ /^(\w\w)\s+(.+)$/;
  $abbrev = uc $abbrev;

  InsertState($abbrev, $full);
}

sub CheckOrCreateTable {
  my ($table, $querystr) = @_;

  if ($dbh->do("SELECT * FROM $table WHERE 1 = 0")) {
    print "Table $table already exists; not recreating.\n";
  } else {
    print "Creating table $table\n";
    $dbh->do($querystr) or die
      "Couldn't create table: " . $dbh->errstr;
  }
}

sub InsertState {
  my ($abbrev, $fullname) = @_;

  print "Inserting: $abbrev => $fullname\n";

  my $result = $dbh->do("INSERT INTO states (abbrev, fullname)
                        VALUES ('$abbrev', '$fullname')");
 
  unless ($result) {
    warn "Insert failed: " . $dbh->errstr;
  }
}
