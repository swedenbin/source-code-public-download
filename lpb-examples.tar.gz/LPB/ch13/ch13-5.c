#include <stdio.h>
#include <signal.h>
#include <stdarg.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>

#if defined(__linux__) && !defined(SI_KERNEL)
#define SI_KERNEL 0x80
#endif


int tprintf(const char *fmt, ...);
void sighandler(int signum, siginfo_t *info, void *extra);
void continuehandler(int signum, siginfo_t *info, void *extra);
char buffer[200];

int main(void) {
  struct sigaction act;
  sigset_t blockset, pending;
  int pendingcount;

  /* Initialize buffer in case someone interrupts the program before
     assigning anything to it. */

  strcpy(buffer, "None\n");

  /* Set some values to apply to all the signals. */

  sigemptyset(&blockset);
  act.sa_mask = blockset;
  act.sa_flags = SA_SIGINFO;

  /* Two signals use the same handler. */
  act.sa_sigaction = &sighandler;
  if (sigaction(SIGTERM, &act, NULL) == -1) {
    tprintf("Couldn't register signal handler for SIGTERM.\n");
  }
  if (sigaction(SIGINT, &act, NULL) == -1) {
    tprintf("Couldn't register signal handler for SIGINT.\n");
  }

  /* A different handler for the third. */
  act.sa_sigaction = &continuehandler;
  if (sigaction(SIGCONT, &act, NULL) == -1) {
    tprintf("Couldn't register signal handler for SIGCONT.\n");
  }

  /* blockset is still the empty set. */

  sigaddset(&blockset, SIGTERM);
  sigaddset(&blockset, SIGINT);

  while (1) {
    sigprocmask(SIG_BLOCK, &blockset, NULL);
    fgets(buffer, sizeof(buffer), stdin);
    tprintf("Input: %s", buffer);

    /* Process pending signals. */

    sigpending(&pending);
    pendingcount = 0;
    if (sigismember(&pending, SIGINT)) pendingcount++;
    if (sigismember(&pending, SIGTERM)) pendingcount++;
    if (pendingcount) {
      tprintf("There are %d signals pending.\n", pendingcount);
    }

    /* Deliver them. */

    sigprocmask(SIG_UNBLOCK, &blockset, NULL);
  }
  return 0;
}

int tprintf(const char *fmt, ...) {
  va_list args;
  struct tm *tstruct;
  time_t tsec;
 
  tsec = time(NULL);
  tstruct = localtime(&tsec);
 
  printf("%02d:%02d:%02d %5d| ",
         tstruct->tm_hour,
         tstruct->tm_min,
         tstruct->tm_sec,
         getpid());
    
  va_start(args, fmt);
  return vprintf(fmt, args);
}

void sighandler(int signum, siginfo_t *info, void *extra) {
  tprintf("Caught signal %d from ", signum);
  switch (info->si_code) {
    case SI_USER: printf("a user process\n");
                  break;
    case SI_KERNEL: printf("the kernel\n");
                    break;
    default: printf("something strange\n");
  }
}

void continuehandler(int signum, siginfo_t *info, void *extra) {
  tprintf("Continuing.\n");
  tprintf("Your last input was: %s", buffer);
}
