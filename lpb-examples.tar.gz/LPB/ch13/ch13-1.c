#include <stdio.h>
#include <signal.h>
#include <stdarg.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>

int tprintf(const char *fmt, ...);
void sighandler(int signum);

int main(void) {
char buffer[200];

  if (signal(SIGTERM, &sighandler) == SIG_ERR) {
    tprintf("Couldn't register signal handler.\n");
  }

  while (1) {
    fgets(buffer, sizeof(buffer), stdin);
    tprintf("Input: %s", buffer);
  }
  return 0;
}

int tprintf(const char *fmt, ...) {
  va_list args;
  struct tm *tstruct;
  time_t tsec;
 
  tsec = time(NULL);
  tstruct = localtime(&tsec);
 
  printf("%02d:%02d:%02d %5d| ",
         tstruct->tm_hour,
         tstruct->tm_min,
         tstruct->tm_sec,
         getpid());
    
  va_start(args, fmt);
  return vprintf(fmt, args);
}

void sighandler(int signum) {
  tprintf("Caught signal SIGTERM.\n");
}
