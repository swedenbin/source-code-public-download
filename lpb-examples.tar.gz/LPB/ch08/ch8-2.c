#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void addstr(char *inputstring);

int main(void) {
  
  addstr("Hello");
  addstr("Goodbye");
  
  return 0;
}

void addstr(char *inputstring) {
  int counter;
  char printstring[5];
  
  strncpy(printstring, inputstring, sizeof(printstring));
  printstring[sizeof(printstring) - 1] = 0;
  
  for (counter = 0; counter < strlen(printstring); counter++) {
    printstring[counter] += 2;
  }

  printf("Result: %s\n", printstring);
}
