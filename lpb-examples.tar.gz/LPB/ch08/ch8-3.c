#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DATASIZE 10

typedef struct TAG_mydata {
  char thestring[DATASIZE];
  int iscontinuing;
  struct TAG_mydata *next;
} mydata;

mydata *append(mydata *start, char *input);
void displaydata(mydata *start);
void freedata(mydata *start);

int main(void) {
  char input[DATASIZE];
  mydata *start = NULL;
  
  printf("Enter some data, and press Ctrl+D when done.\n");
  
  while (fgets(input, sizeof(input), stdin)) {
    start = append(start, input);
  }
  
  displaydata(start);
  freedata(start);
  return 0;
}

mydata *append(mydata *start, char *input) {
  mydata *cur = start, *prev = NULL, *new;
  
  /* Search through until reach the end of the link, then add a new element. */
  
  while (cur) {
    prev = cur;
    cur = cur->next;
  }
  
  /* cur will be NULL now.  Back up one; prev is the last element. */
  
  cur = prev;
  
  /* Allocate some new space. */
  
  new = malloc(sizeof(mydata));
  if (!new) {
    fprintf(stderr, "Couldn't allocate memory, terminating\n");
    exit(255);
  }
  
  if (cur) {
    /* If there's already at least one element in the list, update its next
       pointer. */
    cur->next = new;
  } else {
    /* Otherwise, update start. */
    start = new;
  }
  
  /* Now, just set it to cur to make manipulations easier. */
  
  cur = new;
  
  /* Copy in the data. */
  
  strcpy(cur->thestring, input);
  
  /* If the string ends with \n or \r, it ends the line and thus
     the next struct does not continue. */
  
  cur->iscontinuing = !(input[strlen(input)-1] == '\n' ||
                  input[strlen(input)-1] == '\r');
  cur->next = NULL;
  
  /* Return start to the caller. */
  
  return start;
}

void displaydata(mydata *start) {
  mydata *cur;
  int linecounter = 0, structcounter = 0;
  int newline = 1;
  
  cur = start;
  while (cur) {
    if (newline) {
      printf("Line %d: ", ++linecounter);
    }
    structcounter++;
    printf("%s", cur->thestring);
    newline = !cur->iscontinuing;
    cur = cur->next;
  }
  printf("This data contained %d lines and was stored in %d structs.\n",
       linecounter, structcounter);
}

void freedata(mydata *start) {
  mydata *cur, *next = NULL;
  
  cur = start;
  while (cur) {
    next = cur->next;
    free(cur);
    cur = next;
  }
}
