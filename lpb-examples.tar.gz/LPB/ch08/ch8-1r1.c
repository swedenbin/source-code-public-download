#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char *addstr(char *inputstring);

int main(void) {
  char *str1, *str2;
  
  str1 = addstr("Hello");
  str2 = addstr("Goodbye");
  
  printf("str1 = %s, str2 = %s\n", str1, str2);
  free(str1);
  free(str2);
  return 0;
}

char *addstr(char *inputstring) {
  int counter;
  char *returnstring;

  returnstring = malloc(strlen(inputstring) + 1);
  if (!returnstring) {
    fprintf(stderr, "Error allocating memory; aborting!\n");
    exit(255);
  }
  strcpy(returnstring, inputstring);
  for (counter = 0; counter < strlen(returnstring); counter++) {
    returnstring[counter] += 2;
  }

  return returnstring;
}
