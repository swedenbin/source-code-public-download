#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DATASIZE 10

typedef struct TAG_mydata {
  char *thestring;
  struct TAG_mydata *next;
} mydata;

mydata *append(mydata *start, char *input, int newline);
void displaydata(mydata *start);
void freedata(mydata *start);

int main(void) {
  char input[DATASIZE];
  mydata *start = NULL;
  int newline = 1;
  
  printf("Enter some data, and press Ctrl+D when done.\n");
  
  while (fgets(input, sizeof(input), stdin)) {
    start = append(start, input, newline);
    newline = (input[strlen(input)-1] == '\n' ||
               input[strlen(input)-1] == '\r');
  }
  
  displaydata(start);
  freedata(start);
  return 0;
}

mydata *append(mydata *start, char *input, int newline) {
  mydata *cur = start, *prev = NULL, *new;
  
  /* Search through until reach the end of the link, then add a new
     element if necessary. */
  
  while (cur) {
    prev = cur;
    cur = cur->next;
  }
  
  /* cur will be NULL now.  Back up one; prev is the last element. */
  
  cur = prev;
  
  /* Allocate some new space, if necessary. */
  
  if (newline || !cur) {
    new = malloc(sizeof(mydata));
    if (!new) {
      fprintf(stderr, "Couldn't allocate memory, terminating\n");
      exit(255);
    }
  
    if (cur) {
      /* If there's already at least one element in the list, update its next
         pointer. */
      cur->next = new;
    } else {
      /* Otherwise, update start. */
      start = new;
    }
  
    /* Now, just set it to cur to make manipulations easier. */
  
    cur = new;
    cur->thestring = NULL;   /* Flag it for needing new allocation. */
  } /* (newline || !cur) */ 
  
  /* Copy in the data. */
  
  if (cur->thestring) {
    cur->thestring = realloc(cur->thestring,
                             strlen(cur->thestring) + strlen(input) + 1);
    if (!cur->thestring) {
      fprintf(stderr, "Error re-allocating memory, exiting!\n");
      exit(255);
    }
    strcat(cur->thestring, input);
  } else {
    cur->thestring = strdup(input);
    if (!cur->thestring) {
      fprintf(stderr, "Couldn't allocate space for the string; exiting!\n");
      exit(255);
    }
  }
  
  cur->next = NULL;
  
  /* Return start to the caller. */
  
  return start;
}

void displaydata(mydata *start) {
  mydata *cur;
  int linecounter = 0, structcounter = 0;
  
  cur = start;
  while (cur) {
    printf("Line %d: %s", ++linecounter, cur->thestring);
    structcounter++;
    cur = cur->next;
  }
  printf("This data contained %d lines and was stored in %d structs.\n",
         linecounter, structcounter);
}

void freedata(mydata *start) {
  mydata *cur, *next = NULL;
  
  cur = start;
  while (cur) {
    next = cur->next;
    free(cur->thestring);
    free(cur);
    cur = next;
  }
}
