#!/usr/bin/perl

$HEADER = 'Chapter 15 Example 5';

BEGIN { $Curses::OldCurses = 1; }
use Curses;
use perlmenu;

&menu_prefs(0, 0, 0, "", "n", 0, 1);

$window = &initscr();
&menu_curses_application($window);

# A few subs to automate curses access

sub cprintw {
    printw @_;
    refresh;
}

# Main program starts here

&scrheader;

cprintw "Loading data, please wait...";
&loaddata;
cprintw "\nDone.\n";

&mainmenu;
endwin();

sub scrheader {
    clear; refresh;
    attron(A_BOLD);
    cprintw "$HEADER\n\n";
    attroff(A_BOLD);
    refresh;
}

sub loaddata {
    cprintw "students...";
    &loaddata_students;
    cprintw "grades...";
    &loaddata_grades;
    cprintw "assignments...";
    &loaddata_assignments;
    cprintw "categories...";
    &loaddata_categories;
}

sub loaddata_students {
    open SFILE, "<students" or die "Couldn't open students file";
    foreach (<SFILE>) {
       chomp;
       ($id, $name) = /(.+?)[\s;:]+(.*)/;
       $students{$id} = $name;
    }
}

sub loaddata_grades {
    open GFILE, "<grades" or return;
    foreach (<GFILE>) {
        chomp;
        ($id, $name) = /(.+?)[\s;:]+(.*)/;
        $grades{$id} = $name;
    }
}

sub loaddata_categories {
    $catnum = 0;
    open CFILE, "<categories" or die "Couldn't open categories file";

    foreach (<CFILE>) {
        chomp;
        ($catnam, $pcat) = /(.+?)[;:](.+)/;
        $catlist[$catnum] = $catnam;
        $catprint{$catnam} = $pcat;
        $catnum++;
    }
}

sub loaddata_assignments {
    $anum = 0;
    open AFILE, "<assignments" or die "Couldn't open assignments file";
    foreach (<AFILE>) {
        chomp;
        ($c, $a, $p) = /(.+?)[\s;:](.+?)[;:]+(.*)/;
        $categories[$anum] = $c;
        $assignments[$anum] = $a;
        $possible[$anum] = $p;
        $anum++;
    }
}

sub mainmenu {
    while (1) {
        &menu_init(1, "Main Menu", 0, "$HEADER", "Press q to quit");
        &menu_quit_routine("endwin");
        &menu_item("Add grades", "add");
        &menu_item("View/Modify grades", "view");
        &menu_item("Generate report", "report");
        $choice = &menu_display("");

        SWITCH: {
           if ($choice eq "add") {
               &assignmenu(1);
               last SWITCH;
        }
        if ($choice eq "view") {
               &usermenu(1);
               last SWITCH;
        }
        if ($choice eq "report") {
               &scrheader;
               cprintw("Report generator not in this sample.\n\n");
               cprintw "Press Enter to continue.\n";
               <STDIN>;
               last SWITCH;
        }
      }
    }
}


# argument:
#    1 if should call usermenu; 0 otherwise.

sub assignmenu{
    my $adefault = 0;
while (1) {
    if ($_[0] == 0) {
       &parsegrades;         # Make sure grades for menu are current
    }
    &menu_init(1, "Select assignment", 0,
         ($_[0]) ? "(Add Grades)" :
                   "User: $students{$curstudent} ($curstudent)");
    for ($i = 0; $i < $anum; $i++) {
       if ($_[0]) {          # Selecting before user
           &menu_item(sprintf("%-35s %-3s possible",
                             $assignments[$i],
                             $possible[$i]), $i);
       } else {                 # Selecting AFTER user
           &menu_item(sprintf("%-35s %-3s of %-3s",
                             $assignments[$i],
                             $curgrades[$i],
                             $possible[$i]), $i);
       }
    }
    my $topline = 0;
    if ($adefault > 0) {
        $topline = 1;
        $adefault--;
    }
    $curassign = &menu_display("", $topline, $adefault);
    if ($curassign eq "%UP%") { return; }
    $adefault = $curassign + 1;
    if ($adefault >= ($anum)) { $adefault = 0; }

    if ($_[0]) {
        &usermenu(0);
    } else {
        &parsegrades;
        &setgrade;
    }
 }                # while (1)
}

# argument:
#    a. 1 if should call assignmenu; 0 otherwise.

sub usermenu {
    my $udefault = 0;
    my $z = 0;
    while (1) {   
        &menu_init(1, "Select a user", 0,
                   (! $_[0]) ? "Assignment: $assignments[$curassign]"
                             : "(View/Modify)");
        $z = 0;
        foreach (sort keys %students) {
           if ($_[0] == 0) {
               $curstudent = $_;
               &parsegrades;
               $_ = $curstudent;
               &menu_item(sprintf("%-15s %-30s %-3s of %-3s",
                                  $_,
                                  $students{$_},
                                  $curgrades[$curassign],
                                  $possible[$curassign]), "$_:$z");
           } else {
               &menu_item(sprintf("%-15s %s",$_,$students{$_}), "$_:$z");
           }
           $z++;
        }
        my $topline = 0;
        if ($udefault > 0) {
            $topline = 1;
            $udefault--;
        }
        $curstudent = &menu_display("", $topline, $udefault);
        if ($curstudent eq "%UP%") {
            return;
        }

        ($curstudent, $udefault) = $curstudent =~ /(.+?):(.+)/;

        # Find the proper setting for udefault

        $udefault++;          # Add 1
        if ($udefault >= (scalar(keys %students))) {
            $udefault = 0;
        }
   
        &parsegrades;
        if ($_[0]) {
             &assignmenu(0);
        } else {
             &setgrade;
        }
    }
}

# Sets the grade

sub setgrade {
    &scrheader;

    cprintw("Id: $curstudent\n");
    cprintw("Student: $students{$curstudent}\n");
    cprintw("Assignment: $curassign, $assignments[$curassign];$possible[$curassign] possible\n\n");
    cprintw("Current grade: $curgrades[$curassign]\n");
    cprintw("New grade: ");
   
    my $foo;
    getstr($foo);
    $curgrades[$curassign] = $foo;
    chomp $curgrades[$curassign];
    &setgrades;
    &writegrades;
}

# Generate a curgrades array with this student's current grades

sub parsegrades {
    @curgrades = $grades{$curstudent} =~ m/(\d*),/g;
}

# Convert the curgrades array back to the comma-delimited format

sub setgrades {
    $grade = "";

    for ($i = 0; $i < $anum; $i++) {
        $grade .= "$curgrades[$i],";
    }

    $grades{$curstudent} = $grade;
}

# Write the grades file

sub writegrades {
    open GFILE, ">grades" or die "Couldn't write to grades file";
    foreach (sort keys %students) {
         print(GFILE sprintf("%-8s %s\n", $_, $grades{$_}));
    }
    close GFILE;
}
