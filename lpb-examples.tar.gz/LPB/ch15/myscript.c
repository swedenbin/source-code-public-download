#include <pty.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/ioctl.h>
#include "safecalls.h"

int masterfd, output, execpid, childpid;
struct termios origsettings;


void slave(void);
void master(void);
void master_frompty(void);
void master_topty(void);
int write_buffer(int fd, const void *buf, int count);
void catchchildren(int signum);


int main(void) {
  struct winsize size;

  tcgetattr(0, &origsettings);
  ioctl(0, TIOCGWINSZ, (void *) &size);

  output = safeopen2("mytypescript", O_CREAT | O_WRONLY | O_TRUNC, 0600);
 
  execpid = forkpty(&masterfd, NULL, &origsettings, &size);

  switch (execpid) {
    case 0: slave(); break;
    case -1: HandleError(errno, "forkpty", "failure"); break;
    default: master(); break;
  }
  return 0;
}

/* Here is the process to handle the slave side.  The slave PTY has
   already been set to be the controlling terminal, so all that's left
   to do is exec. */

void slave(void) {
  printf("Starting process, use exit to return...\n");
  if (execl("/bin/sh", "/bin/sh", NULL) == -1) {
    HandleError(errno, "execl", "failure to exec /bin/sh");
  }
}

/* Master needs to set it up to copy in two directions: from stdin to
   the pty and from the pty to stdout and the file. */

void master(void) {
  childpid = fork();
  if (childpid == -1) {
    HandleError(errno, "fork", "failed to fork second child");
    return;
  }

  if (childpid == 0) {
    master_frompty();
    return;
  }

  /* Set up signal handlers to exit and kill off other process if any
     one of the other processes dies. */
 
  signal(SIGCHLD, &catchchildren);

  master_topty();
}

void master_frompty(void) {
  char buffer[2000];
  ssize_t size;

  while ((size = read(masterfd, buffer, sizeof(buffer))) > 0) {
    write_buffer(output, buffer, size);
    write_buffer(1, buffer, size);
  }
}

void master_topty(void) {
  char buffer[2000];
  ssize_t size;
  struct termios newt;

  newt.c_iflag &= ~(ICRNL | INPCK | ISTRIP | IXON | BRKINT | IXOFF | IXANY |
                    INLCR | IGNBRK);
  newt.c_oflag &= ~OPOST;
  newt.c_lflag &= ~(ECHO | ICANON | NOFLSH | ISIG | IEXTEN);
  newt.c_cflag |= CS8;
  newt.c_cflag &= ~CSIZE;

  newt.c_cc[VMIN] = 1;
  newt.c_cc[VTIME] = 0;

  tcsetattr(0, TCSANOW, &newt);

  while ((size = read(0, buffer, sizeof(buffer))) > 0) {
    write_buffer(masterfd, buffer, size);
  }
}

int write_buffer(int fd, const void *buf, int count) {
  const void *pts = buf;
  int  status = 0, n;
 
  if (count < 0) return (-1);
 
  while (status != count) {
    n = safewrite(fd, pts+status, count-status);
    if (n < 0) return (n);
    status += n;
  }
  return (status);
}

void catchchildren(int signum) {
  kill(execpid, SIGTERM);
  kill(childpid, SIGTERM);
  tcsetattr(0, TCSANOW, &origsettings);
  printf("Process exited; back to normal!\n");
  exit(0);
}
