#include <termios.h>
#include <unistd.h>
#include <stdio.h>

int main(void) {
  int input;

  struct termios save, current;

  tcgetattr(0, &save);
  current = save;
 
  current.c_lflag &= ~ICANON;
  current.c_lflag &= ~ECHO;

  current.c_cc[VMIN] = 1;
  current.c_cc[VTIME] = 0;

  tcsetattr(0, TCSANOW, &current);

  printf("Enter some text, Q to stop.\n");
  while ((input = getc(stdin)) != 'Q') {
    printf("You typed: %c\n", input);
  }

  tcsetattr(0, TCSANOW, &save);

  printf("Terminal values back to default.\n");
  printf("Try some text again, Q to stop.\n");
  while ((input = getc(stdin)) != 'Q') {
    printf("You typed: %c\n", input);
  }

  return 0;

}
