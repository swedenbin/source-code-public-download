#include <curses.h>

void doexit(int exitcode);

int main(void) {
  initscr(); cbreak(); noecho();
  start_color();
  clear();
  if (!has_colors()) {
    printw("I'm sorry, but your terminal does not allow color changes.\n");
    doexit(255);
  }

  init_pair(1, COLOR_RED, COLOR_BLACK);
  attrset(COLOR_PAIR(1));
  printw("Here's something in a nice red.  Maybe useful for a warning\n");
  printw("message.\n\n");
  attrset(COLOR_PAIR(1) | A_BOLD);
  printw("Notice how you can get bright colors by adding the A_BOLD\n");
  printw("attribute.\n\n");
  init_pair(2, COLOR_WHITE, COLOR_BLUE);
  attrset(COLOR_PAIR(2));
  printw("Here's white on blue.\n");
  attrset(COLOR_PAIR(2) | A_BOLD);
  printw("And this is a lighter white on blue.\n\n");

  init_pair(3, COLOR_YELLOW, COLOR_BLACK);
  attrset(COLOR_PAIR(3));
  printw("Notice that the \"dark\" yellow appears brown on some terminals.\n");
  attrset(COLOR_PAIR(3) | A_BOLD);
  printw("But it becomes yellow when the bright version is used.\n\n");
  attrset(COLOR_PAIR(0));
  printw("Press any key to watch what happens when a pair is redefined.\n");
  refresh();
  getch();
  init_pair(1, COLOR_GREEN, COLOR_BLACK);
  attrset(COLOR_PAIR(1));
  printw("Notice the existing text printed to the screen with this\n");
  printw("pair is not modified, but this new text has the new color.\n");
 
  attrset(A_NORMAL);
  printw("You can use A_NORMAL or COLOR_PAIR(0) to return to\n");
  printw("the terminal's default color.\n\n");

  doexit(0);
  return 0;            /* to suppress warning */
}

void doexit(int exitcode) {
  printw("Press any key to exit.\n");
  refresh();
  cbreak();
  noecho();
  getch();
  endwin();
  exit(exitcode);
}
