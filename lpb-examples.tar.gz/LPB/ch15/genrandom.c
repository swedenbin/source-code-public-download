/*  
   genrandom will create a text file with the following specifications:
    * The first line will contain the number of integers
    * Each following line will contain a randomly generated integer,
      up to the number of integers specified on the first line
*/

#include <stdio.h>
#include <sys/time.h>
#include <limits.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
unsigned long num, counter;
FILE *outfile;
int seed;
  if (argc < 2) {
    printf("Syntax: genrandom filename\n");
    printf("It will write the numbers to the filename passed, and the\n");
    printf("line will contain the number of integers written.\n");
    exit(255);
  }
  printf("Enter number of lines to create: ");
  scanf("%lu", &num);
  outfile = fopen(argv[1], "wt");
  if (!outfile) exit(255);
  fprintf(outfile, "%lu\n", num);
  seed = (int)(time(NULL) / (ULONG_MAX / INT_MAX));
  printf("Using seed %d\n", seed);
  srandom(seed);
  for (counter = 1; counter <= num; counter++) {
    fprintf(outfile, "%d\n", (int)(random() / (LONG_MAX / INT_MAX)));
    if (!(counter % 10000))        /* printf is S L O W when dealing
                           with thousands of calls */
      printf("Wrote %lu of %lu numbers, %d%%\r", counter, num, (int)(100 * counter / num));
  }
  fclose(outfile);
  printf("\n");                /* Add terminating newline */
  return 0;
}
