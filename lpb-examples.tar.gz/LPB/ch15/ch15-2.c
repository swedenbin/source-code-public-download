/* Include some standard stuff... */

#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <malloc.h>
#include <limits.h>
#include <stdlib.h>
#include <memory.h>
#include <signal.h>

/* Curses is used for interactive operation */

#include <curses.h>

/* Standard macros */

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef NULL
#define NULL 0
#endif

/* Type used for the array */

typedef int typearray;

/* Defines for type of array in memory */
#define ARRAYTYPE_NONE 0
#define ARRAYTYPE_UNSORTED 1
#define ARRAYTYPE_SORTED 2

/* Defines for type of sort */
#define INSERTIONSORT 1
#define MERGESORT 2
#define HEAPSORT 3

/* Some global information */

int isinteratvive = TRUE;               /* True if running interactively */
typearray* globalarray = NULL;          /* Main array, used for sorting */
unsigned long arraysize = 0;            /* Size of main array....This is
                                           stored in a very big number so
                                           that very large arrays can be
                                           accommodated. */
time_t start = 0;                       /* Start time, in seconds */
int is_firstline_size = TRUE;           /* True if the first line of file
                                           is number of elements in the
                                           file */
int arraytype = ARRAYTYPE_NONE;         /* Type of array in memory */
char defoutput[80];                     /* Default output file/viewer */
char definput[80];                      /* Default input file */
int sorttype = HEAPSORT;

/* Function prototypes */
void mainmenu(void);
void readitin(void);
void reset(void);
void toggleint(int *togglevar, int min, int max);
void runsort(void);
     void insertionsort(void);
     void mergesort(unsigned long first, unsigned long last);
     void heapsort(void);
void writeoutput(void);
     void changeviewer(void);
void checkvalidity(void);
void setinputfile(void);
void mergesort_merge(unsigned long first, unsigned long last);
void heapsort_buildheap(unsigned long heapsize);
void heapsort_heapify(unsigned long node);
void heapsort_heapsort(unsigned long node);
void heapsort_swap(unsigned long index1, unsigned long index2);

int main(void) {
 
  /* Curses may cause program to die with SIGSEGV or other signal if the
     TERM variable is incorrectly set.  This is due to a bug in some versions
     of curses.  The above message will appear only for an instant if
     curses works correctly because the screen will be cleared with a curses
     call. */
 
  initscr(); cbreak(); clear(); refresh();      /* Set up curses */
  printw("\n Notes on operation:\n");
  printw(" * If you are using a file in which the first line denotes the\n");
  printw("   number of elements in the file, and thus should *not* be\n");
  printw("   included in any sort, you will need to select option 3 before\n");
  printw("   doing anything else.\n\n");
  printw(" * Put license/copyright thing here perhaps.\n\n");
  printw("Press any key to continue.");
  refresh();
  getch();
  clear();
                     /* Do some initialization */
  strcpy(defoutput, "|less");
  strcpy(definput, "INPUTINT.TXT");
  sigblock(sigmask(SIGPIPE));    /* Ignore the SIGPIPE signal --
                                    Otherwise program would terminate
                                    if user ends the viewer before
                                    all data had been sent through
                                    the pipe */
 
 
  mainmenu();
  endwin();                      /* End curses */
  if (globalarray) free(globalarray);  /* If the array is still allocated,
                                          free it. */

  return 0;
}

void mainmenu(void)
{
int selection = 0;
int maxy, maxx;

  getmaxyx(stdscr, maxy, maxx); 
  do {
    clear();
    move(maxy - 1, 0);
    attron(A_REVERSE);
    printw("  Sometimes a status bar goes here.  ");
    attroff(A_REVERSE);
    move(0, 0);
    printw("Main Menu\n");
    printw("0. Exit program\n");
    switch (arraytype) {
      case ARRAYTYPE_NONE:
        printw("1. Load data into memory [no data in memory]\n");
        break;
      case ARRAYTYPE_UNSORTED:
        printw("1. Reload data [data loaded and unsorted]\n");
        break;
      case ARRAYTYPE_SORTED:
        printw("1. Reload data [data loaded and sorted]\n");
        break;
    }
    switch (arraytype) {
      case ARRAYTYPE_NONE: printw("   Cannot sort (no data loaded into memory)\n"); break;
      case ARRAYTYPE_UNSORTED: printw("2. Sort the array\n"); break;
      case ARRAYTYPE_SORTED: printw("   No sort necessary (data already sorted)\n"); break;
    }
    printw("3. Toggle method of determining size of array to hold data\n");
    printw("   Current: ");
    if (is_firstline_size)
      printw("[First line of input denotes size of data]\n");
    else
      printw("[Count lines in file before sorting]\n");
    if (arraytype)
      printw("4. View or output sorted data\n");
    else
      printw("   There must be data in memory before it can be viewed.\n");
    printw("5. Change output file or viewer [%s]\n", defoutput);
    if (arraytype == ARRAYTYPE_SORTED)
      printw("6. Check validity of sorted array\n");
    else
      printw("   Array not yet sorted; validity test unavailable.\n");
    printw("7. Set type of sort: ");
    switch (sorttype) {
      case INSERTIONSORT: printw("[insertion sort]\n"); break;
      case MERGESORT: printw("[merge sort]\n"); break;
      case HEAPSORT: printw("[heap sort]\n"); break;
    }
    printw("8. Set input filename [%s]\n", definput);
    refresh();
    noecho();                       /* Turn off echo */
    selection = getch();
    echo();
    switch (selection) {
      case '1':                       /* Load data into memory */
                if (arraytype) reset();           /* Reset if data in memory */
                readitin();
                arraytype = ARRAYTYPE_UNSORTED;
                break;
      case '2': if (arraytype == ARRAYTYPE_UNSORTED) runsort(); break;
      case '3': toggleint(&is_firstline_size, 0, 1); break;
      case '4': if (arraytype) writeoutput(); break;
      case '5': changeviewer(); break;
      case '6': if (arraytype == ARRAYTYPE_SORTED) checkvalidity(); break;
      case '7': toggleint(&sorttype, INSERTIONSORT, HEAPSORT); break;
      case '8': setinputfile(); break;
    }
                    /* Other cases either exit program
                       or are ignored */
  } while (selection != '0');
}

void readitin(void)
{
unsigned long counter;
FILE *infile;
int tempbuffer, fscanfresult;
  arraysize = 0;
  clear();
  infile = fopen(definput, "rt");
  if (!infile) {
    printw("Error opening input file %s.  Data not read.\n", definput);
    printw("Press any key...");
    refresh();
    getch();
    return;
  }
  printw("Reading data...\n"); refresh();
  if (!is_firstline_size) {
    printw("Counting lines:\n");
    infile = fopen(definput, "rt");
    while (!feof(infile)) {
      if ((!feof(infile)) && (fscanf(infile, "%d", &tempbuffer))) arraysize++;
      if (!(arraysize % 10000)) {  /* It goes faster if screen not updated
                                      for every single line...here it is updated
                                      every 10000 lines */
        printw("Got %lu lines\r", arraysize);
        refresh();
      }
    }
    arraysize--;                   /* The above code, using fscanf, always
                                      will yield one greater than the actual
                                      size due to a quirk in fscanf.  Here
                                      this is compensated for. */
   
    rewind(infile);                /* Reset to the beginning */
    clearerr(infile);
  } else                           /* First line denotes size */
    if (!fscanf(infile, "%lu", &arraysize)) arraysize = 0;
  if (arraysize)
    printw("There are %lu integers in the data file.\n", arraysize);
  else {
    printw("Empty or corrupted data file, read failed.\n");
    printw("Press any key...\n");
    refresh();
    getch();
    fclose(infile);
    return;
  }
  refresh();
  /* Now allocate the array in dynamic memory */
  globalarray = calloc(arraysize, sizeof(typearray));
  if (!globalarray) {
    printw("Could not allocate memory.  Press any key to continue.\n");
    refresh();
    getch();
    fclose(infile);
    return;
  }
   
  for (counter = 0; counter < arraysize; counter++) {
    if (!(counter % 10000)) {
      printw("Read %lu of %lu elements, %d percent done\r",
              counter, arraysize, (int)(100 * counter / arraysize));
      refresh();
    }
    do
      fscanfresult = fscanf(infile, "%d", globalarray + counter);
    while (!fscanfresult && !feof(infile));
    if (feof(infile)) {
      printw("Unexpected end of file, read aborted.  Memory freed.\n");
      printw("Counter = %d\n", counter);
      printw("Press any key.\n");
      refresh();
      free(globalarray);
      globalarray = NULL;
      getch();
      return;
    }
  }
 
  arraytype = ARRAYTYPE_UNSORTED;
}

void reset(void)               /* Reset state of program */
{
  if (globalarray) {
    free(globalarray);
    globalarray = NULL;
  }
  arraytype = ARRAYTYPE_NONE;
  arraysize = 0;
}

void toggleint(int *togglevar, int min, int max)
{
  if (++*togglevar > max) *togglevar = min;
}


void runsort(void)
{
  clear();
  start = time(NULL);
  printw("Running sort: ");
  switch (sorttype) {
    case INSERTIONSORT: printw("insertion sort....\n"); refresh();
                        insertionsort(); break;
    case MERGESORT: printw("merge sort...\n"); refresh();
                    mergesort(0, arraysize-1); break;
    case HEAPSORT: printw("heap sort...\n"); refresh(); heapsort(); break;
  }
  arraytype = ARRAYTYPE_SORTED;
  printw("Elapsed time was: %lu seconds\n", time(NULL) - start);
  printw("Please note: Other processes on a multi-tasking operating system\n");
  printw("may have an effect on the amount of time a given sort takes.\n");
  printw("\nPress any key to continue.");
  refresh();
  getch();
}

void insertionsort(void)
{
register unsigned long x, y;
int temp_holder;

  for (x = 1; x < arraysize; x++) {
    temp_holder = *(globalarray + x);
    y = x;
    while (y > 0 && temp_holder < *(globalarray + y - 1)) {
      *(globalarray + y) = *(globalarray + y - 1);
      y--;
    }
    *(globalarray + y) = temp_holder;
  }
}

void mergesort(unsigned long first, unsigned long last)
{
    /* the 1 is added to the value because, for instance, if you
       have an array with 2 elements, first is 0, last is 1,
       then last - first = 1, but space is really needed for 2.
    */
unsigned long mid;
  if (first < last) {         /* If they're the same, don't bother */
    mid = (first + last) / 2;
    mergesort(first, mid);
    mergesort(mid+1, last);
    mergesort_merge(first, last);
  }
}

void mergesort_merge(unsigned long first, unsigned long last)
{
typearray *temparray = calloc(last - first + 1, sizeof(typearray));
unsigned long mid = (first + last) / 2;
unsigned long position = 0, left = first, right = mid + 1;

  if (!temparray) {
    printw("FATAL ERROR IN mergesort(): COULD NOT ALLOCATE ENOUGH MEMORY\n");
    printw("FOR TEMPORARY ARRAY.  ABORTING.\n");
    refresh();
    exit(255);
  }
 
  while ((left <= mid) && (right <= last))    /* Run the loop as long
                                                 as both left and right
                                                 portions of the array
                                                 contain data */
    if (*(globalarray + left) < *(globalarray + right))
      *(temparray + position++) = *(globalarray + left++);
    else
      *(temparray + position++) = *(globalarray + right++);
     
  /* Now copy any remaining elements into temparray */
 
  /* Because of the "&&" above, only one of the below will execute. */
 
  while (left <= mid)
    *(temparray + position++) = *(globalarray + left++);
  while (right <= last)
    *(temparray + position++) = *(globalarray + right++);
 
  /* Now copy temparray back into globalarray */
 
  memcpy(globalarray + first, temparray,
         (last - first + 1) * sizeof(typearray));
        
  /* And free the memory used by temparray */
 
  free(temparray);

}

/* Variables for heapsort funtions */

unsigned long heapsize;

void heapsort(void)
{
  heapsize = arraysize;           /* Initialize it */
  printw("heapsort: building the heap\n");
  refresh();
  heapsort_buildheap(heapsize);
  printw("heapsort: sorting the heap\n");
  refresh();
  heapsort_heapsort(heapsize);
}

void heapsort_buildheap(unsigned long heapsize)
{
unsigned long node;

  /* Because an unsigned item is used here, the heapify function has to
     be called once later....because node should never go below 0 */

  for (node = heapsize / 2; node > 0; node--)
    heapsort_heapify(node);
  heapsort_heapify(0);
}

void heapsort_heapify (unsigned long node)
{
unsigned long left = (node + 1) * 2 - 1,
              right = (node + 1) * 2,
              largest;     /* Index of largest */

  if ((left < heapsize) &&
      (*(globalarray + left) > *(globalarray + node)))
    largest = left;
  else
    largest = node;
   
  if ((right < heapsize) &&
      (*(globalarray + right) > *(globalarray + largest)))
    largest = right;
 
  if (largest != node) {
    heapsort_swap(node, largest);
    heapsort_heapify(largest);
  }
 
}
   

void heapsort_heapsort(unsigned long node)
{

unsigned long i;

  for (i = node - 1; i >= 1; --i) {
    heapsort_swap(0, i);
    --heapsize;
    heapsort_heapify(0);
  }
}

void heapsort_swap(unsigned long index1, unsigned long index2)
{
typearray tempholder;
  tempholder = *(globalarray + index1);
  *(globalarray + index1) = *(globalarray + index2);
  *(globalarray + index2) = tempholder;
}

void writeoutput(void)
{
FILE *outfile;
int ispipe = FALSE;
unsigned long counter;
  if (defoutput[0] != '|')
    outfile = fopen(defoutput, "wt");
  else {
    clear(); refresh();        /* Clear the screen before piping */
    outfile = popen(defoutput + 1, "w");
    ispipe = TRUE;
  }
  if (!outfile) {
    printw("Error opening output file!  Press any key to continue...\n");
    refresh();
    getch();
    return;
  }
  for (counter = 0; counter < arraysize; counter++) {
    if (fprintf(outfile, "%d\n", *(globalarray + counter)) == EOF) {
      clear();
      if (ispipe) {            /* Viewer/program exited early */
        printw("Pipe closed before all data could be sent.\n");
        pclose(outfile);
      } else {                 /* Some sort of disk error */
        printw("Error writing data to file!\n");
        fclose(outfile);
      }
      printw("Press any key.\n");
      refresh();
      getch();
      return;
    }
  }
  if (ispipe) pclose(outfile);
    else fclose(outfile);
  clear();
  printw("Write/view successful.\n");
  printw("Press any key...\n");
  refresh();
  getch();
}

void changeviewer(void)
{
  clear();
  printw("Here you can set the file to write output to, or a viewer to use.\n");
  printw("To write the output to a file, just enter the filename.  To pipe\n");
  printw("the output to a program, use the pipe character (|) followed by\n");
  printw("the command line to use to invoke the program.  For instance, to\n");
  printw("use the less file viewer, type in \"|less\" (w/o the quotes).\n");
  printw("Enter your selection: ");
  refresh();
  nocbreak();              /* Re-enables things like backspace! */
  getstr(defoutput);
  cbreak();                /* Back to "raw" mode for curses */
}

void checkvalidity(void)
{
unsigned long counter;
int last = INT_MIN;        /* Init to lowest possible value */
  clear();
  printw("Performing check on sorted data to ensure it is correctly sorted.\n");
  for (counter = 0; counter < arraysize; counter++) {
    if (*(globalarray + counter) < last)
      printw("Item %lu (%d) less than item %lu (%d)\n",
             counter, *(globalarray + counter),
             counter - 1, *(globalarray + counter - 1));
    else
      if (counter % 10000 == 0) {
        printw("Item %lu OK\r", counter);
        refresh();
      }
    last = *(globalarray + counter);        /* Reset it for next time */
  }
  printw("Scan finished.  Problems in sorted data, if any, are shown above.\n");
  printw("If no problems are shown above, sorted data has been sorted\n");
  printw("correctly.\n\n");
  printw("Press any key to continue.\n");
  refresh();
  getch();
}

void setinputfile(void)
{
  clear();
  printw("Input filename: ");
  refresh();
  nocbreak(); getstr(definput); cbreak();
}
