#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>

int tprintf(const char *fmt, ...);

int main(void) {
  pid_t pid;
  
  pid = fork();
  
  if (pid == 0) {
    tprintf("Hello from the child process!\n");
    tprintf("The child is exiting now.\n");
  } else if (pid != -1) {
    tprintf("Hello from the parent, pid %d.\n", getpid());
    tprintf("The parent has forked process %d.\n", pid);
    waitpid(pid, NULL, 0);
    tprintf("The child has stopped.  Sleeping for 60 seconds.\n");
    sleep(60);
    tprintf("The parent is exiting now.\n");
  } else {
    tprintf("There was an error with forking.\n");
  }
  return 0;
}

int tprintf(const char *fmt, ...) {
  va_list args;
  struct tm *tstruct;
  time_t tsec;
  
  tsec = time(NULL);
  tstruct = localtime(&tsec);
  
  printf("%02d:%02d:%02d %5d| ",
         tstruct->tm_hour,
         tstruct->tm_min,
         tstruct->tm_sec,
         getpid());
       
  va_start(args, fmt);
  return vprintf(fmt, args);
}
