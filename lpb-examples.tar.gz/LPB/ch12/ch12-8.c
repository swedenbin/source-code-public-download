#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>

int tprintf(const char *fmt, ...);
void enhancedperms(void);
void normalperms(void);
void tryopen(void);

int ruid, euid;

int main(void) {

  /* FIRST THING: save of uid values and IMMEDIATELY ditch extra permissions.
   */

  ruid = getuid();
  euid = geteuid();
  normalperms();

  /* If the two values were equal, the program wasn't set setuid in the
     filesystem (or was just run by root in the first place).  */

  if (ruid == euid) {
    tprintf("Warning: This program wasn't marked setuid in the filesystem\n");
    tprintf("or you are running the program as root.\n");
  }

  tryopen();
  enhancedperms();
  tryopen();
  normalperms();
  
  tprintf("Exiting now.\n");
  return 0;
}

int tprintf(const char *fmt, ...) {
  va_list args;
  struct tm *tstruct;
  time_t tsec;
  
  tsec = time(NULL);
  tstruct = localtime(&tsec);
  
  printf("%02d:%02d:%02d %5d| ",
         tstruct->tm_hour,
         tstruct->tm_min,
         tstruct->tm_sec,
         geteuid());
       
  va_start(args, fmt);
  return vprintf(fmt, args);
}

void enhancedperms(void) {
  if (seteuid(euid) == -1) {
    tprintf("Failed to switch to enhanced permissions: %s\n",
        sys_errlist[errno]);
    exit(255);
  } else {
    tprintf("Switched to enhanced permissions.\n");
  }
}

void normalperms(void) {
  if (seteuid(ruid) == -1) {
    tprintf("Failed to switch to normal permissions: %s\n",
        sys_errlist[errno]);
    exit(255);
  } else {
    tprintf("Switched to normal permissions.\n");
  }
}

void tryopen(void) {
  char *filename = "/etc/shadow";
  int result;

  result = open(filename, O_RDONLY);
  if (result == -1) {
    tprintf("Open failed: %s\n", sys_errlist[errno]);
  } else {
    tprintf("Open was successful.\n");
    close(result);
  }
}
