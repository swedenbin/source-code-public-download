#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main(void) {
  pid_t pid;
  
  pid = fork();
  
  if (pid == 0) {
    printf("Hello from the child process!\n");
    printf("The child is exiting now.\n");
  } else if (pid != -1) {
    printf("Hello from the parent, pid %d.\n", getpid());
    printf("The parent has forked process %d.\n", pid);
    sleep(60);
    printf("The parent is exiting now.\n");
  } else {
    printf("There was an error with forking.\n");
  }
}
