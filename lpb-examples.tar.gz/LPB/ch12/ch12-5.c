#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

int tprintf(const char *fmt, ...);
void realsleep(int seconds);
void waitchildren(int signum);

int main(void) {
  pid_t pid;
  
  pid = fork();
  
  if (pid == 0) {
    tprintf("Hello from the child process!\n");
    tprintf("The child is sleeping for 15 seconds.\n");
    realsleep(15);
    tprintf("The child is exiting now.\n");
  } else if (pid != -1) {
    /* Set up the signal handler. */
    signal(SIGCHLD, (void *)waitchildren);

    tprintf("Hello from the parent, pid %d.\n", getpid());
    tprintf("The parent has forked process %d.\n", pid);
    tprintf("The parent is sleeping for 30 seconds.\n");
    realsleep(30);
    tprintf("The parent is exiting now.\n");
  } else {
    tprintf("There was an error with forking.\n");
  }
  return 0;
}

int tprintf(const char *fmt, ...) {
  va_list args;
  struct tm *tstruct;
  time_t tsec;
  
  tsec = time(NULL);
  tstruct = localtime(&tsec);
  
  printf("%02d:%02d:%02d %5d| ",
         tstruct->tm_hour,
         tstruct->tm_min,
         tstruct->tm_sec,
         getpid());
       
  va_start(args, fmt);
  return vprintf(fmt, args);
}

void waitchildren(int signum) {
  pid_t pid;

  while ((pid = waitpid(-1, NULL, WNOHANG)) > 0) {
    tprintf("Caught the exit of child process %d.\n", pid);
  }
}

void realsleep(int seconds) {
  while (seconds) {
    seconds = sleep(seconds);
    if (seconds) {
      tprintf("Restarting interrupted sleep for %d more seconds.\n", seconds);
    }
  }
}
