#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

int tprintf(const char *fmt, ...);
void waitchildren(int signum);

int main(void) {
  pid_t pid;
  int status;
  
  pid = fork();
  
  if (pid == 0) {
    tprintf("Hello from the child process!\n");
    setenv("PS1", "CHILD \\$ ", 1);
    tprintf("I'm calling exec.\n");
    execl("/bin/sh", "/bin/sh", NULL);
    tprintf("You should never see this because the child is already gone.\n");
  } else if (pid != -1) {

    tprintf("Hello from the parent, pid %d.\n", getpid());
    tprintf("The parent has forked process %d.\n", pid);
    tprintf("The parent is waiting for the child to exit.\n");
    waitpid(pid, &status, 0);
    tprintf("The child has exited.\n");
    if (WIFEXITED(status)) {
      tprintf("The child exited normally with code %d.\n",
          WEXITSTATUS(status));
    }
    if (WIFSIGNALED(status)) {
      tprintf("The child exited because of signal %d.\n",
          WTERMSIG(status));
    }
    tprintf("The parent is exiting.\n");
  } else {
    tprintf("There was an error with forking.\n");
  }
  return 0;
}

int tprintf(const char *fmt, ...) {
  va_list args;
  struct tm *tstruct;
  time_t tsec;
  
  tsec = time(NULL);
  tstruct = localtime(&tsec);
  
  printf("%02d:%02d:%02d %5d| ",
       tstruct->tm_hour,
       tstruct->tm_min,
       tstruct->tm_sec,
       getpid());
       
  va_start(args, fmt);
  return vprintf(fmt, args);
}
