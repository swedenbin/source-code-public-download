#!/usr/bin/perl -w

my $subref = sub {
  my $arg = shift @_;
  print "Hello, I am an anonymous sub ($arg)!\n"
};

&$subref("really");
