#!/usr/bin/perl -w

print "Enter a filename: ";
$filename = <STDIN>;
chomp $filename;

open OUTFILE, ">$filename" or
  die "Couldn't open output file: $!";

print "Enter a number: ";
$number = <STDIN>;
print OUTFILE $number * 3, "\n";

close OUTFILE;
