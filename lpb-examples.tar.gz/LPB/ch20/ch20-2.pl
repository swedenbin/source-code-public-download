#!/usr/bin/perl -w

while ($inputline = readinput()) {
  ($key, $value) = $inputline =~ /^([^=]+)=(.+)$/;
  if ($key && $value) {
    $hash{$key} = $value;
  } else {
    print "Bad input, try again.\n";
  }
}

foreach $key (sort keys %hash) {
  print "$key is set to the value $hash{$key}\n";
}

sub readinput {
  print "Enter a key=value pair, or type END when done: ";
  $input = <STDIN>;
  return undef unless $input;
  chomp $input;

  return undef if $input =~ /^END$/i;

  return $input;
}
