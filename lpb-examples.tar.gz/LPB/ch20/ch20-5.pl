#!/usr/bin/perl -w

$arrayref = [1, 3, [500, 600, 700], 8, 9, [1000, 1100, [2000, 2100] ], 10];

printit($arrayref, 0);

sub printit {
  my ($ref, $count) = @_;
  my $key;
  my $counter = 0;

  foreach $key (@$ref) {
    print " " x ($count * 3);
    if (ref $key) {
      printf "%3d: nested array:\n", $counter;
      printit($key, $count + 1);
    } else {
      printf "%3d: %d\n", $counter, $key;
    }
    $counter++;
  }
}
   
print "\n\$arrayref->[5][2][0] = $arrayref->[5][2][0]\n";
