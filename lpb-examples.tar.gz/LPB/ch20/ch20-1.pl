#!/usr/bin/perl -w

@input = <STDIN>;

$counter = 0;

foreach $key (sort @input) {
  chomp $key;
  $counter++;
  print "Line $counter: \"$key\"\n";
}
