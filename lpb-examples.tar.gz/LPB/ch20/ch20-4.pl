#!/usr/bin/perl -w

$scalarref = \"Hi";
$arrayref = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
$hashref = {key1 => 1, key2 => 2, key3 => 3};

print "$$scalarref\n";

foreach $key (@$arrayref) {
  print "Array: $key\n";
}

foreach $key (sort keys %$hashref) {
  print "Hash: $key = $hashref->{$key}\n";
}
