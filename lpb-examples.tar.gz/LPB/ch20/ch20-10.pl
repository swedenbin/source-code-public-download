#!/usr/bin/perl -w

require FileObject;

# Perl's unless is an inverse if.  That is, unless(a) is the same as
# if (!(a)).

unless ($ARGV[0]) {
  die "Must specify a directory."
}

# -d is a Perl shorthand.  It does a stat() on the passed filename, and
# then looks at the mode.  If the filename is a directory, it returns true;
# if not, it returns false.

unless (-d $ARGV[0]) {
  die "The filename supplied was not a directory."
}

my $dirs = dircontents($ARGV[0]);
printit($dirs, 0);

sub dircontents{
  my $startname = shift @_;
  my $filename;
  my $retval = {};          # Initialize with an empty hash reference
  local *DH;                # Ensure that the handle is locally scoped

# This is the same as DH = opendir("filename") in C.
# In C, you can use DIR *DH; to declare the variable.

  unless(opendir(DH, $startname)) {
    warn "Couldn't open directory $startname: $!";
    return undef;
  }

  # In C, readdir() returns a pointer to struct dirent, whose members are
  # defined in readdir(3).  In Perl, returns one file in scalar context,
  # or all remaining filenames in list context.

  while ($filename = readdir(DH)) {
    my $object = new FileObject($startname);
    $object->populate($filename);
    if ($object->{isdir}) {
      $object->setsubdir(dircontents("$startname/$filename"));
    }
    $retval->{$filename} = $object;
  }

  closedir(DH);
  return $retval;
}

sub printit {
  my ($ref, $count) = @_;
  my $key;

  foreach $key (sort keys %$ref) {
    $ref->{$key}->display($count);
    if ($ref->{$key}->{isdir}) {
      printit($ref->{$key}->{subdir}, $count + 1)
    }
  }
}
