#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <stdarg.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#include "safecalls.h"

void parent(char *argv[]);
void child(char *argv[]);
int write_buffer(int fd, const void *buf, int count);
int read_buffer(int fd, void *buf, int count);
int readnlstring(int socket, char *buf, int maxlen);
int readdelimstring(int socket, char *buf, int maxlen, char delim);
int tprintf(const char *fmt, ...);
pid_t safefork(void);

int main(int argc, char *argv[]) {

  if (argc < 2)
    parent(argv);
  else
    child(argv);

  return 0;
}


void parent(char *argv[]) {
  char buffer[100];
  int fd;
  /* Close standard input.  Don't need it. */

  close(0);

  /* Create the FIFO and open it. */

  if (mkfifo("ch17-fifo", 0600) == -1)
    HandleError(errno, "mkfifo", "failed to create ch17-fifo");

  tprintf("The server is listening on ch17-fifo.\n");

  /* This will block until someone else connects to write. */

  fd = safeopen("ch17-fifo", O_RDONLY);
 
  tprintf("Client has connected.\n");

  /* Now wait for data, and display it. */

  while (readnlstring(fd, buffer, sizeof(buffer)) >= 0) {
    tprintf("Received message: %s\n", buffer);
  }
  tprintf("No more data; parent exiting.\n");
  safeclose(fd);
 
  /* Delete the FIFO. */

  unlink("ch17-fifo");
}

void child(char *argv[]) {
  int fd;
  char buffer[100];

  fd = safeopen(argv[1], O_WRONLY);
 
  tprintf("The client is ready.  Enter messages, or Ctrl+D when done.\n");
 
  while (fgets(buffer, sizeof(buffer), stdin) != NULL) {
    write_buffer(fd, buffer, strlen(buffer));
  }
  tprintf("Client exiting.\n");
  safeclose(fd);

}

/*
   This function writes a certain number of bytes from "buf" to a file
   or socket descriptor specified by "fd". The number of bytes is
   specified by "count". It returns the number of bytes written,
   or <0 on error.
*/

int write_buffer(int fd, const void *buf, int count) {
  const void *pts = buf;
  int  status = 0, n;
 
  if (count < 0) return (-1);
 
  while (status != count) {
    n = safewrite(fd, pts+status, count-status);
    if (n < 0) return (n);
    status += n;
  }
  return (status);
}

int read_buffer(int fd, void *buf, int count) {
  void *pts = buf;
  int  status = 0, n;
 
  if (count < 0) return (-1);
 
  while (status != count) {
    n = saferead(fd, pts+status, count-status);
    if (n < 1) return n;
    status += n;
  }
  return (status);
}

int readnlstring(int socket, char *buf, int maxlen) {
  return readdelimstring(socket, buf, maxlen, '\n');
}

int readdelimstring(int socket, char *buf, int maxlen, char delim) {
  int status;
  int count = 0;

  while (count < maxlen - 1) {
    if ((status = read_buffer(socket, buf+count, 1)) < 1) {
      return -1;
    }
    if (buf[count] == delim) {          /* Found the delimiter */
      buf[count] = 0;
      return 0;
    }
    count++;
  }
  buf[count] = 0;
  return 0;
}

int tprintf(const char *fmt, ...) {
  va_list args;
  struct tm *tstruct;
  time_t tsec;
 
  tsec = time(NULL);
  tstruct = localtime(&tsec);
 
  printf("%02d:%02d:%02d %5d| ",
         tstruct->tm_hour,
         tstruct->tm_min,
         tstruct->tm_sec,
         getpid());
        
  va_start(args, fmt);
  return vprintf(fmt, args);
}

pid_t safefork(void) {
  pid_t retval;

  retval = fork();
  if (retval == -1)
    HandleError(errno, "fork", "failed");
  return retval;
}
