#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <stdarg.h>
#include <time.h>
#include <string.h>

#include "safecalls.h"

#define FD_READ 0
#define FD_WRITE 1

void parent(int pipefds[2]);
void child(int pipefds[2]);
int write_buffer(int fd, const void *buf, int count);
int read_buffer(int fd, void *buf, int count);
int readnlstring(int socket, char *buf, int maxlen);
int readdelimstring(int socket, char *buf, int maxlen, char delim);
int tprintf(const char *fmt, ...);
pid_t safefork(void);

int main(void) {
  int pipefds[2];

  safepipe(pipefds);
  if (safefork())
    parent(pipefds);
  else
    child(pipefds);
 
  return 0;
}

void parent(int pipefds[2]) {
  char buffer[100];
  /* First, close the descriptors that the parent doesn't need.
     Since the parent will not be reading from the terminal -- only
     the child will -- close off standard input as well. */

  close(pipefds[FD_WRITE]);
  close(0);

  tprintf("The parent is ready.\n");

  /* Now wait for data, and display it. */

  while (read_buffer(pipefds[FD_READ], buffer, 1) > 0) {
    if (buffer[0] == 'E') {
      tprintf("Received exit code from child.\n");
      break;
    }
    if (buffer[0] == 'M') {
      readnlstring(pipefds[FD_READ], buffer, sizeof(buffer));
      tprintf("Received message: %s\n", buffer);
    } else {
      tprintf("Received unknown action code.\n");
    }
  }
  tprintf("Parent exiting.\n");
  safeclose(pipefds[FD_READ]);
}

void child(int pipefds[2]) {
  char buffer[100];

  /* First, close the descriptor that the child doesn't need. */

  close(pipefds[FD_READ]);
 
  tprintf("The child is ready.  Enter messages, or Ctrl+D when done.\n");
 
  while (fgets(buffer, sizeof(buffer), stdin) != NULL) {
    /* Send a message code and then the message. */
    write_buffer(pipefds[FD_WRITE], "M", 1);
    write_buffer(pipefds[FD_WRITE], buffer, strlen(buffer));
  }
  write_buffer(pipefds[FD_WRITE], "E", 1);
  tprintf("Client exiting.\n");
  safeclose(pipefds[FD_WRITE]);
}

/*
   This function writes certain number bytes from "buf" to a file
   or socket descriptor specified by "fd". The number of bytes is
   specified by "count". It returns the number of bytes written,
   or <0 on error.
*/

int write_buffer(int fd, const void *buf, int count) {
  const void *pts = buf;
  int  status = 0, n;
 
  if (count < 0) return (-1);
 
  while (status != count) {
    n = safewrite(fd, pts+status, count-status);
    if (n < 0) return (n);
    status += n;
  }
  return (status);
}

int read_buffer(int fd, void *buf, int count) {
  void *pts = buf;
  int  status = 0, n;
 
  if (count < 0) return (-1);
 
  while (status != count) {
    n = saferead(fd, pts+status, count-status);
    if (n < 1) return n;
    status += n;
  }
  return (status);
}

int readnlstring(int socket, char *buf, int maxlen) {
  return readdelimstring(socket, buf, maxlen, '\n');
}

int readdelimstring(int socket, char *buf, int maxlen, char delim) {
  int status;
  int count = 0;

  while (count < maxlen - 1) {
    if ((status = read_buffer(socket, buf+count, 1)) < 1) {
      printf("Error reading: EOF in readdelimstring()\n");
      return -1;
    }
    if (buf[count] == delim) {          /* Found the delimiter */
      buf[count] = 0;
      return 0;
    }
    count++;
  }
  buf[count] = 0;
  return 0;
}

int tprintf(const char *fmt, ...) {
  va_list args;
  struct tm *tstruct;
  time_t tsec;
 
  tsec = time(NULL);
  tstruct = localtime(&tsec);
 
  printf("%02d:%02d:%02d %5d| ",
         tstruct->tm_hour,
         tstruct->tm_min,
         tstruct->tm_sec,
         getpid());
        
  va_start(args, fmt);
  return vprintf(fmt, args);
}

pid_t safefork(void) {
  pid_t retval;

  retval = fork();
  if (retval == -1)
    HandleError(errno, "fork", "failed");
  return retval;
}
