#include <gnome.h>

void exitbutton(void);

GnomeUIInfo FileMenu[] = {
  GNOMEUIINFO_MENU_EXIT_ITEM(exitbutton, NULL),
  GNOMEUIINFO_END
};

GnomeUIInfo MainMenu[] = {
  GNOMEUIINFO_MENU_FILE_TREE(FileMenu),
  GNOMEUIINFO_END
};


int main(int argc, char *argv[]) {
  GtkWidget *window, *frame;
  
  gnome_init("ch25-3", "1.0", argc, argv);

  /* Create the window. */
  window = gnome_app_new("ch25-1", "Hi!");
  gnome_app_create_menus_with_data(GNOME_APP(window), MainMenu, window);
  frame = gtk_frame_new(NULL);
  gnome_app_set_contents(GNOME_APP(window), frame);

  gtk_container_add(GTK_CONTAINER(frame), gtk_color_selection_new());

  
  gtk_widget_show_all(window);
 
  gtk_main();

  return 0;
}
     
void exitbutton(void) {
  static int displayed = 0;
  GtkWidget *appwindow, *top, *button, *blabel, *frame;

  if (displayed) return;    /* Don't display twice. */
  displayed++;

  appwindow = gnome_app_new("ch25-3", "Goodbye");
  frame = gtk_frame_new(NULL);
  gnome_app_set_contents(GNOME_APP(appwindow), frame);
  top = gtk_packer_new();
  gtk_container_add(GTK_CONTAINER(frame), top);

  /* Now the label. */

  gtk_packer_add_defaults(GTK_PACKER(top),
                          gtk_label_new("You are now leaving the"
                                        "demonstration program."),
                          GTK_SIDE_TOP, GTK_ANCHOR_CENTER, 0);

  /* And the button.  Pack the label explicitly though. */

  gtk_packer_add_defaults(GTK_PACKER(top),
                          button = gtk_button_new(),
                          GTK_SIDE_TOP, GTK_ANCHOR_CENTER, 0);

  blabel = gtk_label_new("OK");
  gtk_container_add(GTK_CONTAINER(button), blabel);

  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(gtk_main_quit), NULL);
  gtk_signal_connect(GTK_OBJECT(appwindow), "delete_event",
                     GTK_SIGNAL_FUNC(gtk_main_quit), NULL);

  gtk_widget_show_all(appwindow);
}
