#include <gnome.h>

void exitbutton(void);

int main(int argc, char *argv[]) {
  GtkWidget *window, *frame, *pack, *label, *button;
  
  gnome_init("ch25-1", "1.0", argc, argv);

  /* Create the window. */
  window = gnome_app_new("ch25-2", "Hi!");
  frame = gtk_frame_new(NULL);
  gnome_app_set_contents(GNOME_APP(window), frame);

  /* Create the widget packer. */

  pack = gtk_packer_new();
  gtk_container_add(GTK_CONTAINER(frame), pack);
  
  /* The main label. */

  label = gtk_label_new("Hello from Gnome!");
  gtk_packer_add_defaults(GTK_PACKER(pack), label, GTK_SIDE_TOP,
                          GTK_ANCHOR_CENTER,
                          0);

  /* The button. */

  button = gtk_button_new_with_label("Exit");
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(exitbutton), NULL);
  gtk_packer_add_defaults(GTK_PACKER(pack), button, GTK_SIDE_TOP,
                          GTK_ANCHOR_CENTER, 0);

  gtk_signal_connect(GTK_OBJECT(window), "delete_event",
                     GTK_SIGNAL_FUNC(exitbutton), NULL);

  gtk_widget_show_all(window);
 
  gtk_main();

  return 0;
}
     
void exitbutton(void) {
  static int displayed = 0;
  GtkWidget *appwindow, *top, *button, *blabel, *frame;

  if (displayed) return;    /* Don't display twice. */
    displayed++;

  appwindow = gnome_app_new("ch25-2", "Goodbye");
  frame = gtk_frame_new(NULL);
  gnome_app_set_contents(GNOME_APP(appwindow), frame);
  top = gtk_packer_new();
  gtk_container_add(GTK_CONTAINER(frame), top);

  /* Now the label. */

  gtk_packer_add_defaults(GTK_PACKER(top),
              gtk_label_new("You are now leaving the"
                            "demonstration program."),
              GTK_SIDE_TOP, GTK_ANCHOR_CENTER, 0);

  /* And the button.  Pack the label explicitly though. */

  gtk_packer_add_defaults(GTK_PACKER(top),
                          button = gtk_button_new(),
                          GTK_SIDE_TOP, GTK_ANCHOR_CENTER, 0);

  blabel = gtk_label_new("OK");
  gtk_container_add(GTK_CONTAINER(button), blabel);

  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(gtk_main_quit), NULL);
  gtk_signal_connect(GTK_OBJECT(appwindow), "delete_event",
                     GTK_SIGNAL_FUNC(gtk_main_quit), NULL);

  gtk_widget_show_all(appwindow);
}
