#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <errno.h>
#include <arpa/inet.h>
#include "safecalls.h"

#define PROTOCOL "tcp"
#define REQUEST "GET / HTTP/1.0\n\n"

int write_buffer(int fd, const void *buf, int count);

int main(int argc, char *argv[]) {
  int sockid;
  struct servent *serviceaddr;
  struct hostent *hostaddr;
  struct protoent *protocol;
  struct sockaddr_in socketaddr;
  char buffer[1024];
  int count;
 
  /******** Step 1: resolve names and generate the socket structure. */

  /* First, initialize the socketaddr. */
  bzero((char *) &socketaddr, sizeof(socketaddr));
  socketaddr.sin_family = AF_INET;

  /* Resolve the service name. */

  serviceaddr = getservbyname(argv[2], PROTOCOL);
  if (!serviceaddr) {
    HandleError(0, "getservbyname", "service resolution failed");
  }
  socketaddr.sin_port = serviceaddr->s_port;

  /* Resolve the host name. */

  hostaddr = gethostbyname(argv[1]);
  if (!hostaddr) {
    HandleError(0, "gethostbyname", "host resolution failed");
  }

  memcpy(&socketaddr.sin_addr, hostaddr->h_addr, hostaddr->h_length);

  /* Resolve the protocol name. */

  protocol = getprotobyname(PROTOCOL);
  if (!protocol) {
    HandleError(0, "getprotobyname", "protocol resolution failed");
  }
  /* Note: using SOCK_STREAM below since this is only TCP. */

  /********* Step 2: Create the socket for this end. */

  sockid = socket(PF_INET, SOCK_STREAM, protocol->p_proto);
  if (sockid < 0) {
    HandleError(errno, "socket", "couldn't create socket");
  }

  /********* Step 3: Connect the socket to the server.  (Almost done!) */

  if (connect(sockid, &socketaddr, sizeof(socketaddr)) < 0) {
    HandleError(errno, "connect", "connect call failed");
  }

  /********************************************************************/

  /* The channel for communication to the server has now been established.
     Now, request the document at the server root. */

  write_buffer(sockid, REQUEST, strlen(REQUEST));

  /* Request has been sent.  Read the result. */

  while ((count = saferead(sockid, buffer, sizeof(buffer) - 1))) {
    write_buffer(1, buffer, count);
  }

  return 0;
}

int write_buffer(int fd, const void *buf, int count) {
  const void *pts = buf;
  int  status = 0, n;
 
  if (count < 0) return (-1);
 
  while (status != count) {
    n = safewrite(fd, pts+status, count-status);
    if (n < 0) return (n);
    status += n;
  }
  return (status);
}
