#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <errno.h>
#include "safecalls.h"
#include "networkinglib.h"

#define PROTOCOL "tcp"
#define SERVICE "7797"
#define WELCOME "You have connected to the counting server.  Welcome!\n"

void waitchildren(int signum);
pid_t safefork(void);

static int connectioncount = 0;

int main(void) {
  int mastersock, workersock;
  struct sigaction act;
  struct sockaddr_in socketaddr;
  int addrlen;
  char buffer[1024];
  char size[100];

  /* Initialize the signal handler. */

  sigemptyset(&act.sa_mask);
  act.sa_flags = SA_RESTART;
  act.sa_handler = (void *)waitchildren;
  sigaction(SIGCHLD, &act, NULL);
 
  mastersock = serverinit(SERVICE, PROTOCOL);

  printf("The server is active.  You may terminate it with Ctrl-C.\n");

  while (1) {
    addrlen = sizeof(socketaddr);
    workersock = accept(mastersock, &socketaddr, &addrlen);
    if (workersock < 0) {
      HandleError(errno, "accept", "couldn't open worker socket");
    }

    connectioncount++;

    if (safefork ()) {               /* parent process */
      safeclose(workersock);         /* don't need this socket for the parent */
      printf("Received connection from a client at ");
      printf("%s port %d\n", inet_ntoa(socketaddr.sin_addr),
             ntohs(socketaddr.sin_port));
      printf("There are %d clients active.\n", connectioncount);
    } else {                         /* child process */
      safeclose(mastersock);
      write_buffer(workersock, WELCOME, strlen(WELCOME));
     
      while(readnlstring(workersock, buffer, sizeof(buffer)) >= 0) {
        sprintf(size, "Size: %d\n", strlen(buffer) - 1);
        write_buffer(workersock, size, strlen(size));
        if (strncmp(buffer, "exit", 4) == 0) break;
      }

      safeclose(workersock);
      exit(0);
    }
  }
     
  printf("Shutting down.\n");

  safeclose(mastersock);
 
  return 0;
}

void waitchildren(int signum) {
  while (wait3((int *)NULL,
               WNOHANG,
               (struct rusage *)NULL) > 0) {
    connectioncount--;
    printf("A client disconnected.\n");
    printf("There are %d clients active.\n", connectioncount);
  }
}

pid_t safefork(void) {
  int retval;

  retval = fork();

  if (retval == -1) {
    HandleError(errno, "fork", "fork failed");
  }
  return retval;
}
