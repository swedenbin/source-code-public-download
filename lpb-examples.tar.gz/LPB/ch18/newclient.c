#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <errno.h>
#include <arpa/inet.h>
#include "safecalls.h"
#include "networkinglib.h"

#define PROTOCOL "tcp"
#define REQUEST "GET / HTTP/1.0\n\n"

int main(int argc, char *argv[]) {
  int sockid;

  sockid = clientconnect(argv[1], argv[2], "tcp");

  /* The channel for communication to the server has now been established.
     Now, request the document at the server root. */

  write_buffer(sockid, REQUEST, strlen(REQUEST));

  /* Request has been sent.  Read the result. */

  copy(sockid, 1, 0);

  return 0;
}
