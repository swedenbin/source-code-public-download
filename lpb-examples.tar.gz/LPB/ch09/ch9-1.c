#include <stdio.h>
#include <errno.h>

/* The next four are for system-call I/O */

#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include "safecalls.h"
#include "safecalls2.h"

int write_buffer(int fd, const void *buf, int count);

int main(void) {
  int outfile;

  /* Open the file */

  outfile = safeopen2("test.dat", O_RDWR | O_CREAT | O_TRUNC, 0640);

  safelseek(1, 10000, SEEK_SET);
  return 0;
}
