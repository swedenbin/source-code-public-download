/* John Goerzen

   This module contains wrappers around a number of system calls and
   library functions so that a default error behavior can be defined.

*/

#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include "safecalls.h"
#include "safecalls2.h"
#include "errno.h"

off_t safelseek(int fildes, off_t offset, int whence) {
  off_t retval;

  retval = lseek(fildes, offset, whence);
  if (retval == (off_t) -1)
    HandleError(errno, "lseek", "failed");
  return retval;
}

int safefseek(FILE *stream, long offset, int whence) {
  int retval;

  retval = fseek(stream, offset, whence);
  if (retval == -1) 
    HandleError(errno, "fseek", "failed");
  return retval;
}
