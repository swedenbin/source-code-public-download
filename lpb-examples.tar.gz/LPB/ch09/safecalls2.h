/* John Goerzen
 */

#ifndef __SAFECALLS2_H__
#define __SAFECALLS2_H__

#include <stdio.h>        /* required for FILE * stuff */
#include <sys/types.h>
#include <signal.h>

off_t safelseek(int fildes, off_t offset, int whence);
int safefseek(FILE *stream, long offset, int whence);

#endif
