#include <dlfcn.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

#include "safecalls.h"
#include "safecalls2.h"

/* Declare a wrapper around lseek. */

off_t lseek(int fildes, off_t offset, int whence) {
  /* A pointer to the "real" lseek function.  Static so it only
     has to be filled in once.*/

  static off_t (*funcptr)(int, off_t, int) = NULL;
  
  if (!funcptr) {
    funcptr = (off_t (*)(int, off_t, int)) dlsym(RTLD_NEXT, "lseek");
  }

  if (fildes == 1) {        /* Error condition is occuring */
    fprintf(stderr, "Hey!  I've trapped an attempt to lseek on fd 1.  I'm\n");
    fprintf(stderr, "returning you a fake success indicator.\n");
    return offset;
  } else {            /* Otherwise, pass it through. */
    fprintf(stderr, "OK, passing your lseek through.\n");
    return (*funcptr)(fildes, offset, whence);
  }
}

/* And one around safeopen2, just for kicks. */

int safeopen2(const char *pathname, int flags, mode_t mode) {
  static int (*funcptr)(const char *, int, mode_t) = NULL;

  if (!funcptr) {
    funcptr = (int (*)(const char *, int, mode_t)) dlsym(RTLD_NEXT,
                             "safeopen2");
  }

  fprintf(stderr, "I'm passing along a safeopen2() call now.\n");
  return (*funcptr)(pathname, flags, mode);
}
