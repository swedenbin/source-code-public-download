extern int someglobal;

int computer(void) {
 return 5 * someglobal;
}
