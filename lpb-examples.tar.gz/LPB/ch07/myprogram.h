int computer(void);
int foo(void);
