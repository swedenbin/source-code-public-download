#include <stdio.h>
#include "myprogram.h"

int foo(void) {
 printf("The value is: %d.\n", computer());
 return 1;
}
