#include <stdio.h>
#include "myprogram.h"

int someglobal = 11;

int main(void) {
 foo();
 return 0;
}
