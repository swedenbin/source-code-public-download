#include <string.h>
#include <stdlib.h>
#include "safecalls.h"
#include "queue.h"

static struct qtype *qstart = NULL;
static struct qtype *qend = NULL;

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

/* enq() is the heart of the queue system.  It accepts a pointer to a string
that contains null-terminated raw data that arrived over the network
connection.  It splits the data up into individual commands, and queues them.
*/

int addtoqueue(int id, char *data) {
  struct qtype *item;
  int iscompleted = 0;
  char *substring = data, *endloc = data;
  char *newdata = NULL;               /* To hold new data */

  while ((endloc = strstr(substring, "\n"))) {
    /* While there are still newlines to process... */
    iscompleted = 1;
    *(endloc) = 0;
    item = findincomplete(id);
    if (item->data) {
      /* We are finishing data for this item. */
      newdata = safemalloc(strlen(item->data) + strlen(substring) + 2);
      if (!newdata) return 0;
      strcpy(newdata, item->data);
      strcat(newdata, substring);
      free(item->data);
      item->data = newdata;
    } else {
      item->data = safestrdup(substring);
      if (! item->data) return 0;
    }
    item->iscomplete = TRUE;
    substring = (char *)(endloc + 1);
  }
   
  /* At this point:
     - substring could point to a null character, if we just finished
       a terminating newline and are at the end of the string
     - substring could point to a valid part of the data.  In this case,
       there is partial data remaining. */
 
  if (*substring) {        /* More data. */
    item = findincomplete(id);
     
    /* Same code as above.... almost! */
    
    if (item->data) {
      /* We are finishing data for this item. */
      newdata = safemalloc(strlen(item->data) + strlen(substring) + 2);
      if (!newdata) return 0;
      strcpy(newdata, item->data);
      strcat(newdata, substring);
      free(item->data);
      item->data = newdata;
    } else {
      item->data = safemalloc(strlen(substring) + 2);
      if (!item->data) return 0;
      strcpy(item->data, substring);
    }
     
    item->iscomplete = FALSE;
  }
     
  return TRUE;
}

struct qtype *deqany(void) {
  struct qtype *item = qstart;
 
  while (item) {
    if (item->iscomplete)
      return deqptr(item);        /* deqptr() just returns item */
    item = item->next;
  }
  return (struct qtype *)NULL;
}

struct qtype *deqid(int id) {
  struct qtype *item = qstart;

  while (item) {
    if ((item->id == id) && (item->iscomplete))
      return deqptr(item);
    item = item->next;
  }
  return (struct qtype *)NULL;
}

struct qtype *deqptr(struct qtype *pointer) {

  struct qtype *previtem = qstart;
  if (!qstart) return (struct qtype *)NULL;  /* empty queue! */
  if (qstart == pointer) {    /* first item in queue */
    qstart = pointer->next;
    if (qend == pointer)    /* only item in queue */
      qend = qstart;
  } else while ((previtem) && (previtem->next != pointer))
    previtem = previtem->next;
  if (!previtem) return previtem;
 
  /* OK, now...previtem is the item immediately preceding the one do be
     dequeued. */
    
  previtem->next = pointer->next;
  if (qend == pointer) qend = previtem;
 
  return pointer;
}

int deleteallid(int id) {

  struct qtype *item = qstart, *next;
  while (item) {
    next = item->next;           /* Must save it because item may be deleted! */
    if (item->id == id)
      if (!deleteitem(item)) return FALSE;
    item = next;
  }
  return TRUE;
}

int deleteitem(struct qtype *item) {
  /* Dequeue */
 
  if (!deqptr(item)) return FALSE;
 
  /* De-allocate memory. */
  if (item->data) free(item->data);
  free(item);
 
  return TRUE;
}

struct qtype *findincomplete(int id) {

  struct qtype *item = qstart;
  while (item) {
    if ((item->id == id) && (!(item->iscomplete))) return item;
    item = item->next;
  }
  /* Not found; create a new one for 'em. */
 
  item = createitem();
  item->id = id;
  return item;
}

struct qtype *createitem(void) {
 
  struct qtype* item;
  item = allocq();
  if (!item) return item;            /* error condition */
 
  /* Insert into the queue. */
 
  if (!qend) {                       /* Queue is empty */
    qstart = qend = item;
  } else {
    qend->next = item;
    qend = item;
  }
 
  /* Set up reasonable defaults. */
 
  item->next = (struct qtype *)NULL;
  item->data = (char *)NULL;
  item->iscomplete = FALSE;
  item->id = 0;
 
  return item;
}
 
struct qtype *allocq(void) {
  return (struct qtype *)malloc(sizeof(struct qtype));
}
