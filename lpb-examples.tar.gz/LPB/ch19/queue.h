/*
   header file for queue implementations
   */
  
#ifndef __QUEUE_H__
#define __QUEUE_H__

struct qtype {                 /* Each entry in queue will be of this type */
  char *data;
  int iscomplete;              /* TRUE if it is a complete line
                                  no entry will ever have more than one line
                               */
  struct qtype *next;          /* Pointer to next entry
                                  the queue is implemented as a linked list */
  int id;                      /* Unique ID (socket number works here) */
} ;

/************ FUNCTIONS ************/

/* Add data to the queue. */
int addtoqueue(int id, char *data);
            
/* Will dequeue and return the first completed item in the queue.
   NULL is returned if there are no completed items in the queue.
   Data is NOT de-allocated. */
struct qtype *deqany(void);

/* Will dequeue and return the first item matching the given id.  NULL is
   returned if no *completed* items match the given id. */
struct qtype *deqid(int id);

/* Will dequeue the item pointed to.  Used internally by queue.c.  Returns
   pointer. Memory not freed. */
struct qtype *deqptr(struct qtype *pointer);

/* Will DELETE all items associated with the given id.  Will also de-allocate
   memory, etc. */
int deleteallid(int id);

/* Will DELETE only the item pointed to.  Will free memory. */
int deleteitem(struct qtype *item);

/* Will find any incomplete one matching the given id.
   If there are no matching items, will return a pointer to a new queue
   entry to be filled in. */
struct qtype *findincomplete(int id);

/* Will return a pointer to a new, empty queue entry that is already
   properly linked into the chain. */
struct qtype *createitem(void);

struct qtype *allocq(void);

#endif                /* __QUEUE_H__ */
