#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <errno.h>
#include "safecalls.h"
#include "networkinglib.h"
#include "queue.h"

#define PROTOCOL "tcp"
#define SERVICE "7797"
#define WELCOME "You have connected to the counting server.  Welcome!\n"

int main(void) {
  int mastersock, workersock;
  char buffer[1024];
  char sizebuf[100];
  int nfds = getdtablesize();
  struct qtype *item;

  fd_set orig_fdset, fdset;
  int counter, size;

  mastersock = serverinit(SERVICE, PROTOCOL);

  printf("The server is active.  You may terminate it with Ctrl-C.\n");

  FD_ZERO(&orig_fdset);
  FD_SET(mastersock, &orig_fdset);

  while (1) {
    /* Restore watch set as appropriate. */
    bcopy(&orig_fdset, &fdset, sizeof(orig_fdset));
   
    select(nfds, &fdset, (fd_set *)0, (fd_set *)0,
             (struct timeval *)0);
    if (FD_ISSET(mastersock, &fdset)) {
      /* New connection! */
      printf("Received connection from a client.\n");
      workersock = accept(mastersock, NULL, NULL);
      FD_SET(workersock, &orig_fdset);
      write_buffer(workersock, WELCOME, strlen(WELCOME));
    }

    /* Data on existing connection.  Add to the queue. */

    for (counter = 0; counter < nfds; counter++) {
      if ((counter != mastersock) && FD_ISSET(counter, &fdset)) {
          size = saferead(counter, buffer, sizeof(buffer) -1);
          buffer[size] = 0;         /* add trailing null */
          addtoqueue(counter, buffer);
      }
    }

    /* Process items in the queue. */

    while ((item = deqany())) {
      sprintf(sizebuf, "Size: %d\n", strlen(item->data) - 1);
      write_buffer(item->id, sizebuf, strlen(sizebuf));
      if (strncmp(buffer, "exit", 4) == 0) {
          safeclose(item->id);
          FD_CLR(item->id, &orig_fdset);
      }
      deleteitem(item);
    }
  }
  safeclose(mastersock);
}
