#include <stdio.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "safecalls.h"

void display(int fd);
void add(int fd);
int flockwrapper(int fd, int operation);
int write_buffer(int fd, const void *buf, int count);
int read_buffer(int fd, void *buf, int count);

int main(void) {
  int input;
  int fd;

  fd = safeopen2("ch14-10.dat", O_CREAT | O_RDWR, 0640);

  printf("Select: \n");
  printf("1. Display file\n");
  printf("2. Add to file\n");
  printf("\nYour selection: ");
  scanf("%d", &input);

  switch (input) {
    case 1: display(fd);
            break;
    case 2: add(fd);
            break;
    default:  printf("Invalid selection.  Exiting.\n");
  }
  return 0;
}

/* Display the files.  Request a lock such that processes writing won't
   be able to do that while I'm reading.  */

void display(int fd) {
  int data;

  flockwrapper(fd, LOCK_SH);
  while (read_buffer(fd, &data, sizeof(int)) > 0) {
    printf("Data: %d\n", data);
  }
  close(fd);
}

/* Add new entries.  Request a lock to block everything else. */

void add(int fd) {
  int data;

  flockwrapper(fd, LOCK_EX);
  lseek(fd, 0, SEEK_END);

  do {
    printf("Enter a number (-1 when done): ");
    scanf("%d", &data);
    write_buffer(fd, &data, sizeof(int));
  } while (data != -1);
  close(fd);
}

int flockwrapper(int fd, int operation) {
  printf("Obtaining %s lock on fd %d\n",
     (operation & LOCK_SH) ? "shared" : "exclusive",
     fd);
  if (flock(fd, operation | LOCK_NB) != -1) return 0;
  printf("Another process has a lock; please wait until it is released.\n");
  return flock(fd, operation);
}

/* 
   This function writes certain number bytes from "buf" to a file 
   or socket descriptor specified by "fd". The number of bytes is 
   specified by "count". It returns the number of bytes written,
   or <0 on error.
*/

int write_buffer(int fd, const void *buf, int count) {
  const void *pts = buf;
  int  status = 0, n; 
  
  if (count < 0) return (-1);
  
  while (status != count) { 
    n = safewrite(fd, pts+status, count-status); 
    if (n < 0) return (n);
    status += n; 
  } 
  return (status);
} 

int read_buffer(int fd, void *buf, int count) {
  void *pts = buf;
  int  status = 0, n; 
  
  if (count < 0) return (-1);
  
  while (status != count) { 
    n = saferead(fd, pts+status, count-status); 
    if (n < 1) return n;
    status += n; 
  }
  return (status);
}
