#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/mman.h>

/* The next four are for system call I/O */

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "safecalls.h"

int write_buffer(int fd, const void *buf, int count);

int main(void) {
  int outfile;
  char *mapped;
  char *ptr;

  /* Open the file */

  outfile = safeopen2("test.dat", O_RDWR | O_CREAT | O_TRUNC, 0640);

  lseek(outfile, 1000, SEEK_SET);
  safewrite(outfile, "\0", 1);
  mapped = mmap(NULL, 1000, PROT_READ | PROT_WRITE, MAP_SHARED, 
        outfile, 0);
  if (!mapped) {
    printf("mmap failed.\n");
  }

  ptr = mapped;
  printf("Please enter a number: \n");
  fgets(mapped, 80, stdin);

  ptr += strlen(mapped);
  sprintf(ptr, "Your number times two is: %d\n",
      atoi(mapped) * 2);
  printf("Your number times two is: %d\n",
     atoi(mapped) * 2);

  msync(mapped, 1000, MS_SYNC);
  munmap(mapped, 1000);

  safeclose(outfile);
  return 0;
}

/* 
   This function writes certain number bytes from "buf" to a file 
   or socket descriptor specified by "fd". The number of bytes is 
   specified by "count". It returns the number of bytes written,
   or <0 on error.
*/

int write_buffer(int fd, const void *buf, int count) {
  const void *pts = buf;
  int  status = 0, n; 
  
  if (count < 0) return (-1);
  
  while (status != count) { 
    n = safewrite(fd, pts+status, count-status); 
    if (n < 0) return (n);
    status += n; 
  } 
  return (status);
} 
