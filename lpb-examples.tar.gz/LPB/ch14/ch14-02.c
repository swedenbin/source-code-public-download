#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

/* The next four are for system call I/O */

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void stripcrlf(char *temp);
int write_buffer(int fd, const void *buf, int count);

int main(void) {
  int outfile;
  char input[80];
  char buffer[80];

  printf("Select output filename: ");
  fgets(input, sizeof(input), stdin);
  stripcrlf(input);

  outfile = open(input, O_WRONLY | O_CREAT | O_TRUNC, 0640);
  
  if (outfile == -1) {
    printf("Error opening output file: %s\n",
       sys_errlist[errno]);
    exit(255);
  }

  printf("Please enter some numbers.  Use -1 when you want to exit.\n");
  
  do {
    fgets(input, sizeof(input), stdin);
    if (write_buffer(outfile, input, strlen(input)) < 0) {
      printf("Error writing: %s\n",
         sys_errlist[errno]);
      exit(255);
    }
    stripcrlf(input);

    sprintf(buffer, "New: %d\n",
        atoi(input) * 5 + (20 * 100) - 12);         

    if (write_buffer(outfile, buffer, strlen(buffer)) < 0) {
      printf("Error writing: %s\n",
         sys_errlist[errno]);
      exit(255);
    }
  } while (atoi(input) != -1);
  close(outfile);
  return 0;
}

void stripcrlf(char *temp) {
  while (strlen(temp) && temp[0] && 
     ((temp[strlen(temp)-1] == 13) || (temp[strlen(temp)-1] == 10))) {
    temp[strlen(temp)-1] = 0;
  }
}

/* 
   This function writes certain number bytes from "buf" to a file 
   or socket descriptor specified by "fd". The number of bytes is 
   specified by "count". It returns the number of bytes written,
   or <0 on error.
*/

int write_buffer(int fd, const void *buf, int count)
{
  const void *pts = buf;
  int  status = 0, n; 
  
  if (count < 0) return (-1);
  
  while (status != count) { 
    n = write(fd, pts+status, count-status); 
    if (n < 0) return (n);
    status += n; 
  } 
  return (status);
} 
