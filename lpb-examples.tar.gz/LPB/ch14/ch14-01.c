#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

void stripcrlf(char *temp);

int main(void) {
  FILE *outfile;
  char input[80];

  printf("Select output filename: ");
  fgets(input, sizeof(input), stdin);
  stripcrlf(input);
  
  outfile = fopen(input, "w");
  if (!outfile) {
    printf("Error opening output file: %s\n",
       sys_errlist[errno]);
    exit(255);
  }

  printf("Please enter some numbers.  Use -1 when you want to exit.\n");
  
  do {
    fgets(input, sizeof(input), stdin);
    if (fwrite(input, strlen(input), 1, outfile) != 1) {
      printf("Error writing: %s\n",
         sys_errlist[errno]);
      exit(255);
    }
    stripcrlf(input);
    if (fprintf(outfile, "New: %d\n",
        atoi(input) * 5 + (20 * 100) - 12) < 1) {
      printf("Error writing: %s\n",
         sys_errlist[errno]);
      exit(255);
    }
  } while (atoi(input) != -1);
  fclose(outfile);
  return 0;
}

void stripcrlf(char *temp)
{
  while (strlen(temp) && temp[0] && 
        ((temp[strlen(temp)-1] == 13) || (temp[strlen(temp)-1] == 10))) {
    temp[strlen(temp)-1] = 0;
  }
}
