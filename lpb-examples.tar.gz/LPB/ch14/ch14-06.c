#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

/* The next four are for system call I/O */

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "safecalls.h"

int write_buffer(int fd, const void *buf, int count);

int main(void) {
  int outfile;

  /* Open the file */

  outfile = safeopen2("test.dat", O_WRONLY | O_CREAT | O_TRUNC, 0640);

  write_buffer(outfile, "Hi", 2);
  lseek(outfile, 10485760, SEEK_SET);
  write_buffer(outfile, "Hi", 2);

  safeclose(outfile);
  return 0;
}

/* 
   This function writes a certain number of bytes from "buf" to a file 
   or socket descriptor specified by "fd". The number of bytes is 
   specified by "count". It returns the number of bytes written,
   or <0 on error.
*/

int write_buffer(int fd, const void *buf, int count) {
  const void *pts = buf;
  int  status = 0, n; 
  
  if (count < 0) return (-1);
  
  while (status != count) { 
    n = safewrite(fd, pts+status, count-status); 
    if (n < 0) return (n);
    status += n; 
  } 
  return (status);
} 
