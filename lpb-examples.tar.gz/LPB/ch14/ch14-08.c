/*
  Chapter 14 example program 8

  Here we demonstrate the use of select().

*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "safecalls.h"

int write_buffer(int fd, const void *buf, int count);

int pipes[2];            /* [0] for reading, [1] for writing */

int child(void);
int parent(void);

int main(void) {
  pid_t pid;
  safepipe(pipes);
  
  pid = fork();

  if (pid == 0)
    return child();

  if (pid > 0)
    return parent();

  return 255;
}

/* The thild process will just send some random data over to the parent
   every 10 seconds. */

int child(void) {
  char buffer[80];

  close(pipes[0]);        /* Get rid of unneeded pipe */
  srand(time(NULL));

  do {
    sleep(10);
    sprintf(buffer, "Message %d\n", rand());
  } while (write_buffer(pipes[1], buffer, strlen(buffer)) != -1);

  return 0;
}

int parent(void) {
  char buffer[100];
  fd_set readfds;

  close(pipes[1]);        /* Get rid of unneeded pipe */
  printf("You may enter some data.  I'll read it and data from the\n");
  printf("other process and display each.\n\n");
  
  while(1) {
    FD_ZERO(&readfds);
    FD_SET(0, &readfds);           /* standard input */
    FD_SET(pipes[0], &readfds);    /* child process */
    
    select(pipes[0] + 1, &readfds, NULL, NULL, NULL);
    
    if (FD_ISSET(0, &readfds)) {
      buffer[saferead(0, buffer, sizeof(buffer) -1)] = 0;
      printf("You typed: %s\n", buffer);
    }

    if (FD_ISSET(pipes[0], &readfds)) {
      buffer[saferead(pipes[0], buffer, sizeof(buffer) -1)] = 0;
      printf("Child sent: %s\n", buffer);
    }
  }
}

/* 
   This function writes certain number bytes from "buf" to a file 
   or socket descriptor specified by "fd". The number of bytes is 
   specified by "count". It returns the number of bytes written,
   or <0 on error.
*/

int write_buffer(int fd, const void *buf, int count) {
  const void *pts = buf;
  int  status = 0, n; 
  
  if (count < 0) return (-1);
  
  while (status != count) { 
    n = safewrite(fd, pts+status, count-status); 
    if (n < 0) return (n);
    status += n; 
  } 
  return (status);
} 
