#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

/* The next four are for system call I/O */

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void stripcrlf(char *temp);
int write_buffer(int fd, const void *buf, int count);
int read_buffer(int fd, void *buf, int count);
int readnlstring(int socket, char *buf, int maxlen);
int readdelimstring(int socket, char *buf, int maxlen, char delim);
void exiterror(char *message, int errnum);

const char *MESSAGE_filename = "Select output filename: ";
const char *MESSAGE_numbers = "Please enter some numbers.  Use -1 when you want to exit.\n";

int main(void) {
  int outfile;
  char input[80];
  char buffer[80];

  /* Write the prompt for filename and read in the filename. */

  write_buffer(1, MESSAGE_filename, strlen(MESSAGE_filename));
  readnlstring(0, input, sizeof(input));

  /* Open the file */

  outfile = open(input, O_WRONLY | O_CREAT | O_TRUNC, 0640);
  
  if (outfile == -1) {
    exiterror("Error opening output file: ", errno);
  }

  /* Write the basic instructions. */

  write_buffer(1, MESSAGE_numbers, strlen(MESSAGE_numbers));
  
  do {
    /* Read a line of input, */
    readnlstring(0, input, sizeof(input));

    /* Write it out with trailing newline. */
    if (write_buffer(outfile, input, strlen(input)) < 0) {
      exiterror("Error writing: ", errno);
    }
    if (write_buffer(outfile, "\n", 1) < 0) {
      exiterror("Error writing: ", errno);
    }

    sprintf(buffer, "New: %d\n",
        atoi(input) * 5 + (20 * 100) - 12);
    if (write_buffer(outfile, buffer, strlen(buffer)) < 0) {
      exiterror("Error writing: ", errno);
    }
  } while (atoi(input) != -1);
  close(outfile);
  return 0;
}

void stripcrlf(char *temp) {
  while (strlen(temp) && temp[0] && 
     ((temp[strlen(temp)-1] == 13) || (temp[strlen(temp)-1] == 10))) {
    temp[strlen(temp)-1] = 0;
  }
}

/* 
   This function writes certain number bytes from "buf" to a file 
   or socket descriptor specified by "fd". The number of bytes is 
   specified by "count". It returns the number of bytes written,
   or <0 on error.
*/

int write_buffer(int fd, const void *buf, int count) {
  const void *pts = buf;
  int  status = 0, n; 
  
  if (count < 0) return (-1);
  
  while (status != count) { 
    n = write(fd, pts+status, count-status); 
    if (n < 0) return (n);
    status += n; 
  } 
  return (status);
} 

int read_buffer(int fd, void *buf, int count) {
  void *pts = buf;
  int  status = 0, n; 
  
  if (count < 0) return (-1);
  
  while (status != count) { 
    n = read(fd, pts+status, count-status); 
    if (n < 1) return n;
    status += n; 
  }
  return (status);
}

int readnlstring(int socket, char *buf, int maxlen) {
  return readdelimstring(socket, buf, maxlen, '\n');
}

int readdelimstring(int socket, char *buf, int maxlen, char delim) {
  int status;
  int count = 0;

  while (count < maxlen - 1) {
    if ((status = read_buffer(socket, buf+count, 1)) < 1) {
      printf("Error reading.\n");
      return -1;
    }
    if (buf[count] == delim) {          /* Found the delimiter */
      buf[count] = 0;
      return 0;
    }
    count++;
  }
  buf[count] = 0;
  return 0;
}

void exiterror(char *message, int errnum) {
  write_buffer(1, message, strlen(message));
  write_buffer(1, sys_errlist[errnum], strlen(sys_errlist[errnum]));
  write_buffer(1, "\n", 1);
  exit(255);
}
