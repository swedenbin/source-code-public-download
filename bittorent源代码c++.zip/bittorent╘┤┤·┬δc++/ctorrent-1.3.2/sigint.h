#ifndef SIGINT_H
#define SIGINT_H

#ifndef WINDOWS
void sigint_catch(int sig_no);
#endif

#endif
