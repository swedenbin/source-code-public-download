/* /nodynamiccopyright/ */ 
public class Test {
    public void test() {
        abcdefg
    }
}
