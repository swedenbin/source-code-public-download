//made in GamVan  今晚制造
document.writeln(" <DIV id=GVbar align=\"right\">");
document.writeln("<ul>");
document.writeln("<li><a href=\"http://www.gamvan.COM/\" target=\"_blank\">今晚首页</a></li>");

document.writeln("<li><a href=\"http://www.gamvan.com/news/\" target=\"_blank\">业界新闻</a></li>");

document.writeln("<li><a href=\"http://www.gamvan.COM/web/\" target=\"_blank\">网站建设</a></li>");


document.writeln("<li><a href=\"http://www.gamvan.COM/developer/\" target=\"_blank\">开发者</a></li>");

document.writeln("<li><a href=\"http://www.gamvan.com/database/\" target=\"_blank\">数据库</a></li>");

document.writeln("<li><a href=\"http://www.gamvan.com/server/\" target=\"_blank\">操作系统</a></li>");

document.writeln("<li><a href=\"http://www.gamvan.COM/design/\" target=\"_blank\">设计相关</a></li>");

document.writeln("<li><a href=\"http://www.gamvan.net/\" target=\"_blank\">基础服务</a></li>");

document.writeln("<li><a href=\"http://cha.gamvan.com/alexa.jsp\"  target=\"_blank\">查询</a></li>");

document.writeln("</ul></DIV>");


















