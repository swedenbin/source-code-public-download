document.write("<table width=\"99%\"  border=\"0\" align=\"center\" cellpadding=\"3\" cellspacing=\"1\">");
document.write("<tr>");
document.write("</tr><tr><td height=\"30\"><strong>合作伙伴</strong>");

document.write("&nbsp;&nbsp;<a href=\"http://www.gamvan.com/\" target=\"_blank\">今晚在线</a>");

document.write("&nbsp;&nbsp;<a href=\"http://www.cxchina.com/\" target=\"_blank\">畅想中国</a>");

document.write("</td></tr></table>");

//made in gamvan  今晚制造




