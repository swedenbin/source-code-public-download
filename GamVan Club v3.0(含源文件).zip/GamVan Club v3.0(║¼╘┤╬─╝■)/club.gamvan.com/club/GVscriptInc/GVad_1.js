//this ad code Made In GamVan
var a = 3;
var slump = Math.random();
var talet = Math.round(slump * (a-1)+1);
b = new Array();
u = new Array();
w = new Array();
h = new Array();
b[1] = '/club/ad/cx3.swf';
u[1] = '';
w[1] = 468;
h[1] = 60;

b[2] = '/club/ad/cx1.swf';
u[2] = '';
w[2] = 468;
h[2] = 60;

b[3] = '/club/ad/2006_600x79.swf';
u[3] = '';
w[3] = 600;
h[3] = 79;

showad(b[talet], u[talet], w[talet], h[talet]);

