document.writeln("<DIV class=list_topBar>&nbsp;");
document.writeln("<a href=\"main.jsp\" target=\"_self\">进站画面</a>&nbsp;&nbsp;");
document.writeln("<a href=\"./\" target=\"_parent\">首页</a>&nbsp;");
document.writeln("<a href=\"userLogin.jsp\" target=\"_self\">登陆</a>&nbsp;&nbsp;");
document.writeln("<a href=\"userAgree.jsp\" target=\"_self\"><Strong>注册</strong></a>&nbsp;&nbsp;");
document.writeln("<a href=\"onlineList.jsp\" target=\"_self\">在线</a>&nbsp;&nbsp;");

document.writeln("<a href=\"searchAll.jsp\" target=\"_self\"><font color=red>全文检索</font></a>&nbsp;&nbsp;");

document.writeln("<a href=\"search.jsp\" target=\"_self\">搜索</a>&nbsp;&nbsp;");

document.writeln("<a href=\"upFiles.jsp\" target=\"_self\">媒体库</a>&nbsp;&nbsp;");
document.writeln("<a href=\"help.jsp\" target=\"_self\">帮助</a>&nbsp;&nbsp;");
document.writeln("<a href=\"userFindPass.jsp\" target=\"_self\">找回</a>&nbsp;&nbsp;")
document.writeln("<a href=\"loginOut.jsp\" target=\"_parent\">退出</a>&nbsp;&nbsp;")
document.writeln("<a href=\"javascript:location.assign(self.location)\">刷新</a>&nbsp;&nbsp;");	
document.writeln("<a href=\"javascript:history.back()\"><<快速后退</a>&nbsp;&nbsp;");
document.writeln("</DIV>");
document.writeln("<DIV class=\"line\"></DIV>");

//made in GamVan  今晚制造







