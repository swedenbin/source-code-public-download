<!--
function writeContent(i){
	var txt;
	txt = document.Gforms.content.value;
	txt = txt.replace("[GVtype]","");
	txt = txt.replace("[/GVtype]","");	
	if(i==0||i==3){ //判断是否为普通或求助贴
		document.Gforms.content.value = txt;		
	}else{
		document.Gforms.content.value = "[GVtype] " + txt + " [/GVtype]";
	}
}
function showTypeInfo(id){
	if (id=="0"){
		document.getElementById("div1").style.display = "none";
		document.getElementById("div2").style.display = "none";
		document.getElementById("div3").style.display = "none";
		document.getElementById("div4").style.display = "none";
	}
	if (id=="1"){
		document.getElementById("div1").style.display = "";
		document.getElementById("div2").style.display = "none";
		document.getElementById("div3").style.display = "none";
		document.getElementById("div4").style.display = "none";
	}
	if (id=="2"){
		document.getElementById("div1").style.display = "none";
		document.getElementById("div2").style.display = "";
		document.getElementById("div3").style.display = "none";
		document.getElementById("div4").style.display = "none";
	}
	if (id=="3"){
		document.getElementById("div1").style.display = "none";
		document.getElementById("div2").style.display = "none";
		document.getElementById("div3").style.display = "";
		document.getElementById("div4").style.display = "none";
	}
	if (id=="4"){
		document.getElementById("div1").style.display = "none";
		document.getElementById("div2").style.display = "none";
		document.getElementById("div3").style.display = "none";
		document.getElementById("div4").style.display = "";
	}
}

function checkForm(){
	if (document.Gforms.gvUserName.value.length == 0) {
		alert("请输入您的用户名.");
		document.Gforms.gvUserName.focus();
		return false;
	}
	if (document.Gforms.gvUserName.value.indexOf("<")!=-1 || document.Gforms.gvUserName.value.indexOf(">")!=-1){
		alert("用户名中不能包含英文半角括号 (<,>) ");
		document.Gforms.gvUserName.focus();
		return false;
	}
	if (document.Gforms.gvUserName.value.indexOf("'")!=-1){
		alert("用户名中不能包含 (') ");
		document.Gforms.gvUserName.focus();
		return false;
	}
	if (document.Gforms.gvUserPass.value.length == 0) {
		alert("请输入您的密码.");
		document.Gforms.gvUserPass.focus();
		return false;
	}
	if (document.Gforms.gvTopic.value.length==0&&document.Gforms.content.value.length==0) {
		alert("标题和内容请任选一项填写，不能全部为空！");
		document.Gforms.gvTopic.focus();
		return false;
	}
	postMsg();
	return true;
}

var ieg
ieg = (document.all)? true:false
if (ieg){
	function keyForm(eventobject){
		if(event.ctrlKey && window.event.keyCode==13){
			document.Gforms.gvSubmit.value="正在提交...";
			document.Gforms.gvSubmit.disabled=true;
			document.Gforms.gvBack.disabled=true;
			this.document.Gforms.submit();
		}
	}
}
//
-->