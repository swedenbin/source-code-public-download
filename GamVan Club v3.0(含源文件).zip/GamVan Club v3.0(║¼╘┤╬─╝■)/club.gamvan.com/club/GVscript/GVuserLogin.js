function CheckForm(){
	var iu, iuu, regArray=new Array("","◎","■","●","№","↑","→","↓"+
	"!","@","#","$","%","^","&","*","(",")","_","-","+","=","|","'","[","]","？","~","`"+
	"!","<",">","‰","→","←","↑","↓","¤","§","＃","＆","＆","＼","≡","≠"+
	"≈","∈","∪","∏","∑","∧","∨","⊥","∥","∥","∠","⊙","≌","≌","√","∝","∞","∮"+
	"∫","≯","≮","＞","≥","≤","≠","±","＋","÷","×","／","Ⅱ","Ⅰ","Ⅲ","Ⅳ","Ⅴ","Ⅵ","Ⅶ","Ⅷ","Ⅹ","Ⅻ","㈠","㈡"+
	"╄","╅","╇","┻","┻","┇","┭","┷","┦","┣","┝","┤","┷","┷","┹","╉","╇","【","】"+
	"㈢","㈣","㈤","㈥","㈦","㈧","㈨","㈩","①","②","③","④","⑤","⑥","⑦","⑧","⑨","⑩","┌","├","┬","┼","┍","┕","┗","┏","┅","─"+
	"〖","〗","←","〓","☆","§","□","‰","◇","︿","＠","△","▲","＃","℃","※",".","≈","￠"); 
	iuu=regArray.length;
	for(iu=1;iu<=iuu;iu++){
		if (document.Gforms.gvUserName.value.indexOf(regArray[iu])!=-1){
			alert("注册名不可以包含：" + regArray[iu]);
			document.Gforms.gvUserName.focus();
			return false;
		}
	}
	if (document.Gforms.gvUserName.value.length == 0) {
		alert("请输入您的用户名.");
		document.Gforms.gvUserName.focus();
		return false;
	}
	if (document.Gforms.gvUserName.value.length < 2) {
		alert("用户名应大于2个小于15个字符");
		document.Gforms.gvUserName.focus();
		return false;
	}
	if (document.Gforms.gvUserName.value.length > 30) {
		alert("用户名应大于3个,小于15个字符.");
		document.Gforms.gvUserName.focus();
		return false;
	}
	if (document.Gforms.gvUserName.value.indexOf(" ")!=-1){
		alert("用户名中不能含有空格！！！");
		document.Gforms.gvUserName.focus();
		return false;
	}
	if (document.Gforms.gvUserPass.value.length == 0) {
		alert("请输入您的密码.");
		document.Gforms.gvUserPass.focus();
		return false;
	}
		if (document.Gforms.gvUserPass.value.length < 6) {
		alert("密码至少6位.");
		document.Gforms.gvUserPass.focus();
		return false;
	}
	return true;
}