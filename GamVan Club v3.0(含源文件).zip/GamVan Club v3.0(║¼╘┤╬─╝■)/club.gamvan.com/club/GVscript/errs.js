function errTxt(ierr){
	var ext
	switch(ierr){
		case 1:
			ext=("<strong><font color=#bb0000>权限不足</font></strong>");
		break
		case 2:
			ext=("<strong><font color=#bb0000>过滤字符</font></strong>");
		break
		case 3:
			ext=("<strong><font color=#bb0000>参数错误</font></strong>");
		break	
		case 4:
			ext=("<strong><font color=#bb0000>主题属性</font></strong>");		
		break
		case 5:
			ext=("<strong><font color=#bb0000>论坛属性</font></strong>");		
		break
		case 6:
			ext=("<strong><font color=#bb0000>登陆信息</font></strong>");		
		break
		case 7:
			ext=("<strong><font color=#bb0000>数据记录出错</font></strong>");		
		break
		case 8:
			ext=("<strong><font color=#bb0000>提交数据</font></strong>");		
		break									
		default:
			ext=("未知！！！");
	}
document.write("<span class=smallTxt>●</span> 您在社区的操作触发提示类型为：");
document.write(ext+"<table border=0 height=2><tr><td></td></tr></table><span class=smallTxt>●</span> 详细信息：");
}