//Pop-it menu- By Dynamic Drive - Modified by Wbird
//For full source code and more DHTML scripts, visit http://www.dynamicdrive.com
//This credit MUST stay intact for use
var GVOffX=0	//菜单距连接文字最左端距离
var GVOffY=18	//菜单距连接文字顶端距离

var vBobjects = new Array();
var fo_shadows=new Array()
var linkset=new Array()
////No need to edit beyond here
var ie4=document.all&&navigator.userAgent.indexOf("Opera")==-1
var ns6=document.getElementById&&!document.all
var ns4=document.layers
var opera = navigator.userAgent.indexOf("Opera")!=-1;

var xslDoc;
function MM_findObj(n, d) {
var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  
	for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  
	if(!x && d.getElementById) x=d.getElementById(n); return x;

} 
function fetch_object(idname, forcefetch)
{
	if (typeof(vBobjects[idname]) == "undefined")
	{
		vBobjects[idname] = MM_findObj(idname);
	}
	return vBobjects[idname];
}
//showmenu vmenu:内容，允许为空,vmenuobj DIV数据ID，MOD 0=关闭浏览器自适应，用于版面导航菜单
function showmenu(e,vmenu,vmenuobj,mod){
	if (!document.all&&!document.getElementById&&!document.layers)
		return
	var which=vmenu;
	if (vmenuobj)
	{
		var MenuObj = fetch_object(vmenuobj);
		if (MenuObj)
		{
			which = MenuObj.innerHTML;
		}
	}
	if (!which)
	{
		return
	}
	clearhidemenu();
	ie_clearshadow();
	menuobj= ie4? document.all.popmenu : 
			ns6? document.getElementById("popmenu") : 
			opera? document.getElementById("popmenu") : 
			ns4 ? document.popmenu : 
			"";
	
	menuobj.thestyle=(ie4||ns6||opera)? menuobj.style : menuobj;
	if (ie4||ns6||opera)
		menuobj.innerHTML=which
	else{
		menuobj.document.write('<layer name=gui bgcolor="#E6E6E6" width="165" onmouseover="clearhidemenu()" onmouseout="hidemenu()">'+which+'</layer>')
		menuobj.document.close()
	}
	menuobj.contentwidth=(ie4||ns6||opera)? menuobj.offsetWidth : menuobj.document.gui.document.width
	menuobj.contentheight=(ie4||ns6||opera)? menuobj.offsetHeight : menuobj.document.gui.document.height
	eventX=ie4? event.clientX : 
			ns6? e.clientX : e.x
			opera? e.clientX : e.x
			;
	eventY=ie4? event.clientY : 
			ns6? e.clientY : e.y
			opera? e.clientX : e.x
			;
	var rightedge=ie4? document.body.clientWidth-eventX : window.innerWidth-eventX
	var bottomedge=ie4? document.body.clientHeight-eventY : window.innerHeight-eventY
	var getlength
		if (rightedge<menuobj.contentwidth){
			getlength=ie4? document.body.scrollLeft+eventX-menuobj.contentwidth+GVOffX : ns6? window.pageXOffset+eventX-menuobj.contentwidth : eventX-menuobj.contentwidth
		}else{
			getlength=ie4? ie_x(event.srcElement)+GVOffX : ns6? window.pageXOffset+eventX : eventX
		}
		menuobj.thestyle.left=getlength+'px'
		if (bottomedge<menuobj.contentheight&&mod!=0){
			getlength=ie4? document.body.scrollTop+eventY-menuobj.contentheight-event.offsetY+GVOffY-23 : ns6? window.pageYOffset+eventY-menuobj.contentheight-10 : eventY-menuobj.contentheight
		}	else{
			getlength=ie4? ie_y(event.srcElement)+GVOffY : ns6? window.pageYOffset+eventY+10 : eventY
		}
	menuobj.thestyle.top=getlength+'px'
	menuobj.thestyle.visibility="visible"
	ie_dropshadow(menuobj,"#999999",3)
	return false
}

function ie_y(e){  
	var t=e.offsetTop;  
	while(e=e.offsetParent){  
		t+=e.offsetTop;  
	}  
	return t;  
}  
function ie_x(e){  
	var l=e.offsetLeft;  
	while(e=e.offsetParent){  
		l+=e.offsetLeft;  
	}  
	return l;  
}  
function ie_dropshadow(el, color, size)
{
	var i;
	for (i=size; i>0; i--)
	{
		var rect = document.createElement('div');
		var rs = rect.style
		rs.position = 'absolute';
		rs.left = (el.style.posLeft + i) + 'px';
		rs.top = (el.style.posTop + i) + 'px';
		rs.width = el.offsetWidth + 'px';
		rs.height = el.offsetHeight + 'px';
		rs.zIndex = el.style.zIndex - i;
		rs.backgroundColor = color;
		var opacity = 1 - i / (i + 1);
		rs.filter = 'alpha(opacity=' + (100 * opacity) + ')';
		//el.insertAdjacentElement('afterEnd', rect);
		fo_shadows[fo_shadows.length] = rect;
	}
}
function ie_clearshadow()
{
	for(var i=0;i<fo_shadows.length;i++)
	{
		if (fo_shadows[i])
			fo_shadows[i].style.display="none"
	}
	fo_shadows=new Array();
}


function contains_ns6(a, b) {
	while (b.parentNode)
		if ((b = b.parentNode) == a)
			return true;
	return false;
}

function hidemenu(){
	if (window.menuobj)
		menuobj.thestyle.visibility=(ie4||ns6||opera)? "hidden" : "hide"
	ie_clearshadow()
}

function dynamichide(e){
	if (ie4&&!menuobj.contains(e.toElement))
		hidemenu()
	else if ((opera || ns6) && e.currentTarget!= e.relatedTarget && !contains_ns6(e.currentTarget, e.relatedTarget))
		hidemenu()
}

function delayhidemenu(){
	if (opera||ie4||ns6||ns4)
		delayhide=setTimeout("hidemenu()",500)
}

function clearhidemenu(){
	if (window.delayhide)
		clearTimeout(delayhide)
}

function highlightmenu(e,state){
	if (document.all)
		source_el=event.srcElement
	else if (document.getElementById)
		source_el=e.target
	if (source_el.className=="menuitems"){
		source_el.id=(state=="on")? "mouseoverstyle" : ""
	}
	else{
		while(source_el.id!="popmenu"){
			source_el=document.getElementById? source_el.parentNode : source_el.parentElement
			if (source_el.className=="menuitems"){
				source_el.id=(state=="on")? "mouseoverstyle" : ""
			}
		}
	}
}


// ===================================================

function hidelayer() {
  if(window.layerobj) {
    layerobj.thestyle.visibility = (ie4 || ns6) ? "hidden" : "hide";
  }
  ie_clearshadow();
}
function delayhidelayer() {
  if(ie4 || ns6 || ns4) {
    delayhide = setTimeout("hidelayer()", 5000);
  }
}
function clearhidelayer() {
  if(window.delayhide) {
    clearTimeout(delayhide);
  }
}
function showlayer(e, vlayer, mod){
  if(!(ie4 || ns4 || ns6)) {
    return;
  }
  which = encodeHtmlTag(vlayer);
  clearhidelayer();
  ie_clearshadow();
  layerobj = ie4 ? document.all.poplayer : ns6 ? document.getElementById("poplayer") : ns4 ? document.poplayer : "";
  layerobj.thestyle = (ie4 || ns6) ? layerobj.style : layerobj;
  
  if(ie4 || ns6) {
    layerobj.innerHTML = which;
  }
  else {
    layerobj.document.write('<layer name="gui" bgColor="#E6E6E6" width="165" onmouseover="clearhidelayer()" onmouseout="hidelayer()">' + which + '</layer>');
    layerobj.document.close();
  }
  layerobj.contentwidth = (ie4 || ns6) ? layerobj.offsetWidth : layerobj.document.gui.document.width;
  layerobj.contentheight = (ie4 || ns6)? layerobj.offsetHeight : layerobj.document.gui.document.height;
  
  eventX = ie4 ? event.clientX : ns6 ? e.clientX : e.x;
  eventY = ie4 ? event.clientY : ns6 ? e.clientY : e.y;
  
  var rightedge = ie4 ? document.body.clientWidth - eventX : window.innerWidth - eventX;
  var bottomedge = ie4 ? document.body.clientHeight - eventY : window.innerHeight-eventY;
  if(rightedge < layerobj.contentwidth) {
    layerobj.thestyle.left = ie4 ? document.body.scrollLeft + eventX - layerobj.contentwidth + GVOffX : ns6? window.pageXOffset + eventX - layerobj.contentwidth : eventX - layerobj.contentwidth;
  }
  else {
    layerobj.thestyle.left = ie4 ? ie_x(event.srcElement) + GVOffX : ns6 ? window.pageXOffset + eventX : eventX;
  }
  if(bottomedge<layerobj.contentheight&&mod != 0) {
    layerobj.thestyle.top = ie4 ? document.body.scrollTop + eventY - layerobj.contentheight-event.offsetY + GVOffY - 23 : ns6 ? window.pageYOffset + eventY - layerobj.contentheight-10 : eventY-layerobj.contentheight;
  }
  else {
    layerobj.thestyle.top = ie4 ? ie_y(event.srcElement) + GVOffY : ns6 ? window.pageYOffset + eventY + 10 : eventY;
  }
  layerobj.thestyle.visibility = "visible";
  ie_dropshadow(layerobj, "#999999", 3);
  return false;
}
function encodeHtmlTag(text) {
	text = text.replace(/&/g, "&amp;") ;
	text = text.replace(/&/g, "&amp;") ;
	text = text.replace(/"/g, "&quot;") ;
	//text = text.replace(/</g, "&lt;") ;
	//text = text.replace(/>/g, "&gt;") ;
	text = text.replace(/'/g, "&#146;") ;
	return text ;
}
document.write("<DIV class=\"showMenu\" id=\"popmenu\" onmouseover=\"clearhidemenu();\" style=\"Z-INDEX: 100\" ");
document.write(" onmouseout=\"dynamichide(event);\"></DIV>");
document.write("<div class=\"poplayer\" id=\"poplayer\" style=\"Z-INDEX: 100\"></div>");