// Made in GamVan
var ie = document.all != null;
var mozilla = document.all == null;
var ie4 = document.all && navigator.userAgent.indexOf("Opera") == -1;
var ns6 = document.getElementById && !document.all;
var ns4 = document.layers;
var opera = navigator.userAgent.indexOf("Opera")!=-1;
function loadTree(tID, replaceUrl) {
  if(!ie4 && !ns6 && !opera) {
    return false;
  }
	if(!showTree(tID)) {
		if(replaceUrl.length!=0){
			var obj;
				obj = ie4 ? document.frames["hiddenframe"] : ns6 
					? document.getElementById("hiddenframe") : ns4 
					? document.getElementById("hiddenframe") : opera 
					? document.getElementById("hiddenframe"): "";
			if(ns6 || opera) {
			  obj.src = replaceUrl;
			}
			else {
			  obj.location.replace(replaceUrl);
			}
		 }
  	}
}
function showTree(id) {
  var icon = null;
  var load_block = null;
  var show_block = null;
  var imgPath = null;
  var loaded = false;
  if(ie) {
    icon = eval("icon_" + id);
    load_block = eval("load_" + id);
    show_block = "block";
  }
  else {
    icon = document.getElementById("icon_" + id);
    load_block = document.getElementById("load_" + id);
    show_block = "table-row";
  }
  imgPath = icon.src;
  if(icon.src.indexOf("noreply") != -1) {
    return false;
  }
  loaded = !(icon.src.indexOf("t1.gif") != -1);
  imgPath = imgPath.substring(0, imgPath.lastIndexOf("/"));
  if("object" == typeof(icon)) {
    if(load_block.style.display != show_block) {
      load_block.style.display = show_block;
      icon.src = imgPath + "/t2.gif";
      icon.title = "关闭";
    }
    else {
      load_block.style.display = "none";
      icon.src = imgPath + "/t1.gif";
      icon.title = "展开";
    }
  }
  return loaded;
}
////////////////////////////////////////////////
function loadTreeNoimg(tID, replaceUrl) {
  if(!ie4 && !ns6 && !opera) {
    return false;
  }
	//if(!showTreeNoimg(tID)) {
		if(replaceUrl.length!=0){  
			var obj;
				obj = ie4 ? document.frames["hiddenframe"] : ns6 
					? document.getElementById("hiddenframe") : ns4 
					? document.getElementById("hiddenframe") : opera 
					? document.getElementById("hiddenframe"): "";
			if(ns6 || opera) {
			  obj.src = replaceUrl;
			}
			else {
			  obj.location.replace(replaceUrl);
			}
		 }
  	//}
}
function showTreeNoimg(id) {
  var load_block = null;
  var show_block = null;
  var loaded = false;
  if(ie) {
    load_block = eval("load_" + id);
    show_block = "block";
  }
  else {
    load_block = document.getElementById("load_" + id);
    show_block = "table-row";
  }
   //if(load_block.style.display != show_block) {
      //load_block.style.display = show_block;
    //}
    //else {
      //l/oad_block.style.display = "none";
    //}
  return false;
}