<!--
function MM_preloadImages() {
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function loadImg(){
	MM_preloadImages(
		'./GVimgs/classMenu/c11.gif'
		,'./GVimgs/classMenu/c22.gif'
		,'./GVimgs/classMenu/c33.gif'
		,'./GVimgs/classMenu/c44.gif'
		,'./GVimgs/classMenu/c55.gif'
		,'./GVimgs/classMenu/c66.gif'
		,'./GVimgs/classMenu/c1.gif'
		,'./GVimgs/classMenu/c2.gif'
		,'./GVimgs/classMenu/c3.gif'
		,'./GVimgs/classMenu/c4.gif'
		,'./GVimgs/classMenu/c5.gif'
		,'./GVimgs/classMenu/c6.gif'
		);
}
//-->
