function CheckForm(){
	var iu, iuu, regArray=new Array("","◎","■","●","№","↑","→","↓"+
	"!","@","#","$","%","^","&","*","(",")","_","-","+","=","|","'","[","]","？","~","`"+
	"!","<",">","‰","→","←","↑","↓","¤","§","＃","＆","＆","＼","≡","≠"+
	"≈","∈","∪","∏","∑","∧","∨","⊥","∥","∥","∠","⊙","≌","≌","√","∝","∞","∮"+
	"∫","≯","≮","＞","≥","≤","≠","±","＋","÷","×","／","Ⅱ","Ⅰ","Ⅲ","Ⅳ","Ⅴ","Ⅵ","Ⅶ","Ⅷ","Ⅹ","Ⅻ","㈠","㈡"+
	"╄","╅","╇","┻","┻","┇","┭","┷","┦","┣","┝","┤","┷","┷","┹","╉","╇","【","】"+
	"㈢","㈣","㈤","㈥","㈦","㈧","㈨","㈩","①","②","③","④","⑤","⑥","⑦","⑧","⑨","⑩","┌","├","┬","┼","┍","┕","┗","┏","┅","─"+
	"〖","〗","←","〓","☆","§","□","‰","◇","︿","＠","△","▲","＃","℃","※",".","≈","￠"); 
	iuu=regArray.length;
	for(iu=1;iu<=iuu;iu++){
		if (document.Gforms.gvUserName.value.indexOf(regArray[iu])!=-1){
			alert("注册名不可以包含：" + regArray[iu]);
			document.Gforms.gvUserName.focus();
			return false;
		}
	}
	if (document.Gforms.gvUserName.value.length == 0) {
		alert("请输入您的名字.");
		document.Gforms.gvUserName.focus();
		return false;
	}
	if (document.Gforms.gvUserName.value.length < 2) {
		alert("用户名应大于2个小于15个字符");
		document.Gforms.gvUserName.focus();
		return false;
	}
	if (document.Gforms.gvUserName.value.length > 16) {
		alert("用户名应大于3个,小于15个字符.");
		document.Gforms.gvUserName.focus();
		return false;
	}
	if (document.Gforms.gvUserName.value.indexOf(" ")!=-1){
		alert("用户名中不能含有空格！！！");
		document.Gforms.gvUserName.focus();
		return false;
	}
	if (document.Gforms.gvUserPass.value.length == 0) {
		alert("请输入您的密码.");
		document.Gforms.gvUserPass.focus();
		return false;
	}
		if (document.Gforms.gvUserPass.value.length < 6) {
		alert("密码至少6位.");
		document.Gforms.gvUserPass.focus();
		return false;
	}
	if (document.Gforms.gvUserPass2.value.length == 0) {
		alert("请确认您的密码.");
		document.Gforms.gvUserPass2.focus();
		return false;
	}
	if (document.Gforms.gvUserPass.value != document.Gforms.gvUserPass2.value) {
		alert("您两次输入的密码不一样！请重新输入.");
		document.Gforms.gvUserPass.focus();
		return false;
	}
	if (document.Gforms.gvUserEmail.value.length == 0) {
		alert("请输入您的电子邮件.");
		document.Gforms.gvUserEmail.focus();
		return false;
	}
	if (document.Gforms.gvUserEmail.value.length > 0 && !document.Gforms.gvUserEmail.value.match(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/) ) {
		alert("Email 错误！请重新输入");
		document.Gforms.gvUserEmail.focus();
		return false;
	}
		if (document.Gforms.gvUserPen.value.length > 200) {
		alert("您的签名太长了，换短点吧！.");
		document.Gforms.gvUserPen.focus();
		return false;
	}
	if (document.Gforms.gvUserIntro.value.length > 500) {
		alert("自我介绍不能超过500字符.");
		document.Gforms.gvUserIntro.focus();
		return false;
	}
	postMsg();
	return true;
}
<!--
  var myxmlhttp;
  var isBrowserCompatible;
  var hidePasswordBar;
  ratingMsgs = new Array(6);
  ratingMsgColors = new Array(6);
  barColors = new Array(6);
  ratingMsgs[0] = "未评级";
  ratingMsgs[1] = "太短";
  ratingMsgs[2] = "弱";
  ratingMsgs[3] = "一般";
  ratingMsgs[4] = "很好";
  ratingMsgs[5] = "极佳"; //If the password server is down
  ratingMsgColors[0] = "#808080";
  ratingMsgColors[1] = "#da5301";
  ratingMsgColors[2] = "#ccbe00";
  ratingMsgColors[3] = "#1e91ce";
  ratingMsgColors[4] = "#0000FF";
  ratingMsgColors[5] = "#ff0000";
  barColors[0] = "#e0e0e0";
  barColors[1] = "#da5301";
  barColors[2] = "#f0e54b";
  barColors[3] = "#1e91ce";
  barColors[4] = "#0000FF";
  barColors[5] = "#ff0000";
  hidePasswordBar = false;
  function CreateRateUserPassReq(formKey) {
    if (!isBrowserCompatible) {
      return;
    }
    var passwd = document.forms[formKey].gvUserPass.value;
	var min_passwd_len = 6;
    var passwdKey = "passwd";
    if (passwd.length < min_passwd_len) {
    	DrawBar(1);
    }else{
  	  //We need to escape the password now so it won't mess up with length test
      passwd = escape(passwd);
      var params = passwdKey + "=" + passwd
      myxmlhttp = CreateXmlHttpReq(RateUserPassXmlHttpHandler);
      XmlHttpPOST(myxmlhttp, "/club/rateUserPass.gv", params);
    }
  }

  function getElement(name) {
    if (document.all) {
      return document.all(name);
    }
    return document.getElementById(name);
  }

  function RateUserPassXmlHttpHandler() {
    // Can't check status since safari doesn't support it
    if (myxmlhttp.readyState !=4 ) {
      return;
    }
    rating = parseInt(myxmlhttp.responseText);
    DrawBar(rating);
  }

  function DrawBar(rating) {
    var posbar = getElement('posBar');
    var negbar = getElement('negBar');
    var passwdRating = getElement('passwdRating');
    var barLength = getElement('passwdBarDiv').width;
    if (rating >= 0 && rating <= 5) {  //We successfully got a rating
      posbar.style.width = barLength / 5 * rating;
      negbar.style.width = barLength / 5 * (5 - rating);
    } else {
      posbar.style.width = 0;
      negbar.style.width = barLength;
      rating = 5; // Not rated Rating
    }
    posbar.style.background = barColors[rating]
    passwdRating.innerHTML = "<font color='" + ratingMsgColors[rating] +
                             "'>" + ratingMsgs[rating] + "</font>";
  }
  
