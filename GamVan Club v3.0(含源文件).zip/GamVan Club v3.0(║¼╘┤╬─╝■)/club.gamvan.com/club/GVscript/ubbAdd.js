
helpstat = false;
stprompt = false;
basic = true;
function stringManage(strbegin,strend){
	if ((document.selection)&&(document.selection.type == "Text")) {
		var range = document.selection.createRange();
		var ch_text=range.text;
		range.text = strbegin + ch_text + strend;
	} 
	else {
		document.Gforms.content.value=document.Gforms.content.value+strbegin+strend;
		document.Gforms.content.focus();
	}
}
function thelp(swtch){
	if (swtch == 1){
		basic = false;
		stprompt = false;
		helpstat = true;
	} else if (swtch == 0) {
		helpstat = false;
		stprompt = false;
		basic = true;
	} else if (swtch == 2) {
		helpstat = false;
		basic = false;
		stprompt = true;
	}
}
function AddText(NewCode) {
document.Gforms.content.value+=NewCode
}
function emailurl() {
var txt2, txt
	if (helpstat) {
		alert("UBB EMAiL语法,可作为email的超级连接.\n\n用法 #1: [email]someone\@anywhere.com[/email] \n用法 #2: [email=someone\@anywhere.com]连接文字[/email]");
		}
	else if (basic) {
		AddTxt="[email] [/email]";
		AddText(AddTxt);
		}
	else { 
		txt2=prompt("以下文字显示于EMAiL连接上. ",""); 
		if (txt2!=null) {
			txt=prompt("连接地址.","mailto:");      
			if (txt!=null) {
				if (txt2=="") {
					AddTxt="[email]"+txt+"[/email]";
					AddText(AddTxt);
				} else {
					AddTxt="[email="+txt+"]"+txt2+"[/email]";
					AddText(AddTxt);
				}         
			} 
		}
	}
}
function showsize(size) {
	if (helpstat) {
		alert("设置文字大小. 课选择1号到4号字体.\n\n用法: [size="+size+"]文字内容大小[/size]");
	} else if (basic) {
		stringManage("[size="+size+"]","[/size]");
	} else {                       
		txt=prompt("以下文字显示的大小为 "+size,"文字"); 
		if (txt!=null) {             
			AddTxt="[size="+size+"] "+txt+"[/size]";
			AddText(AddTxt);
		}        
	}
}

function bold() {
	if (helpstat) {
		alert("UBB粗体于发言.\n\n用法: [B]粗体[/B]");
	} else if (basic) {
		stringManage("[B]","[/B]");
	} else {  
		txt=prompt("以下文字将变为粗体.","文字");     
		if (txt!=null) {           
			AddTxt="[B] "+txt+"[/B]";
			AddText(AddTxt);
		}       
	}
}

function italicize() {
	if (helpstat) {
		alert("UBB斜体于发言.\n\n用法: [i]斜体[/i]");
	} else if (basic) {
		stringManage("[i]","[/i]");
	} else {   
		txt=prompt("以下文字将变为斜体","文字");     
		if (txt!=null) {           
			AddTxt="[i] "+txt+"[/i]";
			AddText(AddTxt);
		}	        
	}
}
function quote() {
	if (helpstat){
		alert("UBB引用语法,可特别表示引用别人处.\n\n用法: [quote]这里是引用[/quote]");
	} else if (basic) {
		stringManage(" [quote]","[/quote]");
	} else {   
		txt=prompt("以下内容将被引用","文字");     
		if(txt!=null) {          
			AddTxt=" [quote] "+txt+" [/quote]";
			AddText(AddTxt);
		}	        
	}
}

function showcolor(color) {
	if (helpstat) {
		alert("UBB颜色设置语句,提示内的颜色都可以引用.\n\n用法: [color="+color+"]这里是带有颜色的字体[/color]");
	} else if (basic) {
		stringManage("[color="+color+"] ","[/color]");
	} else {  
     	txt=prompt("以下文字颜色将变为 "+color,"文字");
		if(txt!=null) {
			AddTxt="[color="+color+"] "+txt+"[/color]";
			AddText(AddTxt);        
		} 
	}
}

function center() {
 	if (helpstat) {
		alert("UBB文字居中显示.\n\n用法: [center]文字将被居中[/center]");
	} else if (basic) {
		stringManage("[center]","[/center]");
	} else {  
		txt=prompt("以下文字将被居中","文字");     
		if (txt!=null) {          
			AddTxt="[center]"+txt+"[/center]";
			AddText(AddTxt);
		}	       
	}
}
function right() {
 	if (helpstat) {
		alert("UBB文字居右显示.\n\n用法: [right]文字将被居中[/right]");
	} else if (basic) {
		stringManage("[right] ","[/right]");
	} else {  
		txt=prompt("以下文字将被居右显示","文字");     
		if (txt!=null) {          
			AddTxt="[right]"+txt+"[/right]";
			AddText(AddTxt);
		}	       
	}
}

function move() {
 	if (helpstat) {
		alert("UBB文字居中显示.\n\n用法: [move]文字将被居中[/move]");
	} else if (basic) {
		stringManage("[move]","[/move]");
	} else {  
		txt=prompt("以下文字将被移动显示","文字");     
		if (txt!=null) {          
			AddTxt="[move]"+txt+"[/move]";
			AddText(AddTxt);
		}	       
	}
}

function hyperlink() {
	if (helpstat) {
		alert("UBB超级连接 \n放置URL作为超级连接.\n\n用法: [url]http://www.GamVan.com[/url]\n\n用法: [url=http://www.GamVan.com]连接文字[/url]");
	} else if (basic) {
		stringManage("[URL]","[/URL]");
	} else { 
		txt2=prompt("以下文字显示为URL连接.",""); 
		if (txt2!=null) {
			txt=prompt("下面URL转化为超级连接.","http://");      
			if (txt!=null) {
				if (txt2=="") {
					AddTxt="[URL]"+txt+"[/URL]";
					AddText(AddTxt);
				} else {
					AddTxt="[URL="+txt+"]"+txt2+"[/URL]";
					AddText(AddTxt);
				}         
			} 
		}
	}
}

function image() {
	if (helpstat){
		alert("UBB插入图片语句.\n\n用法: [img]http://www.GamVan.com/images.gif[/img]");
	} else if (basic) {
		stringManage("[img]","[/img]");
	} else {  
		txt=prompt("要插入图片的地址","http://");    
		if(txt!=null) {            
			AddTxt="[img]"+txt+"[/img]";
			AddText(AddTxt);
		}	
	}
}
function flash() {
	if (helpstat){
		alert("UBB插入flash动画语句.\n\n开放右键用法： [flash]http://www.GamVan.com/images/index/man.swf[/flash]\n\n屏闭右键用法：[fla]http://www.GamVan.com/images/index/man.swf[/fla]");
	} else if (basic) {
		stringManage("[flash]","[/flash]");
	} else {  
		txt=prompt("要插入flash动画的地址","http://");    
		if(txt!=null) {   
			var txt2 = prompt("SWF文件宽度和高度 例如：450,350 ","450,350");
			if (txt2!=null) {
				var w = txt2.substring(0, txt2.indexOf(","));
				var h = txt2.substring(txt2.indexOf(","),txt2.length);
				AddTxt="[flash=" + w + h + "]" + txt + "[/flash]";
				AddText(AddTxt);
			}
		}	
	}
}
function showcode() {
	if (helpstat) {
		alert("按照编号显示.\nUsefull for posting code.\n\n用法: [code]这是编号过的文字[/code]");
	} else if (basic) {
		stringManage("[code]","[/code]");
	} else {   
		txt=prompt("加入编号","");     
		if (txt!=null) {          
			AddTxt="[code]"+txt+"[/code]";
			AddText(AddTxt);
		}	       
	}
}

function underline() {
  	if (helpstat) {
		alert("文字下划线.\n\nUSE: [u]下划线文字[/u]");
	} else if (basic) {
		stringManage("[u]","[/u]");
	} else {  
		txt=prompt("文字已经下划线.","Text");     
		if (txt!=null) {           
			AddTxt="[u] "+txt+"[/u]";
			AddText(AddTxt);
		}	        
	}
}
function codes() {
  	if (helpstat) {
		alert("输入程序代码[code]在这里输入程序代码[/code]");
	} else if (basic) {
		stringManage("[code]","[/code]");
	} else {  
		txt=prompt("粘贴程序代码","Text");     
		if (txt!=null) {           
			AddTxt="[code]"+txt+"[/code]";
			AddText(AddTxt);
		}	        
	}
}
function htmls() {
  	if (helpstat) {
		alert("输入源代码内容![html]在这里输入代码[/html]");
	} else if (basic) {
		stringManage("[html]","[/html]");
	} else {  
		txt=prompt("粘贴源代码内容.","Text");     
		if (txt!=null) {           
			AddTxt="[html]"+txt+"[/html]";
			AddText(AddTxt);
		}	        
	}
}
function real() {
  	if (helpstat) {
		alert("插入启动real播放器播放的音频或视频[real]媒体文件的链接地址[/real]");
	} else if (basic) {
		stringManage("[real]","[/real]");
	} else {  
		txt=prompt("媒体文件的链接地址.","http://");     
		if (txt!=null) {
			var txt2 = prompt("媒体文件宽度和高度 例如：450,350 ","450,350");
			if (txt2!=null) {
				var w = txt2.substring(0, txt2.indexOf(","));
				var h = txt2.substring(txt2.indexOf(","),txt2.length);
				AddTxt="[real=" + w + h + "]" + txt + "[/real]";
				AddText(AddTxt);
			}
			
		}	        
	}
}
function win() {
  	if (helpstat) {
		alert("插入启动win媒体播放器播放的音频或视频[video]媒体文件的链接地址[/video]");
	} else if (basic) {
		stringManage("[video]","[/video]");
	} else {  
		txt=prompt("媒体文件的链接地址.","http://");     
		if (txt!=null) {       
			var txt2 = prompt("媒体文件宽度和高度 例如：300,80 ","300,80");
			if (txt2!=null) {
				var w = txt2.substring(0, txt2.indexOf(","));
				var h = txt2.substring(txt2.indexOf(","),txt2.length);
				AddTxt="[video=" + w + h + "]" + txt + "[/video]";
				AddText(AddTxt);
			}
		}	        
	}
}
function showfont(font) {
 	if (helpstat){
		alert("Font Tag Sets the font face for the enclosed text.\n\nUSE: [font="+font+"]The font of this text is "+font+"[/font]");
	} else if (basic) {
		stringManage("[font="+font+"]","[/font="+font+"]");
	} else {                  
		txt=prompt("Text to be in "+font,"Text");
		if (txt!=null) {             
			AddTxt="[font="+font+"]"+txt+"[/font="+font+"]";
			AddText(AddTxt);
		}        
	}  
}
