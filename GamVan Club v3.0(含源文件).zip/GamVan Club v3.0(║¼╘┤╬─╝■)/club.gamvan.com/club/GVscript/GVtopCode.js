// made in GamVan
function prtie(txt){
	parent.frames.window.status=txt;
	parent.frames.document.title=txt;
}
function prtie2(txt2){
	window.status=txt2;
}


function tabline(w,h,c){
	document.write("<table  bgcolor=\"" + c + "\" width=\""+ w + "\" height=\"" + h + "\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">");
	document.write("<tr><td></td></tr></table>");
	}


var DHTML = (document.getElementById || document.all || document.layers);    
var preImages = new Array(); 

function loadImages() {  
	for (i = 0; i < imgLen; i++) {  
		preImages[i] = new Image();  
		preImages[i].src = yourImages[i]; 
		//alert(yourImages[i]); 
	}  
}  
function gv_getObj(name) {    
	if (document.getElementById) {    
		return document.getElementById(name).style;    
	} else if (document.all) {   
		return document.all[name].style;    
	} else if (document.layers) {    
		return document.layers[name];    
	}    
}    

function gv_showWait(div,flag) {    
	if (!DHTML) return;    
		var x = gv_getObj(div);    
		x.visibility = (flag) ? 'visible':'hidden'    
		if(! document.getElementById) {  
			if(document.layers) {  
				x.left=280/2;  
			}  
		}  
	//loadImages();  
	return true;    
} 

function gv_textarea(formsName, num_c, num_r){ 
	document.write("<span onclick=\"javascript:document.Gforms."+ formsName + ".rows+= " + num_r + ";\" title=\"拉长\" style=\"cursor:hand\">");
	document.write("<img src=\"GVimgs/down.gif\" border=\"0\"></span>");
	document.write("&nbsp;&nbsp;<span onclick=\"javascript:if(document.Gforms."+ formsName + ".rows != "+ num_r + "){document.Gforms."+ formsName + ".rows-="+ num_r +";}else{document.Gforms."+ formsName + ".rows="+ num_r +";}\" title=\"缩短\" style=\"cursor:hand\">");
	document.write("<img src=\"GVimgs/up.gif\" border=\"0\"></span>");
}
function gv_textarea2(formsName, num_c, num_r){ 
	document.write("<span onclick=\"javascript:document.Gforms."+ formsName + ".rows+= " + num_r + ";\" title=\"拉长\" style=\"cursor:hand\">");
	document.write("<img src=\"../GVimgs/down.gif\" border=\"0\"></span>");
	document.write("&nbsp;&nbsp;<span onclick=\"javascript:if(document.Gforms."+ formsName + ".rows != "+ num_r + "){document.Gforms."+ formsName + ".rows-="+ num_r +";}else{document.Gforms."+ formsName + ".rows="+ num_r +";}\" title=\"缩短\" style=\"cursor:hand\">");
	document.write("<img src=\"../GVimgs/up.gif\" border=\"0\"></span>");
}
function checkAll(form){
	for (var i=0;i<form.elements.length;i++){
		var e = form.elements[i];
		if (e.name != 'chkall')
		e.checked = form.chkall.checked;
	}
}
//function winpop(url,width,height){
//window.open(url,"winpop", 'width='+ width + ',height=' + height +', left=300, top=200, resizable=1, status=no,scrollbars=yes,toolbar=no,menubar=no,location=no')
//}
function winpop(url, width, height){
	var Win = window.open(url,"openScript",'width=' + width + ',height=' + height + ', left=300, top=200, resizable=1,scrollbars=yes,menubar=no,status=no' );
}

function openPop(obj) {
    URL=obj.href;
    window.open(URL,'','width=510,height=220,top=20,scrollbars=0,resizable=1,scrollbars=yes');
    return false;
}

function openPop(obj, w, h, t, l) {
    URL=obj.href;
    window.open(URL,'',"width=" + w + ",height=" + h + ",top=" + t + ",left=" + l + ",scrollbars=0,resizable=1,scrollbars=yes");
    return false;
}

function openPop2(url, w, h, t, l) {
    window.open(url,'',"width=" + w + ",height=" + h + ",top=" + t + ",left=" + l + ",resizable=0,menubar=no,status=no,scrollbars=no");
}



function gConfirm(txt, gUrl){
	isDel = confirm(txt);
	if(isDel){
		location.assign(gUrl);
	}	
}

//提交表单
function postMsg(){
	var o=event.srcElement;
	o.gvSubmit.value="正在提交...";
	o.gvSubmit.disabled=true;
	o.gvBack.disabled=true;
}

//提交表单
function postMsg2(){
	var o=event.srcElement;
	o.gvSubmit2.value="正在提交...";
	o.gvSubmit2.disabled=true;
}

// this code powered by google
var agt = navigator.userAgent.toLowerCase();
var is_op = (agt.indexOf("opera") != -1);
var is_ie = (agt.indexOf("msie") != -1) && document.all && !is_op;
var is_ie5 = (agt.indexOf("msie 5") != -1) && document.all && !is_op;

function CreateXmlHttpReq(handler) {
  var xmlhttp = null;
  if (is_ie) {
    // Guaranteed to be ie5 or ie6
    var control = (is_ie5) ? "Microsoft.XMLHTTP" : "Msxml2.XMLHTTP";
    try {
      xmlhttp = new ActiveXObject(control);
      xmlhttp.onreadystatechange = handler;
    } catch (ex) {
      // TODO: better help message
      alert("You need to enable active scripting and activeX controls");  
    }
  } else {
    // Mozilla
    xmlhttp = new XMLHttpRequest();
    xmlhttp.onload = handler;
    xmlhttp.onerror = handler;
  }
  return xmlhttp;
}
// XMLHttp send POST request
function XmlHttpPOST(xmlhttp, url, data) {
  try {
    xmlhttp.open("POST", url, true);
    xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
    xmlhttp.send(data);

  } catch (ex) {
    // do nothing
  }
}

// XMLHttp send GEt request
function XmlHttpGET(xmlhttp, url) {
  try {
    xmlhttp.open("GET", url, true);	
    xmlhttp.send(null);
  } catch (ex) {
    // do nothing
  }
}

function copyUrl(){
	//document.write("<input onfocus=\"this.select();\" class=\"inputText\"  name=\"\" type=\"text\"  style='width:100%; height:20px;OVERFLOW: hidden;'   value=\""+self.location+"\" />");
	document.write(self.location);
}
