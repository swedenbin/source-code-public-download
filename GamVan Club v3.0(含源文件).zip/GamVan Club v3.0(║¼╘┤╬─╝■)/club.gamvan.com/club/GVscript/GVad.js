function adpic(obj, url ,w , h){
		document.writeln("<a href=\""+ url +"\" target=\"_blank\">");
		document.writeln("<img src=\""+ obj +"\" border=\"0\" ");
		if(w>0){document.write(" width=\""+ w +"\"");}
		if(h>0){document.write(" height=\""+ h +"\"");}
		document.write(" alt=\"广告\"/>");
		document.writeln("</a>");
}


function adflash(obj,wf,hf){
	
	    document.write("<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0\" ");
		document.write(" width=\""+ wf +"\" height=\""+ hf +"\">");
		document.write("<param name=\"movie\" value=\""+ obj +"\" />");
        document.write("<param name=\"quality\" value=\"high\" />");
        document.write("<embed src=\""+ obj +"\" quality=\"high\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" ");
		document.write(" type=\"application/x-shockwave-flash\" width=\""+ wf +"\" height=\""+ hf +"\"></embed>");
    	document.write("</object>");
		
}
function showad(obj, url ,w , h){
	var i, ext;
	i = obj.lastIndexOf(".");
	ext = obj.substring(i+1,obj.length);
	ext = ext.toLowerCase();

	switch(ext){
		case "gif":
			adpic(obj,url ,w , h);
			break;
		case "jpg":
			adpic(obj,url ,w , h);
			break;
		case "png":
			adpic(obj,url ,w , h);
			break;
		case "swf":
			adflash(obj,w,h);
			
			break;			
			
		default:
			adpic(obj,url);
	}
}
