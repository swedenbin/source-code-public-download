//Made In GamVan
document.write("<DIV id=\"topmenu\"><UL>");
document.write("<li><a href=\"/club/\">社区首页</a></li>");
document.write("<li><a href=\"http://www.gamvan.com/\">技术文摘</a></li>");
document.write("<li><a href=\"/club/index.jsp?url=clubClass.jsp?ccID=3\">网站建设</a></li>");
document.write("<li><a href=\"/club/index.jsp?url=clubClass.jsp?ccID=23\">站长交流</a></li>");
document.write("<li><a href=\"/club/index.jsp?url=clubClass.jsp?ccID=4\">JAVA技术</a></li>");
document.write("<li><a href=\"/club/index.jsp?url=clubClass.jsp?ccID=27\">安全阵线</a></li>");
document.write("<li><a href=\"/club/index.jsp?url=clubClass.jsp?ccID=40\">软件资源</a></li>");
document.write("<li><a href=\"/club/index.jsp?url=clubClass.jsp?ccID=38\">源码资源</a></li>");
document.write("<li><a href=\"/club/index.jsp?url=clubClass.jsp?ccID=15\">情定今生</a></li>");
document.write("<li><a href=\"/club/index.jsp?url=clubClass.jsp?ccID=7\">精彩贴图</a></li>");
document.write("<li><a href=\"/club/index.jsp?url=clubClass.jsp?ccID=32\">弦动我心</a></li>");
document.write("<li><a href=\"/club/index.jsp?url=clubClass.jsp?ccID=33\">电影分享</a></li>");
document.write("</UL></DIV>");
