// Made In GamVan
document.write("<table width=\"100%\"  border=\"0\" cellpadding=\"2\" cellspacing=\"1\" bgcolor=\"#e5e5e5\">");
document.write("<tr><td align=\"center\" bgcolor=\"#f6f6f6\">");
document.write(" Copyright &copy; 2001-2006 GamVan.com All Rights Reserved 今晚在线 版权所有 津ICP备05003701号");
document.write("</td>");
document.write("</tr></table>");
document.write("<a href=\"http://club.gamvan.com\" target=\"_blank\">");
document.write("<img src=\"/club/GVimgs/gamvanFoot.gif\" alt=\"今晚在线社区 GamVan Club\" border=\"0\" />");
document.write("</a>"); 
  
  

