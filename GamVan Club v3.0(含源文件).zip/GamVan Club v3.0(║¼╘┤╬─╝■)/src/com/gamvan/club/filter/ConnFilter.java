/*
 * Created on 2005-10-6
 * Last modified on 2005-10-6
 * Powered by GamVan.com
 */
package com.gamvan.club.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.hibernate.HibernateException;


import com.gamvan.conn.ConnClub;

public class ConnFilter implements Filter {
    protected FilterConfig filterConfig = null;
    
    public void init(FilterConfig filterconfig) throws ServletException {
        this.filterConfig = filterconfig;
        ConnClub.init();
    } 
    
    public void doFilter(ServletRequest request
            , ServletResponse response
            , FilterChain chain) throws IOException, ServletException 
    {
        try{
            chain.doFilter(request,response);
        }
        finally{
            try {
                ConnClub.closeSession2(); 
            }catch (HibernateException e) {
                e.printStackTrace();
            }
        }
    }
    
    public void destroy() {
       this.filterConfig = null;
        // TODO Auto-generated method stub  
    }
}
