/*
 * Created on 2006-1-22
 * Last modified on 2006-1-22
 * @author GamVan Studio by 我容易么我
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import com.gamvan.club.item.ClubCounterItem;

public interface ClubCounterDAO {

    /**
     * 社区统计相关信息
     * @param hits 点击数
     * @param tpv 今日pv
     * @param ct 社区主题
     * @param cr 社区回复
     * @param cb 社区注册用户男 人数
     * @param cg 社区注册用户女 人数
     * @param cm 最高在线人数
     * @param nu 最后注册用户名
     */
	public void counterUpdate(int hits, int tpv, int ct, int cr,
	            int cb, int cg, int cm, String nu);
	
	
	public ClubCounterItem clubCounterInfo();
	
	
}
