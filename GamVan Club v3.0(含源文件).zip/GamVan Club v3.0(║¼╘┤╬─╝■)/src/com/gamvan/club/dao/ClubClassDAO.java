/* 
 * Created on 2005-12-25
 * Last modified on 2006-1-23
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import java.util.List;

import com.gamvan.club.item.ClubClassItem;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public interface ClubClassDAO {
	
	
	public List classdList(String hql);
	
	/**
	 * 更新版面文章统计信息
	 * @param ccid 版面ID编号
	 * @param ct 主题数
	 * @param cr 回复数
	 * @return
	 * @author GamVan Studio by 我容易么我
	 */
	public boolean classCounter(int ccid, int ct, int cr);

	public ClubClassItem classInfo(int ccid);
}
