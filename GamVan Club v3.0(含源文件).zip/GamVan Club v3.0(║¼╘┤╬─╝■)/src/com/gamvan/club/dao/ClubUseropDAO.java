/* 
 * Created on 2005-12-3
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import java.util.List;

import com.gamvan.club.item.ClubUseropItem;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public interface ClubUseropDAO {
	
	public ClubUseropItem useropAdd(int userid, String user
			, int gradeid, int ccid
			, byte uois, String byuser
			, String byip, String bytime
		);
	
	/**
	 * 按主键删除
	 * @param id
	 * 2005-12-3 16:49:00 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public void useropDel(int id);
	
	/**
	 * 批量删除 SQL的in语句
	 * @param ids
	 * 2005-12-3 16:56:56 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public int useropDels(String[] ids);
	
	/**
	 * 更新
	 * @param id
	 * @param userid
	 * @param user
	 * @param gradeid
	 * @param ccid
	 * @param uois
	 * @param byuser
	 * @param byip
	 * @param bytime
	 * 2005-12-3 16:52:58 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public boolean useropUpdate(int id, int userid, String user
			, int gradeid, int ccid
			, byte uois, String byuser
			, String byip, String bytime);
	
	/**
	 * 按主键返回对象
	 * @param id
	 * @return
	 * 2005-12-3 16:54:10 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public ClubUseropItem useropInfo(int id);
	
	/**
	 * 按用户ID和版面ID返回对象
	 * @param userid
	 * @param ccid
	 * @param ccid1
	 * @param ccid2
	 * @return
	 * 2005-12-3 17:04:56 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public ClubUseropItem useropInfo(int userid, int ccid, int ccid1, int ccid2);
	public ClubUseropItem useropInfo(String user, int ccid, int ccid1, int ccid2);

	/**
	 * 管理员列表
	 * @param ccid
	 * @param ccid1
	 * @param ccid2
	 * @return
	 * 2005-12-3 17:09:10 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public List useroplist(int page, int pageNum, int ccid, int ccid1, int ccid2);
	public int useropCount(int ccid, int ccid1, int ccid2);
}
