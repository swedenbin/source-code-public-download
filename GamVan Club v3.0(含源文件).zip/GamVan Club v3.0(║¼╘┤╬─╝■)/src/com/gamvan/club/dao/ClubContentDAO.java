/*
 * Created on 2005-10-22
 * Last modified on 2006-1-22
 * @author GamVan Studio by 我容易么我
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import java.util.List;

import com.gamvan.club.item.ClubContentItem;
import com.gamvan.club.item.ClubContentReItem;

public interface ClubContentDAO {
    
    public boolean contentAdd();
    
    public boolean contentUpdate(int topicid);
    
    public boolean contentDel(int topicid);
    
    public ClubContentItem contentInfo(int topicid);
    
    public boolean contentReAdd();
    
    public boolean contentReUpdate(int topicreid);
    
    public boolean contentReDel(int topicreid);
    
    /** 标记删除  */
    public boolean contentReDel_(int topicreid, byte isdel);
    
    
    public ClubContentReItem contentReInfo(int topicreid);

    public List contentReList(int page, int pageNum, int topicid);
}
