/*
 * Created on 2005-10-24
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import java.util.List;

import com.gamvan.club.item.ClubUserItem;

public interface ClubUserDAO {

    
    public ClubUserItem userInfo(int id);
    public ClubUserItem userInfo(String name);
    
    /**
     * 依靠用户名和密码验证用户登录
     * @param uName
     * @param uPass
     * @return ClubUserItem
     */
    public ClubUserItem userLogin(String uName, String uPass);
    
    /**
     * 依靠用户ID和密码验证用户登录
     * @param uID
     * @param uPass
     * @return
     */
    public ClubUserItem userLogin(int uID, String uPass);
    
    public ClubUserItem userAdd();
    public void userUpdate(int id);
    
    /**
     * 用户登录时需要更新的信息
     * @param id 用户ID
     * @param lastip 最后登录IP	
     * @param lasttime 最后登录时间	
     * @param usermark 积分
     * @param usermoney 金币
     * @param usercredit 信誉
     * 2005-11-5 17:40:28 Made In GamVan
     * com.gamvan.club.dao
     */
    public void userLoginUpdate
    (int id, String lastip, String lasttime
    , double usermark, double usermoney, double usercredit);
    
    
    /**
     * 更新用户头像
     * @param userid
     * @param userpic
     * 2005-11-5 18:11:22 Made In GamVan
     * com.gamvan.club.dao
     */
    public void userHeadUpdate(int userid, String userpic);
    
    
    /**
     * 更新用户发帖回帖等各项参数
     * @param userid 用户ID	
     * @param uMark 积分
     * @param uMoney 金币
     * @param uCredit 信誉
     * @param isRe 是否为回复
     * @param tCount 主题或回复的累加数，一般只为1
     * 2005-11-5 18:16:37 Made In GamVan
     * com.gamvan.club.dao
     */
    public void userUpdate(int userid, double uMark, double uMoney,
            double uCredit, int isRe, int tCount);
    
    
	/**
	 * 用户列表信息，实现简单的查询， key_* 参数均作为查询参数
	 * @param page
	 * @param pageNum
	 * @param order 0默认按用户注册ID倒叙排列  1按登陆次数
	 * @param key_userName
	 * @param key_userIp
	 * @param key_userSex
	 * @param key_userAreaId
	 * @return
     * 2005-11-18 2:46:36 Made In GamVan
     * com.gamvan.club.dao
     */
    public List userList(int page, int pageNum, int order
    		, String key_userName, String key_userIp, byte key_userSex
    		, int key_userAreaId);
    public int userCount
    (String key_userName, String key_userIp, byte key_userSex
    		, int key_userAreaId);
    
    /* 逻辑删除 */
    public boolean userUpdate_isDel(int id, boolean isdel);
    
    /* 物理删除 */
    public boolean userDel(int id);
    
}







