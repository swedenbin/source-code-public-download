/*
 * Created on 2005-10-16
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import java.util.List;

/**
 * 主题相关列表的集合
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public interface ClubTopicListDAO {

    /**
     * 主题列表
     * @param page
     * @param pageNum
     * @param hqlOrder 追加在HQL语句后的排序规则
     * @return
     */
    public List topicList(int page, int pageNum, String hqlappend);
    public int topicCount(String hqlappend);
    
    /**
     * 回复列表
     * @param page
     * @param pageNum
     * @param hqlOrder 追加在HQL语句后的排序规则
     * @return
     */
    public List topicReList(int tid, int page, int pageNum, String hqlappend);
    public int topicReCount(int tid, String hqlappend);
    
    /**
     * 引用文章列表
     * @param page
     * @param pageNum
     * @param order 排序方式
     * @param ccid
     * @param tpro
     * @return
     * 2005-11-24 19:57:34 Made In GamVan
     * com.gamvan.club.dao
     */
    public List topicImportList
    	(int page, int pageNum, int order, int ccid, int tpro);
    
    public List topicAllList(int page, int pageNum, Boolean ispass, String hqlappend);
    public int topicAllCount(Boolean ispass, String hqlappend);
    
    public List topicReAllList(int page, int pageNum, Boolean ispass, String hqlappend);
    public int topicReAllCount(Boolean ispass, String hqlappend);

}
