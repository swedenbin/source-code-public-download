/* 
 * Created on 2005-11-30
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import java.util.List;

import com.gamvan.club.item.ClubTopicLogItem;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public interface ClubTopicLogDAO {
	
	public ClubTopicLogItem topicLogAdd();
	
	/**
	 * 根据主键更新日志信息
	 * @param id
	 * com.gamvan.club.dao
	 */
	public void topicLogUpdate(int id);
	
	/**
	 * 根据帖子ID、日志操作用户id、日志操作类型 查询日志信息
	 * @param topicid
	 * @param type 0查询主题帖子ID日志  1查询回复帖子ID日志
	 * @param byuserid
	 * @param logso
	 * @return
	 * com.gamvan.club.dao
	 */
	public ClubTopicLogItem topicLogInfo
		(int topicid, int type,  int byuserid, String logso);
	
	/**
	 * 
	 * @param ccid 版面id主键
	 * @param topicid 贴子主题id主键
	 * @param type 0查询主题帖子ID日志  1查询回复帖子ID日志
	 * @param loglist 是否显示的日志
	 * @return
	 * com.gamvan.club.dao
	 */
	public List topicLogList(int topicid, int type, int loglist);
	
	/**
	 * 
	 * @param page 分页显示-当前页
	 * @param pageNum 分页显示-每页显示行数
	 * @param ccid 版面id主键
	 * @param type 0查询主题帖子ID日志  1查询回复帖子ID日志
	 * @param loglist 是否显示的日志
	 * @return
	 * com.gamvan.club.dao
	 */
	public List topicLogList(int page, int pageNum
			, int ccid,  int type, int loglist);
	
	public int topicLogCount(int ccid,  int type, int loglist);

	public boolean topicLogDel(int id);
	public boolean topicLogDels(String[] ids);
	
	/**
	 * 按照主题批量删除日志
	 * @param topicid
	 * @return
	 * com.gamvan.club.dao
	 */
	public boolean topicLogDel_topicID(int topicid);
}
