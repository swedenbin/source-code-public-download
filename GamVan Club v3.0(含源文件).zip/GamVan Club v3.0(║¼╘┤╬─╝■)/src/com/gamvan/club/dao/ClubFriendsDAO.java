/* 
 * Created on 2005-12-1
 * Last modified on 2006-1-22
 * @author GamVan Studio by 我容易么我
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import java.util.List;

import com.gamvan.club.item.ClubFriendsItem;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public interface ClubFriendsDAO {
	
	/**
	 * 添加好友
	 * @param meid 操作用户ID
	 * @param meName 操作用户的名字
	 * @param friendid 朋友的ID
	 * @param friendname 朋友的名字
	 * @param addtime 添加时间
	 * @param message 申请好友时的消息提醒
	 * @param meip 操作IP
	 * @param isonline 是否在线
	 * @return
	 * 2005-12-1 14:15:10 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public ClubFriendsItem friendsAdd
		(int meid, String meName, int friendid, String friendname
		,String addtime, String message, String meip, int isonline);
	
	/**
	 * 按主键删除好友
	 * @param id
	 * 2005-12-1 14:18:28 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public void friendsDel(int id);
	
	/**
	 * 按主人ID和朋友ID查询好友
	 * @param meid
	 * @param friendid
	 * @return
	 * 2005-12-1 14:19:46 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public ClubFriendsItem friendsInfo(int meid, int friendid);
	
	/**
	 * 按主人ID和朋友用户名查询好友
	 * @param meid
	 * @param friendname
	 * @return
	 * 2005-12-1 14:21:01 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public ClubFriendsItem friendsInfo(int meid, String friendname);
	
	/**
	 * 好友列表
	 * @param page
	 * @param pageNum
	 * @param order
	 * @param meid
	 * @param isonline 在线、离线、隐身
	 * @return
	 * 2005-12-1 14:51:45 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public List friendsList(int page, int pageNum, String hqlappend, int meid, int isonline);
	public int friendsCount(int meid, int isonline, String hqlappend);
}
