/* 
 * Created on 2005-11-11
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import java.util.List;

import com.gamvan.club.item.ClubBusinessItem;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public interface ClubBusinessDAO {
	
	public ClubBusinessItem businessAdd();
	
	/**
	 * 删除交易记录
	 * @param id
	 * @param type 0按主键单独删除  1按用户ID批量删除
	 * 2005-11-11 14:37:39 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public void businessDel(int id, int type);
	
	public List businessList
	(int page, int pageNum, int userid, byte type);
	
	public int businessCount(int userid, byte type);
	
	

}
