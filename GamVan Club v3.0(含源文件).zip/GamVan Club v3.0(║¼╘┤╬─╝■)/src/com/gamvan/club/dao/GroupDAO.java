/* 
 * Created on 2005-11-17
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import java.util.List;

import com.gamvan.club.item.GroupItem;


public interface GroupDAO {
	
	public GroupItem groupAdd();
	
	public void groupDel(int id);
	
	public void groupUpdate(int id);
	
	/**
	 * 更新分组下统计数字
	 * @param id
	 * @param i
	 * @param type 更新方式; 累加或覆盖;
	 * 2005-11-17 21:54:53 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public void groupCountUpdate(int id, int i, int type);
	
	public GroupItem groupInfo(String s);
	public GroupItem groupInfo(int id);
	
	
	/**
	 * 
	 * @param page
	 * @param pageNum
	 * @param type
	 * @param order
	 * @return
	 * 2005-11-17 21:54:48 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public List groupList
	(int page, int pageNum, int layer, int type, int order);
	
	/**
	 * 
	 * @param page
	 * @param pageNum
	 * @param s
	 * @return
	 * 2005-11-17 21:54:44 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public List groupQuery(int page, int pageNum, String s);
	
}
