/* 
 * Created on 2005-11-13
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import java.util.List;

import com.gamvan.club.item.ClubTopicTypeItem;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public interface ClubTopicTypeDAO {

	
	/* 发购买贴获得的金币数，或是提问贴送出的积分数 */
	public double topicTypeNumed(int topicid, short typeinfo);
	
	public ClubTopicTypeItem topicTypeAdd();
	
	/**
	 * 更新信息
	 * @param topicid 贴子id
	 * @param userid 用户id
	 * @param typeInfo 贴子类型
	 * @return
	 * 2005-11-13 15:30:13 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public void topicTypeUpdate
		(int topicid, int userid, short typeInfo);
	
	public ClubTopicTypeItem topicTypeInfo
		(int topicid, int userid, short typeinfo);
	
	public List topicTypeList(int topicid, short typeinfo);
	
	/**
	 * 删除特殊类型帖子的相关记录
	 * @param topicid
	 * 2005-11-30 0:55:51 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public void topicTypeDel(int topicid);
}
