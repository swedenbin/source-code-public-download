/*
 * Created on 2006-1-9
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

public class ClubUpFilesDAO {
	
	
}
