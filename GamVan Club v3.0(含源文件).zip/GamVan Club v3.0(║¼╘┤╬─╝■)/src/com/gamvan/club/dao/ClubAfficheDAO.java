/*
 * Created on 2005-10-31
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import java.util.List;

import com.gamvan.club.item.ClubAfficheItem;


/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public interface ClubAfficheDAO {

    public ClubAfficheItem afficheInfo(int id);
    public ClubAfficheItem afficheAdd();
    public void afficheUpdate(int id);
    public void afficheDel(int id);
    
    /**
     * 分页公告
     * @param page
     * @param pageNum
     * @return
     */
    public List afficheList(int page, int pageNum, int ccid);
    public int afficheCount(int ccid);
}
