/* 
 * Created on 2005-11-4
 * Last modified on 2006-1-22
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import java.util.Collection;
import java.util.List;

import com.gamvan.club.item.ClubMessageSendItem;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public interface ClubMessageSendDAO {

	/* 消息发送数据表相关方法 */
	public ClubMessageSendItem messageSendInfo(int id);
	public ClubMessageSendItem messageSendAdd();
	
	/**
	 * 依据短信主键删除
	 * @param id
	 * @return
	 * 2005-12-27 3:08:35 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public boolean messageSendDel(int id);
	
	/**
	 * 依据短信用户ID批量删除
	 * @param id
	 * @return
	 * 2005-12-27 3:08:35 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public boolean messageSendDel_userid(int userid);
	
	/**
	 * 批量删除in语法
	 * @param ids
	 * @return
	 * 2005-11-4 5:41:07 Made In GamVan
	 */
	public int messageSendDel(Collection ids);
	
	
	/**
	 * 发件箱或草稿箱消息列表
	 * @param page 当前页
	 * @param pageNum 每页显示的数量
	 * @param sendid 发送此消息的用户ID
	 * @param sendis 判断是否发送，用以来判断消息是在发件箱还是在草稿箱。
	 * @return
	 * 2005-11-4 5:17:30 Made In GamVan
	 */
	public List messageSendList(int page, int pageNum, int sendid, boolean sendis);
	
	/**
	 * 统计总数为了分页
	 * @param sendid
	 * @param sendis
	 * @return
	 * 2005-11-4 5:20:10 Made In GamVan
	 */
	public int messageSendCount(int sendid, boolean sendis);
	
	/**
	 * 更改短消息状态[是否发送]
	 * @param id
	 * @param is
	 * @return
	 * 2005-11-29 20:02:53 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public void messageIsSendUpdate(int id, boolean is);
	
	
	
	
}
