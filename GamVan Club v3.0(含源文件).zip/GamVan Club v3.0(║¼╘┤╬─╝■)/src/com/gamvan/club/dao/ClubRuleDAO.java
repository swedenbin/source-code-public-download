/*
 * Created on 2005-10-28
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import com.gamvan.club.item.ClubRuleItem;

public interface ClubRuleDAO {

    
    public ClubRuleItem ruleInfo();
    
    /**
     * 更新社区制度
     * @param credit
     * @param mark
     * @param money
     * 2005-11-29 21:10:41 Made In GamVan
     * com.gamvan.club.dao
     */
    public void ruleUpdate(String credit, String mark, String money);
}
