/* 
 * Created on 2005-12-1
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import java.util.List;

import com.gamvan.club.item.ClubOnlineItem;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public interface ClubOnlineDAO {
	
	/**
	 * 加入到在线名单
	 * @param sessionid
	 * @param userip
	 * @param userid
	 * @param username
	 * @param userhide
	 * @param logintime
	 * @param lasttime
	 * @param lastymdhms 年月日时分秒组成的数字
	 * @return
	 * 2005-12-1 20:01:27 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public ClubOnlineItem onlineAdd(String sessionid, String userip
			, int userid, String username, boolean userhide
			, String logintime, String lasttime
			, long lastymdhms, String  userarea);
	
	/**
	 * 更新在线人员信息
	 * @param type 更新条件 1按照ip更新、2按照sessionid更新
	 * @param sessionid
	 * @param userid
	 * @param username
	 * @param lasttime
	 * @param lastymdhms 年月日时分秒组成的数字
	 * @param userarea
	 * 2005-12-1 20:05:44 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public void onlineUpdate(int type, String sessionid, String userip
			, int userid
			, String username, String lasttime
			, long ymdhms, String  userarea);
	
	/**
	 * 删除超时在线人员名单
	 * @param timeout 超时时间 按秒计算
	 * @param lasthms 最后更新 小时分秒组成的数字
	 * 2005-12-1 20:10:40 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public void onlineDelTimeout(long timeout);
	
	/**
	 * 
	 * @param page
	 * @param pageNum
	 * @return
	 * 2005-12-1 20:12:54 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public List onlineList(int page, int pageNum);
	public int onlineCount();
	
	/**
	 * 
	 * @param sessionid
	 * @param userip
	 * @param userid
	 * @return
	 * 2005-12-2 0:24:57 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public ClubOnlineItem onlineInfo(String sessionid, String userip, int userid);
}
