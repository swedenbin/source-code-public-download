/* 
 * Created on 2005-11-29
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import com.gamvan.club.item.ClubTopicReUsersItem;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public interface ClubTopicReUsersDAO {
	/**
	 * 
	 * @param tid 帖子ID
	 * @param reUsers 回复过的用户
	 * @return
	 * 2005-11-29 23:03:39 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public ClubTopicReUsersItem reUsersAdd(int tid, String reUsers);
	
	/**
	 * 
	 * @param tid 帖子ID
	 * @param reUsers 回复过的用户
	 * 2005-11-29 23:03:43 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public void reUsersUpdate(int tid, String reUsers);
	
	/**
	 * 
	 * @param tid 帖子ID
	 * @return
	 * 2005-11-29 23:03:46 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public ClubTopicReUsersItem reUsersInfo(int tid);
	
	/**
	 * 删除该贴的回复人员名单信息
	 * @param tid
	 * 2005-11-30 0:48:06 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public void reUsersDel(int tid);
	
}
