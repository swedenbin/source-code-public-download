/* 
 * Created on 2005-12-3
 * Last modified on 2006-1-22
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import com.gamvan.club.item.ClubInfoItem;


public interface ClubInfoDAO {
	
	public ClubInfoItem clubInfoAdd();
	public void clubInfoUpdate();
	public ClubInfoItem clubInfo();
		
	/**
	 * 更新注册协议
	 * @param regagree
	 * @author GamVan Studio by 我容易么我
	 */
	public void clubRegAgreeUpdate(String regagree);
	
	public void clubLastReIDUpdate(int lastreid);
}
