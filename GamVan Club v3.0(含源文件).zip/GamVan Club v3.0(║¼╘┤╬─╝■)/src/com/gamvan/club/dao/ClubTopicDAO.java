/*
 * Created on 2005-10-15
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;


import java.util.List;

import com.gamvan.club.item.ClubTopicItem;
import com.gamvan.club.item.ClubTopicReItem;

public interface ClubTopicDAO {
    
    /**
     * 认证以下id不为0的主题， 如果id为-1，则不加限定更新整个表数据
     * @param tid
     * @param reid
     * @return
     */
    public int topicUpdateIsPass(int tid, int reid, boolean ispass);
    
    
    /**
     * 更新帖子topicPro
     * @param id
     * @param reid 回复表自动编号，大于0则更新回复表 否则更新主题表
     * @param pro
     * @return
     */
    public int topicUpatePro(int id, int reid, int pro);

       
    /**
     * 删除主题表 物理删除
     * @param id
     * @return
     */
    public void topicDel(int id);
    
    /**
     * 删除回复表 物理删除
     * @param id 回复表主键
     * @return
     */
    public void topicReDel(int id);
    
    /**
     * 删除回复表，批量物理删除
     * @param id 回复表主题ID，非主键
     * @return
     */
    public void topicReDel_topicID(int id);
    
    /*用户的主题*/
    public int userTopicCount(int userid);
    public List userTopicList(int userid, int page, int pageNum);
    /*用户的回复*/
    public int userTopicReCount(int userid);
    public List userTopicReList(int userid, int page, int pageNum);
    
    
    /**
     * 更新主题表和回复表的帖子内容。
     * @param id
     */
    public void topicUpdate(int id);
    public void topicReUpdate(int id);
    
    
    /**
     * 更新主题表 topicReID 和 topicID 同步
     * @param id
     */
    public void topicID_reID(int id);
    
    /**
     * 更新主题表最后回复和最后回复时间
     * @param id
     */
    public void topicUpdateLastInfo(int id, int reid, String sTime, String sUser);
    
    public ClubTopicItem topicAdd();
    
    public ClubTopicReItem topicReAdd();

    /**
     * 更新察看次数
     * @param id
     */
    public boolean topicUpdateVcount(int id);
    
    /**
     * 察看次数
     * @param id
     */
    public boolean topicReUpdateVcount(int id);
    
    /**
     * 回复次数
     * @param id
     * @return
     */
    public boolean topicUpdateRcount(int id); //<主题表>
    public boolean topicReUpdateRcount(int id); //<回复表>
    
    /**
     * 帖子信息
     */
    public ClubTopicItem topicInfo(int id); //<主题表>
    public ClubTopicReItem topicReInfo(int id); //<回复表>
    
    
    /**
     * 依据reid是否为0判断回复的是主题还是回复从而更新回复主题表内的相关回复的排序
     * 如果reid为０则回复内容为主题 给以主题是id相关回复的topicOrder字段累加1
     * 否则只给topicOrder字段大于order的相关回复的 topicOrder字段累加1
     * @param id
     * @param reid
     * @param order
     * 2005-11-7 20:49:53 Made In GamVan
     * com.gamvan.club.dao
     */
    public void topicReUpdateOrder(int id, int reid, int order);
    
    /**
     * 更新帖子类型  目前主要用于结贴
     * @param id
     * @param type
     * 2005-11-13 22:17:54 Made In GamVan
     * com.gamvan.club.dao
     */
    public void topicTypeUpdate(int id, short type);
    
    /**
     * 移动帖子
     * @param tid 帖子
     * @param moveccid 目标版面ID
     * @param ccid1 版面ID
     * @param ccid2 版面ID
     * @param byuser 操作人员
     * @param movetime 移动时间 
     * @param savelink 判断送是否在原来的版面保留链接
     * 2005-12-1 1:19:31 Made In GamVan
     * com.gamvan.club.dao
     */
    public void topicMove(int tid, int moveccid
    		, int ccid1, int ccid2
    		, String byuser, String movetime
    		, String savelink
    );
    
    /* 对单独字段更新 限定int类型字段*/
    public void topicFieldUpdate(String where, String field, int num);
    public void topicFieldUpdate_re(String where, String field, int num);
    
    public void topicIsDelUpdate(int id, byte isdel);
    
    public void topicIsDelUpdate_re(int reid, byte isdel);
}
