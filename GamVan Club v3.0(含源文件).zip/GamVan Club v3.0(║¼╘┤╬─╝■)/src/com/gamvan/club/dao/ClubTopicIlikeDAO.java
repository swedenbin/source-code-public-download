/* 
 * Created on 2005-11-30
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao;

import java.util.List;

import com.gamvan.club.item.ClubTopicIlikeItem;

/**
 * 帖子订阅相关
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public interface ClubTopicIlikeDAO {
	
	/**
	 * 添加订阅信息
	  * @param topicid 帖子ID
	  * @param userid 用户ID
	  * @param topic 帖子标题
	  * @param username 用户名
	  * @param addtime 订阅时间
	  * @param lasttime 最后被查看的时间
	  * @param topiclastretime 帖子最后更新时间
	  * @param ccid
	 * @return
	 * 2005-11-30 14:50:07 Made In GamVan
	 * com.gamvan.club.dao
	 */
	 public ClubTopicIlikeItem ilikeAdd(int topicid, String topic
			 ,int myuserid, String myusername
			 ,int topicuserid, String topicusername
			 ,String addtime, String lasttime
			 ,String topiclastretime, int ccid);
	 
	 /**
	  * 更新订阅主题的最后被订阅人查看的时间
	  * @param topicid
	  * @param myuserid
	  * @param lasttime
	  * 2005-11-30 15:04:59 Made In GamVan
	  * com.gamvan.club.dao
	  */
	 public void ilikeUpdateLastTime(int topicid, int myuserid, String lasttime);
	 
	 /**
	  * 更新订阅主题的最后回复时间
	  * @param topicid
	  * @param lastReTime
	  * 2005-11-30 19:57:30 Made In GamVan
	  * com.gamvan.club.dao
	  */
	 public void ilikeUpdateLastReTime(int topicid, String lastReTime);
	 
	 /**
	  * 订阅信息
	  * @param topicid
	  * @param userid
	  * @return
	  * 2005-11-30 14:36:12 Made In GamVan
	  * com.gamvan.club.dao
	  */
	 public ClubTopicIlikeItem ilikeInfo(int topicid, int myuserid);
	 
	 /**
	  * 删除定阅
	  * @param id 
	  * @param type 0按主键、1按用户id删除、2按帖子id删除
	  * 2005-11-30 14:37:49 Made In GamVan
	  * com.gamvan.club.dao
	  */
	 public void ilikeDel(int id, int type);
	 
	 /**
	  * 被订阅的主题列表
	  * @param page
	  * @param pageNum
	  * @param topicid
	  * @param userid
	  * @return
	  * 2005-11-30 14:42:36 Made In GamVan
	  * com.gamvan.club.dao
	  */
	 public List ilikeList(int page, int pageNum, int topicid, int myuserid);
	 public int ilikeCount(int topicid, int myuserid);
}
