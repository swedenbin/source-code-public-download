/*
 * Created on 2005-10-24
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.Iterator;
import java.util.List;

import org.hibernate.CacheMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.ClubUserDAO;
import com.gamvan.club.item.ClubUserItem;
import com.gamvan.conn.ConnClub;


/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubUserImpl extends ClubUserItem implements ClubUserDAO{

    private static final long serialVersionUID = 1L;

    
    /**
     * 根据用户ID返回用户信息
     * @param id
     * @return
     * 2005-11-5 17:37:06 Made In GamVan
     * @see com.gamvan.club.dao.ClubUserDAO#userInfo(int)
     */
    public ClubUserItem userInfo(int id) {
    	ClubUserItem cui = null;
        Session session = ConnClub.getSession();
        String hql = new String();
        try{
            hql = "from ClubUserItem where userID=?";
            Query query = session.createQuery(hql)
            .setInteger(0, id);
            /* 启用查询缓存 */
            query.setCacheable(true); 
            /* 为查询指定其命名的缓存区域 */
            query.setCacheRegion("userCache");
            /*  从二级缓存读写数据 */
            query.setCacheMode(CacheMode.NORMAL);
            cui = (ClubUserItem)query.uniqueResult();
        }catch(Exception e){

        }
        return cui;
    }
    
    
    /**
     * 根据用户名返回用户信息
     * @param name
     * @return
     * 2005-11-5 17:34:34 Made In GamVan
     * @see com.gamvan.club.dao.ClubUserDAO#userInfo(java.lang.String)
     */
    public ClubUserItem userInfo(String name) {
        ClubUserItem cui = null;
        Session session = ConnClub.getSession();
        String hql = new String();
        try{
            hql = "from ClubUserItem where userName=?";
            Query query = session.createQuery(hql)
            .setString(0, name);
            /* 启用查询缓存 */
            query.setCacheable(true); 
            /* 为查询指定其命名的缓存区域 */
            query.setCacheRegion("userCache");
            /*  从二级缓存读写数据 */
            query.setCacheMode(CacheMode.NORMAL);
            cui = (ClubUserItem)query.uniqueResult();
        }catch(Exception e){

        }
       return cui;
    }

    
    /**
     * 根据用户名、密码登录系统
     * @param uName
     * @param uPass
     * @return
     * 2005-11-5 17:34:56 Made In GamVan
     * @see com.gamvan.club.dao.ClubUserDAO#userLogin(java.lang.String, java.lang.String)
     */
    public ClubUserItem userLogin(String uName, String uPass) {
        Session session = ConnClub.getSession();
        String hql = new String();
        ClubUserItem cui = null;
        try{
            hql = "from ClubUserItem where userName=? and userPass=?";
            Query query = session.createQuery(hql)
            .setString(0, uName)
            .setString(1, uPass);
            /* 启用查询缓存 */
            query.setCacheable(true); 
            /* 为查询指定其命名的缓存区域 */
            query.setCacheRegion("userCache");
            /* 从二级缓存读写数据 */
            query.setCacheMode(CacheMode.NORMAL);
            cui = (ClubUserItem)query.uniqueResult();
        }catch(HibernateException e){

        }
        return cui;
    }
    
    
    /**
     * 根据用户ID验证用户登录，一般用作系统登录后进行重要操作的最终确认
     * @param uID
     * @param uPass
     * @return
     * 2005-11-5 17:35:22 Made In GamVan
     * @see com.gamvan.club.dao.ClubUserDAO#userLogin(int, java.lang.String)
     */
    public ClubUserItem userLogin(int uID, String uPass) {
        Session session = ConnClub.getSession();
        String hql = new String();
        ClubUserItem cui = null;
        try{
            hql = "from ClubUserItem where userID=? and userPass=?";
            Query query = session.createQuery(hql)
            .setInteger(0, uID)
            .setString(1, uPass)
            ;
            /* 启用查询缓存 */
            query.setCacheable(true); 
            /* 为查询指定其命名的缓存区域 */
            query.setCacheRegion("userCache");
            /* 从二级缓存读写数据 */
            query.setCacheMode(CacheMode.NORMAL);
            cui = (ClubUserItem)query.uniqueResult();
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return cui;
    }
    
    /**
     * 向数据表添加用户信息
     * @return
     * 2005-11-5 17:36:24 Made In GamVan
     * @see com.gamvan.club.dao.ClubUserDAO#userAdd()
     */
    public ClubUserItem userAdd() {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        ClubUserItem cui = null;
        try{
            cui = new ClubUserItem();
            cui.setUserName(userName);
            cui.setUserPass(userPass);
            cui.setUserName2(userName2);
            cui.setUserSex(userSex);
            cui.setUserEmail(userEmail);
            cui.setUserEmailOpen(userEmailOpen);
            cui.setUserQuestion(userQuestion);
            cui.setUserAnswer(userAnswer);
            cui.setUserWeb(userWeb);
            cui.setUserQQ(userQQ);
            cui.setUserArea(userArea);
            cui.setUserCity(userCity);
            cui.setUserWork(userWork);
            cui.setUserPen(userPen);
            cui.setUserIntro(userIntro);
            cui.setUserUpfile(userUpfile);
            cui.setUserTxt(userTxt);
            cui.setUserRegTime(userRegTime);
            cui.setUserLastTime(userLastTime);
            cui.setUserLoginTimes(0);
            cui.setUserRegip(userRegip);
            cui.setUserLastip(userLastip);
            cui.setUserMoney(userMoney);
            cui.setUserMark(userMark);
            cui.setUserDeposit(0); //用户存款
            cui.setUserCredit(userCredit);         
            cui.setUserTopicCount(0);
            cui.setUserReCount(0);
            cui.setUserIsDel(userIsDel);
            cui.setUserUpfileOpen(userUpfileOpen);
            cui.setUserUpfileSize(userUpfileSize);
            cui.setUserPic(userPic);
            cui.setUserPicIs(userPicIs);
            cui.setUserAreaId(userAreaId);
            session.save(cui);
            session.flush();
            tran.commit(); 
        }catch(HibernateException e){
            cui = null;
            e.printStackTrace();
        }
        return cui;
    }
    
    
    /**
     * 更新用户注册资料
     * @param id
     * 2005-11-5 17:36:46 Made In GamVan
     * @see com.gamvan.club.dao.ClubUserDAO#userUpdate(int)
     */
    public void userUpdate(int id) {
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        Transaction tran = session.beginTransaction();
        try{
            hql.append("update ClubUserItem ");
            hql.append(" set userPass=?");
            hql.append(", userName2=?");
            hql.append(", userSex=?");
            hql.append(", userEmail=?");
            hql.append(", userEmailOpen=?");
            hql.append(", userBirthday=?");
            hql.append(", userWeb=?");
            hql.append(", userQQ=?");
            hql.append(", userArea=?");
            hql.append(", userCity=?");
            hql.append(", userWork=?");
            hql.append(", userPen=?");
            hql.append(", userIntro=?");
            hql.append(", userAreaId=?");
            hql.append(" where userID=?");
            session.createQuery(hql.toString())
            .setString(0, userPass)
            .setString(1, userName2)
            .setByte(2, userSex)
            .setString(3, userEmail)
            .setShort(4, userEmailOpen)
            .setString(5, userBirthday)
            .setString(6, userWeb)
            .setString(7, userQQ)
            .setString(8, userArea)
            .setString(9, userCity)
            .setString(10, userWork)
            .setString(11, userPen)
            .setString(12, userIntro)
            .setInteger(13, userAreaId)
            .setInteger(14, id)
            .executeUpdate();
            tran.commit();
        }catch(HibernateException e){
            e.printStackTrace();
            throw new HibernateException("资料更新失败：" + e.toString());
        }
    }

    
    
    /**
     * 用户登录时需要更新的信息
     * @param id 用户ID
     * @param lastip 最后登录IP	
     * @param lasttime 最后登录时间	
     * @param usermark 积分
     * @param usermoney 金币
     * @param usercredit 信誉
     * 2005-11-5 17:40:28 Made In GamVan
     * com.gamvan.club.dao
     */
	public void userLoginUpdate	(int id, String lastip, String lasttime, 
			double usermark, double usermoney, double usercredit)
	{
		try{
	           
			Session session = ConnClub.getSession();
	        StringBuffer hql = new StringBuffer();
	        Transaction tran = session.beginTransaction();
	        hql.append("update ClubUserItem set userLastTime=?");
	        hql.append(", userLoginTimes=userLoginTimes+1");
	        hql.append(", userLastip=?");
	        hql.append(", userMoney=userMoney+?");
	        hql.append(", userMark=userMark+?");
	        hql.append(", userCredit=userCredit+?");
	        hql.append(" where userID=?");
	        Query query = session.createQuery(hql.toString())
	        .setString(0, lasttime)
	        .setString(1, lastip)
	        .setDouble(2, usermoney)
	        .setDouble(3, usermark)
	        .setDouble(4, usercredit)
	        .setInteger(5, id);
	        query.executeUpdate();
	        tran.commit();
	    }catch(HibernateException e){
	    
	    }
	}

    /**
     * 
     * @param userid
     * @param userpic
     * 2005-11-5 18:11:15 Made In GamVan
     * @see com.gamvan.club.dao.ClubUserDAO#userHeadUpdate(int, java.lang.String)
     */
	public void userHeadUpdate(int userid, String userpic) {
		Session session = ConnClub.getSession();
		String hql = new String();
		Transaction tran = session.beginTransaction();
		try{
			hql = "Update ClubUserItem set userPic=? where userID=?";
			Query query = session.createQuery(hql)
			.setString(0, userpic)
			.setInteger(1, userid);
			query.executeUpdate();
			tran.commit();
	    }catch(HibernateException e){
	    }
	}

    /**
     * 更新用户发帖回帖等各项参数
     * @param userid 用户ID	
     * @param uMark 积分
     * @param uMoney 金币
     * @param uCredit 信誉
     * @param isRe 是否为回复
     * @param tCount 主题或回复的累加数，一般只为1
     * 2005-11-5 18:16:37 Made In GamVan
     * com.gamvan.club.dao
     */
	public void userUpdate(int userid
			, double uMark, double uMoney, double uCredit
			, int isRe, int tCount) 
	{
		Session session = ConnClub.getSession();
		StringBuffer hql = new StringBuffer();
		Transaction tran = session.beginTransaction();
		try{
	        hql.append("update ClubUserItem set ");
	        hql.append(" userMoney=userMoney+?");
	        hql.append(", userMark=userMark+?");
	        hql.append(", userCredit=userCredit+?");
			if(isRe==0){
				hql.append(", userTopicCount=userTopicCount+"+ tCount +"");
			}
	        else if(isRe==1){
	            hql.append(", userReCount=userReCount+"+ tCount +"");
	        }
	        hql.append(" where userID=?");
			Query query = session.createQuery(hql.toString())
			.setDouble(0, uMoney)
			.setDouble(1, uMark)
			.setDouble(2, uCredit)
			.setInteger(3, userid);
			query.executeUpdate();
			tran.commit();   
	       }catch(HibernateException e){
	       }		
	}

	/**
	 * 用户列表信息，实现简单的查询， key_* 参数均作为查询参数
	 * @param page
	 * @param pageNum
	 * @param order 0默认按用户注册ID倒叙排列  1按登陆次数
	 * @param key_userName
	 * @param key_userIp
	 * @param key_userSex  为-1则不作查询条件
	 * @param key_userAreaId  为-1则不作查询条件
	 * @return
	 * 2005-11-18 2:46:08 Made In GamVan
	 * @see com.gamvan.club.dao.ClubUserDAO#userList(int, int, int, java.lang.String, java.lang.String, byte, int)
	 */
	public List userList(int page, int pageNum, int order
			, String key_userName, String key_userIp
			, byte key_userSex, int key_userAreaId)
	{
        /* 计算从第几条记录开始读取数据 */
        if(page<1)page=1;
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        List list = null;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubUserItem where userID>0");
            if(key_userSex!=-1){
                hql.append(" and userSex="+ key_userSex +"");
            }
            if(key_userIp!=null && !key_userIp.equals("")){
                hql.append(" and (userRegIp like '%"+ key_userIp +"%'");
                hql.append(" or userLastip like '%"+ key_userIp +"%')");
            }
            if(key_userName!=null && !key_userName.trim().equals("")){
            	key_userName = key_userName.trim();
                hql.append(" and userName like ?");
            }
            if(key_userAreaId!=-1){
            	hql.append(" and userAreaId=");
            	hql.append(key_userAreaId);
            }            
            if(order==0){
                hql.append(" order by userID desc");
            }
            else if(order==1){
            	hql.append(" order by userLoginTimes desc");
            }
            Query query = session.createQuery(hql.toString());
            if(key_userName!=null && !key_userName.equals("")){
                query.setString(0, "%"+ key_userName +"%");
            }
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();  
        }catch(HibernateException e){
            e.printStackTrace();
        }      
        return list;
	}

	/**
	 * 
	 * @param key_userName
	 * @param key_userIp
	 * @param key_userSex 为-1则不作查询条件
	 * @param key_userAreaId 为-1则不作查询条件
	 * @return
	 * 2005-11-18 2:48:49 Made In GamVan
	 * @see com.gamvan.club.dao.ClubUserDAO#userCount(java.lang.String, java.lang.String, byte, int)
	 */
	public int userCount(String key_userName, String key_userIp
			, byte key_userSex, int key_userAreaId) 
	{
        int i = 0;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("select count(*) from ClubUserItem where userID>0");
            if(key_userSex!=-1){
                hql.append(" and userSex="+ key_userSex +"");
            }
            if(key_userIp!=null && !key_userIp.equals("")){
            	key_userIp = key_userIp.trim();
                hql.append(" and (userRegIp like '%"+ key_userIp +"%'");
                hql.append(" or userLastip like '%"+ key_userIp +"%')");
            }
            if(key_userName!=null && !key_userName.equals("")){
            	key_userName = key_userName.trim();
                hql.append(" and userName like ?");
            }
            if(key_userAreaId!=-1){
            	hql.append(" and userAreaId=");
            	hql.append(key_userAreaId);
            } 
            Query query = session.createQuery(hql.toString());
            if(key_userName!=null && !key_userName.equals("")){
                query.setString(0, "%"+ key_userName +"%");
            }
            List list = query.list();
            Iterator it = list.iterator();
            Integer results = null;
            while(it.hasNext()){
                results = (Integer) it.next();
                i = results.intValue();
            } 
        }catch(HibernateException e){
            i = 0;
            e.printStackTrace();
        }       
        return i;
	}

	/**
	 * 标记删除用户
	 * @param id
	 * @param isdel
	 * @return
	 * 2005-12-27 11:01:26 Made In GamVan
	 * @see com.gamvan.club.dao.ClubUserDAO#userUpdate_isDel(int, boolean)
	 */
	public boolean userUpdate_isDel(int id, boolean isdel) {
        boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubUserItem set userIsDel=? where userID=?");
            Query query = session.createQuery(hql.toString())
            .setBoolean(0, isdel)
            .setInteger(1, id);
            int i = query.executeUpdate();
            tran.commit();
            session.evict(ClubUserItem.class);
            if(i>0){
                bea = true;
            }
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return bea;
	}

	/**
	 * 物理删除用户
	 * @param id
	 * @return
	 * 2005-12-27 11:01:44 Made In GamVan
	 * @see com.gamvan.club.dao.ClubUserDAO#userDel(int)
	 */
	public boolean userDel(int id) {
        boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("delete ClubUserItem where userID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, id);
            int i = query.executeUpdate();
            tran.commit();
            session.evict(ClubUserItem.class);
            if(i>0){
                bea = true;
            }
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return bea;
	}

}






