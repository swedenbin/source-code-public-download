/* 
 * Created 2005-11-30
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.ClubTopicLogDAO;
import com.gamvan.club.item.ClubTopicLogItem;
import com.gamvan.conn.ConnClub;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicLogImpl extends ClubTopicLogItem 
	implements ClubTopicLogDAO
{
	private static final long serialVersionUID = 1L;
	private static final Logger logger = 
    	Logger.getLogger(ClubTopicLogImpl.class.getName());
	/**
	 * @return
	 * 2005-11-30 22:47:24 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicLogDAO#topicLogAdd()
	 */
	public ClubTopicLogItem topicLogAdd() {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        ClubTopicLogItem ctli = new ClubTopicLogItem();
    	try{
            ctli.setUserID(userID);
            ctli.setUserName(userName);
            ctli.setTopic(topic);
            ctli.setTopicID(topicID);
            ctli.setTopicLogTxt(topicLogTxt);
            ctli.setTopicLogByUserID(topicLogByUserID);
            ctli.setTopicLogByUserName(topicLogByUserName);
            ctli.setTopicLogByUserIP(topicLogByUserIP);
            ctli.setTopicLogByDateTime(topicLogByDateTime);
            ctli.setUserCredit(userCredit);
            ctli.setUserMark(userMark);
            ctli.setUserMoney(userMoney);
            ctli.setTopicLogSo(topicLogSo);
            ctli.setTopicLogByUserList(topicLogByUserList);
            ctli.setTopicLogList(topicLogList);
            ctli.setTopicReID(topicReID);
            ctli.setCcID(ccID);
            session.save(ctli);
            tran.commit();
    	}catch(HibernateException e){
    		logger.error(e.toString());
    	}
    	return ctli;
	}
	
	/**
	 * 
	 * @param id
	 * 2005-11-30 23:10:42 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicLogDAO#topicLogUpdate(int)
	 */
	public void topicLogUpdate(int id) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer("");
		try{
            hql.append("update ClubTopicLogItem set ");
            hql.append(" topic=?");
            hql.append(", topicLogTxt=?");
            hql.append(", topicLogByUserIP=?");
            hql.append(", topicLogByDateTime=?");
            hql.append(", userCredit=?");
            hql.append(", userMark=?");
            hql.append(", userMoney=?");
            hql.append(", topicLogSo=?");
            hql.append(", topicLogByUserList=?");
            hql.append(" where topicLogID=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, topic)
            .setString(1, topicLogTxt)
            .setString(2, topicLogByUserIP)
            .setString(3, topicLogByDateTime)
            .setDouble(4, userCredit)
            .setDouble(5, userMark)
            .setDouble(6, userMoney)
            .setString(7, topicLogSo)
            .setShort(8, topicLogByUserList)
            .setInteger(9, id);
            query.executeUpdate();
            tran.commit();
		}catch(HibernateException e){
			logger.error(e.toString());
		}	
	}
	
	/**
	 * 根据帖子ID、日志操作用户id、日志操作类型 查询日志信息
	 * @param topicid
	 * @param type 0查询主题帖子ID日志  1查询回复帖子ID日志
	 * @param byuserid
	 * @param logso
	 * @return
	 * 2005-11-30 23:03:54 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicLogDAO#topicLogInfo(int, int, int, java.lang.String)
	 */
	public ClubTopicLogItem topicLogInfo
		(int topicid, int type, int byuserid, String logso) 
	{
		Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer("");
        ClubTopicLogItem ctli = null;
        if(type==1){
            hql.append("from ClubTopicLogItem where topicReID=? and topicLogByUserID=?");
            hql.append(" and topicLogSo=?");
        }
        else if(type==0){
            hql.append("from ClubTopicLogItem where topicID=? and topicLogByUserID=?");
            hql.append(" and topicLogSo=?");
        }
        else{
        	return null;
        }
		try{
            Query query = session.createQuery(hql.toString())
            .setInteger(0, topicid)
            .setInteger(1, byuserid)
            .setString(2, logso);
            query.setMaxResults(1);
            ctli = (ClubTopicLogItem)query.uniqueResult();
		}catch(HibernateException e){
			logger.error(e.toString());
		}
		return ctli;
	}
	
	/**
	 * 帖子管理日志列表
	 * @param ccid 版面id主键
	 * @param topicid 贴子主题id主键
	 * @param type 0查询主题帖子ID日志  1查询回复帖子ID日志
	 * @param loglist 是否显示的日志
	 * @see com.gamvan.club.dao.ClubTopicLogDAO#topicLogList(int, int, int)
	 * com.gamvan.club.dao.impl
	 */
	public List topicLogList(int topicid, int type, int loglist){
		StringBuffer hql = new StringBuffer("");
     	if(type==0){
            hql.append("from ClubTopicLogItem where topicReID=0 and topicID=");
    	}
     	else if(type==1){
            hql.append("from ClubTopicLogItem where topicReID=");
    	}
     	else{
    		return null;
    	}
     	hql.append(topicid);
     	if(loglist!=-1){
        	hql.append(" and topicLogList=");
        	hql.append(loglist);
        }
     	hql.append(" order by topicLogID desc");
        Session session = ConnClub.getSession();
        List list = null;
        try{
            Query query = session.createQuery(hql.toString());
            list = query.list(); 
        }catch(HibernateException e){
        	e.printStackTrace();
        }
        return list;
	}
	
	/**
	 * @param page 分页显示-当前页
	 * @param pageNum 分页显示-每页显示行数
	 * @param ccid 版面id主键
	 * @param type 0查询主题帖子ID日志  1查询回复帖子ID日志
	 * @param loglist 是否显示的日志
	 * @return
	 * @see com.gamvan.club.dao.ClubTopicLogDAO#topicLogList(int, int, int, int, int)
	 * com.gamvan.club.dao.impl
	 */
	public List topicLogList(int page, int pageNum
			, int ccid, int type, int loglist) {
        if(page<1){page=1;}
        /* 计算从第几条记录开始读取数据 */   
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
		StringBuffer hql = new StringBuffer("");
		hql.append("from ClubTopicLogItem ");
		if(type==0){
            hql.append(" where topicReID=0 ");
            if(ccid!=-1){
         		hql.append(" and ccID=");
         		hql.append(ccid);
         	}
    	}
     	else if(type==1){
            hql.append("  where topicReID>0 ");
            if(ccid!=-1){
         		hql.append(" and ccID=");
         		hql.append(ccid);
         	}
    	}else{
    		if(ccid!=-1){
         		hql.append(" where ccID=");
         		hql.append(ccid);
         	}
    	}
     	if(loglist!=-1){
        	hql.append(" and topicLogList=");
        	hql.append(loglist);
        }
     	hql.append(" order by topicLogID desc");
        Session session = ConnClub.getSession();
        List list = null;
        try{
            Query query = session.createQuery(hql.toString());
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list(); 
        }catch(HibernateException e){
        	logger.error(e.toString());
        	return null;
        }
        return list;
	}

	public int topicLogCount(int ccid, int type, int loglist) {
		int i = 0;
		StringBuffer hql = new StringBuffer("");
		hql.append("select count(*) from ClubTopicLogItem ");
		if(type==0){
            hql.append(" where topicReID=0 ");
            if(ccid!=-1){
         		hql.append(" and ccID=");
         		hql.append(ccid);
         	}
    	}
     	else if(type==1){
            hql.append("  where topicReID>0 ");
            if(ccid!=-1){
         		hql.append(" and ccID=");
         		hql.append(ccid);
         	}
    	}else{
    		if(ccid!=-1){
         		hql.append(" where ccID=");
         		hql.append(ccid);
         	}
    	}
     	if(loglist!=-1){
        	hql.append(" and topicLogList=");
        	hql.append(loglist);
        }
     	try{
	        Session session = ConnClub.getSession();
	        Query query = session.createQuery(hql.toString());
	        Iterator it =  query.iterate();
	        Integer results = null;
	        while(it.hasNext()){
	            results = (Integer) it.next();
	            i = results.intValue();
	        }
     	}catch(HibernateException e){
     		logger.error(e.toString());
        	return 0;
        }
		return i;
	}
	
	/**
	 * 删除日志
	 * @param id
	 * @return
	 * @see com.gamvan.club.dao.ClubTopicLogDAO#topicLogDel(int)
	 * com.gamvan.club.dao.impl
	 */
	public boolean topicLogDel(int id) {
		boolean bea = false;
		StringBuffer hql = new StringBuffer("");
		hql.append("delete from ClubTopicLogItem where topicLogID=?");
		Session session = ConnClub.getSession();
		Transaction tran = session.beginTransaction();
        try{
        	Query query = session.createQuery(hql.toString());
        	query.setInteger(0, id);
        	query.executeUpdate();
        	tran.commit();
        	bea = true;
        }catch(HibernateException e){
     		logger.error(e.toString());
        }
		return bea;
	}
	
	/**
	 * 批量删除日志
	 * @param ids
	 * @return
	 * @see com.gamvan.club.dao.ClubTopicLogDAO#topicLogDels(java.lang.String[])
	 * com.gamvan.club.dao.impl
	 */
	public boolean topicLogDels(String[] ids) {
		boolean bea = false;
		StringBuffer hql = new StringBuffer("");
		hql.append("delete from ClubTopicLogItem where topicLogID in (:ids)");
		Session session = ConnClub.getSession();
		Transaction tran = session.beginTransaction();
        try{
        	Query query = session.createQuery(hql.toString());
        	query.setParameterList("ids", ids); 
        	query.executeUpdate();
        	tran.commit();
        	bea = true;
        }catch(HibernateException e){
     		logger.error(e.toString());
        }
		return bea;
	}
	
	/**
	 * 按照主题批量删除日志
	 * @param topicid
	 * @return
	 * @see com.gamvan.club.dao.ClubTopicLogDAO#topicLogDel_topicID(int)
	 * com.gamvan.club.dao.impl
	 */
	public boolean topicLogDel_topicID(int topicid) {
		boolean bea = false;
		StringBuffer hql = new StringBuffer("");
		hql.append("delete from ClubTopicLogItem where topicID=?");
		Session session = ConnClub.getSession();
		Transaction tran = session.beginTransaction();
        try{
        	Query query = session.createQuery(hql.toString());
        	query.setInteger(0, topicid);
        	query.executeUpdate();
        	tran.commit();
        	bea = true;
        }catch(HibernateException e){
     		logger.error(e.toString());
        }
		return bea;
	}
	
	/* test
	public static void main(String args[]){
		ConnClub.init();
		ClubTopicLogImpl ctli = new ClubTopicLogImpl();
		ctli.topicLogList(7019, 0, 1);
	}
	*/
}
