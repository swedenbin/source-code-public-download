/* 
 * Created on 2005-11-17
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.List;

import org.hibernate.CacheMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.GroupDAO;
import com.gamvan.club.item.GroupItem;
import com.gamvan.conn.ConnClub;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class GroupImpl extends GroupItem 
	implements GroupDAO
{
	private static final long serialVersionUID = 1L;
	
	/**
	 * 
	 * @return
	 * 2005-11-17 21:57:36 Made In GamVan
	 * @see com.gamvan.club.dao.GroupDAO#groupAdd()
	 */
	public GroupItem groupAdd() {
		GroupItem gi = null;
        Session session = ConnClub.getSession();
        Transaction tran = null;
        try{
            tran = session.beginTransaction();
            gi = new GroupItem();
            gi.setGroupName(groupName);
            gi.setGroupIDD(groupIDD);
            gi.setGroupLayer(groupLayer);
            gi.setGroupOrder(groupOrder);
            gi.setGroupType(groupType);
            gi.setGroupCount(0);
            session.save(gi);
            tran.commit(); 
        }catch(Exception e){
        	
        }  
        return gi;
	}
	
	/**
	 * 
	 * @param id
	 * 2005-11-17 21:57:41 Made In GamVan
	 * @see com.gamvan.club.dao.GroupDAO#groupDel(int)
	 */
	public void groupDel(int id) {
		Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        try{
        	String hql = "delete from GroupItem where groupID=?";
            Query query = session.createQuery(hql)
            .setInteger(0, id);
            query.executeUpdate();
            tran.commit();          
        }catch(HibernateException e){

        }
		
	}
	
	/**
	 * 
	 * @param id
	 * 2005-11-17 21:58:10 Made In GamVan
	 * @see com.gamvan.club.dao.GroupDAO#groupUpdate(int)
	 */
	public void groupUpdate(int id) {
		Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update GroupItem Set ");
            hql.append("groupName=?, groupIDD=?");
            hql.append(", groupLayer=?, groupType=?");
            hql.append(", groupOrder=? where groupID=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, groupName)
            .setInteger(1, groupIDD)
            .setInteger(2, groupLayer)
            .setInteger(3, groupType)
            .setInteger(4, groupOrder)
            .setInteger(5, id);
            query.executeUpdate();
            tran.commit();
        }catch(Exception e){

        }		
	}
	
	/**
	 * 
	 * @param id
	 * @param i
	 * @param type 如果为1则累加方式更新;如果为2则覆盖方式更新;
	 * 2005-11-18 13:39:40 Made In GamVan
	 * @see com.gamvan.club.dao.GroupDAO#groupCountUpdate(int, int, int)
	 */
	public void groupCountUpdate(int id, int i, int type) {
		Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update GroupItem Set ");
            if(type==1){
            	hql.append(" groupCount=groupCount+");
            	hql.append(i);
            } 
            else if(type==2){
            	hql.append(" groupCount=");
            	hql.append(i);
            }
            if(id!=-1){
            	hql.append(" where groupID=");
            	hql.append(id);
            }
            Query query = session.createQuery(hql.toString());
            query.executeUpdate();
            tran.commit();
        }catch(Exception e){

        }
	}
	
	/**
	 * 
	 * @param s
	 * @return
	 * 2005-11-17 22:00:38 Made In GamVan
	 * @see com.gamvan.club.dao.GroupDAO#groupInfo(java.lang.String)
	 */
	public GroupItem groupInfo(String s) {
		Session session = ConnClub.getSession();
        GroupItem gi = null;
        String hql = "";
        try{
            hql = "from GroupItem where groupName=?";
            Query query = session.createQuery(hql)
            .setString(0, s);
            //启用查询缓存
            query.setCacheable(true); 
            //为查询指定其命名的缓存区域
            query.setCacheRegion("groupCache");
            //* 从二级缓存读写数据
            query.setCacheMode(CacheMode.NORMAL);
            gi = (GroupItem)query.uniqueResult();
        }catch(HibernateException e){
            gi = null;
            e.printStackTrace();
        }
        return gi;
	}
	
	/**
	 * 
	 * @param id
	 * @return
	 * 2005-11-17 22:00:34 Made In GamVan
	 * @see com.gamvan.club.dao.GroupDAO#groupInfo(int)
	 */
	public GroupItem groupInfo(int id) {
		Session session = ConnClub.getSession();
        GroupItem gi = null;
        String hql = "";
        try{
            hql = "from GroupItem where groupID=?";
            Query query = session.createQuery(hql)
            .setInteger(0, id);
            //启用查询缓存
            query.setCacheable(true); 
            //为查询指定其命名的缓存区域
            query.setCacheRegion("groupCache");
            //* 从二级缓存读写数据
            query.setCacheMode(CacheMode.NORMAL);
            gi = (GroupItem)query.uniqueResult();
        }catch(HibernateException e){
            gi = null;
        }
        return gi;
	}
	
	
	/**
	 * 
	 * @param page
	 * @param pageNum
	 * @param type
	 * @param order
	 * @return
	 * 2005-11-17 21:59:57 Made In GamVan
	 * @see com.gamvan.club.dao.GroupDAO#groupList(int, int, int, int)
	 */
	public List groupList(int page, int pageNum, int layer, int type, int order) {
        if(page<1)page=1;
        //计算从第几条记录开始读取数据   
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        
        List list = null;
		Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from GroupItem where groupID>0");
            if(layer>0){
                hql.append(" and groupLayer="+ layer +"");
            }
            if(type>0){
                hql.append(" and groupType="+ type +"");
            }
            if(order==0){
            	hql.append(" order by groupOrder desc, groupID");
            }
            else if(order==1){
            	hql.append(" order by groupCount desc, groupOrder desc");
            }
            Query query = session.createQuery(hql.toString());
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();            
        }catch(HibernateException e){

        }
        return list;
	}
	
	/**
	 * 
	 * @param page
	 * @param pageNum
	 * @param s
	 * @return
	 * 2005-11-17 22:00:27 Made In GamVan
	 * @see com.gamvan.club.dao.GroupDAO#groupQuery(int, int, java.lang.String)
	 */
	public List groupQuery(int page, int pageNum, String s) {
        if(page<1)page=1;
        //计算从第几条记录开始读取数据   
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        
		List list = null;
        Session session = ConnClub.getSession();
        try{
            Query query = session.createQuery(s);
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();            
        }catch(HibernateException e){

        }
        return list;
	}

}
