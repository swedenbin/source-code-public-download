/*
 * Created on 2005-10-31
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.ClubAfficheDAO;
import com.gamvan.club.item.ClubAfficheItem;
import com.gamvan.conn.ConnClub;

public class ClubAfficheImpl extends ClubAfficheItem
    implements ClubAfficheDAO{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public ClubAfficheItem afficheAdd() {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        ClubAfficheItem cai = new ClubAfficheItem();
        try{
            cai.setCcID(ccID);
            cai.setCaTopic(caTopic);
            cai.setCaContent(caContent);
            cai.setCaAddTime(caAddTime);
            cai.setCaByip(caByip);
            cai.setCaByUser(caByUser);
            cai.setCaDays(caDays);
            session.save(cai);
            tran.commit();
        }catch(HibernateException e){
            cai = null;
            throw new HibernateException("公告添加失败！");
        }
        return cai;
    }
    
    
    /**
     * 
     * @param id
     * 2005-11-7 21:03:35 Made In GamVan
     * @see com.gamvan.club.dao.ClubAfficheDAO#afficheUpdate(int)
     */
    public void afficheUpdate(int id) {
        StringBuffer hql = new StringBuffer();
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        try{
            hql.append("update ClubAfficheItem set ");
            hql.append(" caTopic=?");
            hql.append(", caContent=?");
            hql.append(", caDays=?");
            hql.append(", caByUser=?");
            hql.append(", caByip=?");
            hql.append(", ccID=?");
            hql.append(" where caID=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, caTopic)
            .setString(1, caContent)
            .setInteger(2, caDays)
            .setString(3, caByUser)
            .setString(4, caByip)
            .setInteger(5, ccID)
            .setInteger(6, id);
            query.executeUpdate();
            tran.commit();
        }catch(HibernateException e){
            throw new HibernateException("公告删除失败！");
        }
    }
    
    /**
     * 
     * @param id
     * @see com.gamvan.club.dao.ClubAfficheDAO#afficheDel(int)
     * com.gamvan.club.dao.impl
     */
    public void afficheDel(int id) {
        StringBuffer hql = new StringBuffer();
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        try{
            hql.append("delete from ClubAfficheItem where caID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, id);
            query.executeUpdate();
            session.flush();
            tran.commit();            
        }catch(HibernateException e){
            
        }
        
    }

    /**
     * 
     * @param id
     * @return
     * @see com.gamvan.club.dao.ClubAfficheDAO#afficheInfo(int)
     * com.gamvan.club.dao.impl
     */
    public ClubAfficheItem afficheInfo(int id) {
        ClubAfficheItem cai = null;
        Session session = ConnClub.getSession();
        try{
            cai = (ClubAfficheItem)session.load(ClubAfficheItem.class, new Integer(id));
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return cai;
    }


    /**
     * 分页显示
     * @param page
     * @param pageNum
     * @param ccid
     * @return
     * 2005-12-3 12:24:00 Made In GamVan
     * @see com.gamvan.club.dao.ClubAfficheDAO#afficheList(int, int, int)
     */
    public List afficheList(int page, int pageNum, int ccid) {
        if(page<1)page=1;
        /* 计算从第几条记录开始读取数据 */   
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum; 
        StringBuffer hql = new StringBuffer();
        List list = null;
        Session session = ConnClub.getSession();
        try{
             hql.append("from ClubAfficheItem ");
             if(ccid!=-1){
                 hql.append(" where ccID=");
                 hql.append(ccid);
                 hql.append(" or ccID=-1");
             }
             hql.append(" order by caID desc");
             Query query = session.createQuery(hql.toString());
             query.setFirstResult(startRow);
             query.setMaxResults(endRow);
             list = query.list();
        }catch(HibernateException e){
             e.printStackTrace();
       }
       return list;
    }

    /**
     * 统计总数
     * @param ccid
     * @return
     * 2005-12-3 12:23:34 Made In GamVan
     * @see com.gamvan.club.dao.ClubAfficheDAO#afficheCount(int)
     */
	public int afficheCount(int ccid) { 
        int i = 0;
        StringBuffer hql = new StringBuffer();
        Session session = ConnClub.getSession();
        try{
             hql.append("select count(*) from ClubAfficheItem ");
             if(ccid!=-1){
                 hql.append(" where ccID=");
                 hql.append(ccid);
                 hql.append(" or ccID=-1");
             }
             Query query = session.createQuery(hql.toString());
             Iterator iterate = query.iterate();
             Integer results = null;
             while(iterate.hasNext()){
                  results = (Integer) iterate.next();
                  i = results.intValue();
             }
         }catch(Exception e){
             e.printStackTrace();
         }
       return i;
	}

}
