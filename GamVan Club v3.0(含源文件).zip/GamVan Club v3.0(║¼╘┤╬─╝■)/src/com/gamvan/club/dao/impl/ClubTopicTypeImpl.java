/* 
 * Created on 2005-11-13
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.ClubTopicTypeDAO;
import com.gamvan.club.item.ClubTopicTypeItem;
import com.gamvan.conn.ConnClub;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicTypeImpl extends ClubTopicTypeItem implements ClubTopicTypeDAO
{
	private static final long serialVersionUID = 1L;

	/**
	 * 发购买贴获得的金币数，或是提问贴送出的积分数
	 * @param id 贴子主题ID
	 * @param type 贴子类型
	 * @return
	 * 2005-11-13 15:03:59 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicTypeDAO#topicTypeNumed(int)
	 */
	public double topicTypeNumed(int topicid, short typeinfo){
		double d = 0;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
        	hql.append("select sum(ct.typeNum) ");
        	hql.append(" from ClubTopicTypeItem as ct where ct.topicID=?");
        	hql.append(" and ct.typeInfo=?");
        	Query query = session.createQuery(hql.toString());
        	query.setInteger(0, topicid);
        	query.setShort(1, typeinfo);
            Iterator it =  query.iterate();
            Double results = null;
            while(it.hasNext()){
                 results = (Double) it.next();
                 d = results.doubleValue();
            }
        }catch(HibernateException e){
        	e.printStackTrace();
        }
		return d;
	}

	
	/**
	 * 
	 * @return
	 * 2005-11-13 16:16:51 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicTypeDAO#topicTypeAdd()
	 */
	public ClubTopicTypeItem topicTypeAdd() {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        ClubTopicTypeItem ctti = null;
        try{
            ctti = new ClubTopicTypeItem();
            ctti.setTopicID(topicID);
            ctti.setAddTime(addTime);
            ctti.setTypeInfo(typeInfo);
            ctti.setTypeNum(typeNum);
            ctti.setUserID(userID);
            ctti.setUserName(userName);
            session.save(ctti);
            session.flush();
            tran.commit();            
        }catch(HibernateException e){
            e.printStackTrace();
        }  
        return ctti;
	}

	public void topicTypeUpdate(int topicid, int userid, short typeinfo) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubTopicTypeItem set typeNum=?");
            hql.append(", addTime=?, userName=?");
            hql.append(" where userID=? and topicID=? and typeInfo=?");
            Query query = session.createQuery(hql.toString())
            .setDouble(0, typeNum)
            .setString(1, addTime)
            .setString(2, userName)
            .setInteger(3, userid)
            .setInteger(4, topicid)
            .setShort(5, typeinfo);
            query.executeUpdate();
            tran.commit();
        }catch(HibernateException e){
            e.printStackTrace();
        }
	}


	public ClubTopicTypeItem topicTypeInfo(int topicid, int userid, short typeinfo) {
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        ClubTopicTypeItem ctti = null;
        try{
            hql.append("from ClubTopicTypeItem where topicID=? and userID=? and typeInfo=? ");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, topicid)
            .setInteger(1, userid)
            .setShort(2, typeInfo);
            ctti = (ClubTopicTypeItem)query.uniqueResult(); 
        }catch(HibernateException e){
            ctti = null;
        }
        return ctti;
	}

	
	/**
	 * 
	 * @param topicid
	 * @param typeinfo
	 * @return
	 * 2005-11-14 8:57:30 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicTypeDAO#ClubTopicTypeList(int, short)
	 */
	public List topicTypeList(int topicid, short typeinfo) {
		List list = null;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubTopicTypeItem where topicID=? and typeInfo=? ");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, topicid)
            .setShort(1, typeinfo)
            ;
            list = query.list();
        }catch(HibernateException e){
        	e.printStackTrace();
        }
		return list;
	}

	/**
	 * 删除特殊类型帖子的相关记录
	 * @param topicid
	 * 2005-11-30 2:02:11 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicTypeDAO#topicTypeDel(int)
	 */
	public void topicTypeDel(int topicid) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        String hql = new String();
        try{
        	hql = "delete from ClubTopicTypeItem where topicID=?";
            Query query = session.createQuery(hql.toString())
            .setInteger(0, topicid);
            query.executeUpdate();
            tran.commit();
        }catch(HibernateException e){
        	e.printStackTrace();
        }
	}
	
	
	
	/* test
	public static void main(String args[]){
		ConnClub.init();
		ClubTopicTypeImpl cttim = new ClubTopicTypeImpl();
		//double d = cttim.topicTypeNumed(8280,(short)3);
		//System.out.println(d);
		List list = cttim.clubTopicTypeList(8282,(short)3);
		System.out.println(list);
		ConnClub.closeSession2();
	}
	*/

}
