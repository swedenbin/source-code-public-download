/* 
 * Created on 2005-12-3
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.CacheMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.ClubUseropDAO;
import com.gamvan.club.item.ClubUseropItem;
import com.gamvan.conn.ConnClub;
/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubUseropImpl implements ClubUseropDAO {
	private static final Logger logger = 
		Logger.getLogger(ClubUseropImpl.class.getName());

	public ClubUseropItem useropAdd(int userid, String user, int gradeid
			,int ccid, byte uois, String byuser
			, String byip, String bytime) 
	{
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        ClubUseropItem cuoi = null;
        try{
            cuoi = new ClubUseropItem();
            cuoi.setUserID(userid);
            cuoi.setUoUser(user);
            cuoi.setUoGradeID(gradeid);
            cuoi.setUoCID(ccid);
            cuoi.setUoIs(uois);
            cuoi.setUoByUser(byuser);
            cuoi.setUoByip(byip);
            cuoi.setUoByTime(bytime);
            session.save(cuoi);
            tran.commit();
        }catch(HibernateException e){
            
        }
        return cuoi;
	}
	
	/**
	 * 按主键删除
	 * @param id
	 * 2005-12-3 19:16:51 Made In GamVan
	 * @see com.gamvan.club.dao.ClubUseropDAO#useropDel(int)
	 */
	public void useropDel(int id) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("delete ClubUseropItem where uoID=?");
            Query query  = session.createQuery(hql.toString());
            query.setInteger(0, id);
            query.executeUpdate();
            tran.commit();
        }catch(Exception e){
            
        }
	}
	
	/**
	 * 批量删除 SQL的in语句
	 * @param ids
	 * @return
	 * 2005-12-3 19:16:55 Made In GamVan
	 * @see com.gamvan.club.dao.ClubUseropDAO#useropDels(java.lang.String[])
	 */
	public int useropDels(String[] ids) {
		int i = 0;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("delete ClubUseropItem where uoID in (:ids)");
            Query query  = session.createQuery(hql.toString());
            query.setParameterList("ids", ids); 
            i = query.executeUpdate();
            tran.commit();
        }catch(Exception e){
            
        }
        return i;
	}
	
	/**
	 * 更新
	 * @param id
	 * @param userid
	 * @param user
	 * @param gradeid
	 * @param ccid
	 * @param uois
	 * @param byuser
	 * @param byip
	 * @param bytime
	 * 2005-12-3 19:28:45 Made In GamVan
	 * @see com.gamvan.club.dao.ClubUseropDAO#useropUpdate(int, int, java.lang.String, int, int, byte, java.lang.String, java.lang.String, java.lang.String)
	 */
	public boolean useropUpdate(int id, int userid, String user, int gradeid,
			int ccid, byte uois, String byuser, String byip, String bytime) 
	{
		boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubUseropItem set");
            hql.append(" uoUser=?");
            hql.append(", uoGradeID=?");
            hql.append(", uoCID=?");
            hql.append(", uoIs=?");
            hql.append(", uoByUser=?");
            hql.append(", uoByip=?");
            hql.append(", uoByTime=?");
            hql.append(", userID=?");
            hql.append(" where uoID=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, user)
            .setInteger(1, gradeid)
            .setInteger(2, ccid)
            .setByte(3, uois)
            .setString(4, byuser)
            .setString(5, byip)
            .setString(6, bytime)
            .setInteger(7,userid)
            .setInteger(8, id);
            query.executeUpdate();
            tran.commit();
            bea = true;
        }catch(HibernateException e){
            logger.error("更新管理团队信息出错："+e.toString());
        }
        return bea;
	}

	/**
	 * 
	 * @param id
	 * @return
	 * 2005-12-3 19:30:40 Made In GamVan
	 * @see com.gamvan.club.dao.ClubUseropDAO#useropInfo(int)
	 */
	public ClubUseropItem useropInfo(int id) {
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        ClubUseropItem cuoi = new ClubUseropItem();
        try{
            hql.append("from ClubUseropItem where uoID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, id);
            query.setCacheable(true); //启用查询缓存
            query.setCacheRegion("opCache"); //为查询指定其命名的缓存区域
            query.setCacheMode(CacheMode.NORMAL); //从二级缓存读写数据
            query.setMaxResults(1);
			cuoi = (ClubUseropItem)query.uniqueResult();
        }catch(HibernateException e){
        }
        return cuoi;
	}

	/**
	 * 根据用户ID检查用户是否具有板块管理权
	 * @param userid
	 * @param ccid
	 * @param ccid1
	 * @param ccid2
	 * @return
	 * 2005-12-3 20:01:24 Made In GamVan
	 * @see com.gamvan.club.dao.ClubUseropDAO#useropInfo(int, int, int, int)
	 */
	public ClubUseropItem useropInfo(int userid, int ccid, int ccid1, int ccid2)
	{
        StringBuffer hql = new StringBuffer();
        ClubUseropItem cuoi = null;
        Session session = ConnClub.getSession();
        try{
            hql.append("from ClubUseropItem where uoIs=1"); 
            if(ccid>0){
                hql.append(" and (uoCID=0 or uoCID="+ ccid +"");
                if(ccid1>0){
                    hql.append(" or uoCID="+ ccid1 +"");
                }
                if(ccid2>0){
                    hql.append(" or uoCID="+ ccid2 +"");
                }
                hql.append(")");
            }
            hql.append(" and userID="+ userid +"");
            hql.append(" order by uoGradeID"); //正序排列，最高等级排在最前面。
            Query query = session.createQuery(hql.toString());
            query.setCacheable(true); //启用查询缓存
            query.setCacheRegion("gradeCache"); //为查询指定其命名的缓存区域
            query.setCacheMode(CacheMode.NORMAL); //从二级缓存读写数据
            query.setMaxResults(1);
            cuoi = (ClubUseropItem) query.uniqueResult();
         }catch(HibernateException e){
            e.printStackTrace();
        }
        return cuoi;
	}
	public ClubUseropItem useropInfo(String user, int ccid, int ccid1, int ccid2)
	{
        StringBuffer hql = new StringBuffer();
        ClubUseropItem cuoi = null;
        Session session = ConnClub.getSession();
        try{
            hql.append("from ClubUseropItem where uoIs=1"); 
            if(ccid>0){
                hql.append(" and (uoCID=0 or uoCID="+ ccid +"");
                if(ccid1>0){
                    hql.append(" or uoCID="+ ccid1 +"");
                }
                if(ccid2>0){
                    hql.append(" or uoCID="+ ccid2 +"");
                }
                hql.append(")");
            }
            hql.append(" and uoUser=?");
            Query query = session.createQuery(hql.toString());
            query.setString(0, user);
            query.setCacheable(true); //启用查询缓存
            query.setCacheRegion("gradeCache"); //为查询指定其命名的缓存区域
            query.setCacheMode(CacheMode.NORMAL); //从二级缓存读写数据
            query.setMaxResults(1);
            cuoi = (ClubUseropItem) query.uniqueResult();
         }catch(HibernateException e){
            e.printStackTrace();
        }
        return cuoi;
	}
	
	
	/**
	 * 
	 * @param page
	 * @param pageNum
	 * @param ccid
	 * @param ccid1
	 * @param ccid2
	 * @return
	 * 2005-12-3 19:48:46 Made In GamVan
	 * @see com.gamvan.club.dao.ClubUseropDAO#useroplist(int, int, int, int, int)
	 */
	public List useroplist(int page, int pageNum, int ccid, int ccid1, int ccid2) {
        /* 计算从第几条记录开始读取数据 */
        if(page<1)page=1;
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
		Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        List list = null;
        try{
            hql.append("from ClubUseropItem ");
            if(ccid>0){
                hql.append(" where (uoCID="+ ccid +"");
                if(ccid1>0){
                    hql.append(" or uoCID="+ ccid1 +"");
                }
                if(ccid2>0){
                    hql.append(" or uoCID="+ ccid2 +"");
                }
                hql.append(")");
            }
            hql.append(" order by uoGradeID, uoID ");
            Query query = session.createQuery(hql.toString());
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();
        }catch(HibernateException e){
            list = null;
        }
        return list;
	}

	public int useropCount(int ccid, int ccid1, int ccid2) {
		int i = 0;
		Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("select count(*) from ClubUseropItem ");
            if(ccid>0){
                hql.append(" where (uoCID="+ ccid +"");
                if(ccid1>0){
                    hql.append(" or uoCID="+ ccid1 +"");
                }
                if(ccid2>0){
                    hql.append(" or uoCID="+ ccid2 +"");
                }
                hql.append(")");
            }
            Query query = session.createQuery(hql.toString());
            Iterator it = query.iterate();
            Integer results = null;
            while(it.hasNext()){
                results = (Integer) it.next();
                i = results.intValue();
            }
        }catch(Exception e){
            i = 0;
        }
        return i;
	}

}
