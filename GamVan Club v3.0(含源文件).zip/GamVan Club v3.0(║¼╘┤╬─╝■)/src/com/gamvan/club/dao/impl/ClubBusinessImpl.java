/* 
 * Created on 2005-11-11
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.ClubBusinessDAO;
import com.gamvan.club.item.ClubBusinessItem;
import com.gamvan.conn.ConnClub;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubBusinessImpl extends ClubBusinessItem 
	implements ClubBusinessDAO
{
	private static final long serialVersionUID = 1L;
	
	
	/**
	 * 添加交易记录
	 * @return
	 * 2005-11-11 14:36:31 Made In GamVan
	 * @see com.gamvan.club.dao.ClubBusinessDAO#businessAdd()
	 */
	public ClubBusinessItem businessAdd() {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        ClubBusinessItem cbi = null;
        try{
            cbi = new ClubBusinessItem();
            cbi.setUserID(userID);
            cbi.setUserName(userName);
            cbi.setBusinessDateTime(businessDateTime);
            cbi.setBusinessType(businessType);
            cbi.setBusinessIp(businessIp);
            cbi.setBusinessRate(businessRate);
            cbi.setUserCredit(userCredit);
            cbi.setUserMark(userMark);
            cbi.setUserMoney(userMoney);
            cbi.setBusinessLog(businessLog);
            cbi.setRelatingName(relatingName);
            cbi.setRelatingID(relatingID);
            session.save(cbi);
            tran.commit();
        }catch(HibernateException e){
        	cbi = null;
        }
        return cbi;
	}
	
	/**
	 * 删除交易记录
	 * @param id
	 * @param type 0按主键单独删除  1按用户ID批量删除
	 * 2005-11-11 14:53:48 Made In GamVan
	 * @see com.gamvan.club.dao.ClubBusinessDAO#businessDel(int, int)
	 */
	public void businessDel(int id, int type) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("delete from ClubBusinessItem ");
            if(type==1){
            	hql.append(" where businessId=?");
            }else if(type==2){
            	hql.append(" where userID=?");
            }
            Query query = session.createQuery(hql.toString());
            query.setInteger(0, id);
            query.executeUpdate();
            session.flush();
            tran.commit();
        }catch(HibernateException e){

        }
	}
	
	/**
	 * 用户的社区交易清单  
	 * @param page
	 * @param pageNum
	 * @param userid 用户ID 值为-1将不作条件查询
	 * @param type 为交易类别 值为-1将不作条件查询
	 * @return
	 * 2005-11-11 18:02:27 Made In GamVan
	 * @see com.gamvan.club.dao.ClubBusinessDAO#businessList(int, int, int, byte)
	 */
	public List businessList(int page, int pageNum, int userid, byte type) {
        /* 计算从第几条记录开始读取数据 */
        if(page<1)page=1;
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        List list = null;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubBusinessItem ");
            if(userid!=-1){
            	hql.append(" where userID=");
            	hql.append(userid);
            	if(type!=-1){
            		hql.append(" and businessType=");
            		hql.append(type);
            	}
            }else{
            	if(type!=-1){
            		hql.append(" where businessType=");
            		hql.append(type);
            	}
            }
            hql.append(" order by businessID desc");
            Query query = session.createQuery(hql.toString());
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();
        }catch(HibernateException e){
            e.printStackTrace();            
        }
        return list;
	}

	public int businessCount(int userid, byte type) {
        int i = 0;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("select count(*) from ClubBusinessItem ");
            if(userid!=-1){
            	hql.append(" where userID=");
            	hql.append(userid);
            	if(type!=-1){
            		hql.append(" and businessType=");
            		hql.append(type);
            	}
            }else{
            	if(type!=-1){
            		hql.append(" where businessType=");
            		hql.append(type);
            	}
            }
            Query query = session.createQuery(hql.toString());
            Iterator it = query.iterate();
            Integer results = null;
            while(it.hasNext()){
                results = (Integer) it.next();
                i = results.intValue();
            }
        }catch(HibernateException e){
            e.printStackTrace();            
        }
        return i;
	}

}
