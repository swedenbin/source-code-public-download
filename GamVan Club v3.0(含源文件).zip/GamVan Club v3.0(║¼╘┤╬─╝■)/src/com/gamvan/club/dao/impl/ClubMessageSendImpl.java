/* 
 * 2005-11-4
 * Made in GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.ClubMessageSendDAO;
import com.gamvan.club.item.ClubMessageSendItem;
import com.gamvan.conn.ConnClub;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubMessageSendImpl extends ClubMessageSendItem 
	implements ClubMessageSendDAO
{
	private static final long serialVersionUID = 1L;
	private static final Logger logger = 
		Logger.getLogger(ClubMessageSendImpl.class.getName());
	/**
	 * 社区发送的消息数据信息
	 * @param id
	 * @return
	 * 2005-11-4 5:30:10 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageSendDAO#messageSendInfo(int)
	 */
	public ClubMessageSendItem messageSendInfo(int id) {
        Session session = ConnClub.getSession();
        ClubMessageSendItem cmsi = null;
        try{
        	cmsi = (ClubMessageSendItem) session.load(ClubMessageSendItem.class, new Integer(id));
        }catch(HibernateException e){
        	
        }
		return cmsi;
	}

	/**
	 * 添加用户发送的消息数据
	 * @return
	 * 2005-11-4 5:30:55 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageSendDAO#messageSendAdd()
	 */
	public ClubMessageSendItem messageSendAdd() {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction(); 
        ClubMessageSendItem cmsi = null;
        try{
            cmsi = new ClubMessageSendItem();
            cmsi.setCmSendUser(cmSendUser);
            cmsi.setCmTakeUser(cmTakeUser);
            cmsi.setCmTopic(cmTopic);
            cmsi.setCmContent(cmContent);
            cmsi.setCmUserIp(cmUserIp);
            cmsi.setCmAddTime(cmAddTime);
            cmsi.setCmIsSend(cmIsSend);
            cmsi.setCmOrder(cmOrder);
            cmsi.setCmReID(cmReID);           
            cmsi.setCmSendID(cmSendID);
            cmsi.setCmTakeID(cmTakeID);
            session.save(cmsi);
            tran.commit();
        }catch(HibernateException e){
        }
		return cmsi;
	}

	/**
	 * 按ID精确删除
	 * @param id
	 * @return
	 * 2005-11-4 5:42:10 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageSendDAO#messageSendDel(int)
	 */
	public boolean messageSendDel(int id) {
		boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction(); 
        StringBuffer hql = new StringBuffer();
        try{
        	hql.append("delete from ClubMessageSendItem where cmID=?");
        	Query query = session.createQuery(hql.toString());
        	query.setInteger(0, id);
        	query.executeUpdate();
        	tran.commit();
        	bea = true;
        }catch(HibernateException e){
        	logger.error(e.toString());
        }
		return bea;
	}
	
	/**
	 * 删除发件箱此用户发送的短消息
	 * 仅删除主动发送方的短消息
	 * @param userid
	 * @return
	 * 2005-12-27 9:40:07 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageSendDAO#messageSendDel_userid(int)
	 */
	public boolean messageSendDel_userid(int userid) {
		boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction(); 
        StringBuffer hql = new StringBuffer();
        try{
        	hql.append("delete from ClubMessageSendItem where cmSendID=?");
        	Query query = session.createQuery(hql.toString());
        	query.setInteger(0, userid);
        	query.executeUpdate();
        	tran.commit();
        	bea = true;
        }catch(HibernateException e){
        	logger.error(e.toString());
        }
		return bea;
	}

	
	/**
	 * 批量删除in语法
	 * @param ids
	 * @return
	 * 2005-11-4 5:42:24 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageSendDAO#messageSendDel(java.lang.String)
	 */
	public int messageSendDel(Collection ids) {
		int i = 0;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction(); 
        StringBuffer hql = new StringBuffer();
        try{
        	hql.append("delete from ClubMessageSendItem where cmID in (:ids)");
        	Query query = session.createQuery(hql.toString());
        	query.setParameterList("ids", ids);
        	i = query.executeUpdate();
        	tran.commit();
        }catch(HibernateException e){
        	
        }
		return i;
	}
	
	
	/**
	 * 发件箱或草稿箱消息列表
	 * @param page
	 * @param pageNum
	 * @param sendid 发送此消息的用户ID
	 * @param sendis 判断是否发送，用以来判断消息是在发件箱还是在草稿箱。
	 * @return
	 * 2005-11-4 5:49:37 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageSendDAO#messageSendList(int, int, int, boolean)
	 */
	public List messageSendList(int page, int pageNum, int sendid, boolean sendis) 
	{
        /* 计算从第几条记录开始读取数据 */
		if(page<1){page=1;}
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        Session session = ConnClub.getSession();
        List list = null;        
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubMessageSendItem  where cmSendID=?");
            hql.append(" and cmIsSend = ?");
            hql.append(" order by cmID desc");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, sendid)
            .setBoolean(1, sendis);
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();           
        }catch(HibernateException e){

        }
        return list;
	}

	
	/**
	 * 统计总数为了分页 NND，困死，吃早饭睡觉了......
	 * @param sendid
	 * @param sendis
	 * @return
	 * 2005-11-4 5:51:12 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageSendDAO#messageSendCount(int, boolean)
	 */
	public int messageSendCount(int sendid, boolean sendis) {
        Session session = ConnClub.getSession();
        List list = null;        
        StringBuffer hql = new StringBuffer();
        int i = 0;
        try{
            hql.append("select count(*) from ClubMessageSendItem  where cmSendID=?");
            hql.append(" and cmIsSend = ?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, sendid)
            .setBoolean(1, sendis);
            list = query.list();
            Iterator it = list.iterator();
            Integer results = null;
            while(it.hasNext()){
                results = (Integer) it.next();
                i = results.intValue();
            }         
        }catch(HibernateException e){
        }
        return i;
	}
	
	/**
	 * 更改短消息状态[是否发送] 不发送则表示存放在草稿箱内
	 * @param id
	 * @param is
	 * 2005-11-29 20:03:49 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageSendDAO#messageIsSendUpdate(int, boolean)
	 */
	public void messageIsSendUpdate(int id, boolean is) {
        StringBuffer hql = new StringBuffer("");
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction(); 
        try{
            hql.append("update ClubMessageSendItem set cmIsSend=? where cmID=?");
            Query query = session.createQuery(hql.toString())
            .setBoolean(0, is)
            .setInteger(1, id);
            query.executeUpdate();
            tran.commit();            
        }catch(Exception e){
        	
        }
	}
}
