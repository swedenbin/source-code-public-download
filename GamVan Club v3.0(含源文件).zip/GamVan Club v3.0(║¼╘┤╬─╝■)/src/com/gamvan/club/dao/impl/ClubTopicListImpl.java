/*
 * Created on 2005-10-16
 * Last modified on 2006-1-25
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

import com.gamvan.club.dao.ClubTopicListDAO;
import com.gamvan.club.item.ClubTopicItem;
import com.gamvan.conn.ConnClub;

public class ClubTopicListImpl extends ClubTopicItem 
	implements ClubTopicListDAO
{
    private static final long serialVersionUID = 1L;
    /* 查询时的关键字 */
    private String searchKey = null;
    private static final Logger logger = 
    	Logger.getLogger(ClubTopicListImpl.class.getName());
    /**
     * @param page
     * @param pageNum
     * @param hqlOrder
     * @return
     * 2005-12-3 11:25:55 Made In GamVan
     * @see com.gamvan.club.dao.ClubTopicListDAO#topicList(int, int, java.lang.String)
     */
    public List topicList(int page, int pageNum, String hqlappend) {
        List list = null;
        if(page<1){page=1;}
        //计算从第几条记录开始读取数据   
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubTopicItem ");
            hql.append(" where (topicIsDel=? and topicIsPass=?) ");
            if(ccID>0){
                hql.append(" and ((ccID=" + ccID + " or ccID1=" +ccID + " or ccID2=" +ccID + ")");
                hql.append(" or (moveCCID=" + ccID + " and moveCCID>0) or topicOrder=3) ");
            }
            if(topicPro==1){
                hql.append(" and topicPro=1 ");
            }
            if(topicType>0){
            	hql.append(" and topicType=");
           	 	hql.append(topicType);
            }
            if(!userName.equals("")){
            	hql.append(" and userName=?");
            }
            if(searchKey!=null&&!searchKey.equals("")){
                searchKey = searchKey.trim();
                StringTokenizer st = new StringTokenizer(searchKey, " ");
                for(int i=0;st.hasMoreTokens();i++){
                    if(i==0){
                        hql.append(" and (topic like ? ");
                    }else{
                        hql.append(" or topic like ? ");
                    }
                    st.nextToken();
                }
                hql.append(")");
            }
            hql.append(hqlappend);
            Query query = session.createQuery(hql.toString());
            query.setByte(0, topicIsDel);
            query.setBoolean(1, topicIsPass);
            if(searchKey!=null&&!searchKey.equals("")){
            	if(!userName.equals("")){
                 	query.setString(2, userName);
                 	StringTokenizer st = new StringTokenizer(searchKey, " ");
                    for(int i=2;st.hasMoreTokens();i++){
                       query.setString(i+1, "%"+ st.nextToken() +"%");
                    }
                }else{
                	StringTokenizer st = new StringTokenizer(searchKey, " ");
                    for(int i=1;st.hasMoreTokens();i++){
                       query.setString(i+1, "%"+ st.nextToken() +"%");
                    }
                }
            }else{
            	if(!userName.equals("")){
                 	query.setString(2, userName);
                }
            }
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();     
        }catch(HibernateException e){
        	logger.error(e.toString());
            
            list = null;
        }
        return list;
    }
    
    /**
     * 
     * @param hqlappend
     * @return
     * 2005-12-3 11:26:04 Made In GamVan
     * @see com.gamvan.club.dao.ClubTopicListDAO#topicCount(java.lang.String)
     */
    public int topicCount(String hqlappend) {
        int c = 0;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("select count(*) from ClubTopicItem");
            hql.append(" where (topicIsDel=? and topicIsPass=?) ");
            if(ccID>0){
                hql.append("  and ((ccID=" + ccID + " or ccID1=" +ccID + " or ccID2=" +ccID + ")");
                hql.append(" or (moveCCID=" + ccID + " and moveCCID>0)  or topicOrder=3) ");
            }
            if(topicPro==1){
                hql.append(" and topicPro=1 ");
            }
            if(!userName.equals("")){
            	hql.append(" and userName=?");
            }
            if(searchKey!=null&&!searchKey.equals("")){
                searchKey = searchKey.trim();
                StringTokenizer st = new StringTokenizer(searchKey, " ");
                for(int i=0;st.hasMoreTokens();i++){
                    if(i==0){
                        hql.append(" and (topic like ? ");
                    }else{
                        hql.append(" or topic like ? ");
                    }
                    st.nextToken();
                }
                hql.append(")");
            }
            hql.append(hqlappend);
            Query query = session.createQuery(hql.toString());
            query.setByte(0, topicIsDel);
            query.setBoolean(1, topicIsPass);
            if(searchKey!=null&&!searchKey.equals("")){
            	if(!userName.equals("")){
                 	query.setString(2, userName);
                 	StringTokenizer st = new StringTokenizer(searchKey, " ");
                    for(int i=2;st.hasMoreTokens();i++){
                       query.setString(i+1, "%"+ st.nextToken() +"%");
                    }
                }else{
                	StringTokenizer st = new StringTokenizer(searchKey, " ");
                    for(int i=1;st.hasMoreTokens();i++){
                       query.setString(i+1, "%"+ st.nextToken() +"%");
                    }
                }
            }else{
            	if(!userName.equals("")){
                 	query.setString(2, userName);
                }
           }
           Iterator it =  query.iterate();
           Integer results = null;
           while(it.hasNext()){
                results = (Integer) it.next();
                c = results.intValue();
           }
        }catch(HibernateException e){
           
        }
        return c; 
    }

    /**
     * 
     * @param tid
     * @param page
     * @param pageNum
     * @param hqlOrder
     * @return
     * 2005-12-1 0:57:01 Made In GamVan
     * @see com.gamvan.club.dao.ClubTopicListDAO#topicReList(int, int, int, java.lang.String)
     */
    public List topicReList(int tid, int page, int pageNum, String hqlappend) {
        List list = null;
        if(page<1){page=1;}
        //计算从第几条记录开始读取数据   
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubTopicReItem where (topicIsDel=? and topicIsPass=?)");
            if(tid>0){
                hql.append(" and topicID="+ tid +"");
            }
            if(!userName.equals("")){
            	hql.append(" and userName=?");
            }
            if(searchKey!=null&&!searchKey.equals("")){
                searchKey = searchKey.trim();
                StringTokenizer st = new StringTokenizer(searchKey, " ");
                for(int i=0;st.hasMoreTokens();i++){
                    if(i==0){
                        hql.append(" and (topic like ? ");
                    }else{
                        hql.append(" or topic like ? ");
                    }
                    st.nextToken();
                }
                hql.append(")");
            }
            hql.append(hqlappend);
            Query query = session.createQuery(hql.toString());
            query.setByte(0, topicIsDel);
            query.setBoolean(1, topicIsPass);
            if(searchKey!=null&&!searchKey.equals("")){
            	if(!userName.equals("")){
                 	query.setString(2, userName);
                 	StringTokenizer st = new StringTokenizer(searchKey, " ");
                    for(int i=2;st.hasMoreTokens();i++){
                       query.setString(i+1, "%"+ st.nextToken() +"%");
                    }
                }else{
                	StringTokenizer st = new StringTokenizer(searchKey, " ");
                    for(int i=1;st.hasMoreTokens();i++){
                       query.setString(i+1, "%"+ st.nextToken() +"%");
                    }
                }
            }else{
            	if(!userName.equals("")){
                 	query.setString(2, userName);
                }
           }
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();            
        }catch(HibernateException e){
        	logger.error(e.toString());
            
            list = null;
        }
        return list;
    }
    
    /**
     * 
     * @param tid
     * @param hqlappend
     * @return
     * 2005-12-1 0:57:07 Made In GamVan
     * @see com.gamvan.club.dao.ClubTopicListDAO#topicReCount(int, java.lang.String)
     */
    public int topicReCount(int tid, String hqlappend) {
        int i = 0;
        Session session = ConnClub.getSession();
        try{
            StringBuffer hql = new StringBuffer();
            hql.append("select count(*) from ClubTopicReItem");
            hql.append(" where (topicIsDel=? and topicIsPass=?)");
            if(tid>0){
                hql.append(" and topicID=");
                hql.append(tid);
            }
            if(!userName.equals("")){
            	hql.append(" and userName=?");
            }
            if(searchKey!=null&&!searchKey.equals("")){
                searchKey = searchKey.trim();
                StringTokenizer st = new StringTokenizer(searchKey, " ");
                for(int c=0;st.hasMoreTokens();c++){
                    if(c==0){
                        hql.append(" and (topic like ? ");
                    }else{
                        hql.append(" or topic like ? ");
                    }
                    st.nextToken();
                }
                hql.append(")");
            }
            Query query = session.createQuery(hql.toString());
            query.setByte(0, topicIsDel);
            query.setBoolean(1, topicIsPass);
            if(searchKey!=null&&!searchKey.equals("")){
            	if(!userName.equals("")){
                 	query.setString(2, userName);
                 	StringTokenizer st = new StringTokenizer(searchKey, " ");
                    for(int c=2;st.hasMoreTokens();c++){
                       query.setString(c+1, "%"+ st.nextToken() +"%");
                    }
                }else{
                	StringTokenizer st = new StringTokenizer(searchKey, " ");
                    for(int c=1;st.hasMoreTokens();c++){
                       query.setString(c+1, "%"+ st.nextToken() +"%");
                    }
                }
            }else{
            	if(!userName.equals("")){
                 	query.setString(2, userName);
                }
           }
           Iterator it =  query.iterate();
           Integer results = null;
           while(it.hasNext()){
                results = (Integer) it.next();
                i = results.intValue();
           }
        }catch(HibernateException e){
            
        }
        return i; 
    }

    public void setSearchKey(String searchKey) {
        this.searchKey = searchKey;
    }


	public List topicImportList
		(int page, int pageNum, int order, int ccid, int tpro) 
	{
        /* 计算从第几条记录开始读取数据 */   
        if(page<1)page=1;
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        Session session = ConnClub.getSession();
        List list = null;
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubTopicItem where topicIsDel=0 and topicIsPass=?");
            if(ccid>0){
                hql.append(" and (ccID="+ ccid +" or ccID2="+ ccid +" or ccID1=" + ccid + ")");
            }
            if(tpro==1){ //最新精品
                hql.append(" and topicPro=1  ");
            }
            else if(tpro==2){ //推荐话题
                hql.append(" and topicOrder>0 ");
            }        
            if(order==1){
                hql.append(" order by topicReCount desc, topicViewCount desc");
            }
            else if(order==2){
                hql.append(" order by topicReID desc");
            }
            else{
                hql.append(" order by topicID desc");
            }
            Query query = session.createQuery(hql.toString());
            query.setBoolean(0, true);
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();
        }catch(Exception e){
            
        }
        return list;
	}

	public List topicAllList(int page, int pageNum, Boolean ispass, String hqlappend)
	{
        List list = null;
        if(page<1){page=1;}
        /* 计算从第几条记录开始读取数据 */   
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubTopicItem ");
			hql.append(" where topicIsDel=");
			hql.append(topicIsDel);
			if(ccID>0){
				hql.append(" and (ccID=");
				hql.append(ccID);
				hql.append(" or ccID2=");
				hql.append(ccID);
				hql.append(" or ccID1=");
				hql.append(ccID);
				hql.append(") ");
			}
            if(ispass!=null){
            	hql.append(" and topicIsPass=? ");
            }
            hql.append(hqlappend);
            Query query = session.createQuery(hql.toString());
            if(ispass!=null){
            	query.setBoolean(0, ispass.booleanValue());
            }
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();     
        }catch(HibernateException e){
            
            list = null;
        }
        return list;
	}

	public int topicAllCount(Boolean ispass, String hqlappend)
	{
        int i = 0;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("select count(*) from ClubTopicItem");
			hql.append(" where topicIsDel=");
			hql.append(topicIsDel);
			if(ccID>0){
				hql.append(" and (ccID=");
				hql.append(ccID);
				hql.append(" or ccID2=");
				hql.append(ccID);
				hql.append(" or ccID1=");
				hql.append(ccID);
				hql.append(") ");
			}
            if(ispass!=null){
            	hql.append(" and topicIsPass=? ");
            }
            hql.append(hqlappend);
            Query query = session.createQuery(hql.toString());
            if(ispass!=null){
            	query.setBoolean(0, ispass.booleanValue());
            }
            Iterator it =  query.iterate();
            Integer results = null;
            while(it.hasNext()){
                results = (Integer) it.next();
                i = results.intValue();
            }
        }catch(HibernateException e){
            
            i = 0;
        }
        return i; 
	}

	public List topicReAllList(int page, int pageNum, Boolean ispass, String hqlappend)
	{
        List list = null;
        if(page<1){page=1;}
        /* 计算从第几条记录开始读取数据 */   
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubTopicReItem ");
			hql.append(" where topicIsDel=");
			hql.append(topicIsDel);
			if(ccID>0){
				hql.append(" and (ccID=");
				hql.append(ccID);
				hql.append(" or ccID2=");
				hql.append(ccID);
				hql.append(" or ccID1=");
				hql.append(ccID);
				hql.append(") ");
			}
            if(ispass!=null){
            	hql.append(" and topicIsPass=?");
            }
            hql.append(hqlappend);
            Query query = session.createQuery(hql.toString());
            if(ispass!=null){
            	query.setBoolean(0, ispass.booleanValue());
            }
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();     
        }catch(HibernateException e){
            
            list = null;
        }
        return list;
	}

	public int topicReAllCount(Boolean ispass, String hqlappend)
	{
        int i = 0;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("select count(*) from ClubTopicReItem");
			hql.append(" where topicIsDel=");
			hql.append(topicIsDel);
			if(ccID>0){
				hql.append(" and (ccID=");
				hql.append(ccID);
				hql.append(" or ccID2=");
				hql.append(ccID);
				hql.append(" or ccID1=");
				hql.append(ccID);
				hql.append(") ");
			}
            if(ispass!=null){
            	hql.append(" and topicIsPass=?");
            }
            hql.append(hqlappend);
            Query query = session.createQuery(hql.toString());
            if(ispass!=null){
            	query.setBoolean(0, ispass.booleanValue());
            }
            Iterator it =  query.iterate();
            Integer results = null;
            while(it.hasNext()){
                results = (Integer) it.next();
                i = results.intValue();
            }
        }catch(HibernateException e){
            
            i = 0;
        }
        return i;
	}
}
