/* 
 * Created on 2005-12-3
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import org.hibernate.CacheMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.ClubInfoDAO;
import com.gamvan.club.item.ClubInfoItem;
import com.gamvan.conn.ConnClub;
/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubInfoImpl extends ClubInfoItem
	implements ClubInfoDAO 
{
	private static final long serialVersionUID = 1L;
	
	
	public ClubInfoItem clubInfoAdd() {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        ClubInfoItem cii = null;
        try{
        	cii = new ClubInfoItem();
        	cii.setClubName(clubName);
        	cii.setClubUrl(clubUrl);
        	cii.setClubTitle(clubTitle);
        	cii.setClubMeta(clubMeta);
        	cii.setClubSmtp(clubSmtp);
        	cii.setClubSmtpID(clubSmtpID);
        	cii.setClubSmtpPass(clubSmtpPass);
        	cii.setClubSmtpPort(clubSmtpPort);
        	cii.setClubUpfileOpen(clubUpfileOpen);
        	cii.setClubUpfileMax(clubUpfileMax);
        	cii.setClubUpfileUser(clubUpfileUser);
        	cii.setClubUpfileExt(clubUpfileExt);
        	cii.setClubCopyRight(clubCopyRight);
        	cii.setClubYear(clubYear);
        	cii.setClubUserPic(clubUserPic);
        	cii.setClubSmtpSSL(clubSmtpSSL);
        	cii.setClubRefreshPage(clubRefreshPage);
        	cii.setClubHotTopic(clubHotTopic);
        	cii.setClubHotRe(clubHotRe);
        	cii.setClubUpfileDomain(clubUpfileDomain);
        	cii.setClubTopicIsPass(clubTopicIsPass);
        	cii.setClubEmail(clubEmail);
        	cii.setClubEmailSend(clubEmailSend);
        	cii.setClubMenu(clubMenu);
        	cii.setClubLastReID(0);
        	session.save(cii);
        	tran.commit();
        }catch(HibernateException e){
            	
        }
        return cii;
	}

	public void clubInfoUpdate() {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubInfoItem ");
            hql.append("set  clubName=? ");
            hql.append(", clubUrl=? ");
            hql.append(", clubTitle=? ");
            hql.append(", clubMeta=? ");
            hql.append(", clubSmtp=? ");
            hql.append(", clubSmtpID=? ");
            hql.append(", clubSmtpPass=? ");
            hql.append(", clubUpfileOpen=? ");
            hql.append(", clubUpfileMax=? ");
            hql.append(", clubUpfileUser=? ");
            hql.append(", clubUpfileExt=? ");
            hql.append(", clubCopyRight=? ");
            hql.append(", clubYear=? ");
            hql.append(", clubUserPic=? ");
            hql.append(", clubSmtpPort=? ");
            hql.append(", clubSmtpSSL=?");
            hql.append(", clubRefreshPage=? ");
            hql.append(", clubHotTopic=? ");
            hql.append(", clubHotRe=? ");
            hql.append(", clubUpfileDomain=? ");
            hql.append(", clubTopicIsPass=? ");
            hql.append(", clubEmail=?");
            hql.append(", clubEmailSend=?");
            hql.append(", clubMenu=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, clubName)
            .setString(1, clubUrl)
            .setString(2, clubTitle)
            .setString(3, clubMeta)
            .setString(4, clubSmtp)
            .setString(5, clubSmtpID)
            .setString(6, clubSmtpPass)
            .setInteger(7, clubUpfileOpen)
            .setInteger(8, clubUpfileMax)
            .setInteger(9, clubUpfileUser)
            .setString(10, clubUpfileExt)
            .setString(11, clubCopyRight)
            .setString(12, clubYear)
            .setInteger(13, clubUserPic)
            .setString(14, clubSmtpPort)
            .setInteger(15, clubSmtpSSL)
            .setInteger(16, clubRefreshPage)
            .setInteger(17, clubHotTopic)
            .setInteger(18, clubHotRe)
            .setString(19, clubUpfileDomain)
            .setBoolean(20, clubTopicIsPass)
            .setString(21, clubEmail)
            .setString(22, clubEmailSend)
            .setInteger(23, clubMenu);
            query.executeUpdate();
            tran.commit();
        }
        catch(HibernateException e){
        	
        }
	}

	public ClubInfoItem clubInfo() {
        ClubInfoItem cii = null;
        Session session = ConnClub.getSession();
        String hql = "";
        try{
            hql = "from ClubInfoItem ";
            Query query = session.createQuery(hql);
            query.setCacheable(true); //启用查询缓存
            query.setCacheRegion("clubInfoCache"); //为查询指定其命名的缓存区域
            query.setCacheMode(CacheMode.NORMAL); //从二级缓存读写数据
            query.setMaxResults(1);
            cii = (ClubInfoItem)query.uniqueResult();
        }catch(HibernateException e){
        	e.printStackTrace();
            cii = null;
        }
        return cii;
	}
	
	/**
     * 更新注册协议
	 * @param regagree
	 * 2005-12-3 15:38:31 Made In GamVan
	 * @see com.gamvan.club.dao.ClubInfoDAO#clubRegAgreeUpdate(java.lang.String)
	 */
	public void clubRegAgreeUpdate(String regagree) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        String hql = new String();
        try{
            hql = "update ClubInfoItem set clubRegAgree=?";
            Query query = session.createQuery(hql)
            .setString(0, regagree);
            query.executeUpdate();
            tran.commit();
        }catch(HibernateException e){

        } 
	}
	
	/**
     * 更新社区回复表的最后一条主题的ID
     * 用于主题表主题排序
	 * @param lastreid
	 * 2005-12-3 15:40:42 Made In GamVan
	 * @see com.gamvan.club.dao.ClubInfoDAO#clubLastReID(int)
	 */
	public void clubLastReIDUpdate(int lastreid) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        String hql = new String();
        try{
            hql = "update ClubInfoItem set clubLastReID=?";
            Query query = session.createQuery(hql)
            .setInteger(0, lastreid);
            query.executeUpdate();
            session.flush();
            tran.commit();
        }catch(HibernateException e){
            e.printStackTrace();
        }
	}

}
