/*
 * Created on 2005-10-22
 * Last modified on 2006-1-23
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.ClubContentDAO;
import com.gamvan.club.item.ClubContentItem;
import com.gamvan.club.item.ClubContentReItem;
import com.gamvan.conn.ConnClub;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubContentImpl extends ClubContentItem implements ClubContentDAO {
    private static final long serialVersionUID = 1L;
    
    /**
     * 
     * @return
     * 2005-11-29 21:19:22 Made In GamVan
     * @see com.gamvan.club.dao.ClubContentDAO#contentAdd()
     */
    public boolean contentAdd() {
        boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        try{
            ClubContentItem cci = new ClubContentItem();
            cci.setTopicID(topicID);
            cci.setContent(content);
            cci.setContentUserPen(contentUserPen);
            cci.setContentUrl(contentUrl);
            cci.setContentImg(contentImg);
            cci.setContentEmail(contentEmail);
            cci.setContentCopyRight(contentCopyRight);
            session.save(cci);
            tran.commit();   
            session.evict(cci);
            bea = true;
        }catch(HibernateException e){
            bea = false;
        }
        return bea;
    }

    
    /**
     * 
     * @return
     * 2005-11-29 21:19:15 Made In GamVan
     * @see com.gamvan.club.dao.ClubContentDAO#contentUpdate()
     */
    public boolean contentUpdate(int topicid) {
        boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubContentItem set content=?");
            hql.append(", contentUserPen=?");
            hql.append(", contentUrl=?");
            hql.append(", contentImg=?");
            hql.append(", contentEmail=?");
            hql.append(", contentCopyRight=?");
            hql.append(" where topicID=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, content)
            .setBoolean(1, contentUserPen)
            .setBoolean(2, contentUrl)
            .setBoolean(3, contentImg)
            .setBoolean(4, contentEmail)
            .setByte(5, contentCopyRight)
            .setInteger(6, topicid);
            query.executeUpdate();
            tran.commit();
            bea = true;
        }catch(HibernateException e){
            bea = false;
        }
        return bea;
    }

    /**
     * 
     * @return
     * 2005-11-29 21:19:09 Made In GamVan
     * @see com.gamvan.club.dao.ClubContentDAO#contentDel()
     */
    public boolean contentDel(int topicid) {
        boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("delete from ClubContentItem  where topicID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, topicid);
            query.executeUpdate();
            tran.commit();
            bea = true;
        }catch(HibernateException e){
            bea = false;
        }
        return bea;
    }
    
    /**
     * 
     * @return
     * 2005-11-29 21:18:11 Made In GamVan
     * @see com.gamvan.club.dao.ClubContentDAO#contentInfo()
     */
    public ClubContentItem contentInfo(int topicid) {
        ClubContentItem cci = null;
        Session session = ConnClub.getSession();
        String hql = "";
        try{
            hql = "from ClubContentItem where topicID=?";
            Query query = session.createQuery(hql)
            .setInteger(0, topicid);
            cci = (ClubContentItem)query.uniqueResult();
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return cci;
    }
    
    /* 回复数据表相关方法 */
    /**
     * 
     * @return
     * 2005-11-29 21:18:30 Made In GamVan
     * @see com.gamvan.club.dao.ClubContentDAO#contentReAdd()
     */
    public boolean contentReAdd() {
        boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        try{
            ClubContentReItem cci = new ClubContentReItem();
            cci.setTopicReID(topicReID);
            cci.setContent(content);
            cci.setContentUserPen(contentUserPen);
            cci.setContentUrl(contentUrl);
            cci.setContentImg(contentImg);
            cci.setContentEmail(contentEmail);
            cci.setContentCopyRight(contentCopyRight);
            cci.setContentIsDel(contentIsDel);
            session.save(cci);
            tran.commit();   
            session.evict(cci);
            bea = true;
        }catch(HibernateException e){
            bea = false;
        }
        return bea;
    }



    public boolean contentReUpdate(int topicreid) {
        boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubContentReItem set content=?");
            hql.append(", contentUserPen=?");
            hql.append(", contentUrl=?");
            hql.append(", contentImg=?");
            hql.append(", contentEmail=?");
            hql.append(", contentCopyRight=?");
            hql.append(" where topicReID=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, content)
            .setBoolean(1, contentUserPen)
            .setBoolean(2, contentUrl)
            .setBoolean(3, contentImg)
            .setBoolean(4, contentEmail)
            .setByte(5, contentCopyRight)
            .setInteger(6, topicreid);
            query.executeUpdate();
            tran.commit();
            bea = true;
        }catch(HibernateException e){
            bea = false;
        }
        return bea;
    }



    public boolean contentReDel(int topicreid) {
        boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("delete from ClubContentReItem  where topicReID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, topicreid);
            query.executeUpdate();
            tran.commit();
            bea = true;
        }catch(HibernateException e){
            bea = false;
        }
        return bea;
    }



    public ClubContentReItem contentReInfo(int topicreid) {
        ClubContentReItem ccri = null;
        Session session = ConnClub.getSession();
        String hql = "";
        try{
            hql = "from ClubContentReItem where topicReID=?";
            Query query = session.createQuery(hql)
            .setInteger(0, topicreid);
            ccri = (ClubContentReItem)query.uniqueResult();
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return ccri;
    }
    

	public List contentReList(int page, int pageNum, int topicid) {
        List list = null;
        if(page<1){page=1;}
        //计算从第几条记录开始读取数据   
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
		Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubContentReItem where topicID=? ");
            if(contentIsDel!=(byte)-1){
            	hql.append(" and contentIsDel=");
            	hql.append(contentIsDel);
            }
            hql.append(" order by topicReID");
            Query query = session.createQuery(hql.toString());
            query.setInteger(0, topicid);
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();   
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return list;
	}

	
	/**
	 * 标记删除
	 * @param topicreid
	 * @param isdel 1正常  0删除 
	 * @return 
	 * 2006-1-10 19:55:40 made in GamVan
	 * @see com.gamvan.club.dao.ClubContentDAO#contentReDel_(int, byte)
	 */
	public boolean contentReDel_(int topicreid, byte isdel) {
        boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubContentReItem set contentIsDel=?");
            hql.append(" where topicReID=?");
            Query query = session.createQuery(hql.toString())
            .setByte(0, isdel)
            .setInteger(1, topicreid);
            query.executeUpdate();
            tran.commit();
            bea = true;
        }catch(HibernateException e){
            bea = false;
        }
        return bea;
	}

}
