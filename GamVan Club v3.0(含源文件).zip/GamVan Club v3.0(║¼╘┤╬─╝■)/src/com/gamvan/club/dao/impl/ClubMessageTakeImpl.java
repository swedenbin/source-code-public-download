/* 
 * 2005-11-4
 * Made in GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.ClubMessageTakeDAO;
import com.gamvan.club.item.ClubMessageTakeItem;
import com.gamvan.conn.ConnClub;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubMessageTakeImpl extends ClubMessageTakeItem
	implements ClubMessageTakeDAO
{
	private static final long serialVersionUID = 1L;
	private static final Logger logger = 
		Logger.getLogger(ClubMessageTakeImpl.class.getName());
	
	public ClubMessageTakeItem messageTakeAdd(){
		ClubMessageTakeItem cmti = new ClubMessageTakeItem();
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction(); 
        try{
            cmti.setCmSendUser(cmSendUser);
            cmti.setCmTakeUser(cmTakeUser);
            cmti.setCmTopic(cmTopic);
            cmti.setCmContent(cmContent);
            cmti.setCmUserIp(cmUserIp);
            cmti.setCmAddTime(cmAddTime);
            cmti.setCmIsTake(cmIsTake);
            cmti.setCmOrder(cmOrder);
            cmti.setCmReID(cmReID);           
            cmti.setCmSendID(cmSendID);
            cmti.setCmTakeID(cmTakeID);
            session.save(cmti);
            tran.commit();
        }catch(HibernateException e){
        	cmti = null;
        }
        return cmti;
	}
	
	
	/**
	 * 提取消息内容
	 * @param id
	 * @return
	 * 2005-11-4 16:53:41 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageTakeDAO#messageTakeInfo(int)
	 */
	public ClubMessageTakeItem messageTakeInfo(int id) {
		Session session = ConnClub.getSession();
		ClubMessageTakeItem cti = null;
		try{
			cti = (ClubMessageTakeItem)session.load(ClubMessageTakeItem.class, new Integer(id));
		}catch(HibernateException e){
			
		}
		return cti;
	}
	

	/**
	 * 精确删除
	 * @param id
	 * @return
	 * 2005-11-4 16:53:31 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageTakeDAO#messageTakeDel(int)
	 */
	public boolean messageTakeDel(int id) {
		boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        String hql = "";
        try{
        	hql = "delete from ClubMessageTakeItem where cmID=?";
        	Query query = session.createQuery(hql);
        	query.setInteger(0, id);
        	query.executeUpdate();
        	tran.commit();
        	bea = true;
        }catch(HibernateException e){
        	
        }
		return bea;
	}
	
	/**
	 * 删除收件箱内此用户发送的短消息
	 * 仅删除主动接收方的短消息，被动发送方的保留
	 * @param userid 用户ID 
	 * @return
	 * 2005-12-27 9:30:25 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageTakeDAO#messageTakeDel_userid(int)
	 */
	public boolean messageTakeDel_userid(int userid) {
		boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        String hql = "";
        try{
        	hql = "delete from ClubMessageTakeItem where cmTakeID=?";
        	Query query = session.createQuery(hql);
        	query.setInteger(0, userid);
        	query.executeUpdate();
        	tran.commit();
        	bea = true;
        }catch(HibernateException e){
        	logger.error(e.toString());
        }
		return bea;
	}
	
	/**
	 * 批量删除
	 * @param ids
	 * @return
	 * 2005-11-4 16:52:14 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageTakeDAO#messageTakeDel(java.util.Collection)
	 */
	public int messageTakeDel(Collection ids) {
		int i = 0;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        String hql = "";
        try{
        	hql = "delete from ClubMessageTakeItem where cmID in (:ids)";
        	Query query = session.createQuery(hql);
        	query.setParameterList("ids", ids);
        	i = query.executeUpdate();
        	tran.commit();        	
        }catch(HibernateException e){
        	
        }
        return i;
	}

	/**
	 * 根据接收用户ID读取收件箱消息列表
	 * @param page
	 * @param pageNum
	 * @param takeid 接收用户ID
	 * @return
	 * 2005-11-4 16:51:39 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageTakeDAO#messageTakeList(int, int, int)
	 */
	public List messageTakeList(int page, int pageNum, int takeid, Boolean bea) {
        /* 计算从第几条记录开始读取数据 */
		if(page<1){page=1;}
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        Session session = ConnClub.getSession();
        List list = null;        
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubMessageTakeItem  where cmTakeID=?");
            if(bea!=null){
            	hql.append(" and cmIsTake=?");
            }
            hql.append(" order by cmID desc");
            Query query = session.createQuery(hql.toString());
            query.setInteger(0, takeid);
            if(bea!=null){
            	query.setBoolean(1, bea.booleanValue());
            }
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();           
        }catch(HibernateException e){
        }
        return list;
	}
	
	
	/**
	 * 统计总数为了分页
	 * @param takeid
	 * @return
	 * 2005-11-4 16:52:40 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageTakeDAO#messageTakeCount(int)
	 */
	public int messageTakeCount(int takeid, Boolean bea) {
        Session session = ConnClub.getSession();
        List list = null;        
        StringBuffer hql = new StringBuffer();
        int i = 0;
        try{
            hql.append("select count(*) from ClubMessageTakeItem  where cmTakeID=?");
            if(bea!=null){
            	hql.append(" and cmIsTake=?");
            }
            Query query = session.createQuery(hql.toString());
            query.setInteger(0, takeid);
            if(bea!=null){
            	query.setBoolean(1, bea.booleanValue());
            }
            list = query.list();
            Iterator it = list.iterator();
            Integer results = null;
            while(it.hasNext()){
                results = (Integer) it.next();
                i = results.intValue();
            }         
        }catch(HibernateException e){

        }
        return i;
	}

	
	
	/**
	 * 根据消息ID列出所有回复此消息的消息列表
	 * @param page
	 * @param pageNum
	 * @param id
	 * @return
	 * 2005-11-4 17:16:14 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageTakeDAO#messageTakeReList(int, int, int)
	 */
	public List messageTakeReList(int page, int pageNum, int id) {
        /* 计算从第几条记录开始读取数据 */
		if(page<1){page=1;}
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        List list = null;        
        if(id==0){
            return null;
        }
        try{
            hql.append("from ClubMessageTakeItem  where cmID=? or cmReID=?");
            hql.append(" order by cmID desc");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, id)
            .setInteger(1, id);
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();           
        }catch(HibernateException e){
            list = null;
        }
        return list;
	}

	
	/**
	 * 统计总数为了分页
	 * @param id
	 * @return
	 * 2005-11-4 17:17:13 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageTakeDAO#messageTakeReCount(int)
	 */
	public int messageTakeReCount(int id) {
        Session session = ConnClub.getSession();
        List list = null;        
        StringBuffer hql = new StringBuffer();
        int i = 0;
        if(cmReID==0){
            return 0;
        }
        try{
            hql.append("select count(*) from ClubMessageTakeItem  where cmID=? or cmReID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, id)
            .setInteger(1, id);
            list = query.list();
            Iterator it = list.iterator();
            Integer results = null;
            while(it.hasNext()){
                results = (Integer) it.next();
                i = results.intValue();
            }         
        }catch(HibernateException e){
            list = null;
        }
        return i;
	}

	
	/**
	 * 根据短消息ID更新消息cmIsTake字段 以判断消息是否被查阅过！
	 * @param id
	 * @param istake
	 * 2005-11-4 17:50:59 Made In GamVan
	 * @see com.gamvan.club.dao.ClubMessageTakeDAO#messageIsTakeUpdate(int, boolean)
	 */
	public void messageIsTakeUpdate(int id, boolean istake) {
        StringBuffer hql = new StringBuffer("");
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction(); 
        try{
            hql.append("update ClubMessageTakeItem set cmIsTake=? where cmID=?");
            Query query = session.createQuery(hql.toString())
            .setBoolean(0, istake)
            .setInteger(1, id);
            query.executeUpdate();
            tran.commit();            
        }catch(HibernateException e){
        	
        }
	}

}
