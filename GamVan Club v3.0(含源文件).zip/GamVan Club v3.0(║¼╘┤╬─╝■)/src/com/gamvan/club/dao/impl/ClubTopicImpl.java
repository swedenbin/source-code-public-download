/*
 * Created on 2005-10-15
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.ClubInfo;
import com.gamvan.club.ClubInfoEdit;
import com.gamvan.club.dao.ClubTopicDAO;
import com.gamvan.club.item.ClubContentItem;
import com.gamvan.club.item.ClubContentReItem;
import com.gamvan.club.item.ClubTopicItem;
import com.gamvan.club.item.ClubTopicReItem;
import com.gamvan.conn.ConnClub;

/**
 * 社区帖子的  添加 删除  更新操作内容
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicImpl extends ClubTopicItem implements ClubTopicDAO {
    private static final long serialVersionUID = 1L;
    private boolean bea = false;
    private ClubContentImpl ccil = new ClubContentImpl();
    private static final Logger logger = 
    	Logger.getLogger(ClubTopicImpl.class.getName());
    /**
     * 认证以下id不为0的主题， 如果id为-1，则不加限定更新整个表数据
     * @param tid
     * @param reid
     * @return
     */
    public int topicUpdateIsPass(int tid, int reid, boolean ispass){
        int i = 0;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql_0 = new StringBuffer();
        StringBuffer hql_1 = new StringBuffer();
        Query query ;
        try{
            hql_0.append("update ClubTopicReItem set topicIsPass=? ");
            if(reid!=-1){
                hql_0.append(" where topicReID= "+ reid +" ");
            }
            if(reid>0 || reid==-1){
                query = session.createQuery(hql_0.toString())
                .setBoolean(0, ispass);
                i = query.executeUpdate();
            }
            
            hql_1.append("update ClubTopicItem set topicIsPass=? ");
            if(tid!=-1){
                hql_1.append(" where topicID= "+ tid +" ");
            }
            if(tid>0 || tid==-1){
                query = session.createQuery(hql_1.toString())
                .setBoolean(0, ispass);
                i += query.executeUpdate();
            }
            tran.commit();      
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return i;
    }
    
    public int topicUpatePro(int tid, int reid, int pro){
        int i = 0;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        int id = 0;
        try{
            if(reid>0){
                id = reid;
                hql.append("update ClubTopicReItem set topicPro=? where topicReID=?");
            }else{
                id = tid;
                hql.append("update ClubTopicItem set topicPro=? where topicID=?");
            }
            Query query = session.createQuery(hql.toString())
            .setInteger(0, pro)
            .setInteger(1, id)
            ;
            i = query.executeUpdate();
            tran.commit();            
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return i;
    }

    public void topicDel(int id) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        try{
            /**
             * 级联删除
             */
            ClubTopicItem cti = (ClubTopicItem)session.get(ClubTopicItem.class, new Integer(id));
            cti.setTopicID(id);
            session.delete(cti); 
            tran.commit();
            ccil.contentDel(id);        
        }catch(HibernateException e){
            e.printStackTrace();
        }
    }
    
    public void topicReDel(int id) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        try{
            /**
             * 级联删除
             */
            ClubTopicReItem ctri = (ClubTopicReItem)session.get(ClubTopicReItem.class, new Integer(id));
            ctri.setTopicReID(id);
            session.delete(ctri);
            tran.commit();
            
            ccil.setTopicReID(id);
            ccil.contentReDel(id);   
        }catch(HibernateException e){
            e.printStackTrace();
        }
    }
    
    public void topicReDel_topicID(int id) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        try{
            /**
             * 级联删除
             */
            ClubTopicReItem ctri = new ClubTopicReItem();
            ctri.setTopicReID(id);
            session.delete(ctri);
            tran.commit(); 
            session.evict(ctri);
            
            ccil.setTopicReID(id);
            ccil.contentReDel(id);   
        }catch(HibernateException e){
            e.printStackTrace();
        }
    }
    
    /*用户的主题*/
    public int userTopicCount(int userid){
        int i = 0;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("select count(*) from ClubTopicItem where userID=?");               
            Query query = session.createQuery(hql.toString());
            query.setInteger(0, userid);
            List list = query.list();
            Iterator it = list.iterator();
            Integer results = null;
            while(it.hasNext()){
                results = (Integer) it.next();
                i = results.intValue();
            }
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return i;
    }
    
    public List userTopicList(int userid, int page, int pageNum){
        List list = null;        
        //计算从第几条记录开始读取数据  
        if(page<1)page=1;
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubTopicItem  where userID=?");
            hql.append(" and topicIsDel=?");
            hql.append(" order by topicID desc");
            Query query = session.createQuery(hql.toString());
            query.setInteger(0, userid);
            query.setInteger(1, topicIsDel);
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();           
        }catch(HibernateException e){
            list = null;
        }
        return list;
    }

    /*用户的回复*/
    public int userTopicReCount(int userid){
        int i = 0;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("select count(*) from ClubTopicReItem where userID=?");
            hql.append(" and topicIsDel=?");                 
            Query query = session.createQuery(hql.toString());
            query.setInteger(0, userid);
            query.setInteger(1, topicIsDel);
            List list = query.list();
            Iterator it = list.iterator();
            Integer results = null;
            while(it.hasNext()){
                results = (Integer) it.next();
                i = results.intValue();
            }
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return i;
    }
    
    public List userTopicReList(int userid, int page, int pageNum){
        List list = null;        
        //计算从第几条记录开始读取数据  
        if(page<1)page=1;
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubTopicReItem  where userID=?");
            hql.append(" and topicIsDel=?"); 
            hql.append(" order by topicReID desc");
            Query query = session.createQuery(hql.toString());
            query.setInteger(0, userid);
            query.setInteger(1, topicIsDel);
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();           
        }catch(HibernateException e){
            list = null;
        }
        return list;
    }
    
    /**
     * 更新主题
     * @param id
     * 2005-11-7 21:02:42 Made In GamVan
     * @see com.gamvan.club.dao.ClubTopicDAO#topicUpdate(int)
     */
    public void topicUpdate(int id){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        ClubTopicItem cti = null;
        //ClubContentItem cci = null;
        try{
            cti = (ClubTopicItem) session.load(ClubTopicItem.class, new Integer(id));
            cti.setTopic(topic);
            cti.setTopicList(topicList);
            cti.setTopicMood(topicMood);
            cti.setTopicType(topicType);
            cti.setTopicTypeNum(topicTypeNum);
            cti.setTopicLen(topicLen);
            session.update(cti);
            tran.commit();
            
            //级联更新帖子内容
            ccil.setTopicID(id);
            ccil.setContent(content);
            ccil.setContentCopyRight(contentCopyRight);
            ccil.setContentEmail(contentEmail);
            ccil.setContentImg(contentImg);
            ccil.setContentUrl(contentUrl);
            ccil.setContentUserPen(contentUserPen);
            ccil.contentUpdate(id);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    /**
     * 更新回复
     * @param id
     * 2005-11-7 21:02:55 Made In GamVan
     * @see com.gamvan.club.dao.ClubTopicDAO#topicReUpdate(int)
     */
    public void topicReUpdate(int id){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        ClubTopicReItem ctri = null;
        try{
            ctri = (ClubTopicReItem) session.load(ClubTopicReItem.class, new Integer(id));
            ctri.setTopic(topic);
            ctri.setTopicList(topicList);
            ctri.setTopicMood(topicMood);
            ctri.setTopicType(topicType);
            ctri.setTopicTypeNum(topicTypeNum);
            ctri.setTopicLen(topicLen);
            session.save(ctri);
            tran.commit();
            //级联更新帖子内容
            ccil.setContent(content);
            ccil.setContentCopyRight(contentCopyRight);
            ccil.setContentEmail(contentEmail);
            ccil.setContentImg(contentImg);
            ccil.setContentUrl(contentUrl);
            ccil.setContentUserPen(contentUserPen);
            ccil.contentReUpdate(id);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    

    /**
     * 更新主题表topicReID,为回复表最后一条记录的ID，用于排序规则。
     */
    public void topicID_reID(int id){
        //提取回复表最后一片帖子的ID
		ClubInfo ci = new ClubInfo();
        int lastReID = ci.getLastReID();
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        String hql = "";
        try{
	        hql = "update ClubTopicItem set topicReID=? where topicID=?";
	        session.createQuery(hql)
	        .setInteger(0, lastReID)
	        .setInteger(1, id)
	        .executeUpdate();
	        tran.commit();
        }catch(HibernateException e){
            e.printStackTrace();
        } 

    }
    
    
    public void topicUpdateLastInfo(int id, int reid, String sTime, String sUser){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        String hql = "";
        try{
        hql = "update ClubTopicItem set topicReID=?, topicLastReTime=?, topicLastReUser=? where topicID=?";
            session.createQuery(hql)
            .setInteger(0, reid)
            .setString(1, sTime)
            .setString(2, sUser)
            .setInteger(3, id)
            .executeUpdate();
            tran.commit();
        }catch(HibernateException e){
            e.printStackTrace();
        } 
    }
    
    
    /**
     * 向主题表添加主题和内容
     * @return
     * 2005-11-7 21:01:19 Made In GamVan
     * @see com.gamvan.club.dao.ClubTopicDAO#topicReAdd()
     */
    public ClubTopicItem topicAdd() {
        Session session = ConnClub.getSession();
        ClubTopicItem cti = null;
        ClubContentItem cci = null;
        try{
        	Transaction tran = session.beginTransaction();
            cti = new ClubTopicItem();
            cti.setTopicReID(topicReID);
            cti.setTopicOrder(topicOrder);
            cti.setTopicLayer(topicLayer);
            cti.setTopicTree(topicTree);
            cti.setTopic(topic);
            cti.setUserName(userName);
            cti.setCcID(ccID);
            cti.setCcID2(ccID2);
            cti.setCcID1(ccID1);
            cti.setMoveCCID(moveCCID);
            cti.setTopicList(topicList);
            cti.setTopicMood(topicMood);
            cti.setTopicPro(topicPro);
            cti.setTopicType(topicType);
            cti.setTopicTypeNum(topicTypeNum);
            cti.setTopicAddTime(topicAddTime);
            cti.setTopicAddip(topicAddip);
            cti.setTopicLastReUser(topicLastReUser);
            cti.setTopicLastReTime(topicLastReTime);
            cti.setMoveTime(moveTime);
            cti.setMoveUser(moveUser);
            cti.setTopicViewCount(topicViewCount);
            cti.setTopicReCount(topicViewCount);
            cti.setTopicLen(topicLen);
            cti.setUserID(userID);
            cti.setTopicIsPass(topicIsPass);
            cti.setTopicIsDel(topicIsDel);
            session.save(cti);
            this.topicID = cti.getTopicID();
            tran.commit();
            
            Transaction tran1 = session.beginTransaction();
            cci = new ClubContentItem();
            cci.setTopicID(topicID);
            cci.setContent(content);
            cci.setContentCopyRight(contentCopyRight);
            cci.setContentEmail(contentEmail);
            cci.setContentImg(contentImg);
            cci.setContentUrl(contentUrl);
            cci.setContentUserPen(contentUserPen);
            session.save(cci);
            tran1.commit();
        }catch(HibernateException e){
            cti = null;
            e.printStackTrace();
        }
        return cti;
    }

    /**
     * 向回复表添加主题和内容
     * @return
     * 2005-11-7 21:01:19 Made In GamVan
     * @see com.gamvan.club.dao.ClubTopicDAO#topicReAdd()
     */
    public ClubTopicReItem topicReAdd(){
        Session session = ConnClub.getSession();
        ClubTopicReItem ctri = null;
        ClubContentReItem ccri = null;
        try{
        	Transaction tran = session.beginTransaction();
            ctri = new ClubTopicReItem();
            ctri.setTopicID(topicID);
            ctri.setTopicOrder(topicOrder);
            ctri.setTopicLayer(topicLayer);
            ctri.setTopicTree(topicTree);
            ctri.setTopic(topic);
            ctri.setUserName(userName);
            ctri.setCcID(ccID);
            ctri.setCcID2(ccID2);
            ctri.setCcID1(ccID1);
            ctri.setTopicList(topicList);
            ctri.setTopicMood(topicMood);
            ctri.setTopicPro(topicPro);
            ctri.setTopicType(topicType);
            ctri.setTopicTypeNum(topicTypeNum);
            ctri.setTopicAddTime(topicAddTime);
            ctri.setTopicAddip(topicAddip);
            ctri.setTopicLastReUser(topicLastReUser);
            ctri.setTopicLastReTime(topicLastReTime);
            ctri.setTopicViewCount(topicViewCount);
            ctri.setTopicReCount(topicViewCount);
            ctri.setTopicLen(topicLen);
            ctri.setUserID(userID);
            ctri.setTopicIsPass(topicIsPass);
            ctri.setTopicIsDel(topicIsDel);
            session.save(ctri);
            tran.commit();
            this.topicReID = ctri.getTopicReID();
            
            Transaction tran1 = session.beginTransaction();
            ClubInfoEdit cie = new ClubInfoEdit();
            cie.updateLastReID(this.topicReID);
            ccri = new ClubContentReItem();
            ccri.setTopicID(topicID);
            ccri.setTopicReID(this.topicReID);
            ccri.setContent(content);
            ccri.setContentCopyRight(contentCopyRight);
            ccri.setContentEmail(contentEmail);
            ccri.setContentImg(contentImg);
            ccri.setContentUrl(contentUrl);
            ccri.setContentUserPen(contentUserPen);
            session.save(ccri);
            tran1.commit();

        }catch(HibernateException e){
            ctri = null;
            e.printStackTrace();
        }
        return ctri;
    }
  
    
    /**
     * 主题表的浏览次数累加
     * @param id
     * @return
     * 2005-11-7 21:00:31 Made In GamVan
     * @see com.gamvan.club.dao.ClubTopicDAO#topicReUpdateVcount(int)
     */
    public boolean topicUpdateVcount(int id) {
        bea = true;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        Transaction tran = session.beginTransaction();
        try{
            hql.append("update ClubTopicItem set ");
            hql.append(" topicViewCount=topicViewCount+1");
            hql.append(" where topicID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, id);
            query.executeUpdate();
            tran.commit();
            bea = true;
        }catch(Exception e){
            bea = false;
            e.printStackTrace();
        }
        return bea;
    }
    
    /**
     * 回复表的浏览次数累加
     * @param id
     * @return
     * 2005-11-7 21:00:31 Made In GamVan
     * @see com.gamvan.club.dao.ClubTopicDAO#topicReUpdateVcount(int)
     */
    public boolean topicReUpdateVcount(int id) {
        bea = false;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        Transaction tran = session.beginTransaction();
        try{
            hql.append("update ClubTopicReItem set ");
            hql.append(" topicViewCount=topicViewCount+1");
            hql.append(" where topicReID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, id)
            ;
            query.executeUpdate();
            tran.commit();
            bea = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return bea;
    }
    
    /**
     * 主题表的回复次数累加
     * @param id
     * @return
     * 2005-11-7 20:59:44 Made In GamVan
     * @see com.gamvan.club.dao.ClubTopicDAO#topicUpdateRcount(int)
     */
    public boolean topicUpdateRcount(int id) {
        bea = true;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        Transaction tran = session.beginTransaction();
        try{
            hql.append("update ClubTopicItem set ");
            hql.append(" topicReCount=topicReCount+1");
            hql.append(" where topicID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, id)
            ;
            query.executeUpdate();
            tran.commit();
        }catch(Exception e){
            bea = false;
            e.printStackTrace();
        }
        return bea;
    }
    
    /**
     * 回复表主题的回复次数累加
     * @param id
     * @return
     * 2005-11-7 20:59:13 Made In GamVan
     * @see com.gamvan.club.dao.ClubTopicDAO#topicReUpdateRcount(int)
     */
    public boolean topicReUpdateRcount(int id) {
        bea = false;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        Transaction tran = session.beginTransaction();
        try{
            hql.append("update ClubTopicReItem set ");
            hql.append(" topicReCount=topicReCount+1");
            hql.append(" where topicReID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, id);
            query.executeUpdate();
            session.flush();
            tran.commit();
            bea = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return bea;
    }

    /**
     * 主题表的主题
     * @param id
     * @return
     * 2005-11-7 20:59:02 Made In GamVan
     * @see com.gamvan.club.dao.ClubTopicDAO#topicInfo(int)
     */
    public ClubTopicItem topicInfo(int id) {
        ClubTopicItem cti = null;
        Session session = ConnClub.getSession();
        try{
        	String hql = "from ClubTopicItem where topicID=?";
        	Query query = session.createQuery(hql);
        	query.setInteger(0, id);
            cti = (ClubTopicItem)query.uniqueResult();
        }catch(HibernateException e){
        	cti = null;
            e.printStackTrace();
        }
        return cti;   
    }

    /**
     * 回复表的主题
     * @param id
     * @return
     * 2005-11-7 20:58:40 Made In GamVan
     * @see com.gamvan.club.dao.ClubTopicDAO#topicReInfo(int)
     */
    public ClubTopicReItem topicReInfo(int id) {
        ClubTopicReItem ctri = null;
        Session session = ConnClub.getSession();
        try{
        	String hql = "from ClubTopicReItem where topicReID=?";
        	Query query = session.createQuery(hql);
        	query.setInteger(0, id);
            ctri = (ClubTopicReItem)query.uniqueResult();
        }catch(HibernateException e){
        	ctri = null;
            e.printStackTrace();
        }
        return ctri; 
    }


    /**
     * 依据reid是否为0判断回复的是主题还是回复从而更新回复主题表内的相关回复的排序
     * 如果reid为０则回复内容为主题 给以主题是id相关回复的topicOrder字段累加1
     * 否则只给topicOrder字段大于order的相关回复的 topicOrder字段累加1
     * @param id 所回复的帖子的主题ID号 <主键>
     * @param reid 所回复的回复帖子的ID号 <主键>
     * @param order
     * 2005-11-7 20:57:30 Made In GamVan
     * @see com.gamvan.club.dao.ClubTopicDAO#topicReUpdateOrder(int, int, int)
     */
	public void topicReUpdateOrder(int id, int reid, int order) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubTopicReItem set topicOrder=topicOrder+1 ");
            if(reid==0){
                hql.append(" where topicID="+ id +" ");
            }else{
                hql.append(" where topicID="+ id +" and topicOrder > "+ order +"");
            }
            Query query = session.createQuery(hql.toString()) ;
            query.executeUpdate();
            session.flush();
            tran.commit();
        }catch(Exception e){
            
        }
	}


	/**
	 * 更新帖子类型  目前主要用于结贴
	 * @param id
	 * @param type
	 * 2005-11-13 22:18:04 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicDAO#topicTypeUpdate(int, short)
	 */
	public void topicTypeUpdate(int id, short type) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubTopicItem ");
            hql.append(" set topicType=? ");
            hql.append(" where topicID=?");
            Query query = session.createQuery(hql.toString());
            query.setShort(0, type);
            query.setInteger(1, id);
            query.executeUpdate();
            session.flush();
            tran.commit();
        }catch(Exception e){
        	logger.error(e.toString());
            e.printStackTrace();
        }
	}
	
    /**
     * 移动帖子
     * @param tid 帖子
     * @param moveccid 目标版面ID
     * @param ccid1 版面ID
     * @param ccid2 版面ID
     * @param byuser 操作人员
     * @param movetime 移动时间 
     * @param savelink 判断送是否在原来的版面保留链接
	 * 2005-12-1 1:36:42 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicDAO#topicMove(int, int, int, int, java.lang.String, java.lang.String, java.lang.String)
	 */
	public void topicMove(int tid, int moveccid
			, int ccid1, int ccid2
			, String byuser, String movetime
			, String savelink ) 
	{
		Session session = ConnClub.getSession();
		Transaction tran = session.beginTransaction();
		StringBuffer hql = new StringBuffer("");
		try{
			hql.append("update ClubTopicItem set ccID=?, ccID2=?");
			hql.append(", ccID1=?");
			if(savelink.equals("1")){
				hql.append(", moveCCID=ccID");
			}else{
				hql.append(", moveCCID=0");
			}
			hql.append(", moveUser=?");
			hql.append(", moveTime=?");
			hql.append(" where topicID=?");
			Query query = session.createQuery(hql.toString());
			query.setInteger(0, moveccid);
			query.setInteger(1, ccid2);
			query.setInteger(2, ccid1);
			query.setString(3, byuser);
			query.setString(4, movetime);
			query.setInteger(5, tid);
			query.executeUpdate();
			tran.commit();            
		}catch(HibernateException e){
			logger.error(e.toString());
			e.printStackTrace();
		}
	}


	/**
	 * 对主题表单独字段进行更新
	 * @param tid
	 * @param field 字段名
	 * @param num
	 * 2005-12-1 1:56:14 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicDAO#topicFieldUpdate(int, java.lang.String, int)
	 */
	public void topicFieldUpdate(String where, String field, int num) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer("");
        try{
        	hql.append("update ClubTopicItem set ");
        	hql.append(field);
        	hql.append("=? ");
        	hql.append(where);
            Query query = session.createQuery(hql.toString())
            .setInteger(0, num);
            query.executeUpdate();
            tran.commit();
        }catch(HibernateException e){
        	logger.error(e.toString());
        }
	}


	/**
	 * 对回复表单独字段进行更新
	 * @param reid
	 * @param field 字段名
	 * @param num
	 * 2005-12-1 1:56:46 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicDAO#topicFieldUpdate_re(int, java.lang.String, int)
	 */
	public void topicFieldUpdate_re(String where, String field, int num) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer("");
        try{
        	hql.append("update ClubTopicReItem set ");
        	hql.append(field);
        	hql.append("=?");
        	hql.append(where);
            Query query = session.createQuery(hql.toString())
            .setInteger(0, num);
            query.executeUpdate();
            tran.commit();
        }catch(HibernateException e){
        	logger.error(e.toString());
        }
	}
	
	/**
	 * 逻辑删除主题
	 * @param id
	 * @param isdel
	 * 2005-12-12 4:41:57 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicDAO#topicIsDelUpdate(int, byte)
	 */
	public void topicIsDelUpdate(int id, byte isdel){
	     Session session = ConnClub.getSession();
	        Transaction tran = session.beginTransaction();
	        StringBuffer hql = new StringBuffer("");
	        try{
	        	hql.append("update ClubTopicItem set topicIsDel=? ");
	        	hql.append(" where topicID=?");
	            Query query = session.createQuery(hql.toString())
	            .setByte(0, isdel)
	            .setInteger(1, id);
	            query.executeUpdate();
	            tran.commit();
	        }catch(HibernateException e){
	        	e.printStackTrace();
	        }
	}
	
	/**
	 * 逻辑删除主题
	 * @param id
	 * @param isdel
	 * 2005-12-12 4:41:57 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicDAO#topicIsDelUpdate(int, byte)
	 */
	public void topicIsDelUpdate_re(int reid, byte isdel){
	     Session session = ConnClub.getSession();
	        Transaction tran = session.beginTransaction();
	        StringBuffer hql = new StringBuffer("");
	        try{
	        	hql.append("update ClubTopicReItem set topicIsDel=? ");
	        	hql.append(" where topicReID=?");
	            Query query = session.createQuery(hql.toString())
	            .setByte(0, isdel)
	            .setInteger(1, reid);
	            query.executeUpdate();
	            tran.commit();
	        }catch(HibernateException e){
	        	e.printStackTrace();
	        }
	}
	/* test
	public static void main(String args[]){
		ConnClub.init();
		ClubTopicImpl ctim = new ClubTopicImpl();
		ctim.topicID_reID(8282);
		ClubInfo ci = new ClubInfo();
        int lastReID = ci.getLastReID();
		System.out.println(lastReID);
		ConnClub.closeSession2();
	}
	*/
	
}
