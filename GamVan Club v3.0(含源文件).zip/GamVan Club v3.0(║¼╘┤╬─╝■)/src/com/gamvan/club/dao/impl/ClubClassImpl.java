/* 
 * Created on 2005-12-25
 * Last modified on 2006-1-23
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.CacheMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.ClubCounter;
import com.gamvan.club.dao.ClubClassDAO;
import com.gamvan.club.item.ClubClassItem;
import com.gamvan.club.item.ClubCounterItem;
import com.gamvan.conn.ConnClub;
import com.gamvan.tools.FormatDateTime;

public class ClubClassImpl implements ClubClassDAO {
	private static final Logger logger = 
		Logger.getLogger(ClubClassImpl.class.getName());

	/**
	 * 
	 * @param hql
	 * @return
	 * @see com.gamvan.club.dao.ClubClassDAO#classdList(java.lang.String)
	 * @author GamVan Studio by 我容易么我
	 */
	public List classdList(String hql) {
		List list = null;
		Session session = ConnClub.getSession();
        try{
        	Query query = session.createQuery(hql);
        	//启用查询缓存
            query.setCacheable(true); 
            //为查询指定其命名的缓存区域
            query.setCacheRegion("classCache");
            //* 从二级缓存读写数据
            query.setCacheMode(CacheMode.NORMAL);
            list = query.list();
        }catch(HibernateException e){
            logger.error("版面列表提取失败：" + e.toString());
        }
		return list;
	}
	
	/**
	 * 更新版面文章统计信息
	 * @param ccid 版面ID编号
	 * @param ct 主题数
	 * @param cr 回复数
	 * @return
	 * @see com.gamvan.club.dao.ClubClassDAO#classCounter(int, int, int)
	 * @author GamVan Studio by 我容易么我
	 */
	public boolean classCounter(int ccid, int ct, int cr) {
		boolean bea = false;
        ClubCounter ccu = new ClubCounter();
        ClubCounterItem cuti = ccu.clubCounterInfo();
        if(cuti==null){
        	logger.error("社区统计基本信息提取失败！版面文章统计终止！");
        	return false;
        }
        String clubToday = cuti.getClubToday();
        /* 如果clubToday是今天的日期则返回false */
        boolean isAfter = FormatDateTime.dateCompare(clubToday);
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubClassItem set ");
            hql.append(" ccTopic=ccTopic+");
            hql.append(ct);
            hql.append(", ccReply=ccReply+");
            hql.append(cr);
            if(isAfter){ 
                hql.append(", ccYesterTopic = ccTodayTopic");
                hql.append(", ccYesterReply = ccTodayReply");
                //if(ct>0){
                    hql.append(", ccTodayTopic=");
                    hql.append(ct);
                //}
                //if(cr>0){
                    hql.append(", ccTodayReply="); 
                    hql.append(cr);
                //}
            }else{
                if(ct>0){
                	hql.append(", ccTodayTopic=ccTodayTopic+");
                    hql.append(ct);
                }
                if(cr>0){
                	hql.append(", ccTodayReply=ccTodayReply+"); 
                    hql.append(cr);  
               }
            }
            if(ccid>0){
                hql.append(" where ccID=?");
            }
            Query query = session.createQuery(hql.toString());
            if(ccid>0){
            	query.setInteger(0, ccid);
            }
            query.executeUpdate();
            tran.commit();
        }catch(HibernateException e){
        	logger.error("版面文章统计更新失败：" + e.toString());
        }
		return bea;
	}

	/**
	 * 
	 * @param ccid
	 * @return
	 * @see com.gamvan.club.dao.ClubClassDAO#classInfo(int)
	 * @author GamVan Studio by 我容易么我
	 */
	public ClubClassItem classInfo(int ccid) {
    	if(ccid<=0){
    		return null;
    	}
        ClubClassItem cci = null;
        Session session = ConnClub.getSession();
        String hql = new String();
        try{
            hql = "from ClubClassItem where ccID=?";
            Query query = session.createQuery(hql.toString())
            .setInteger(0, ccid);
            //启用查询缓存
            query.setCacheable(true); 
            //为查询指定其命名的缓存区域
            query.setCacheRegion("classCache");
            //* 从二级缓存读写数据
            query.setCacheMode(CacheMode.NORMAL);
            cci = (ClubClassItem)query.uniqueResult();
        }catch(HibernateException e){
        	logger.error(e.toString());
        }        
        return cci;
	}

	
}
