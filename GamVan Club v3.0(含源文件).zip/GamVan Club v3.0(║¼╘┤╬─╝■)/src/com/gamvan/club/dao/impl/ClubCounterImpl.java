/*
 * Created on 2006-1-22
 * Last modified on 2006-1-22
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.classed.ClubClassInfo;
import com.gamvan.club.dao.ClubCounterDAO;
import com.gamvan.club.item.ClubCounterItem;
import com.gamvan.conn.ConnClub;
import com.gamvan.tools.FormatDateTime;

/**
 * @author GamVan Studio by 我容易么我
 */
public class ClubCounterImpl extends ClubCounterItem
	implements ClubCounterDAO
{
	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = 
		Logger.getLogger(ClubCounterImpl.class.getName());
	
	/**
     * 社区统计相关信息
     * @param hits 点击数
     * @param tpv 今日pv
     * @param ct 社区主题
     * @param cr 社区回复
     * @param cb 社区注册用户 男 人数
     * @param cg 社区注册用户 女 人数
     * @param cm 最高在线人数
     * @param nu 最后注册用户名
	 * @return
	 * 2006-1-22 19:57:51
	 * @author GamVan Studio by 我容易么我
	 */
	public void counterUpdate(int hits, int tpv, int ct, int cr, int cb,
			int cg, int cm, String nu) {
		
		ClubCounterItem cci = clubCounterInfo();
		if(cci!=null){
			clubToday = cci.getClubToday();
			clubMostOnline = cci.getClubMostOnline();
		}else{
			logger.error("社区基本统计信息提取失败！");
			return;
		}
		String now= FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
		StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubCounterItem set clubTemp=0");
            if(hits!=0){
                hql.append(", clubHits = clubHits + "+ hits +"");
            }
            if(cb!=0)
            hql.append(", clubBoy = clubBoy +" + cb +"");
            
            if(cg!=0)
            hql.append(", clubGirl = clubGirl +" + cg +"");
            
            if(ct!=0)
            hql.append(", clubTopic = clubTopic + "+ ct +"");
            
            if(cr!=0)
            hql.append(", clubReply = clubReply + "+ cr +"");
            
            if(clubToday!=null && !clubToday.equals(""))
            {
                if(FormatDateTime.dateCompare(clubToday)){
                    hql.append(", clubYesterPV = clubTodayPV");
                    hql.append(", clubTodayPV = "+ tpv +"");
                    hql.append(", clubYesterTopic = clubTodayTopic");
                    hql.append(", clubYesterReply = clubTodayReply");
                    hql.append(", clubTodayTopic = "+ ct +"");
                    hql.append(", clubTodayReply = "+ cr +"");
                    hql.append(", clubToday ='"+ now +"'");
                    ClubClassInfo classinfo = new ClubClassInfo();
                    classinfo.classCounter(0,0,0);
                }else{
                    if(tpv!=0){
                        hql.append(", clubTodayPV = clubTodayPV + "+ tpv +"");
                        }
                    if(ct>0){
                        hql.append(", clubTodayTopic = clubTodayTopic + "+ ct +"");
                    }
                    if(cr>0){
                        hql.append(", clubTodayReply = clubTodayReply + "+ cr +"");
                    }
                }
            }
            else{
                hql.append(", clubToday ='"+ now +"'");
            }
            
            if(cm > clubMostOnline){
                hql.append(", clubMostOnline = clubMostOnline +" + cm +"");
            }
            
            if(!nu.equals("")){
                hql.append(", clubNewUser = :clubNewUser");
            }
            Session session = ConnClub.getSession();
            Transaction ts = session.beginTransaction();
            Query query = session.createQuery(hql.toString());
            if(!nu.equals("")){
                query.setString("clubNewUser", nu);
            }
            query.executeUpdate();
            ts.commit(); 
        }catch(HibernateException e){
            logger.info("更新统计信息出错：" + e.toString());
        }
	}
	
	/**
	 * 提取统计信息
	 * @return ClubCounterItem
	 * 2006-1-22 20:15:05
	 * @author GamVan Studio by 我容易么我
	 */
	public ClubCounterItem clubCounterInfo() {
    	ClubCounterItem cci = null;
        Session session = ConnClub.getSession();
        try{
        	String hql = "from com.gamvan.club.item.ClubCounterItem";
        	Query query = session.createQuery(hql);
        	query.setMaxResults(1);
            cci = (ClubCounterItem)query.uniqueResult();
        }catch(HibernateException e){
            logger.error(e.toString());
        }
    	return cci;
	}

}
