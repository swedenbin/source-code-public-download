/* 
 * Created on 2005-12-1
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gamvan.club.dao.ClubOnlineDAO;
import com.gamvan.club.item.ClubOnlineItem;
import com.gamvan.conn.ConnClub;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubOnlineImpl implements ClubOnlineDAO{

	/**
	 * 加入到在线名单
	 * @param sessionid
	 * @param userip
	 * @param userid
	 * @param username
	 * @param userhide
	 * @param logintime
	 * @param lasttime
	 * @param lastymdhms 年月日时分秒组成的数字
	 * @param userarea
	 * @return
	 * 2005-12-1 20:49:31 Made In GamVan
	 * @see com.gamvan.club.dao.ClubOnlineDAO#onlineAdd(java.lang.String
	 * 		, java.lang.String, int, java.lang.String, boolean
	 * 		, java.lang.String, java.lang.String, int, java.lang.String)
	 */
	public ClubOnlineItem onlineAdd(String sessionid, String userip
			, int userid, String username
			, boolean userhide, String logintime
			, String lasttime, long lastymdhms, String userarea) 
	{
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        ClubOnlineItem coli = null;
        try{
            coli = new ClubOnlineItem();
            coli.setSessionID(sessionid);
            coli.setUserip(userip);
            coli.setOnUserID(userid);
            coli.setUserName(username);
            coli.setUserHide(userhide);
            coli.setLastTime(logintime);
            coli.setLoginTime(lasttime);
            coli.setLastYMDHMS(lastymdhms);
            coli.setUserArea(userarea);
            session.save(coli) ;
            tran.commit();
        }catch(HibernateException e){

        }
		return coli;
	}

	/**
	 * 更新在线人员信息
	 * @param type 更新条件 1按照ip更新、2按照sessionid更新
	 * @param sessionid
	 * @param userid
	 * @param username
	 * @param lasttime
	 * @param lastymdhms 年月日时分秒组成的数字
	 * @param userarea
	 * 2005-12-1 21:31:41 Made In GamVan
	 * @see com.gamvan.club.dao.ClubOnlineDAO#onlineUpdate(int, java.lang.String
	 * 			, int, java.lang.String, java.lang.String, int, java.lang.String)
	 */
	public void onlineUpdate(int type, String sessionid, String userip
			, int userid, String username
			, String lasttime, long lastymdhms
			, String userarea) 
	{
		Session session = ConnClub.getSession();
		Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
        	hql.append("update ClubOnlineItem set ");
        	hql.append(" onUserID=");
        	hql.append(userid);
        	hql.append(", userName=?");
        	hql.append(", lastTime=?");
        	hql.append(", lastYMDHMS=?");
        	hql.append(", userArea=?");
        	if(type==1){
        		hql.append(" where userip=?");
        	}
        	else if(type==2){
        		hql.append(" where sessionID=?");
        	}
        	Query query = session.createQuery(hql.toString())
        	.setString(0, username)
        	.setString(1, lasttime)
        	.setLong(2, lastymdhms)
        	.setString(3, userarea);
        	if(type==1){
        		query.setString(4, userip);
        	}
        	else if(type==2){
        		query.setString(4, sessionid);
        	}
        	query.executeUpdate();
        	tran.commit();
        }catch(HibernateException e){
        	e.printStackTrace();
        }
		
	}

	public void onlineDelTimeout(long timeout) {
		Session session = ConnClub.getSession();
		Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
        	hql.append("delete from ClubOnlineItem where ");
        	hql.append(" lastYMDHMS<");
        	hql.append(timeout);
        	Query query = session.createQuery(hql.toString());
        	query.executeUpdate();
        	tran.commit();
        }catch(HibernateException e){
        	e.printStackTrace();
        }
	}
	
	/**
	 * 
	 * @param page
	 * @param pageNum
	 * @return
	 * 2005-12-1 21:24:36 Made In GamVan
	 * @see com.gamvan.club.dao.ClubOnlineDAO#onlineList(int, int)
	 */
	public List onlineList(int page, int pageNum) {
        /* 计算从第几条记录开始读取数据 */   
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        List list = null;  
        Session session = ConnClub.getSession();
        String hql = new String();
        try{
            hql = "from ClubOnlineItem order by lastTime desc";
            Query query = session.createQuery(hql);
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return list;
	}
	
	/**
	 * 统计在线人数
	 * @return
	 * 2005-12-1 21:26:41 Made In GamVan
	 * @see com.gamvan.club.dao.ClubOnlineDAO#onlineCount()
	 */
	public int onlineCount() {
        /* 计算从第几条记录开始读取数据 */  
		int i = 0;
        Session session = ConnClub.getSession();
        String hql = new String();
        try{
            hql = "select count(*) from ClubOnlineItem";
            Query query = session.createQuery(hql);
            Iterator it = query.iterate();
            Integer results = null;
            while(it.hasNext()){
                results = (Integer) it.next();
                i = results.intValue();
            }
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return i;
	}

	public ClubOnlineItem onlineInfo(String sessionid, String userip, int userid) {
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        ClubOnlineItem coli = null;
        try{
            hql.append("from ClubOnlineItem where ");
            if(sessionid!=null){
            	hql.append(" sessionID=?");
            }
            else if(userip!=null){
            	hql.append(" userip=?");
            	hql.append(userip);
            }
            else if(userid>0){
            	hql.append(" onUserID=");
            	hql.append(userid);
            }else{
            	return null;
            }
            Query query = session.createQuery(hql.toString());
            if(sessionid!=null){
            	query.setString(0, sessionid);
            }
            query.setMaxResults(1);
            coli = (ClubOnlineItem)query.uniqueResult();
        }catch(HibernateException e){
            e.printStackTrace();
        }
		return coli;
	}

}
