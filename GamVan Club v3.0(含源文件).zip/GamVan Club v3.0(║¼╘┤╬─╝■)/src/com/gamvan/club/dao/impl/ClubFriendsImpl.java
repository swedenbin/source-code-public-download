/* 
 * Created on 2005-12-1
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.ClubFriendsDAO;
import com.gamvan.club.item.ClubFriendsItem;
import com.gamvan.conn.ConnClub;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubFriendsImpl implements ClubFriendsDAO{
	
	/**
	 * 添加好友
	 * @param meid 操作用户ID
	 * @param meName 操作用户的名字
	 * @param friendid 朋友的ID
	 * @param friendname 朋友的名字
	 * @param addtime 添加时间
	 * @param message 申请好友时的消息提醒
	 * @param meip 操作IP
	 * @param isOnLine 是否在线
	 * @return
	 * 2005-12-1 15:44:52 Made In GamVan
	 * @see com.gamvan.club.dao.ClubFriendsDAO#friendsAdd(int, java.lang.String, int, java.lang.String, java.lang.String, java.lang.String, java.lang.String, int)
	 */
	public ClubFriendsItem friendsAdd(int meid, String meName
			, int friendid, String friendname
			, String addtime, String message, String meip, int isOnLine)
	{
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        ClubFriendsItem cfi = null;
        try{
        	cfi = new ClubFriendsItem();
        	cfi.setUserMeID(meid);
	        cfi.setUserMe(meName);
	        cfi.setUserFriendID(friendid);
	        cfi.setUserFriend(friendname);
	        cfi.setAddTime(addtime);
	        cfi.setUserMessage(message);
	        cfi.setUserIp(meip);
	        cfi.setIsOnLine(isOnLine);
	        session.save(cfi);
	        tran.commit();
        }catch(HibernateException e){
        	e.printStackTrace();
        }
        return cfi;
	}
	
	/**
	 * 按主键删除好友
	 * @param id
	 * 2005-12-1 15:56:33 Made In GamVan
	 * @see com.gamvan.club.dao.ClubFriendsDAO#friendsDel(int)
	 */
	public void friendsDel(int id) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        String hql = "";
        try{
            hql = "delete from ClubFriendsItem where cfID=?";
            Query query = session.createQuery(hql)
            .setInteger(0, id);
            query.executeUpdate();       
            tran.commit();
        }catch(HibernateException e){
        	e.printStackTrace();
        }
	}
	
	/**
	 * 
	 * @param meid
	 * @param friendid
	 * @return
	 * 2005-12-1 16:05:12 Made In GamVan
	 * @see com.gamvan.club.dao.ClubFriendsDAO#friendsInfo(int, int)
	 */
	public ClubFriendsItem friendsInfo(int meid, int friendid) {
        Session session = ConnClub.getSession();
        String hql = "";
        ClubFriendsItem cfi = null;
        try{
        	hql = "from ClubFriendsItem where userMeID=? and userFriendID=?";
            Query query = session.createQuery(hql)
            .setInteger(0, meid)
            .setInteger(1, friendid);
            query.setMaxResults(1);
            cfi = (ClubFriendsItem)query.uniqueResult(); 
        }catch(Exception e){
        	cfi = null;
        } 
        return cfi;
	}
	
	/**
	 * 按主人ID和朋友用户名查询好友
	 * @param meid
	 * @param friendname
	 * @return
	 * 2005-12-1 15:59:53 Made In GamVan
	 * @see com.gamvan.club.dao.ClubFriendsDAO#friendsInfo(int, java.lang.String)
	 */
	public ClubFriendsItem friendsInfo(int meid, String friendname) {
        Session session = ConnClub.getSession();
        String hql = "";
        ClubFriendsItem cfi = null;
        try{
            hql = "from ClubFriendsItem where userMeID=? and userFriend=?";
            Query query = session.createQuery(hql)
            .setInteger(0, meid)
            .setString(1, friendname);
            query.setMaxResults(1);
            cfi = (ClubFriendsItem)query.uniqueResult(); 
        }catch(Exception e){
        	cfi = null;
        } 
        return cfi;
	}
	
	/**
	 * 好友列表
	 * @param page
	 * @param pageNum
	 * @param order
	 * @param meid
	 * @param isOnLine 在线、离线、隐身
	 * @return
	 * 2005-12-1 18:40:51 Made In GamVan
	 * @see com.gamvan.club.dao.ClubFriendsDAO#friendsList(int, int, java.lang.String, int, int)
	 */
	public List friendsList(int page, int pageNum
			, String order, int meid
			, int isonline)
	{
        /* 计算从第几条记录开始读取数据 */
        if(page<1)page=1;
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        List list = null;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubFriendsItem ");
            if(meid!=-1){
	            hql.append(" where userMeID=");
	            hql.append(meid);
	            if(isonline!=-1){
	            	hql.append(" and isOnLine=");
	            	hql.append(isonline);
	            }
            }else{
	            if(isonline!=-1){
	            	hql.append(" where isOnLine=");
	            	hql.append(isonline);
	            }
            }
            hql.append(order);
            Query query = session.createQuery(hql.toString());
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();            
        }catch(HibernateException e){
        	e.printStackTrace();
            list = null;
        }
        return list;
	}
	/**
	 * 
	 * @param meid
	 * @param isOnLine
	 * @param hqlappend
	 * @return
	 * 2005-12-1 18:48:30 Made In GamVan
	 * @see com.gamvan.club.dao.ClubFriendsDAO#friendsCount(int, int, java.lang.String)
	 */
	public int friendsCount(int meid, int isonline, String hqlappend) {
        int i = 0;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("select count(*) from ClubFriendsItem ");
            if(meid!=-1){
	            hql.append(" where userMeID=");
	            hql.append(meid);
	            if(isonline!=-1){
	            	hql.append(" and isOnLine=");
	            	hql.append(isonline);
	            }
            }else{
	            if(isonline!=-1){
	            	hql.append(" where isOnLine=");
	            	hql.append(isonline);
	            }
            }
            hql.append(hqlappend);
            Query query = session.createQuery(hql.toString());
            Iterator it = query.iterate();
            Integer results = null;
            while(it.hasNext()){
                results = (Integer) it.next();
                i = results.intValue();
            }
        }catch(HibernateException e){
            e.printStackTrace();
        }
		return i;
	}
	
	/* test
	public static void main(String args[]){
		ConnClub.init();
		ClubFriendsImpl cfim = new ClubFriendsImpl();
		System.out.print(cfim.friendsList(1,1,"",29,-1));
	}
	*/
}
