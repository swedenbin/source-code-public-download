/*
 * Created on 2005-10-28
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import org.hibernate.CacheMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.ClubRuleDAO;
import com.gamvan.club.item.ClubRuleItem;
import com.gamvan.conn.ConnClub;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubRuleImpl extends ClubRuleItem implements ClubRuleDAO{
    private static final long serialVersionUID = 1L;

    public ClubRuleItem ruleInfo() {
        ClubRuleItem cri = null;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();  
        try{
            hql.append("from ClubRuleItem");
            Query query = session.createQuery(hql.toString());
            //启用查询缓存
            query.setCacheable(true); 
            //为查询指定其命名的缓存区域
            query.setCacheRegion("ruleCache");
            //* 从二级缓存读写数据
            query.setCacheMode(CacheMode.NORMAL);
            cri = (ClubRuleItem)query.uniqueResult();
        }catch(HibernateException e){
            throw new HibernateException
            ("系统发生意外错误，指令将不被执行，请重新尝试!");
        }
        return cri;
    }
    
    /**
     * 更新社区制度
     * @param credit
     * @param mark
     * @param money
     * 2005-11-29 20:11:40 Made In GamVan
     * @see com.gamvan.club.dao.ClubRuleDAO#ruleUpdate(java.lang.String, java.lang.String, java.lang.String)
     */
	public void ruleUpdate(String credit, String mark, String money) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();  
        try{
            hql.append("update ClubRuleItem set crCredit=?");
            hql.append(", crMark=?");
            hql.append(", crMoney=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, credit)
            .setString(1, mark)
            .setString(2, money);
            query.executeUpdate();
            tran.commit();        
        }catch(HibernateException e){

        }
	}

}
