/* 
 * Created on 2005-11-29
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.ClubTopicReUsersDAO;
import com.gamvan.club.item.ClubTopicReUsersItem;
import com.gamvan.conn.ConnClub;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicReUsersImpl implements ClubTopicReUsersDAO{
	
	/**
	 * 
	 * @param tid
	 * @param reusers
	 * @return
	 * 2005-11-30 0:39:47 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicReUsersDAO#reUsersAdd(int, java.lang.String)
	 */
	public ClubTopicReUsersItem reUsersAdd(int tid, String reusers) {
		Session session = ConnClub.getSession();
		Transaction tran = session.beginTransaction();
		ClubTopicReUsersItem ctrui = new ClubTopicReUsersItem();
		try{
			ctrui.setTopicID(tid);
			ctrui.setReUsers(reusers);
			session.save(ctrui);
			session.flush();
			tran.commit();
		}catch(HibernateException e){
			e.printStackTrace();          
		}
		return ctrui;
	}
	
	/**
	 * 
	 * @param tid
	 * @param reusers
	 * 2005-11-30 0:39:52 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicReUsersDAO#reUsersUpdate(int, java.lang.String)
	 */
	public void reUsersUpdate(int tid, String reusers) {
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        String hql = new String();
        try{      
            hql = "update ClubTopicReUsersItem set reUsers=? where topicID=?";
            Query query = session.createQuery(hql)
            .setString(0, reusers)
            .setInteger(1, tid);
            query.executeUpdate();
            tran.commit();            
        }catch(HibernateException e){
        	e.printStackTrace();
        }
	}
		
	/**
	 * 
	 * @param tid
	 * @return
	 * 2005-11-30 0:37:19 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicReUsersDAO#topicReUsersInfo(int)
	 */
	public ClubTopicReUsersItem reUsersInfo(int tid) {
		ClubTopicReUsersItem ctrui = new ClubTopicReUsersItem();
		Session session = ConnClub.getSession();
		String hql = new String();
		try{
			hql = "from ClubTopicReUsersItem where topicID=?";
			Query query = session.createQuery(hql)
			.setInteger(0, tid);
			query.setMaxResults(1);
			ctrui = (ClubTopicReUsersItem)query.uniqueResult();
		}catch(HibernateException e){
			e.printStackTrace();
		}
		return ctrui;
	}
	
	/**
	 * 删除该贴的回复人员名单信息
	 * @param tid
	 * 2005-11-30 0:48:27 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicReUsersDAO#reUsersDel(int)
	 */
	public void reUsersDel(int tid) {
		Session session = ConnClub.getSession();
		String hql = new String();
		try{
			hql = "delete from ClubTopicReUsersItem where topicID=?";
			Query query = session.createQuery(hql)
            .setInteger(0, tid);
            query.executeUpdate();
		}catch(HibernateException e){
			e.printStackTrace();
		}
	}
	/*
	public static void main(String args[]){
		ConnClub.init();
		ClubTopicReUsersImpl c = new ClubTopicReUsersImpl();
		//c.reUsersAdd(1, "sfsa");
		c.reUsersInfo(8286);
	}
	*/
}
