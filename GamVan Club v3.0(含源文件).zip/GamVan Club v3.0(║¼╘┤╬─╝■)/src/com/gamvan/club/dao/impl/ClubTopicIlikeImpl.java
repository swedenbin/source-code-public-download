/* 
 * Created on 2005-11-30
 * Last modified on 2006-1-25
 * Powered by GamVan.com
 */
package com.gamvan.club.dao.impl;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.ClubTopicIlikeDAO;
import com.gamvan.club.item.ClubTopicIlikeItem;
import com.gamvan.conn.ConnClub;

public class ClubTopicIlikeImpl implements ClubTopicIlikeDAO{
	
	private static final Logger logger = 
		Logger.getLogger(ClubTopicIlikeImpl.class.getName());
	/**
	 * 添加订阅信息
	 * @param topicid 帖子ID
	 * @param userid 用户ID
	 * @param topic 帖子标题
	 * @param username 用户名
	 * @param addtime 订阅时间
	 * @param lasttime 最后被查看的时间
	 * @param topiclastretime 帖子最后更新时间
	 * @param ccid
	 * @return
	 * @see com.gamvan.club.dao.ClubTopicIlikeDAO#ilikeAdd
	 * (int, java.lang.String, int, java.lang.String, int, java.lang.String, java.lang.String, java.lang.String, java.lang.String, int)
	 */
	public ClubTopicIlikeItem ilikeAdd(int topicid, String topic
			, int myuserid, String myusername
			, int topicuserid, String topicusername
			, String addtime, String lasttime
			, String topiclastretime, int ccid) 
	{
        Session session = ConnClub.getSession();
        Transaction tran =  session.beginTransaction();
        ClubTopicIlikeItem ctil = null;
        try{
            ctil = new ClubTopicIlikeItem();
            ctil.setTopicID(topicid);
            ctil.setTopic(topic);
            ctil.setMyUserID(myuserid);
            ctil.setMyUserName(myusername);
            ctil.setTopicUserID(topicuserid);
            ctil.setTopicUserName(topicusername);
            ctil.setAddTime(addtime);
            ctil.setLastTime(lasttime);
            ctil.setTopicLastReTime(topiclastretime);
            ctil.setCcID(ccid);
            session.save(ctil);
            tran.commit();
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return ctil;
	}
	
	/**
	 * 更新订阅主题的最后被订阅人查看的时间
	 * @param topicid
	 * @param myuserid
	 * @param lasttime
	 * 2005-11-30 15:04:50 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicIlikeDAO#ilikeUpdateLastTime(int, int, java.lang.String)
	 */
	public void ilikeUpdateLastTime
		(int topicid, int myuserid, String lasttime)
	{
        Session session = ConnClub.getSession();
        Transaction ts = session.beginTransaction();
		try{
             String hql = "update ClubTopicIlikeItem set lastTime=? where topicID=? and myUserID=?";
             Query query = session.createQuery(hql);
             query.setString(0, lasttime);
             query.setInteger(1, topicid);
             query.setInteger(2, myuserid);
             query.executeUpdate();
             ts.commit();
         }catch(HibernateException e){
        	 logger.error(e.toString());
             e.printStackTrace();
        }
	}
	
	
	public static void main(String args[]){
		com.gamvan.conn.ConnClub.init();
		ClubTopicIlikeImpl c = new ClubTopicIlikeImpl();
		c.ilikeUpdateLastTime(8084,2769,"2005-10-13 10:48");
	}
	
	/**
	 * 更新订阅主题的最后回复时间
	 * @param topicid
	 * @param lastReTime
	 * 2005-11-30 19:58:10 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicIlikeDAO#ilikeUpdateLastReTime(int, java.lang.String)
	 */
	public void ilikeUpdateLastReTime(int topicid, String last_retime) {
        Session session = ConnClub.getSession();
        Transaction ts = session.beginTransaction();
		try{
             String hql = "update ClubTopicIlikeItem set topicLastReTime=? where topicID=?";
             Query query = session.createQuery(hql);
             query.setString(0, last_retime);
             query.setInteger(1, topicid);
             query.executeUpdate();
             ts.commit();
         }catch(HibernateException e){
             e.printStackTrace();
        }
	}
	
	 /**
	  * 删除定阅
	  * @param id 
	  * @param type 0按主键、1按用户id删除、2按帖子id删除
	 * 2005-11-30 15:27:07 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicIlikeDAO#ilikeDel(int, int)
	 */
	public void ilikeDel(int id, int type) {
		Session session = ConnClub.getSession();
		Transaction ts = session.beginTransaction();
		StringBuffer hql = new StringBuffer();
        try{
            hql.append("delete from ClubTopicIlikeItem ");
            switch(type){
            	case 0 :
            		hql.append(" where likeID=");
            		hql.append(id);
            		break;
            	case 1 :
            		hql.append(" where topicID=");
            		hql.append(id);
            	case 2 :
            		hql.append(" where myUserID=");
            		hql.append(id);
            }
            Query query = session.createQuery(hql.toString());
            query.executeUpdate();
            ts.commit();
        }catch(HibernateException e){
        	e.printStackTrace();
        }
	}
	
	/**
	 * 
	 * @param topicid
	 * @param myuserid
	 * @return
	 * 2005-11-30 15:55:32 Made In GamVan
	 * @see com.gamvan.club.dao.ClubTopicIlikeDAO#ilikeInfo(int, int)
	 */
	public ClubTopicIlikeItem ilikeInfo(int topicid, int myuserid) {
		String hql = "";
        Session session = ConnClub.getSession();
        ClubTopicIlikeItem ctil = null;
        try{
            hql = "from ClubTopicIlikeItem where topicID=? and myUserID=?";
            Query query = session.createQuery(hql);
            query.setInteger(0, topicid);
            query.setInteger(1, myuserid);
            query.setMaxResults(1);
            ctil = (ClubTopicIlikeItem)query.uniqueResult();
        }catch(Exception e){
            
        }
        return ctil;
	}

	/**
	 * 用户订阅帖子列表
	 * @param page
	 * @param pageNum
	 * @param topicid  -1表示帖子ID不作为查询条件
	 * @param myuserid -1表示用户ID不作为查询条件
	 * @return
	 * @see com.gamvan.club.dao.ClubTopicIlikeDAO#ilikeList(int, int, int, int)
	 * com.gamvan.club.dao.impl
	 */
	public List ilikeList(int page, int pageNum, int topicid, int myuserid) {
        /* 计算从第几条记录开始读取数据 */  
        if(page<1)page=1;
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        Session session = ConnClub.getSession();
        List list = null;        
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubTopicIlikeItem where likeID>0 ");
            if(myuserid!=-1){
            	hql.append(" and myUserID=");
            	hql.append(myuserid);
            }
            if(topicid!=-1){
            	hql.append(" and topicID=");
            	hql.append(topicid);
            }
            hql.append(" order by likeID desc, topicID desc");
            Query query = session.createQuery(hql.toString());
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list(); 
        }catch(HibernateException e){
        	
        }
        return list;
	}
	
	public int ilikeCount(int topicid, int myuserid) {
        int i = 0;
        Session session = ConnClub.getSession();     
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("select count(*) from ClubTopicIlikeItem where likeID>0 ");
            if(myuserid!=-1){
            	hql.append(" and myUserID=");
            	hql.append(myuserid);
            }
            if(topicid!=-1){
            	hql.append(" and topicID=");
            	hql.append(topicid);
            }
            Query query = session.createQuery(hql.toString());
            Integer results = null;
            Iterator it = query.iterate();
            while(it.hasNext()){
                results = (Integer) it.next();
                i = results.intValue();
            }
        }catch(HibernateException e){
        }
        return i;
	}

}
