/* 
 * 2005-11-4
 * Made in GamVan.com
 */
package com.gamvan.club.dao;

import java.util.Collection;
import java.util.List;

import com.gamvan.club.item.ClubMessageTakeItem;

/**
 * 用户接收短消息部分
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public interface ClubMessageTakeDAO {
	
	public ClubMessageTakeItem messageTakeAdd();
	public ClubMessageTakeItem messageTakeInfo(int id);
	
	/**
	 * 依据短信主键删除
	 * @param id
	 * @return
	 * 2005-12-27 3:09:53 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public boolean messageTakeDel(int id);
	/**
	 * 依据短信用户ID批量删除
	 * @param id
	 * @return
	 * 2005-12-27 3:10:13 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public boolean messageTakeDel_userid(int userid);
	
	public int messageTakeDel(Collection ids);
	
	/**
	 * 接收消息列表
	 * @param page
	 * @param pageNum
	 * @param takeid 接收用户的注册ID
	 * @param bea 判断列出的是已读短消息还是未读短消息
	 * @return
	 * 2005-11-4 14:55:13 Made In GamVan
	 */
	public List messageTakeList(int page, int pageNum, int takeid, Boolean bea);
	/* 统计总数 为了分页 */
	public int messageTakeCount(int takeid, Boolean bea);
	
	
	/**
	 * 根据消息ID列出回复此消息的所有消息
	 * @param page
	 * @param pageNum
	 * @param id
	 * @return
	 * 2005-11-4 16:55:44 Made In GamVan
	 */
	public List messageTakeReList(int page, int pageNum, int id);
	/* 统计总数 为了分页 */
	public int messageTakeReCount(int id);
	
	
	/**
	 * 根据短消息ID更新消息cmIsTake字段 以判断消息是否被查阅过！
	 * @param id
	 * @param bea 字段cmIsTake
	 * 2005-11-4 17:50:21 Made In GamVan
	 * com.gamvan.club.dao
	 */
	public void messageIsTakeUpdate(int id, boolean bea);
	
}
