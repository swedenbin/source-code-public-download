package com.gamvan.club.manage;

import com.gamvan.club.dao.impl.ClubAfficheImpl;
import com.gamvan.club.item.ClubAfficheItem;

import com.gamvan.tools.FormatDateTime;
import com.gamvan.tools.TypeChange;

public class ClubAffiche extends ClubAfficheItem{
    private static final long serialVersionUID = 1L;
    private String message = new String("");

    /* 格式化当前时间 */
    private String now= FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    private ClubAfficheImpl caim = new ClubAfficheImpl();
    
    /**
     * 
     * @param act
     * @return
     * 2005-12-1 13:29:36 Made In GamVan
     * com.gamvan.club.manage
     */
    public boolean clubAffiche(String act){
        boolean bea = false;
        if(act.equals("add")){
            bea = afficheAdd();
        }else if(act.equals("edit")){
            bea = afficheEdit();
        }else{
             message= "您的操作触发一个美丽的意外，指令将不被执行，请重新尝试！";
        }
        return bea;
    }
    
    /**
     * 
     * @return
     * 2005-12-1 13:29:32 Made In GamVan
     * com.gamvan.club.manage
     */
    public boolean afficheAdd(){
        boolean bea = false;
         try{
             caim.setCcID(ccID);
             caim.setCaTopic(caTopic);
             caim.setCaContent(caContent);
             caim.setCaAddTime(now);
             caim.setCaByip(caByip);
             caim.setCaByUser(caByUser);
             caim.setCaDays(caDays);
             caim.afficheAdd();
             bea = true;
             message= "公告添加成功！";
         }catch(Exception e){
             message= "系统发生意外错误，指令将不被执行，请重新尝试！<br/>"+e.toString();
         }
        return bea;
    }
    
    /**
     * 
     * @return
     * 2005-12-1 13:29:41 Made In GamVan
     * com.gamvan.club.manage
     */
    public boolean afficheEdit(){
        boolean bea = false;
         try{
             caim.setCcID(ccID);
             caim.setCaTopic(caTopic);
             caim.setCaContent(caContent);
             caim.setCaByip(caByip);
             caim.setCaByUser(caByUser);
             caim.setCaDays(caDays);
             caim.afficheUpdate(caID);
             bea = true;
             message= "公告编辑成功！";
         }catch(Exception e){
             bea = false;
             message= "系统发生意外错误，指令将不被执行，请重新尝试！";
         }
        return bea;
    }
    
    /**
     * 
     * @param caid
     * @return
     * 2005-12-1 13:29:49 Made In GamVan
     * com.gamvan.club.manage
     */
    public ClubAfficheItem afficheInfo(int caid){
        ClubAfficheItem cai = null;
         try{
             cai = caim.afficheInfo(caid);
         }catch(Exception e){
             message= "系统发生意外错误，指令将不被执行，请重新尝试！";
         }
        return cai;
    }
    
    /**
     * 
     * @param caid
     * 2005-12-1 13:29:55 Made In GamVan
     * com.gamvan.club.manage
     */
    public void afficheDel(int caid){
        try{
            caim.afficheDel(caid);
        }catch(Exception e){
            message= "系统发生意外错误，指令将不被执行，请重新尝试！";
        }
    }
    
    /**
     * 
     * @param caIDs
     * @return
     * 2005-12-1 13:30:01 Made In GamVan
     * com.gamvan.club.manage
     */
    public boolean afficheDel(String[] caIDs){
        boolean bea = false;
        int caid = 0;
        try{
             int i = 0;   
             for (i = 0; i < caIDs.length; i++) {
                caid = TypeChange.stringToInt(caIDs[i]);
                caim.afficheDel(caid);
             } 
             bea = true;
             message= "所选公告已被删除！";
        }catch(Exception e){
             bea = false;
             message= "系统发生意外错误，指令将不被执行，请重新尝试！";
        }
        return bea;
    }
    
    /*
    public static void main(String args[]){
        ClubAffiche ca = new ClubAffiche();
        ClubAfficheItem cai =  (ClubAfficheItem) ca.afficheInfo(22);
    }
    */
    
    public String getMessage(){
        return this.message;
    }

}

