package com.gamvan.club.manage;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.conn.ConnClub;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubClassManage{
    private String ccSummary = "";
    private String message = "";
    private int ccID = 0;
    
    
    public boolean classManage(String act){
        boolean bea = false;
        if(act.equals("更新寄语")){
            bea = ccSummaryUpdate();
            if(bea){
                message= "版面寄语更新成功！";
            }else{
                message= "版面寄语更新失败，请重新尝试！";
            }
        }else{
            message= "您的操作触发一个美丽的意外，指令将不被执行，请重新尝试！";
        }
        return bea;
    }
    
    /**
     * 
     * @return
     */
    public boolean ccSummaryUpdate(){
        boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer("");
        try{
            hql.append("update ClubClassItem set ccSummary=? where ccID=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, ccSummary)
            .setInteger(1, ccID);
            query.executeUpdate();
            tran.commit();
            message= "版面寄语更新成功！";
            bea = true;
        }catch(Exception e){
            bea = false;
            message= "您的操作触发一个美丽的意外，指令将不被执行，请重新尝试！";
        }
        return bea;
    }
    
    public String getMessage(){
        return this.message;
    }
    
    public void setSummary(String ccSummary){
        ccSummary = ccSummary.trim();
        this.ccSummary = ccSummary;
    }

    public void setCCID(int ccID){
        this.ccID = ccID;
    }
}