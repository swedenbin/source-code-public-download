/*
 * Created on 2005-6-6
 * Last modified on 2005-6-11
 * Powered by GamVan.com
 */
package com.gamvan.club.manage;
import java.util.Iterator;
import java.util.List;

import com.gamvan.club.item.ClubAdItem;
import com.gamvan.conn.ConnClub;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class ClubAd extends ClubAdItem{
    private static final long serialVersionUID = 1L;
    
    private String message = "";
	private String act = null;
	private StringBuffer ads = new StringBuffer();

    public void doAd(){
        if(act.equals("add")){
            adAdd();
        }else if(act.equals("edit")){
            adUpdate();
        }else if(act.equals("del")){
            adDel();
        }else{
            message = "操作内容不详，操作失败！";
        }
    }
    
	public void adAdd(){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        ClubAdItem cai = new ClubAdItem();
		try{
		    cai.setAdObj(adObj);
            cai.setAdTxt(adTxt);
            cai.setAdUrl(adUrl);
            cai.setAdWidth(adWidth);
            cai.setAdHeight(adHeight);
            cai.setAdType(adType);
            session.save(cai);
            tran.commit();
            session.evict(cai);		
            message = "广告内容添加成功！";
		}catch(HibernateException e){
            message = "广告内容添加失败！<br/>";
            message += e.toString();
		}		
	}
    
    public Object adInfo(){
        ClubAdItem cai = null;
        List list = null;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();   
        try{
            hql.append("from ClubAdItem where adID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, adID)
            ;
            list = query.list();
            Iterator it = list.iterator();           
            while(it.hasNext()){
                cai = (ClubAdItem)it.next();
            }            
        }catch(HibernateException e){
            message = e.toString();
        }
        return cai;
    }
    
    
    
    public void adUpdate(){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubAdItem set ");
            hql.append(" adObj=?");
            hql.append(", adTxt=?");
            hql.append(", adUrl=?");
            hql.append(", adWidth=?");
            hql.append(", adHeight=?");
            hql.append(", adType=?");
            hql.append(" where adID=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, adObj)
            .setString(1, adTxt)
            .setString(2, adUrl)
            .setShort(3, adWidth)
            .setShort(4, adHeight)
            .setShort(5, adType)
            .setInteger(6, adID)            
            ;
            query.executeUpdate();
            tran.commit();    
            message = "广告内容更新成功！";
        }catch(HibernateException e){
            message = "广告内容更新失败！<br/>";
            message += e.toString();
        }  
    }

    public void adDel(){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{  
            hql.append("delete from ClubAdItem where adID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, adID)
            ;
            query.executeUpdate();
            tran.commit();     
            message = "广告内容删除成功！";
        }catch(HibernateException e){
            message = "广告内容删除失败！<br/>";
            message = e.toString();
        }
    }

    public List adList(int page, int pageNum){
        //计算从第几条记录开始读取数据   
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum; 
        List list = null;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{  
            hql.append("from ClubAdItem ");
            if(adType>0){
                hql.append(" where adType="+ adType +"");
            }
            hql.append("  order by adID desc");
            Query query = session.createQuery(hql.toString());  
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();
            Iterator it = list.iterator();
            ClubAdItem cai = null;
            int i2 = 1;
            while(it.hasNext()){
                cai = (ClubAdItem)it.next();
                ads.append("b["+ (i2) +"] = '"+ cai.getAdObj() +"';\r");
                ads.append("u["+ (i2) +"] = '"+ cai.getAdUrl() +"';\r");
                ads.append("w["+ (i2) +"] = "+ cai.getAdWidth() +";\r");
                ads.append("h["+ (i2) +"] = "+ cai.getAdHeight() +";\r\r");
                i2++;
            }
            
        }catch(HibernateException e){

        }
        return list;
    }
    
    public int adCount(){
        int i = 0;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{  
            hql.append("select count(*) from ClubAdItem");
            Query query = session.createQuery(hql.toString());  
            Iterator iterate = query.iterate();
            Integer results = null;
            while(iterate.hasNext()){
                 results = (Integer) iterate.next();
                 i = results.intValue();
            }
        }catch(HibernateException e){
    
        } 
        return i;
    }
    
    /* test
    public static void main(String args[]){
        ClubAd ca = new ClubAd();
        ca.adList(1,30);
        System.out.print(ca.getAds());
    }
    */
    
	public String getMessage(){
		return this.message;
	}

    
    public void setAct(String act) {
        this.act = act;
    }

    public String getAds() {
        return ads.toString();
    }

}
