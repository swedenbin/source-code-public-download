package com.gamvan.club.manage;

import java.util.StringTokenizer;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.item.ClubUpfilesItem;
import com.gamvan.conn.ConnClub;
import com.gamvan.tools.FormatDateTime;

public class UpLoadDataBase extends ClubUpfilesItem{
    private static final long serialVersionUID = 1L;
    private String message=new String();
    private String now= FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    
    
    /**
     * 2005-11-5 21:44:30 Made In GamVan
     * com.gamvan.club.manage
     */
    public void filesAdd(){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        ClubUpfilesItem cufi = new ClubUpfilesItem();
        try{
            cufi.setCfNewName(cfNewName);
            cufi.setCfOldName(cfOldName);
            cufi.setCfNewPath(cfNewPath);
            cufi.setCfOldPath(cfOldPath);
            cufi.setCfExt(cfExt);
            cufi.setCfContentType(cfContentType);
            cufi.setCfDateTime(now);
            cufi.setCfSize(cfSize);
            cufi.setCfType(cfType);
            cufi.setCfUseID(cfUseID);
            cufi.setCfUseTxt(cfUseTxt);
            cufi.setCfByUser(cfByUser);
            cufi.setCfByIp(cfByIp);
            cufi.setCcID(ccID);
            cufi.setCcName(ccName);
            cufi.setCfByUserID(cfByUserID);
            session.save(cufi);
            tran.commit();
            session.evict(cufi);            
        }catch(HibernateException e){

        }       
    }

    /**
     * @param cfNames
     * 2005-11-5 21:45:23 Made In GamVan
     * com.gamvan.club.manage
     */
    public void uploadUpdates(String cfNames){
        if(cfNames!=null && !cfNames.equals("")){
            StringTokenizer st = new StringTokenizer(cfNames,"|");
            String[] ist = new String[st.countTokens()];
            for(int i=0;st.hasMoreTokens();i++){
                ist[i] = st.nextToken().trim();
                uploadUpdate(ist[i]);            
            }
        }        
    }
    
    /**
     * @param cfName
     * @return
     * 2005-11-5 21:45:30 Made In GamVan
     * com.gamvan.club.manage
     */
    public boolean uploadUpdate(String cfName){
        boolean bea = false;
        if(cfName!=null && !cfName.equals("")){
            Session session = ConnClub.getSession();
            Transaction tran = session.beginTransaction();
            StringBuffer hql = new StringBuffer();
            try{
                hql.append("update ClubUpfilesItem set ");
                hql.append(" cfUseID=?");
                hql.append(", cfUseTxt=?");
                hql.append(" where cfNewName=?");
                Query query = session.createQuery(hql.toString())
                .setInteger(0, cfUseID)
                .setString(1, cfUseTxt)
                .setString(2, cfName);
                query.executeUpdate();
                tran.commit();
            }catch(HibernateException e){

            }
        }
        return bea;
    }

    
    public String getMessage() {
        return message;
    }   
}

