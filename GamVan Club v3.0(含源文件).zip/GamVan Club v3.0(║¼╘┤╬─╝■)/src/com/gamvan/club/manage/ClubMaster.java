package com.gamvan.club.manage;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.item.ClubMasterItem;
import com.gamvan.conn.*;
import com.gamvan.tools.*;


/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubMaster extends ClubMasterItem{
    private static final long serialVersionUID = 1L;

    private String message = "";
    private int cmPassEdit = 0;
    //格式化当前时间
    private String now= FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    
    EncodeIP enc = new EncodeIP();
    
        //this.cmIP1 = enc.enAddr(cmIP1);
        //this.cmIP2 = enc.enAddr(cmIP2);

    
    public void setCmPassEdit(int cmPassEdit) {
        this.cmPassEdit = cmPassEdit;
    }

    public void masterAdd(){
        ClubMasterItem cmi = new ClubMasterItem();
        
        cmi = (ClubMasterItem)masterInfo();
        if(cmi!=null){
            message = "操作失败，数据库已有同名管理员存在！";
            return;
        }

        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        try{
            cmi = new ClubMasterItem();
            this.cmIp1 = enc.enAddr(cmIp1);
            this.cmIp2 = enc.enAddr(cmIp2);
            cmi.setCmgID(cmgID);
            cmi.setCmName(cmName);
            cmi.setCmPass(this.cmPass);
            cmi.setCmIpLock(cmIpLock);
            cmi.setCmIp1(this.cmIp1);
            cmi.setCmIp2(this.cmIp2);
            cmi.setCmLastLoginTime(now);
            cmi.setCmLastLoginIp("127.0.0.1");
            session.save(cmi);
            tran.commit();
            session.evict(cmi);    
            message = "管理员添加成功";
        }catch(HibernateException e){
            e.printStackTrace();
            message= "系统发生意外错误，指令将不被执行，请重新尝试！<br/>"+e.toString();
        }finally{
            ConnClub.closeSession();
        }
    }
    
    public void masterDel(int cmid){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("delete from ClubMasterItem where cmID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, cmid)
            ;
            query.executeUpdate();
            tran.commit();  
        }catch(HibernateException e){
            message= "系统发生意外错误，指令将不被执行，请重新尝试！<br/>"+e.toString();
        }finally{
           
        }
    }
    
    
    public void masterDels(String[] cmIDs){
        //String cmID = "0";
        int cmid = 0;
        int i = 0;
        try{
            for (i = 0; i < cmIDs.length; i++) {
                //cmID += "," + cmIDs[i];
                cmid = TypeChange.stringToInt(cmIDs[i]);
                masterDel(cmid);                
            }
        }catch(Exception e){
            message= "系统发生意外错误，指令将不被执行，请重新尝试！<br/>"+e.toString();
        }finally{
            ConnClub.closeSession();
        }
    }
    
    
    public Object masterInfo(){
        ClubMasterItem cmi = null;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubMasterItem where cmName=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, cmName);
            List list = query.list();
            Iterator it = list.iterator();
            if(it.hasNext()){
                cmi = (ClubMasterItem)it.next();
            }
        }catch(HibernateException e){
            cmi = null;
            message= "系统发生意外错误，指令将不被执行，请重新尝试！<br/>"+e.toString();
        }finally{
            ConnClub.closeSession();
        }
        return cmi;
    }
    
    public Object masterInfo(int cmid){
        ClubMasterItem cmi = null;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubMasterItem where cmID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, cmid)
            ;
            List list = query.list();
            Iterator it = list.iterator();
            if(it.hasNext()){
                cmi = (ClubMasterItem)it.next();
            }
        }catch(HibernateException e){
            cmi = null;
            message= "系统发生意外错误，指令将不被执行，请重新尝试！<br/>"+e.toString();
        }finally{
            ConnClub.closeSession();
        }
        return cmi;
    }
    
    
    public Object masterLogin(){
        ClubMasterItem cmi = null;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        this.cmPass = EncodeString.encodeString("md5of16",cmPass);
        try{
            hql.append("from ClubMasterItem where cmName=? and cmPass=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, cmName)
            .setString(1, cmPass)
            ;
            List list = query.list();
            Iterator it = list.iterator();
            if(it.hasNext()){
                cmi = (ClubMasterItem)it.next();
                System.out.println(cmi.getCmName());
            }
            System.out.println(cmPass);
        }catch(HibernateException e){
            e.printStackTrace();
            cmi = null;
            message= "系统发生意外错误，指令将不被执行，请重新尝试！<br/>"+e.toString();
        }finally{
            ConnClub.closeSession();
        }
        return cmi;
    }  
    
    
    
    
    
    public List masterList(){
        List list = null;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubMasterItem order by cmID desc");
            Query query = session.createQuery(hql.toString());
            list = query.list();
        }catch(HibernateException e){
            
        }finally{
            ConnClub.closeSession();
        }
        
        return list;
    }
    
    
    public void masterUpdate(int cmid){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubMasterItem set cmgID=?");
            hql.append(", cmName=?");
            hql.append(", cmPass=?");
            hql.append(", cmIpLock=?");
            hql.append(", cmIp1=?");
            hql.append(", cmIp2=?");
            hql.append(" where cmID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, cmgID)
            .setString(1, cmName)
            .setString(2, cmPass)
            .setBoolean(3, cmIpLock)
            .setString(4, cmIp1)
            .setString(5, cmIp2)
            .setInteger(6, cmid)
            ;            
            query.executeUpdate();
            tran.commit();  
            message = "管理员信息编辑成功！";       
        }catch(HibernateException e){
            message= "系统发生意外错误，指令将不被执行，请重新尝试！<br/>"+e.toString();
        }finally{
           
        } 
        
        
        
        
    }
    
    // 添加、编辑管理员信息
    public void masterEdit(int cmid){
        try{
            if(cmPassEdit!=1){
                this.cmPass = EncodeString.encodeString("md5of16",cmPass);
            }
            if(cmid>0){
                masterUpdate(cmid);
            }else{
                masterAdd();
            }
           }catch(Exception e){
               message = e.toString();
        }
    }
    
    
    public String getMessage(){
        return this.message;
    }
 
    
    /*test
    public static void main(String args[]){
        ClubMaster cm = new ClubMaster();
        cm.setCmName("gamvan");
        cm.setCmPass("gamvan");
        //cm.masterAdd();
        //System.out.println(EncodeString.encodeString("md5of16","gamvan"));
        System.out.println(cm.masterLogin());
    }
    */
    

}

