package com.gamvan.club.manage;

import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import org.hibernate.CacheMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.item.ClubStringReplaceItem;
import com.gamvan.conn.ConnClub;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubStringReplace extends ClubStringReplaceItem{
    private static final long serialVersionUID = 1L;
    private String message = "";
    /**
     * 
     * @param str
     * @return
     * 2005-11-5 21:47:05 Made In GamVan
     * com.gamvan.club.manage
     */
    public String haveReplace(String str){
        String string = new String();
        ClubStringReplaceItem csri = (ClubStringReplaceItem)replaceSelect();
        String srUserName = csri.getReplaceUserName();
        if(srUserName!=null && !srUserName.equals("")){
            StringTokenizer st = new StringTokenizer(srUserName, "|");
            String[] ishave = new String[st.countTokens()];
            for(int i=0;st.hasMoreTokens();i++){
                ishave[i]=st.nextToken().trim();
                if(str.indexOf(ishave[i])!=-1){
                    string = ishave[i]; //表示注册名含过滤字符，注册不能通过。
                }
            } 
        }else{
            string = null;
        }
        return string;
    }


    
    /**
     * 
     * @return
     * 2005-11-5 21:47:35 Made In GamVan
     * com.gamvan.club.manage
     */
    public Object replaceSelect(){
        ClubStringReplaceItem csri = new ClubStringReplaceItem();
        Session session = ConnClub.getSession();
        String hql = "";
        try{
            hql = "from ClubStringReplaceItem";
            Query query = session.createQuery(hql);
            //启用查询缓存
            query.setCacheable(true); 
            //为查询指定其命名的缓存区域
            query.setCacheRegion("stringReplaceCache");
            //* 从二级缓存读写数据
            query.setCacheMode(CacheMode.NORMAL);
            List list = query.list();
            Iterator it = list.iterator();
            if(it.hasNext())
            {
                csri = (ClubStringReplaceItem)it.next();
            }else{
                csri = null;
            }
        }catch(Exception e){
            csri = null;
            e.printStackTrace();
            message = e.toString();
        }
        return csri;
    }
    
    /**
     * 
     * @return
     * @throws Exception
     * 2005-11-5 21:47:43 Made In GamVan
     * com.gamvan.club.manage
     */
    public boolean replaceUpdate() throws Exception{
        boolean bea = false;
        StringBuffer hql = new StringBuffer("");
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        try{
            replaceUserName=replaceUserName.replaceAll("\r","");
            replaceUserName=replaceUserName.replaceAll("\n","");
            hql.append("update ClubStringReplaceItem ");
            hql.append(" set replaceUserName=?");
            hql.append(", replaceTopic=?");
            hql.append(", replaceContent=?");
            hql.append(", replaceMsgTopic=?");
            hql.append(", replaceMsgContent=?");
            hql.append(", replaceUserPen=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, replaceUserName)
            .setString(1, replaceTopic)
            .setString(2, replaceContent)
            .setString(3, replaceMsgTopic)
            .setString(4, replaceMsgContent)
            .setString(5, replaceUserPen)
            ;
            query.executeUpdate();
            tran.commit();
            message = "数据更新完毕！";
            bea = true;
        }catch(Exception e){
            message = "数据更细发生错误，详细：" + e.toString();
            bea = false;
        }
        return bea;
    }
    
    public String getMessage(){
        return this.message;
    }
    
    /* test
    public static void main(String args[]){
        ClubStringReplace csr = new ClubStringReplace();
        ClubStringReplaceItem  csri = null;
        csri = (ClubStringReplaceItem)csr.replaceSelect();
        //System.out.print(csri);
        System.out.print(csri.getReplaceTopic());
        
    }
    */
}
