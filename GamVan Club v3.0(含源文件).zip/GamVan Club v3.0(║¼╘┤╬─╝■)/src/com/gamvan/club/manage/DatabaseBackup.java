/*
 * Created on 2005-9-24
 * Last modified on 2005-9-24
 * Powered by GamVan.com
 */
package com.gamvan.club.manage;

import java.sql.Connection;

import java.sql.Statement;
//import java.text.SimpleDateFormat;

import org.hibernate.Session;
import com.gamvan.conn.ConnClub;
import com.gamvan.sql.Backup;

public class DatabaseBackup {
    private String filePath = "";
    private String fileName = "";
    private String message = "";
    private String dbName = "";
    Backup bu = new Backup();
    
    public boolean doBackup(){
        //fileName =  new SimpleDateFormat("yyMMdd").format(new Date()) + "_gv_.bak";
        boolean bea = false;
        Session session = ConnClub.getSession();
        try{
            Connection con=session.connection();  
            Statement stmt = con.createStatement();
            bu.setFileName(fileName);
            bu.setFilePath(filePath);
            bea = bu.sqlServerBackup(con,stmt,this.dbName);
            if(bea){
                message = "数据库备份成功";
            }else{
                message = bu.getMessage();
            }
            stmt.close();
            con.close();
        }catch(Exception e){
            bea = false;
            message = e.toString();
            e.toString();
        }finally{
            ConnClub.closeSession();
        }
        return bea;
    }

    
    public String getDbName() {
        return dbName;
    }

    public void setDbName(String dbName) {
        this.dbName = dbName;
    }
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getMessage() {
        return message;
    }
    
    
}
