/*
 * Created on 2005-6-11
 * Last modified on 2005-6-11
 * Powered by GamVan.com
 */
package com.gamvan.club.manage;

import com.gamvan.club.item.ClubUpfilesItem;
import com.gamvan.conn.ConnClub;
import com.gamvan.tools.TypeChange;
import com.gamvan.tools.FileOperate;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubUpfiles extends ClubUpfilesItem{
    private static final long serialVersionUID = 1L;
    private String message = "";
    private String realPath = "";
    private FileOperate fo = new FileOperate();
    private static final Logger logger = 
    	Logger.getLogger(ClubUpfiles.class.getName());
    /**
     * 
     * @param cfid
     * 2005-11-5 21:48:37 Made In GamVan
     * com.gamvan.club.manage
     */
    public void filesDel(int cfid){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("delete ClubUpfilesItem where cfID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, cfid);
            query.executeUpdate();
            tran.commit();   
            message = "删除成功！";
        }catch(HibernateException e){

        } 
    }
    
    /**
     * 
     * @return
     * 2005-11-5 21:48:32 Made In GamVan
     * com.gamvan.club.manage
     */
    public ClubUpfilesItem filesInfo(){
        ClubUpfilesItem cufi = null;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubUpfilesItem where cfID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, this.cfID)
            ;
            List list = query.list();
            Iterator it = list.iterator();
            if(it.hasNext()){
                cufi = (ClubUpfilesItem)it.next();
            }
        }catch(HibernateException e){
            cufi = null;
        }
        return cufi;
    }
    
    
    /**
     * 
     * @param page
     * @param pageNum
     * @return
     * 2005-11-5 21:48:27 Made In GamVan
     * com.gamvan.club.manage
     */
    public List filesList(int page, int pageNum){
        //计算从第几条记录开始读取数据   
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum; 
        List list = null;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubUpfilesItem order by cfID desc");
            Query query = session.createQuery(hql.toString());
            query.setFirstResult(startRow);
            query.setMaxResults(endRow);
            list = query.list();
        }catch(HibernateException e){
            message = e.toString();
        }        
        return list;
    }
    
    
    /**
     * 
     * @return
     * 2005-11-5 21:48:46 Made In GamVan
     * com.gamvan.club.manage
     */
    public int filesCount(){
        int i = 0;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("select count(*) from ClubUpfilesItem");
            Query query = session.createQuery(hql.toString())
            ;
            Iterator iterate = query.iterate();
            Integer results = null;
            while(iterate.hasNext()){
                 results = (Integer) iterate.next();
                 i = results.intValue();
            }
        }catch(HibernateException e){
            message = e.toString();
        }
        return i;
    }
    
   /**
    * 
    * @param cfids
    * 2005-11-5 21:49:01 Made In GamVan
    * com.gamvan.club.manage
    */
    public void filesDels(String cfids[]){
        ClubUpfilesItem cufi = null;
        if(cfids!=null){
            for(int i=0; i<cfids.length; i++){
            	this.cfID = TypeChange.stringToInt(cfids[i]);
                cufi = filesInfo();
                cfNewPath = cufi.getCfNewPath();
                cfNewName = cufi.getCfNewName();
                if(cufi!=null){
                	boolean bea = false;
                	if(java.io.File.separator.equals("\\")){
                		bea = fo.delFile(realPath + cfNewPath.replaceAll("/",java.io.File.separator+java.io.File.separator) + cfNewName); 
                	}else{
                		bea = fo.delFile(realPath + cfNewPath.replaceAll("/",java.io.File.separator) + cfNewName);
                	}
                    if(bea){
                        filesDel(this.cfID); //删除数据库记录  
                    }else{
                    	filesDel(this.cfID); //删除数据库记录  
                        message = fo.getMessage()+"<br/>数据库记录清除";
                        logger.error(fo.getMessage());
                    }
                }else{
                    message = "ID为: "+ this.cfID +" 的文件信息丢失删除失败！";
                }
            }   
        }else{
            message = "没有文件信息";
        }
    }
    

   /* test
    public static void main(String args[]){
        //ClubUpfiles cuf = new ClubUpfiles();
        //cuf.filesDel(1);
    	//System.out.print("/sdfs/sdfs/sdf/".replaceAll(String.valueOf("/"),(java.io.File.separator+java.io.File.separator)));
    }
    */
    public String getMessage() {
        return message;
    }

    public void setRealPath(String realPath) {
        this.realPath = realPath;
    }
    
}
