package com.gamvan.club.manage;

/* Made in GamVan
 * 管理员等级 javaBean
 */
import com.gamvan.club.item.ClubMasterGradeItem;
import com.gamvan.conn.*;
import com.gamvan.tools.*;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubMasterGrade extends ClubMasterGradeItem{
    private static final long serialVersionUID = 1L;
    private String message = "";
    
    /**
     * 建立删除方法
     * @param cmgid
     * 2005-11-5 22:07:45 Made In GamVan
     * com.gamvan.club.manage
     */
    public void masterGradeDel(int cmgid){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("delete from ClubMasterGradeItem where cmgID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, cmgid)
            ;
            query.executeUpdate();
            tran.commit();  
            message = "后台管理员等级删除操作成功！";
        }catch(HibernateException e){
            message= "系统发生意外错误，指令将不被执行，请重新尝试！<br/>"+e.toString();
        }
    }
    
    
    /**
     * 建立删除方法
     * @param cmgIDs
     * 2005-11-5 22:07:52 Made In GamVan
     * com.gamvan.club.manage
     */
    public void masterGradeDels(String[] cmgIDs){
        try{
            int cmgid = 0;
            int i = 0;
            for (i = 0; i < cmgIDs.length; i++) {
                cmgid = TypeChange.stringToInt(cmgIDs[i]);
                masterGradeDel(cmgid);
            }
        }catch(Exception e){
            message= "系统发生意外错误，指令将不被执行，请重新尝试！<br/>"+e.toString();
        }     
    }
    
    /**
     * 建立删除方法
     * 2005-11-5 22:08:07 Made In GamVan
     * com.gamvan.club.manage
     */
    public  void masterGradeAdd(){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        ClubMasterGradeItem cmgi = new ClubMasterGradeItem();
        try{
            cmgi.setCmgName(cmgName);
            cmgi.setCmgTxt(cmgTxt);
            session.save(cmgi);
            tran.commit();
            session.evict(cmgi);
            message = "操作成功";
        }catch(HibernateException e){
            message= "系统发生意外错误，指令将不被执行，请重新尝试！<br/>"+e.toString();
        }        
    }
    

    /**
     * 
     * @param cmgid
     * 2005-11-5 22:08:37 Made In GamVan
     * com.gamvan.club.manage
     */
    public void masterUpdate(int cmgid){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubMasterGradeItem ");
            hql.append(" set cmgName=?");
            hql.append(", cmgTxt=?");
            hql.append("  where cmgID=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, cmgName)
            .setString(1, cmgTxt)
            .setInteger(2, cmgid);
            query.executeUpdate();
            tran.commit();  
            message = "社区等级权限更新成功！";
        }catch(HibernateException e){
            message= "系统发生意外错误，指令将不被执行，请重新尝试！<br/>"+e.toString();
        } 
    }
    
    /**
     * 
     * @param cmgid
     * 2005-11-5 22:08:47 Made In GamVan
     * com.gamvan.club.manage
     */
    public void masterGradeEdit(int cmgid){
       try{
            if(cmgid==0){ 
                masterGradeAdd();
            }else{
                masterUpdate(cmgid);
            }
           }catch(Exception e){
            P.rint(e.toString());
        }
    }
    
    /**
     * 
     * @return
     * 2005-11-5 22:08:52 Made In GamVan
     * com.gamvan.club.manage
     */
    public List masterGradeList(){
        List list = null;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubMasterGradeItem order by cmgID");
            Query query = session.createQuery(hql.toString());
            list = query.list();            
        }catch(HibernateException e){
            message= "系统发生意外错误，指令将不被执行，请重新尝试！<br/>"+e.toString();
            e.printStackTrace();
        }
        return list;
    }
    
    
    /**
     * 
     * @param cmgid
     * @return
     * 2005-11-5 22:09:02 Made In GamVan
     * com.gamvan.club.manage
     */
    public Object masterGradeInfo(int cmgid){
        if(cmgid<=0){
            cmgid = this.cmgID;
        }
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        ClubMasterGradeItem cmgi = null;
        try{
            hql.append("from ClubMasterGradeItem where cmgID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, cmgid)
            ;
            List list = query.list();
            Iterator it = list.iterator();
            if(it.hasNext()){
                cmgi = (ClubMasterGradeItem)it.next();
            }else{
                cmgi = null;
            }
        }catch(HibernateException e){
            message= "系统发生意外错误，指令将不被执行，请重新尝试！<br/>"+e.toString();
            e.printStackTrace();
        }
        return cmgi;
    }


    public String getMessage() {
        return message;
    }
    
    
    /* test
    public static void main(String args[]){
        ClubMasterGrade cmg = new ClubMasterGrade();
        ClubMasterGradeItem cmgi = null;
        cmgi = (ClubMasterGradeItem)cmg.masterGradeInfo(2);
    }
    */
}
