/*
 * Created on 2005-7-7
 * Last modified on 2005-7-7
 * Powered by GamVan.com
 */
package com.gamvan.club.group;

import com.gamvan.club.dao.impl.GroupImpl;
import com.gamvan.club.item.GroupItem;

/**
 * Club 网页分类信息
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class GroupEdit extends GroupItem{
    private static final long serialVersionUID = 1L;
    private String message = "";
    
    private GroupImpl gim = new GroupImpl();
    
    /**
     * 
     * @param act
     * @return
     * 2005-11-17 22:33:55 Made In GamVan
     * com.gamvan.club.group
     */
    public boolean groupAct(String act){
        boolean bea = false;
        if(act.trim().equals("")){
            message="参数错误请返回重新操作";
        }
        try{
            if(act.equals("add")){
                bea = groupAdd();
            }else if(act.equals("edit")){
                bea = groupEdit(groupID);
            }else if(act.equals("del")){
                bea = groupDel(groupID);
            }
        }catch(Exception e){
            message = "执行期发生异常\n\n" + e.toString();
        }
        return bea;       
    }

    
    /**
     * 删除
     * @param id
     * @return
     * 2005-11-7 20:43:42 Made In GamVan
     * com.gamvan.club.group
     */
    public boolean groupDel(int id){
        if(id==0){
            return false;
        }
        boolean bea = false;
        try{
            gim.groupDel(id);
            bea =  true;
            message = "分类删除成功";            
        }catch(Exception e){
            message = "更新分类出现错误\n\n" + e.toString();
        }
        return bea;
    }
    
    
    /**
     * 更新分类内容
     * @param id
     * @return
     * 2005-11-7 20:43:48 Made In GamVan
     * com.gamvan.club.group
     */
    public boolean groupEdit(int id){
        if(id<=0){
            return false;
        }
        boolean bea = false;
        try{
            gim.setGroupName(groupName);
            gim.setGroupIDD(groupIDD);
            gim.setGroupLayer(groupLayer);
            gim.setGroupType(groupType);
            gim.setGroupOrder(groupOrder);
            gim.groupUpdate(id);
            bea =  true;
            message = "分类更新成功";            
        }catch(Exception e){
            message = "更新分类出现错误\n\n" + e.toString();
        }        
        return bea;
    }
    
    /**
     * 添加分类
     * @return
     * 2005-11-7 20:43:54 Made In GamVan
     * com.gamvan.club.group
     */
    public boolean groupAdd(){
        boolean bea = false;
        try{
            gim.setGroupName(groupName);
            gim.setGroupIDD(groupIDD);
            gim.setGroupLayer(groupLayer);
            gim.setGroupOrder(groupOrder);
            gim.setGroupType(groupType);
            gim.setGroupCount(0);
            gim.groupAdd();
            bea =  true;
            message = "分类添加成功";
        }catch(Exception e){
            message = "添加发生异常\n\n  "+e.toString();
        }
        return bea;

    }
    
    /**
     * 更新分组下统计数字
     * @param id
     * @param i
     * @param type
     * 2005-11-18 2:08:38 Made In GamVan
     * com.gamvan.club.group
     */
    public void groupCountUpdate(int id, int i, int type){
    	if(id==0 || i==0){
    		return ;
    	}
    	try{
    		gim.groupCountUpdate(id, i, type);
    	}catch(Exception e){
    		
    	}
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    
  /*
    public static void main(String args[]){
        GroupEdit ge = new GroupEdit();
        ge.setGroupID(1);
        ge.groupDel(1);
    }
  */
}

