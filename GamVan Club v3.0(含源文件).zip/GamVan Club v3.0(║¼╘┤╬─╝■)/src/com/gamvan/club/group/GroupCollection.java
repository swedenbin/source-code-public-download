/*
 * Created on 2005-7-7
 * Last modified on 2005-7-7
 * Powered by GamVan.com
 */
package com.gamvan.club.group;

import java.util.List;

import com.gamvan.club.item.GroupItem;
import com.gamvan.club.dao.impl.GroupImpl;

/**
 * Club 网页分类信息
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class GroupCollection extends GroupItem{
    private static final long serialVersionUID = 1L;
    private String sql = "";
    private String message = "";
    private GroupImpl gim = new GroupImpl();
   
    /**
     * 查询分类信息
     * @param s
     * @return
     * 2005-11-17 20:56:47 Made In GamVan
     * com.gamvan.music.group
     */
    public GroupItem groupInfo(String s){
        GroupItem gi = null;
        try{
            gi = gim.groupInfo(s);
        }catch(Exception e){
            gi = null;
            e.printStackTrace();
        }
        return gi;
    }

       
    /**
     * 查询分类信息
     * @return
     * 2005-11-17 20:56:42 Made In GamVan
     * com.gamvan.music.group
     */
    public GroupItem groupInfo(){
        if(groupID==0){
                return null;
        }
        GroupItem gi = null;
        try{
            gi = gim.groupInfo(groupID);
        }catch(Exception e){
            gi = null;
            message = "分类更新出现错误" + e.toString();
        }
        return gi;
    }
    
   /**
    * 
    * @return
    * 2005-11-17 20:47:37 Made In GamVan
    * com.gamvan.music.group
    */
    public List groupList(){
        List list = null;
        try{
            list = gim.groupList(1, 1000, groupLayer, groupType, 0);
        }catch(Exception e){
            message = e.toString();
        }
        return list;
    }
    
    /**
     * 
     * @return
     * 2005-11-17 21:05:41 Made In GamVan
     * com.gamvan.music.group
     */
    public List groupQuery(){
        List list = null;
        try{
            list = gim.groupQuery(1, 100, sql);
        }catch(Exception e){
            message = e.toString();
        }
        return list;
    } 
    
    
    public String getSql() {
        return sql;
    }
    public String getMessage() {
        return message;
    }
    public void setSql(String sql) {
        this.sql = sql;
    }
    
    
    /* test
    public void iteratorTest() throws Exception{
        StringBuffer sql = new StringBuffer("");
        sql.append("from GroupItem");
       
        this.sql = sql.toString();
        Collection c = groupQuery();

        Iterator ita = c.iterator();
        
        while(ita.hasNext()){
            GroupItem gcl =(GroupItem)ita.next();
            System.out.print(gcl.getGroupName() + "\n"+c+"\n");
        }
   } 
   */ 
    
    /* test
    public static void main(String[] args){
        try{
            GroupCollection gcl = new GroupCollection();
            gcl.setGroupID(3);
            GroupItem gi = (GroupItem)gcl.groupInfo();
            System.out.print(gi.getGroupName());
            
            System.out.print("=============end==============");
        }catch(Exception e){
            System.out.print(e.toString());
        }
        
    }
    */
    
}
