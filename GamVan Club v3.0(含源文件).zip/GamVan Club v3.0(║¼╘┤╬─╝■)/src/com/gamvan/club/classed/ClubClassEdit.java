/*
 * Created on 2004-11-29
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.classed;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gamvan.club.item.ClubClassItem;
import com.gamvan.conn.*;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubClassEdit extends com.gamvan.club.item.ClubClassItem{
    private static final long serialVersionUID = 1L;
    private String message;
    /**
     * 添加版面
     */
    public void classAdd(){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        try{
            ClubClassItem cci = new ClubClassItem();
            cci.setCcIDD(ccIDD);
            cci.setCcName(ccName);
            cci.setCcOrder(ccOrder);
            cci.setCcType(ccType);
            cci.setCcStyle(ccStyle);
            cci.setCcPro(ccPro);
            cci.setCcHidden(ccHidden);
            cci.setCcUpfilePass(ccUpfilePass);
            cci.setCcUpfileMax(ccUpfileMax);
            cci.setCcUgid(ccUgid);
            cci.setCcTopicNum(ccTopicNum);
            cci.setCcReplyNum(ccReplyNum);
            cci.setCcMostOnline(ccMostOnline);
            cci.setCcSummary(ccSummary);
            cci.setCcUserPass(ccUserPass);
            cci.setCcTopic(0); //统计版面主题数
            cci.setCcReply(0); //统计版面回复数
            cci.setCcList(ccList);
            cci.setCcTodayTopic(ccTodayTopic);
            cci.setCcTodayReply(ccTodayReply);
            cci.setCcYesterTopic(ccYesterTopic);
            cci.setCcYesterReply(ccYesterReply);
            session.save(cci);
            tran.commit();
            message = "版面添加成功！";
        }catch(HibernateException e){
            message = "版面添加失败！<br>"+e.toString();
        }
    }
    
    /**
     * 更新版面信息
     *
     */
    public void classUpdate(int ccid){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubClassItem ");
            hql.append(" set ccIDD=?");
            hql.append(", ccName=?");
            hql.append(", ccOrder=?");
            hql.append(", ccType=?");
            hql.append(", ccStyle=?");
            hql.append(", ccPro=?");
            hql.append(", ccHidden=?");
            hql.append(", ccUpfilePass=?");
            hql.append(", ccUpfileMax=?");
            hql.append(", ccUgid=?");
            hql.append(", ccTopicNum=?");
            hql.append(", ccReplyNum=?");
            hql.append(", ccMostOnline=?");
            hql.append(", ccSummary=?");
            hql.append(", ccUserPass=?");
            hql.append(", ccList=?");
            hql.append(" where ccID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, ccIDD)
            .setString(1, ccName)
            .setInteger(2, ccOrder)
            .setByte(3, ccType)
            .setByte(4, ccStyle)
            .setByte(5, ccPro)
            .setBoolean(6, ccHidden)
            .setByte(7, ccUpfilePass)
            .setInteger(8, ccUpfileMax)
            .setShort(9, ccUgid)
            .setInteger(10, ccTopicNum)
            .setInteger(11, ccReplyNum)
            .setInteger(12, ccMostOnline)
            .setString(13, ccSummary)
            .setString(14, ccUserPass)
            .setBoolean(15, ccList)
            .setInteger(16, ccid);
            int i = query.executeUpdate();
            tran.commit();
            if(i>0){
                message = "版面更新成功！";
            }else{
                message = "版面更新失败！";
            }
        }catch(HibernateException e){
            
        }
    }
    
    public void classEdit(int ccid) throws Exception{
        if(ccid>0){
            ////this.ccID = ccid;
            classUpdate(ccid);
        }else{
            classAdd();
        }
    }

    public static void main(String args[]){
        ClubClassEdit cce = new ClubClassEdit();
        try {
            cce.setCcName("2324234");
            cce.classEdit(10);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.print(cce.getMessage());
    }
    
    
    public String getMessage(){
        return this.message;
    }

}
