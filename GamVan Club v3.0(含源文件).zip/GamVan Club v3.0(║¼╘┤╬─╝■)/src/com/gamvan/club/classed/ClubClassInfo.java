/*
 * Created on 2005-7-1
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.classed;

import com.gamvan.club.dao.impl.ClubClassImpl;
import com.gamvan.club.item.ClubClassItem;


public class ClubClassInfo extends ClubClassItem{
    private static final long serialVersionUID = 1L;
    
    private static ClubClassImpl ccil = new ClubClassImpl();
    
    public ClubClassItem getClubClassInfo(){
        return ccil.classInfo(ccID);
    }
    
    /**
	 * 更新版面文章统计信息
	 * @param ccid 版面ID编号
	 * @param ct 主题数
	 * @param cr 回复数
     * @author GamVan Studio by 我容易么我
     */
    public void classCounter(int ccid, int ct, int cr) {
    	ccil.classCounter(ccid, ct, cr);
    }    

    /* test cache 
    public static void main(String agrs[]){
        ClubClassInfo cci = new ClubClassInfo();
        ClubClassItem ccit = new ClubClassItem();
        
        cci.setCcID(1);
        ccit = (ClubClassItem)cci.getClubClassInfo();
        System.out.println(ccit.getCcName());
        
        cci.setCcID(2);
        ccit = (ClubClassItem)cci.getClubClassInfo();
        System.out.println(ccit.getCcName());
        
        cci.setCcID(1);
        ccit = (ClubClassItem)cci.getClubClassInfo();
        System.out.println(ccit.getCcName()); 
    }
    */
}
