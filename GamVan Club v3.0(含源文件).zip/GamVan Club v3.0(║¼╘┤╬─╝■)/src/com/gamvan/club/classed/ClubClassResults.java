/*
 * Created on 2005-8-3
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.classed;

import java.util.List;
import com.gamvan.club.dao.impl.ClubClassImpl;
import com.gamvan.club.item.ClubClassItem;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubClassResults extends ClubClassItem{
    private static final long serialVersionUID = 1L;
    private String message = "";
    private int reId = 0;
    private ClubClassImpl cci = new ClubClassImpl();
    
    public List classAllList(){
        List list = null;
        StringBuffer hql = new StringBuffer();
        	hql.append("from ClubClassItem" ); 
        	if(ccID>0){
        		hql.append(" where ccID=");
        		hql.append(ccID);
        	}
        	hql.append(" order by ccOrder desc");
        try{
            list = cci.classdList(hql.toString());
        }catch(Exception e){

        }
        return list;
    }
    
    public List classList(){
        List list = null;
        String hql = 
        	("from ClubClassItem  where ccIDD=0 order by ccOrder desc");
        try{
            list = cci.classdList(hql);
        }catch(Exception e){

        }
        return list;
    }

    public List classReList(){
        List list = null;
        StringBuffer hql = new StringBuffer();
        hql.append("from ClubClassItem  where ccIDD=");
        hql.append(reId);
        hql.append(" order by ccOrder desc");
        try{
            list = cci.classdList(hql.toString());
        }catch(Exception e){
            e.printStackTrace();
        }
        return list;
    }

    
    
    /* test
    public static void main(String args[]){
        ClubClassCollection ccc = new ClubClassCollection();
        ccc.setCcIDD(17);
        ccc.classList();  
    }
    */
   
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getReId() {
        return reId;
    }

    public void setReId(int reId) {
        this.reId = reId;
    }
   
    
}
