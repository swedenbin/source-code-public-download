/*
 * Created on 2005-7-8
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.classed;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.ClubCounter;
import com.gamvan.club.item.ClubClassItem;
import com.gamvan.club.item.ClubTopicItem;
import com.gamvan.club.topic.ClubTopicDel;
import com.gamvan.conn.ConnClub;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubClassDel extends ClubClassItem {
    private static final long serialVersionUID = 1L;
    private String message = "";

    public boolean classDel(int ccid){
        boolean bea = false;
        if(classSelectIDD(ccid)){
            message = "该版面还存在下级分类，无法执行删除";
        }else{
            if(classDelTopic(ccid)){
                bea = classDels(ccid);
            }
        }
        return bea;
    }
    
    
    /**
     * 执行删除分类信息
     * @param ccid
     * @return
     */
    public boolean classDels(int ccid){
        boolean bea = false;
        Session session = ConnClub.getSession();
        Transaction ts = session.beginTransaction();
        String hql = new String();
        try{
            hql = "delete from ClubClassItem where ccID=?";
            Query query = session.createQuery(hql)
            .setInteger(0, ccid);
            query.executeUpdate();
            ts.commit();
            bea = true;
            message = "分类已删除";
        }catch(Exception e){
            message = "分类删除失败 "+e.toString();
        }
        return bea;
    }
    
    
    public static void main(String args[]){
    	ConnClub.init();
        ClubClassDel ccd = new ClubClassDel();
        ccd.classDelTopic(14);
        System.out.print("结束");
        ConnClub.closeSession2();
        
    }
    
    /**
     * 执行删除分类下所有文章
     * @param ccid
     * @return
     */
    public boolean classDelTopic(int ccid){
        boolean bea = false;
        /*更新社区主题回复统计*/
        int ct = classTopicCt(ccid); //版面主题数
        int cr = classTopicCr(ccid); //版面回复数
        ClubCounter cc = new ClubCounter();
        cc.counterUpdate(0, 0, -ct, -cr, 0, 0, 0, "");
        /*更新完毕*/
        
        Session session = ConnClub.getSession();
        Transaction ts = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        ClubTopicItem cti = null;
        ClubTopicDel ctd = new ClubTopicDel();
        try{
          
            hql.append("from  ClubTopicItem ");
            hql.append(" where ccID=? or ccID1=? or ccID2=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, ccid)
            .setInteger(1, ccid)
            .setInteger(2, ccid);
            List list = query.list();
            Iterator it = list.iterator();
            while(it.hasNext()){
                cti = (ClubTopicItem)it.next();
                System.out.println(cti.getTopicID());
                ctd.runDel(cti.getTopicID(), false);
            }
            ts.commit();
            bea = true;
            message = "";
        }catch(Exception e){
            e.printStackTrace();
            message = "分类文章删除失败"+e.toString();
        }
        return bea;
    }
    
   
    /**
     * 统计主题数
     * @param ccid
     * @return
     */
    public int classTopicCt(int ccid){
        int i = 0;
        Session session = ConnClub.getSession();
        String hql = new String();
        try{
            hql = "select count(*) from ClubTopicItem where ccID=? or ccID1=? or ccID2=?";
            Query query = session.createQuery(hql.toString())
            .setInteger(0, ccid)
            .setInteger(1, ccid)
            .setInteger(2, ccid);
            Iterator iterate = query.iterate();
            Integer results = null;
            while(iterate.hasNext()){
            results = (Integer) iterate.next();
            i = results.intValue();
            }
        }catch(Exception e){
            message = e.toString();
        }
        return i;
    }
    
    /**
     * 统计回复数
     * @param ccid
     * @return
     */
    public int classTopicCr(int ccid){
        int i = 0;
        Session session = ConnClub.getSession();
        String hql = new String();
        try{
            hql = "select count(*) from ClubTopicReItem where ccID=? or ccID1=? or ccID2=?";
            Query query = session.createQuery(hql.toString())
            .setInteger(0, ccid)
            .setInteger(1, ccid)
            .setInteger(2, ccid);
            Iterator iterate = query.iterate();
            Integer results = null;
            while(iterate.hasNext()){
            	results = (Integer) iterate.next();
            	i = results.intValue();
            }
        }catch(Exception e){
            message = e.toString();
        }
        return i;
    } 
    


    /**
     * 查询是否存在子分类
     * @param ccid
     * @return
     */
    public boolean classSelectIDD(int ccid){
        boolean bea = false;
        Session session = ConnClub.getSession();
        String hql = new String();
        try{
            hql = "from ClubClassItem where ccIDD=?";
            Query query = session.createQuery(hql)
            .setInteger(0,ccid);       
            List list = query.list();
            Iterator it = list.iterator();
            if(it.hasNext()){
                bea = true;
            }else{
                bea = false;
            }
            session.flush();
        }catch(HibernateException e){
            message = "无法执行查询动作，" + e.toString();
        }
        return bea;
    }
    
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
}
