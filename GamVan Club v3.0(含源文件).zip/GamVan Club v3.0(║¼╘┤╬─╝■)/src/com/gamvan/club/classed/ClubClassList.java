/*
 * Created on 2005-7-8
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.classed;
import java.util.Iterator;
import java.util.List;

import com.gamvan.club.dao.impl.ClubClassImpl;
import com.gamvan.club.item.ClubClassItem;

public class ClubClassList extends ClubClassItem{

	private static final long serialVersionUID = 1L;
    private String ccName;
    private int ccOrder, ccStyle, ccPro, ccType, ccTopic, ccReply; 
    private boolean ccHidden = false;
    private final ClubClassImpl ccim = new ClubClassImpl();
    
    
    public String classSelect(int ccID, int layer, int ccid){
        StringBuffer tempString = new StringBuffer();
        ClubClassItem cci = new ClubClassItem();
        try{
        	StringBuffer hql = new StringBuffer();
        	hql.append("from ClubClassItem  where ccIDD = ");
        	hql.append(ccID);
        	hql.append(" order by ccOrder desc");
            List list = ccim.classdList(hql.toString());
            Iterator it = list.iterator();
            while(it.hasNext()){
                cci = (ClubClassItem)it.next();
                ccID = cci.getCcID();
                ccName = cci.getCcName();
                ccType = cci.getCcType();               
                tempString.append("<option value=\""+ String.valueOf(ccID) +"\"");
                if(ccID==ccid){
                    tempString.append(" selected");
                }
                tempString.append(">");
                for(int i = 0; i < layer; i++){
                    tempString.append("&nbsp;");
                }
                if(ccType==0){
                    tempString.append("[分类]&nbsp;");
                }else{
                    tempString.append("[版面]&nbsp;");
                }
                tempString.append(ccName +"</option>");
                //tempString.append(ccl2.classSelectOpt(ccID, layer+2, ccid));
                tempString.append(classSelect(ccID, layer+2, ccid));
            }
        }catch(Exception e){
            cci = null;
        }
       return tempString.toString();  
    }
    
    public String classListTab(int ccID, int layer){
        StringBuffer tempString = new StringBuffer();
        ClubClassItem cci = null;
        try{
        	StringBuffer hql = new StringBuffer();
        	hql.append("from ClubClassItem  where ccIDD = ");
        	hql.append(ccID);
        	hql.append(" order by ccOrder desc");
            List list = ccim.classdList(hql.toString());
            Iterator it = list.iterator();
            while(it.hasNext()){
                cci = (ClubClassItem)it.next();
                ccID = cci.getCcID();
                ccName = cci.getCcName();
                ccType = cci.getCcType(); 
                ccStyle = cci.getCcStyle();
                ccPro = cci.getCcPro();
                ccHidden = cci.getCcHidden();
                ccTopic = cci.getCcTopic();
                ccReply = cci.getCcReply();
                tempString.append("<tr bgcolor=\"#f6f6f6\"><td height=\"22\" align=\"center\" bgcolor=\"#f6f6f6\">");
                tempString.append("<input name=\"ccID\" type=\"checkbox\" id=\"ccID\" value=\"" + ccID + "\" /></td><td>");
                for(int i = 0; i < layer; i++){
                    tempString.append("&nbsp;");
                }
                tempString.append(ccName + "</td><td align=\"center\">");
                if(ccType==0){
                    tempString.append("<font color=#bb0000>分类</font>");
                }else{
                    tempString.append("<font color=#000099>版面</font>");
                }
                tempString.append("</td><td align=\"center\">");
                if(ccHidden){
                    tempString.append("不隐藏" );
                }else{
                    tempString.append("隐藏" );
                }
                tempString.append("</td><td align=\"center\">"); 
                switch(ccPro){
                    case 0: tempString.append(("开放的"));
                        break;
                    case 1: tempString.append(("主题的"));
                        break;
                    case 2: tempString.append(("锁定的"));
                        break;
                    case 3: tempString.append(("认证的"));
                        break;
                    case 4: tempString.append(("链接的"));
                        break;                   
                }                
                tempString.append("</td><td align=\"center\">" );
                if(ccStyle==0){
                    tempString.append("<font color=#000099>BBS风格</font>");
                }else{
                    tempString.append("讨论区风格");
                } 
                tempString.append("</td><td align=\"center\">");
                tempString.append("" + ccTopic + "</td><td align=\"center\">");
                tempString.append(ccReply + "</td><td align=\"center\">");
                tempString.append(ccOrder);
                tempString.append("</td>");
                tempString.append("<td align=\"center\"><a href=\"clubClassEdit.jsp?ccID=" + ccID + "\">配置</a></td>");
                tempString.append("<td align=\"center\">");
                tempString.append("<a onClick=\"javascript:gConfirm('确定要删除此分类吗，删除后将不能恢复！','clubClassList.jsp?act=del&ccID=<%=ccID%>');\" href=\"#\">");
                tempString.append("删除</a>");
                tempString.append("</td></tr>\n\n");
                //tempString.append(ccl2.classListTab(ccID, layer+2));
                tempString.append(this.classListTab(ccID, layer+2));
            }
        }catch(Exception e){
        	e.printStackTrace();
            cci = null;
        }
       return tempString.toString();
    }
    
    /* test
    public static void main(String args[]){
    	com.gamvan.conn.ConnClub.init();
    	ClubClassList ccl = new ClubClassList();
    	System.out.println(ccl.classListTab(0, 0));
    }
    */
}

