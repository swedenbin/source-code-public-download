/*
 * Created on 2005-7-8
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.classed;

import java.util.Iterator;
import java.util.List;

import com.gamvan.club.dao.impl.ClubClassImpl;
import com.gamvan.club.item.ClubClassItem;
import com.gamvan.tools.FileOperate;

/**
 * 自动生成网站左栏和搜索页的论坛分类下拉选框
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */

/**
 * 网站左栏工具条
 */
public class ClubClassBar extends com.gamvan.club.item.ClubClassItem{

    private static final long serialVersionUID = 1L;
    
    /*外部set*/
    private String color_0 = ""; //分类颜色
    private String color_1 = ""; //版面颜色
    private int strong_0 = 0; //分类是否加粗
    private int strong_1 = 0; //版面是否加粗
    private int expert = 0; //判断分类是否启用了高级选项
    private String realPath = ""; //绝对路径。
    private StringBuffer htmlSelect = new StringBuffer();
    private final ClubClassImpl ccim = new ClubClassImpl();
    
    public String classBar_1(){
        int ccid = 0;
        String ccname = "";
        StringBuffer ccnameStyle = new StringBuffer("");
        StringBuffer classStr = new StringBuffer("");
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubClassItem where ccIDD=0 and ccHidden=0 order by ccOrder desc");
            List list = ccim.classdList(hql.toString());
            Iterator it = list.iterator();
            while(it.hasNext()){
                ClubClassItem cci = (ClubClassItem)it.next();
                ccid = cci.getCcID();
                ccname = cci.getCcName(); 
                ccnameStyle.delete(0,ccnameStyle.length());
                if(expert==1){
                    ccnameStyle.append("<span style=\"");
                    if(cci.getCcType()==0){
                        if(!color_0.equals("")){
                            ccnameStyle.append("color: "+ color_0 +"; ");
                        }
                        if(strong_0==1){
                            ccnameStyle.append("font-weight: bold;"); 
                        }
                    }else{
                        if(!color_1.equals("")){
                            ccnameStyle.append("color: "+ color_1 +"; ");
                        }
                        if(strong_1==1){
                            ccnameStyle.append("font-weight: bold;"); 
                        }
                    }    
                    ccnameStyle.append("\">");
                    ccnameStyle.append(ccname);
                    ccnameStyle.append("</span>");
                    ccname = ccnameStyle.toString();
                }
                /*********************** htmlSelect 开始收集 ******************************/
                htmlSelect.append("<option value=\"");
                htmlSelect.append(ccid);
                htmlSelect.append("\">");
                htmlSelect.append(ccname);
                htmlSelect.append("</option>");
                
                /*********************** htmlMenu 开始收集 ***************************/
                classStr.append("<table  width=\"99%\" border=\"0\" cellpadding=\"1\" cellspacing=\"0\">");
                classStr.append("<tr><td height=\"18\" class=\"barbgOut\" onmouseover=\"this.className='barbgOver'\"  ");
                classStr.append(" onmouseout=\"this.className='barbgOut'\"> <img style=\"cursor:hand;\"  id=\"icon_"+ ccid +"\"  ");
                classStr.append(" onclick=\"loadTree("+ ccid +" ,'')\" src=\"GVimgs/tree/t1.gif\" align=\"absmiddle\" />&nbsp;");
                classStr.append("<a onclick=\"loadTree("+ ccid +" ,'');\" ");
                classStr.append(" href=\"clubClass.jsp?ccID="+ ccid +"\" target=\"rFrame\">");
                classStr.append(ccname + "</a>");
                classStr.append("<td></tr>");
                classStr.append("<tr id=\"load_"+ ccid +"\"  style=\"DISPLAY: none\"><td>");              
                classStr.append(classBar_2(ccid));
                classStr.append("<div id=\"replies_"+ ccid +"\"></div>");
                classStr.append("</td></tr></table>");
                if(cci.getCcList()){
                    classStr.append("<script language=\"javascript\">loadTree("+ ccid +" ,'');</script>");
                }
                
            }
          }catch(Exception e){
              e.printStackTrace();
              classStr.delete(0, classStr.length());
              classStr.append("论坛分类索引读取失败<br/>" + e.toString());
        }
        return classStr.toString();
    }
    
    
    /**
     * @param ccidd
     * @param ccname
     */
    public String classBar_2(int ccidd){
        StringBuffer classStr = new StringBuffer("");

        StringBuffer hql = new StringBuffer();
        String ccname = "";
        StringBuffer ccnameStyle = new StringBuffer("");
        int ccid_2 = 0;
        try{
            hql.append("from ClubClassItem where ccIDD = ");
            hql.append(ccidd);
            hql.append(" and ccHidden=0 order by ccOrder desc");
            List list = ccim.classdList(hql.toString());
            Iterator it = list.iterator();
            while(it.hasNext()){
                ClubClassItem cci_2 = (ClubClassItem)it.next();
                ccid_2 = cci_2.getCcID();
                ccname = cci_2.getCcName();
                ccnameStyle.delete(0,ccnameStyle.length());
                if(expert==1){
                    ccnameStyle.append("<span style=\"");
                    if(cci_2.getCcType()==0){
                        if(!color_0.equals("")){
                            ccnameStyle.append("color: "+ color_0 +"; ");
                        }
                        if(strong_0==1){
                            ccnameStyle.append("font-weight: bold;"); 
                        }
                    }else{
                        if(!color_1.equals("")){
                            ccnameStyle.append("color: "+ color_1 +"; ");
                        }
                        if(strong_1==1){
                            ccnameStyle.append("font-weight: bold;"); 
                        }
                    }    
                    ccnameStyle.append("\">");
                    ccnameStyle.append(ccname);
                    ccnameStyle.append("</span>");
                    ccname = ccnameStyle.toString();
                }
                
                /*********************** htmlSelect 开始收集 ******************************/
                htmlSelect.append("<option value=\"");
                htmlSelect.append(ccid_2);
                htmlSelect.append("\">&nbsp;&nbsp;");
                htmlSelect.append(ccname);
                htmlSelect.append("</option>");              
                
                /*********************** htmlMenu 开始收集 ***************************/
                if(cci_2.getCcType()==0){
                    classStr.append("<table  width=\"99%\" border=\"0\" cellpadding=\"1\" cellspacing=\"0\">");
                    classStr.append("<tr><td height=\"18\" class=\"barbgOut\" onmouseover=\"this.className='barbgOver'\" ");
                    classStr.append("onmouseout=\"this.className='barbgOut'\">&nbsp;&nbsp;<img style=\"cursor:hand;\"  id=\"icon_"+ ccid_2 +"\"  ");
                    classStr.append(" onclick=\"loadTree("+ ccid_2 +" ,'')\" src=\"GVimgs/tree/t1.gif\" ");
                    classStr.append("align=\"absmiddle\" />&nbsp;<a onclick=\"loadTree("+ ccid_2 +" ,'');\" ");
                    classStr.append(" href=\"clubClass.jsp?ccID="+ ccid_2 +"\" target=\"rFrame\">");
                    classStr.append(ccname + "</a>");
                    classStr.append("<td></tr>");
                    classStr.append("<tr id=\"load_"+ ccid_2 +"\"  style=\"DISPLAY: none\"><td>");
                    classStr.append(classBar_3(ccid_2));  
                    classStr.append("<div id=\"replies_"+ ccid_2 +"\"></div>");
                    classStr.append("</td></tr></table>");
                    if(cci_2.getCcList()){  //隐藏下级菜单
                        classStr.append("<script language=\"javascript\">loadTree("+ ccid_2 +" ,'');</script>");
                    }
                    }else{
                    classStr.append("<table  width=\"100%\" border=\"0\" cellpadding=\"1\" cellspacing=\"0\">");
                    classStr.append("<tr><td height=\"18\" class=\"barbgOut\" onmouseover=\"this.className='barbgOver'\" ");
                    classStr.append(" onmouseout=\"this.className='barbgOut'\">&nbsp;&nbsp;<img  src=\"GVimgs/tree/t2.gif\" align=\"absmiddle\" />");
                    classStr.append("&nbsp;<a href=\"clubClass.jsp?ccID=");
                    classStr.append(ccid_2 +"\" target=\"rFrame\">");
                    classStr.append(ccname);
                    classStr.append("</a>");
                    classStr.append("</td></tr></table>");
                    }
            }      
        }catch(Exception e){
            classStr.delete(0, classStr.length());
            classStr.append("论坛分类索引读取失败");
        }
        return classStr.toString();
    } 
    
   /**
    * 
    * @param ccidd
    * @param ccname
    * @return
    * @throws Exception
    */
   public String classBar_3(int ccidd){
        StringBuffer classStr = new StringBuffer("");
        StringBuffer hql = new StringBuffer();
        String ccname = "";
        StringBuffer ccnameStyle = new StringBuffer("");
        int ccid_3 = 0;
        try{
            hql.append("from ClubClassItem where ccIDD = ");
            hql.append(ccidd);
            hql.append(" and ccHidden=0 order by ccOrder desc");
            List list = ccim.classdList(hql.toString());
            Iterator it = list.iterator();
            while(it.hasNext()){
                ClubClassItem cci_3 = (ClubClassItem)it.next();
                ccname = cci_3.getCcName();
                ccid_3 = cci_3.getCcID();
                ccnameStyle.delete(0,ccnameStyle.length());
                if(expert==1){
                    ccnameStyle.append("<span style=\"");
                    if(cci_3.getCcType()==0){
                        if(!color_0.equals("")){
                            ccnameStyle.append("color: "+ color_0 +"; ");
                        }
                        if(strong_0==1){
                            ccnameStyle.append("font-weight: bold;"); 
                        }
                    }else{
                        if(!color_1.equals("")){
                            ccnameStyle.append("color: "+ color_1 +"; ");
                        }
                        if(strong_1==1){
                            ccnameStyle.append("font-weight: bold;"); 
                        }
                    }    
                    ccnameStyle.append("\">");
                    ccnameStyle.append(ccname);
                    ccnameStyle.append("</span>");
                    ccname = ccnameStyle.toString();
                }
                /*********************** htmlSelect 开始收集 ******************************/
                htmlSelect.append("<option value=\"");
                htmlSelect.append(ccid_3);
                htmlSelect.append("\">&nbsp;&nbsp;&nbsp;&nbsp;");
                htmlSelect.append(ccname);
                htmlSelect.append("</option>");
                
                /*********************** htmlMenu 开始收集 ***************************/
                classStr.append("<table  width=\"100%\" border=\"0\" cellpadding=\"1\" cellspacing=\"0\">");
                classStr.append("<tr><td height=\"18\" class=\"barbgOut\" onmouseover=\"this.className='barbgOver'\" ");
                classStr.append(" onmouseout=\"this.className='barbgOut'\">&nbsp;&nbsp;&nbsp;&nbsp;<img  src=\"GVimgs/tree/t2.gif\" align=\"absmiddle\" />");
                classStr.append("&nbsp;<a href=\"clubClass.jsp?ccID="+ ccid_3 +"\" target=\"rFrame\">");
                classStr.append(ccname + "</a>");
                classStr.append("</td></tr></table>");
                
            }
         }catch(Exception e){

        }
        return classStr.toString();
    }


   public void createClassFiles(){
	   FileOperate fo = new FileOperate();
       StringBuffer fileContent = new StringBuffer("");
       fileContent.append("<");
       fileContent.append("%@ page language=\"java\" contentType=\"text/html;charset=UTF-8\" errorPage=\"err.jsp\"");
       fileContent.append("%");
       fileContent.append(">");//
       
       StringBuffer htmlMenu = new StringBuffer();
       
       htmlMenu.append(fileContent);
       htmlMenu.append(classBar_1());
       try{
    	   fo.createFile(realPath+"gvFrameBar.jsp",htmlMenu.toString(),"UTF-8");
       } catch (Exception e) {
    	   e.printStackTrace();
	   } 
       StringBuffer htmlselect = new StringBuffer();
       //htmlselect.append("<select name=\"ccID\">");
       htmlselect.append("<option value=\"0\">全部版面</option>");
       htmlselect.append(htmlSelect);
       //htmlselect.append("</select>");
       fileContent.append(htmlselect);
       try{
    	   fo.createFile(realPath+"gvClassSelect.jsp",fileContent.toString(),"UTF-8");
       } catch (Exception e) {
    	   e.printStackTrace();
       }
       fileContent = null;
   }
   
   
   
    public void setColor_0(String color_0) {
        this.color_0 = color_0;
    }
    
    
    public void setColor_1(String color_1) {
        this.color_1 = color_1;
    }
    
    
    public void setStrong_0(int strong_0) {
        this.strong_0 = strong_0;
    }
    
    
    public void setStrong_1(int strong_1) {
        this.strong_1 = strong_1;
    }


    public void setExpert(int expert) {
        this.expert = expert;
    }
   
    
    
   
   public void setRealPath(String realPath) {
        this.realPath = realPath;
    }

   
   /* test
   public static void main(String args[]){
      ClubClassBar ccb = new ClubClassBar();
      ccb.setExpert(1);
      try {
        System.out.print(ccb.classBar_1());
        } catch (Exception e) {
            e.printStackTrace();
        }
   }
   */
   

}