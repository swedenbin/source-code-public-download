/*
 * Made in GamVan
 */
package com.gamvan.club;
import com.gamvan.club.dao.impl.ClubInfoImpl;
import com.gamvan.club.item.ClubInfoItem;
/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com 
 */
public class ClubInfo extends ClubInfoItem{
    private static final long serialVersionUID = 1L;
    private String message = "";
    private ClubInfoImpl ciim = new ClubInfoImpl();
    /**
     * 获取社区最后一条回复的ID编号，为了排序。
     * @return
     * 2005-11-6 21:43:22 Made In GamVan
     * com.gamvan.club
     */
    public int getLastReID(){
        int i = 0;
        ClubInfoItem cii = ciim.clubInfo();
        if(cii!=null){
        	i = cii.getClubLastReID();
        }
        this.clubLastReID= i;
        return i;
    }
   
    /**
     * 社区基本信息
     * @return
     * 2005-11-6 21:43:55 Made In GamVan
     * com.gamvan.club
     */
    public ClubInfoItem clubInfo(){
        ClubInfoItem cii = ciim.clubInfo();
        return cii;
    }
    
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    
   /* test
    public static void main(String args[]){
        ConnClub.init();
        ClubInfo ci = new ClubInfo();
        System.out.print(ci.getLastReID());
    }
    */
}




