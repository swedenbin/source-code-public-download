/*
 * Created on 2006-1-18
 * Last modified on 2006-1-18
 * Powered by GamVan.com
 */
package com.gamvan.club.cache;

/**
 * 此类暂时没有使用
 */
public class ClubWebCache {
	public static String cacheKey(String str, int id, byte b){
		StringBuffer cacheKey = new StringBuffer();
		cacheKey.append("_");
		cacheKey.append(str);
		cacheKey.append(id);
		cacheKey.append("_");
		cacheKey.append(b);
		return cacheKey.toString();
	}
}
