/*
 * Created on 2005-9-21
 * Made In GamVan
 */
package com.gamvan.club;


public class ClubHtmlConst {
    public static String Gfoot(String str, String ver){       
        StringBuffer sb = new StringBuffer();
        sb.append("<SCRIPT language=\"javascript\">gv_showWait('waitDiv', 0); </SCRIPT>");
        sb.append("<table width=\"100%\" align=\"center\" cellpadding=\"2\" cellspacing=\"1\" class=\"tab\">");
        sb.append("<tr><td align=\"center\" height=\"25\" class=\"tab1\">");
        sb.append(str);
        sb.append("</td></tr></table>");
        sb.append("<div align=\"center\" class=\"smallTxt\">");
        sb.append("<a href=\"http://club.GamVan.com/\" target=\"_blank\" title=\"GamVan Club\">");
        sb.append("<span class=\"smallTxt\">GamVan Club Version ");
        sb.append(ver);
        sb.append("</span></a><br>");
        sb.append("<a href=\"http://club.GamVan.com/\" target=\"_blank\">");
        sb.append("<img src=\"./GVimgs/gamvanFoot.gif\" alt=\"GamVan Club\" border=\"0\">");
        sb.append("</a>");
        sb.append("</div>");
        return sb.toString();
    }
    
    /**
     * 
     * @param s
     * @return
     * 2005-11-5 22:34:47 Made In GamVan
     * com.gamvan.club
     */
    public static String gamvan_menu(String s){
    	StringBuffer sb = new StringBuffer();
    	sb.append("<strong>您的位置</strong>&gt;&gt;");
    	sb.append("<a href=\"index.jsp\" target=\"_parent\">社区首页</a>&gt;&gt;");
    	sb.append("<a href=\"main.jsp\">进站画面</a>&gt;&gt;");
    	sb.append(s);
    	return sb.toString();
    }
    
    public static String gamvan_menu(String path, String s){
    	StringBuffer sb = new StringBuffer();
    	sb.append("<strong>您的位置</strong>&gt;&gt;");
    	sb.append("<a href=\"");
    	sb.append("/\">社区首页</a>&gt;&gt;");
    	sb.append(s);
    	return sb.toString();
    }
    /**
     * 
     * @param ccid
     * @param ccid1
     * @param ccid2
     * @param ccname
     * @param ccname1
     * @param ccname2
     * @param ccidd
     * @param ccidd1
     * @return
     * 2005-11-5 22:40:07 Made In GamVan
     * com.gamvan.club
     */
    public static String gamvan_classMenu(int ccid, int ccid1, int ccid2
    		, String ccname, String ccname1, String ccname2
    		, int ccidd, int ccidd1)
    {
    	StringBuffer sb = new StringBuffer();
    	if(ccidd1>0){
    		sb.append("<a href=\"clubClass.jsp?ccID=");
    		sb.append(ccid2);
    		sb.append("\">");
    		sb.append(ccname2);
    		sb.append("</a>&gt;&gt;");
    	}
    	if(ccidd>0){
    		sb.append("<a href=\"clubClass.jsp?ccID=");
    		sb.append(ccid1);
    		sb.append("\">");
    		sb.append(ccname1);
    		sb.append("</a>&gt;&gt;");
    	}
    	sb.append("<a href=\"clubClass.jsp?ccID=");
    	sb.append(ccid);
    	sb.append("\">");
    	sb.append(ccname);
    	sb.append("</a>&gt;&gt;");
    	return sb.toString();
    }
    
    public static String gamvan_classMenu(String path, String fileext
    		, int ccid, int ccid1, int ccid2
    		, String ccname, String ccname1, String ccname2
    		, int ccidd, int ccidd1)
    {
    	StringBuffer sb = new StringBuffer();
    	if(ccidd1>0){
    		sb.append("<a href=\"");
    		sb.append(path);
    		sb.append(ccid2);
    		sb.append(".");
    		sb.append(fileext);
    		sb.append("\">");
    		sb.append(ccname2);
    		sb.append("</a>&gt;&gt;");
    	}
    	if(ccidd>0){
    		sb.append("<a href=\"");
    		sb.append(path);
    		sb.append(ccid1);
    		sb.append(".");
    		sb.append(fileext);
    		sb.append("\">");
    		sb.append(ccname1);
    		sb.append("</a>&gt;&gt;");
    	}
    	sb.append("<a href=\"");
    	sb.append(path);
    	sb.append(ccid);
    	sb.append(".");
		sb.append(fileext);
    	sb.append("\">");
    	sb.append(ccname);
    	sb.append("</a>&gt;&gt;");
    	return sb.toString();
    }
}
