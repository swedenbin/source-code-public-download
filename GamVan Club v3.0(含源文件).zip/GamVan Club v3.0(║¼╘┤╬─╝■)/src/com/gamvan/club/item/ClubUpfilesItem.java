/*
 * Created on 2005-8-22
 * Last modified on 2005-8-22
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

public class ClubUpfilesItem  implements java.io.Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    protected int cfID = 0;
    protected String cfNewName = new String("");
    protected String cfOldName = new String("");
    protected String cfNewPath = new String("");
    protected String cfOldPath = new String("");
    protected String cfExt = new String("");
    protected String cfContentType = new String(""); //附件内容类型
    protected String cfDateTime = new String("");
    protected long cfSize = 0; // 附件大小
    protected short cfType = 0; // 附件类别 1文章相关，2是头像, 0未知。
    protected int cfUseID = 0; //上传被附件被使用，记录文章ID；
    protected String cfUseTxt = new String(""); //上传被附件被使用时的说明
    protected String cfByUser = new String("'"); // 执行上传得用户
    protected String cfByIp = new String("");
    protected int ccID=0;
    protected String ccName = new String("");
    protected int cfByUserID = 0;
    
    
    public int getCfID() {
        return cfID;
    }
    public void setCfID(int cfID) {
        this.cfID = cfID;
    }
    public int getCcID() {
        return ccID;
    }
    public void setCcID(int ccID) {
        this.ccID = ccID;
    }
    public String getCcName() {
        return ccName;
    }
    public void setCcName(String ccName) {
        this.ccName = ccName;
    }
    public String getCfByIp() {
        return cfByIp;
    }
    public void setCfByIp(String cfByIp) {
        this.cfByIp = cfByIp;
    }
    public String getCfByUser() {
        return cfByUser;
    }
    public void setCfByUser(String cfByUser) {
        this.cfByUser = cfByUser;
    }
    public int getCfByUserID() {
        return cfByUserID;
    }
    public void setCfByUserID(int cfByUserID) {
        this.cfByUserID = cfByUserID;
    }
    public String getCfContentType() {
        return cfContentType;
    }
    public void setCfContentType(String cfContentType) {
        this.cfContentType = cfContentType;
    }
    public String getCfDateTime() {
        return cfDateTime;
    }
    public void setCfDateTime(String cfDateTime) {
        this.cfDateTime = cfDateTime;
    }
    public String getCfExt() {
        return cfExt;
    }
    public void setCfExt(String cfExt) {
        this.cfExt = cfExt;
    }
    public String getCfNewName() {
        return cfNewName;
    }
    public void setCfNewName(String cfNewName) {
        this.cfNewName = cfNewName;
    }
    public String getCfNewPath() {
        return cfNewPath;
    }
    public void setCfNewPath(String cfNewPath) {
        this.cfNewPath = cfNewPath;
    }
    public String getCfOldName() {
        return cfOldName;
    }
    public void setCfOldName(String cfOldName) {
        this.cfOldName = cfOldName;
    }
    public String getCfOldPath() {
        return cfOldPath;
    }
    public void setCfOldPath(String cfOldPath) {
        this.cfOldPath = cfOldPath;
    }
    public long getCfSize() {
        return cfSize;
    }
    public void setCfSize(long cfSize) {
        this.cfSize = cfSize;
    }
    public short getCfType() {
        return cfType;
    }
    public void setCfType(short cfType) {
        this.cfType = cfType;
    }
    public int getCfUseID() {
        return cfUseID;
    }
    public void setCfUseID(int cfUseID) {
        this.cfUseID = cfUseID;
    }
    public String getCfUseTxt() {
        return cfUseTxt;
    }
    public void setCfUseTxt(String cfUseTxt) {
        this.cfUseTxt = cfUseTxt;
    }
    

}
