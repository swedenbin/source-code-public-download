/*
 * Created on 2005-7-9
 * Last modified on 2005-7-9
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

public class ClubInfoItem implements java.io.Serializable{
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    protected int clubInfoID=0;
    protected int clubMenu=0;
    protected String clubName = "";
    protected String clubUrl = "";
    protected String clubTitle = "";
    protected String clubMeta = "";
    protected String clubSmtp = "";
    protected String clubEmail = "";

    protected String clubSmtpID = "";
    protected String clubSmtpPass = "";
    protected String clubEmailSend = "";
    protected int clubSmtpUsePass = 0;
    protected int clubUpfileOpen = 0;
    protected int clubUpfileUser = 0;
    protected int clubUpfileMax = 0;
    protected String clubUpfileExt = "";
    protected String clubCopyRight = "";
    protected String clubYear = "";
    protected int clubUserPic=0;
    protected String clubSmtpPort = "";
    protected int clubSmtpSSL = 0;
    protected int clubRefreshPage = 0;
    protected int clubHotTopic=0; //浏览热贴
    protected int clubHotRe=0;//回复热贴
    protected String clubRegAgree = ""; //社区注册协议
    protected String clubUpfileDomain = ""; //上传文件访问地址
    protected boolean clubTopicIsPass = true; //默认帖子是否通过审核。
    protected int clubLastReID = 0;
    
    

    
    public int getClubLastReID() {
        return clubLastReID;
    }
    public void setClubLastReID(int clubLastReID) {
        this.clubLastReID = clubLastReID;
    }
    public boolean getClubTopicIsPass() {
        return clubTopicIsPass;
    }
    public void setClubTopicIsPass(boolean clubTopicIsPass) {
        this.clubTopicIsPass = clubTopicIsPass;
    }
    public int getClubInfoID() {
        return clubInfoID;
    }
    public void setClubInfoID(int clubInfoID) {
        this.clubInfoID = clubInfoID;
    }
    public String getClubCopyRight() {
        return clubCopyRight;
    }
    public void setClubCopyRight(String clubCopyRight) {
        this.clubCopyRight = clubCopyRight;
    }
    public String getClubEmail() {
        return clubEmail;
    }
    public void setClubEmail(String clubEmail) {
        this.clubEmail = clubEmail;
    }
    public String getClubEmailSend() {
        return clubEmailSend;
    }
    public void setClubEmailSend(String clubEmailSend) {
        this.clubEmailSend = clubEmailSend;
    }
    public int getClubHotRe() {
        return clubHotRe;
    }
    public void setClubHotRe(int clubHotRe) {
        this.clubHotRe = clubHotRe;
    }
    public int getClubHotTopic() {
        return clubHotTopic;
    }
    public void setClubHotTopic(int clubHotTopic) {
        this.clubHotTopic = clubHotTopic;
    }
    public int getClubMenu() {
        return clubMenu;
    }
    public void setClubMenu(int clubMenu) {
        this.clubMenu = clubMenu;
    }
    public String getClubMeta() {
        return clubMeta;
    }
    public void setClubMeta(String clubMeta) {
        this.clubMeta = clubMeta;
    }
    public String getClubName() {
        return clubName;
    }
    public void setClubName(String clubName) {
        this.clubName = clubName;
    }
    public int getClubRefreshPage() {
        return clubRefreshPage;
    }
    public void setClubRefreshPage(int clubRefreshPage) {
        this.clubRefreshPage = clubRefreshPage;
    }
    public String getClubRegAgree() {
        return clubRegAgree;
    }
    public void setClubRegAgree(String clubRegAgree) {
        this.clubRegAgree = clubRegAgree;
    }
    public String getClubSmtp() {
        return clubSmtp;
    }
    public void setClubSmtp(String clubSmtp) {
        this.clubSmtp = clubSmtp;
    }
    public String getClubSmtpID() {
        return clubSmtpID;
    }
    public void setClubSmtpID(String clubSmtpID) {
        this.clubSmtpID = clubSmtpID;
    }
    public String getClubSmtpPass() {
        return clubSmtpPass;
    }
    public void setClubSmtpPass(String clubSmtpPass) {
        this.clubSmtpPass = clubSmtpPass;
    }
    public String getClubSmtpPort() {
        return clubSmtpPort;
    }
    public void setClubSmtpPort(String clubSmtpPort) {
        this.clubSmtpPort = clubSmtpPort;
    }
    public int getClubSmtpSSL() {
        return clubSmtpSSL;
    }
    public void setClubSmtpSSL(int clubSmtpSSL) {
        this.clubSmtpSSL = clubSmtpSSL;
    }
    public int getClubSmtpUsePass() {
        return clubSmtpUsePass;
    }
    public void setClubSmtpUsePass(int clubSmtpUsePass) {
        this.clubSmtpUsePass = clubSmtpUsePass;
    }

    public String getClubTitle() {
        return clubTitle;
    }
    public void setClubTitle(String clubTitle) {
        this.clubTitle = clubTitle;
    }
    public String getClubUpfileDomain() {
        return clubUpfileDomain;
    }
    public void setClubUpfileDomain(String clubUpfileDomain) {
        this.clubUpfileDomain = clubUpfileDomain;
    }
    public String getClubUpfileExt() {
        return clubUpfileExt;
    }
    public void setClubUpfileExt(String clubUpfileExt) {
        this.clubUpfileExt = clubUpfileExt;
    }
    public int getClubUpfileMax() {
        return clubUpfileMax;
    }
    public void setClubUpfileMax(int clubUpfileMax) {
        this.clubUpfileMax = clubUpfileMax;
    }
    public int getClubUpfileOpen() {
        return clubUpfileOpen;
    }
    public void setClubUpfileOpen(int clubUpfileOpen) {
        this.clubUpfileOpen = clubUpfileOpen;
    }
    public int getClubUpfileUser() {
        return clubUpfileUser;
    }
    public void setClubUpfileUser(int clubUpfileUser) {
        this.clubUpfileUser = clubUpfileUser;
    }
    public String getClubUrl() {
        return clubUrl;
    }
    public void setClubUrl(String clubUrl) {
        this.clubUrl = clubUrl;
    }
    public int getClubUserPic() {
        return clubUserPic;
    }
    public void setClubUserPic(int clubUserPic) {
        this.clubUserPic = clubUserPic;
    }
    public String getClubYear() {
        return clubYear;
    }
    public void setClubYear(String clubYear) {
        this.clubYear = clubYear;
    }
    
    
}
