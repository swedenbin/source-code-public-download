/*
 * Created on 2005-8-1
 * Last modified on 2005-8-1
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubCounterItem implements java.io.Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    protected int clubCounterID=0;
    protected int clubHits=0;
    protected int clubTodayPV=0;
    protected int clubYesterPV=0;
    protected int clubTopic=0;
    protected int clubReply=0;
    protected int clubTodayTopic=0;
    protected int clubTodayReply=0;
    protected int clubYesterTopic=0;
    protected int clubYesterReply=0;
    protected int clubBoy=0;
    protected int clubGirl=0;
    protected String clubToday="";
    protected int clubMostOnline=0;
    protected String clubNewUser="";
    protected int clubTemp=0;
    
    public int getClubTemp() {
        return clubTemp;
    }
    public void setClubTemp(int clubTemp) {
        this.clubTemp = clubTemp;
    }
    public int getClubBoy() {
        return clubBoy;
    }
    public void setClubBoy(int clubBoy) {
        this.clubBoy = clubBoy;
    }
    public int getClubGirl() {
        return clubGirl;
    }
    public void setClubGirl(int clubGirl) {
        this.clubGirl = clubGirl;
    }
    public int getClubHits() {
        return clubHits;
    }
    public void setClubHits(int clubHits) {
        this.clubHits = clubHits;
    }
    public int getClubMostOnline() {
        return clubMostOnline;
    }
    public void setClubMostOnline(int clubMostOnline) {
        this.clubMostOnline = clubMostOnline;
    }
    public String getClubNewUser() {
        return clubNewUser;
    }
    public void setClubNewUser(String clubNewUser) {
        this.clubNewUser = clubNewUser;
    }
    public int getClubReply() {
        return clubReply;
    }
    public void setClubReply(int clubReply) {
        this.clubReply = clubReply;
    }
    public String getClubToday() {
        return clubToday;
    }
    public void setClubToday(String clubToday) {
        this.clubToday = clubToday;
    }
    public int getClubTodayPV() {
        return clubTodayPV;
    }
    public void setClubTodayPV(int clubTodayPV) {
        this.clubTodayPV = clubTodayPV;
    }
    public int getClubTodayReply() {
        return clubTodayReply;
    }
    public void setClubTodayReply(int clubTodayReply) {
        this.clubTodayReply = clubTodayReply;
    }
    public int getClubTodayTopic() {
        return clubTodayTopic;
    }
    public void setClubTodayTopic(int clubTodayTopic) {
        this.clubTodayTopic = clubTodayTopic;
    }
    public int getClubTopic() {
        return clubTopic;
    }
    public void setClubTopic(int clubTopic) {
        this.clubTopic = clubTopic;
    }
    public int getClubYesterPV() {
        return clubYesterPV;
    }
    public void setClubYesterPV(int clubYesterPV) {
        this.clubYesterPV = clubYesterPV;
    }
    public int getClubYesterReply() {
        return clubYesterReply;
    }
    public void setClubYesterReply(int clubYesterReply) {
        this.clubYesterReply = clubYesterReply;
    }
    public int getClubYesterTopic() {
        return clubYesterTopic;
    }
    public void setClubYesterTopic(int clubYesterTopic) {
        this.clubYesterTopic = clubYesterTopic;
    }
    public int getClubCounterID() {
        return clubCounterID;
    }
    public void setClubCounterID(int clubCounterID) {
        this.clubCounterID = clubCounterID;
    }
    
}
