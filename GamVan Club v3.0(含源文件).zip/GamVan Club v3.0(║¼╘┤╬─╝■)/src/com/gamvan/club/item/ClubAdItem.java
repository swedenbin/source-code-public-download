/*
 * Created on 2005-8-21
 * Last modified on 2005-8-21
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubAdItem implements java.io.Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    protected int adID = 0;
    protected String adObj = "";
    protected String adTxt = "";
    protected String adUrl = "";
    
    protected short adWidth = 10;
    protected short adHeight = 10;
    protected short adType = 0;
    
    
    
    
    
    
    public short getAdHeight() {
        return adHeight;
    }
    public void setAdHeight(short height) {
        adHeight = height;
    }
    public int getAdID() {
        return adID;
    }
    public void setAdID(int adid) {
        adID = adid;
    }
    public String getAdObj() {
        return adObj;
    }
    public void setAdObj(String obj) {
        adObj = obj;
    }
    public String getAdTxt() {
        return adTxt;
    }
    public void setAdTxt(String txt) {
        adTxt = txt;
    }
    public short getAdType() {
        return adType;
    }
    public void setAdType(short type) {
        adType = type;
    }
    public String getAdUrl() {
        return adUrl;
    }
    public void setAdUrl(String url) {
        adUrl = url;
    }
    public short getAdWidth() {
        return adWidth;
    }
    public void setAdWidth(short width) {
        adWidth = width;
    }
    

    
    
    
    
    
    
    
    
    
}
