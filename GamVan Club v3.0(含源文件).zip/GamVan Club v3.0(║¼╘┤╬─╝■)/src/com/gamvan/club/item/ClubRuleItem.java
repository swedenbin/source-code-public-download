/*
 * Created on 2005-8-21
 * Last modified on 2005-8-21
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

public class ClubRuleItem  implements java.io.Serializable{
    
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    protected int crID = 0;
    protected String crMark = new String("");
    protected String crMoney = new String("");
    protected String crCredit = new String("");
    
    
    
    
    public String getCrCredit() {
        return crCredit;
    }
    public void setCrCredit(String crCredit) {
        this.crCredit = crCredit;
    }
    public String getCrMark() {
        return crMark;
    }
    public void setCrMark(String crMark) {
        this.crMark = crMark;
    }
    public String getCrMoney() {
        return crMoney;
    }
    public void setCrMoney(String crMoney) {
        this.crMoney = crMoney;
    }
    public int getCrID() {
        return crID;
    }
    public void setCrID(int crID) {
        this.crID = crID;
    }

    
    
    
}
