/*
 * Created on 2005-8-21
 * Last modified on 2005-8-21
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

public class ClubAfficheItem implements java.io.Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    protected int caID = 0;
    protected int ccID = 0;
    protected String caTopic = new String("");
    protected String caContent = new String("");
    protected String caAddTime = new String("");
    protected int caDays = 0; //公告有效期
    protected String caByUser = new String("");
    protected String caByip = new String("");
    
    public String getCaAddTime() {
        return caAddTime;
    }
    public void setCaAddTime(String caAddTime) {
        this.caAddTime = caAddTime;
    }
    public String getCaByip() {
        return caByip;
    }
    public void setCaByip(String caByip) {
        this.caByip = caByip;
    }
    public String getCaByUser() {
        return caByUser;
    }
    public void setCaByUser(String caByUser) {
        this.caByUser = caByUser;
    }
    public String getCaContent() {
        return caContent;
    }
    public void setCaContent(String caContent) {
        this.caContent = caContent;
    }
    public int getCaID() {
        return caID;
    }
    public void setCaID(int caID) {
        this.caID = caID;
    }
    public String getCaTopic() {
        return caTopic;
    }
    public void setCaTopic(String caTopic) {
        this.caTopic = caTopic;
    }
    public int getCcID() {
        return ccID;
    }
    public void setCcID(int ccID) {
        this.ccID = ccID;
    }
    public int getCaDays() {
        return caDays;
    }
    public void setCaDays(int caDays) {
        this.caDays = caDays;
    }

    
    
    
}
