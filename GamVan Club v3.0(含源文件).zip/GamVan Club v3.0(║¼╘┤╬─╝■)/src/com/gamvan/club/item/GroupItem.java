/*
 * Created on 2005-7-5
 * Last modified on 2005-7-5
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

/**
 * Club 网页分类信息
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class GroupItem implements java.io.Serializable{
    private static final long serialVersionUID = 1L;
    protected String groupName="";
    protected int groupID = 0;
    protected int groupOrder = 0;
    protected int groupType = 0; //分类类别
    protected int groupLayer = 0; 
    protected int groupIDD = 0; //自分类归属
    protected int groupCount = 0;

    public int getGroupID() {
        return groupID;
    }
    public void setGroupID(int groupID) {
        this.groupID = groupID;
    }
    public int getGroupIDD() {
        return groupIDD;
    }
    public void setGroupIDD(int groupIDD) {
        this.groupIDD = groupIDD;
    }
    public int getGroupLayer() {
        return groupLayer;
    }
    public void setGroupLayer(int groupLayer) {
        this.groupLayer = groupLayer;
    }
    public String getGroupName() {
        return groupName;
    }
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
    public int getGroupOrder() {
        return groupOrder;
    }
    public void setGroupOrder(int groupOrder) {
        this.groupOrder = groupOrder;
    }
    public int getGroupType() {
        return groupType;
    }
    public void setGroupType(int groupType) {
        this.groupType = groupType;
    }
	public int getGroupCount() {
		return groupCount;
	}
	public void setGroupCount(int groupCount) {
		this.groupCount = groupCount;
	}

}

