/*
 * Created on 2005-8-7
 * Last modified on 2005-8-7
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicLogItem implements java.io.Serializable{
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    protected int topicLogID=0;
    protected int userID=0;
    protected String userName="";
    protected String topic=""; //主题内容
    protected int topicID=0;
    protected String topicLogTxt = ""; //日志备注，日志产生原因
    protected int  topicLogByUserID = 0; //操作人员ID
    protected String topicLogByUserName = ""; //操作人员
    protected String topicLogByUserIP = ""; //操作人员IP
    protected String topicLogByDateTime = ""; //操作时间
    
    // 用户信誉、金币、积分
    protected double userCredit = 0;
    protected double userMark = 0;
    protected double userMoney = 0;
    
    protected String topicLogSo = ""; //日志结果，日志产生的内容 /
    
    //日志信息是否显示在网页底部
    protected short topicLogByUserList = 0;
    protected boolean topicLogList = true;
    protected int topicReID = 0;
    
    protected int ccID = 0;
    
    
    public int getCcID() {
		return ccID;
	}
	public void setCcID(int ccID) {
		this.ccID = ccID;
	}
	public int getTopicReID() {
        return topicReID;
    }
    public void setTopicReID(int topicReID) {
        this.topicReID = topicReID;
    }
    public String getTopic() {
        return topic;
    }
    public void setTopic(String topic) {
        this.topic = topic;
    }
    public int getTopicID() {
        return topicID;
    }
    public void setTopicID(int topicID) {
        this.topicID = topicID;
    }
    public String getTopicLogByDateTime() {
        return topicLogByDateTime;
    }
    public void setTopicLogByDateTime(String topicLogByDateTime) {
        this.topicLogByDateTime = topicLogByDateTime;
    }
    public int getTopicLogByUserID() {
        return topicLogByUserID;
    }
    public void setTopicLogByUserID(int topicLogByUserID) {
        this.topicLogByUserID = topicLogByUserID;
    }
    public String getTopicLogByUserIP() {
        return topicLogByUserIP;
    }
    public void setTopicLogByUserIP(String topicLogByUserIP) {
        this.topicLogByUserIP = topicLogByUserIP;
    }
    public short getTopicLogByUserList() {
        return topicLogByUserList;
    }
    public void setTopicLogByUserList(short topicLogByUserList) {
        this.topicLogByUserList = topicLogByUserList;
    }
    public String getTopicLogByUserName() {
        return topicLogByUserName;
    }
    public void setTopicLogByUserName(String topicLogByUserName) {
        this.topicLogByUserName = topicLogByUserName;
    }
    public int getTopicLogID() {
        return topicLogID;
    }
    public void setTopicLogID(int topicLogID) {
        this.topicLogID = topicLogID;
    }
    public boolean getTopicLogList() {
        return topicLogList;
    }
    public void setTopicLogList(boolean topicLogList) {
        this.topicLogList = topicLogList;
    }
    public String getTopicLogSo() {
        return topicLogSo;
    }
    public void setTopicLogSo(String topicLogSo) {
        this.topicLogSo = topicLogSo;
    }
    public String getTopicLogTxt() {
        return topicLogTxt;
    }
    public void setTopicLogTxt(String topicLogTxt) {
        this.topicLogTxt = topicLogTxt;
    }
    public double getUserCredit() {
        return userCredit;
    }
    public void setUserCredit(double userCredit) {
        this.userCredit = userCredit;
    }
    public int getUserID() {
        return userID;
    }
    public void setUserID(int userID) {
        this.userID = userID;
    }
    public double getUserMark() {
        return userMark;
    }
    public void setUserMark(double userMark) {
        this.userMark = userMark;
    }
    public double getUserMoney() {
        return userMoney;
    }
    public void setUserMoney(double userMoney) {
        this.userMoney = userMoney;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    
    

}
