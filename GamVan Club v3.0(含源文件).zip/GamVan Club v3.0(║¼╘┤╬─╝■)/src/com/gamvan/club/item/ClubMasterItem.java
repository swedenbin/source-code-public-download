/*
 * Created on 2005-8-21
 * Last modified on 2005-8-21
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubMasterItem implements java.io.Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    protected int cmID = 0;
    protected int cmgID = 0;
    protected String cmName = "";
    protected String cmPass = "";
    protected boolean cmIpLock = false;
    protected String cmIp1 = "";
    protected String cmIp2 = "";
    protected String cmLastLoginTime = "";
    protected String cmLastLoginIp = "";
    
    
    
    public String getCmLastLoginIp() {
        return cmLastLoginIp;
    }
    public void setCmLastLoginIp(String cmLastLoginIp) {
        this.cmLastLoginIp = cmLastLoginIp;
    }
    public String getCmLastLoginTime() {
        return cmLastLoginTime;
    }
    public void setCmLastLoginTime(String cmLastLoginTime) {
        this.cmLastLoginTime = cmLastLoginTime;
    }
    public int getCmgID() {
        return cmgID;
    }
    public void setCmgID(int cmgID) {
        this.cmgID = cmgID;
    }
    public int getCmID() {
        return cmID;
    }
    public void setCmID(int cmID) {
        this.cmID = cmID;
    }
    public String getCmIp1() {
        return cmIp1;
    }
    public void setCmIp1(String cmIp1) {
        this.cmIp1 = cmIp1;
    }
    public String getCmIp2() {
        return cmIp2;
    }
    public void setCmIp2(String cmIp2) {
        this.cmIp2 = cmIp2;
    }
    public boolean getCmIpLock() {
        return cmIpLock;
    }
    public void setCmIpLock(boolean cmIpLock) {
        this.cmIpLock = cmIpLock;
    }

    public String getCmName() {
        return cmName;
    }
    public void setCmName(String cmName) {
        this.cmName = cmName;
    }
    public String getCmPass() {
        return cmPass;
    }
    public void setCmPass(String cmPass) {
        this.cmPass = cmPass;
    }
    

}
