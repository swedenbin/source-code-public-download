/*
 * Created on 2005-9-28
 * Last modified on 2005-9-28
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

public class ClubSafeFileItem  implements java.io.Serializable{
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    protected int fileID = 0;
    protected String fileNameAndPath = "";
    protected String fileExt = "";
    protected String fileDateTime = "";
    protected String fileByUser = "";
    protected int fileByUserID = 0;
    protected String fileByUserIp = "";
    protected String fileFrom = ""; //文件来源
    protected boolean fileIsOpen = true; //文件访问是否打开
    
    
    
    
    public boolean getFileIsOpen() {
        return fileIsOpen;
    }
    public void setFileIsOpen(boolean fileIsOpen) {
        this.fileIsOpen = fileIsOpen;
    }
    public String getFileByUser() {
        return fileByUser;
    }
    public void setFileByUser(String fileByUser) {
        this.fileByUser = fileByUser;
    }
    public int getFileByUserID() {
        return fileByUserID;
    }
    public void setFileByUserID(int fileByUserID) {
        this.fileByUserID = fileByUserID;
    }
    public String getFileByUserIp() {
        return fileByUserIp;
    }
    public void setFileByUserIp(String fileByUserIp) {
        this.fileByUserIp = fileByUserIp;
    }
    public String getFileDateTime() {
        return fileDateTime;
    }
    public void setFileDateTime(String fileDateTime) {
        this.fileDateTime = fileDateTime;
    }
    public String getFileExt() {
        return fileExt;
    }
    public void setFileExt(String fileExt) {
        this.fileExt = fileExt;
    }
    public String getFileFrom() {
        return fileFrom;
    }
    public void setFileFrom(String fileFrom) {
        this.fileFrom = fileFrom;
    }
    public int getFileID() {
        return fileID;
    }
    public void setFileID(int fileID) {
        this.fileID = fileID;
    }
    public String getFileNameAndPath() {
        return fileNameAndPath;
    }
    public void setFileNameAndPath(String fileNameAndPath) {
        this.fileNameAndPath = fileNameAndPath;
    } 
    
    
}
