/*
 * Created on 2005-10-8
 * Last modified on 2005-10-8
 * Powered by GamVan.com
 */
package com.gamvan.club.item;
/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubBusinessItem implements java.io.Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    protected int businessID = 0;
    protected int userID = 0;
    protected String userName = "";
    
    /**
     * 关联的ID和Name 用来表示这笔交易是用户转送朋友还是购买物品
     * relatingID可能记录朋友ID，或者物品ID。
     * relatingName记录朋友名字或是物品名字。
     */
    protected int relatingID = 0;
    protected String relatingName = "";
    
    
    /**
     * 记录用户交易，各项参数的变动
     */
    protected double userCredit = 0; //信誉
    protected double userMark = 0; //积分
    protected double userMoney = 0; //金币
    protected double userDeposit = 0; //帐户存款
    
    protected double businessRate = 0; //当前交易的比率
    
    
    protected String businessDateTime = "";
    protected String businessIp = "";
    protected String businessLog = "";
    
    /**
     * 判断用户的交易类型，是购买物品转曾朋友还是自己兑换，或是存入银行。
     * 1 积分兑换金币
     * 2 金币兑换积分
     * 3 转赠他人
     * 4 购买物品
     * 5 存入银行
     */
    protected byte businessType = 0;
    

    public String getBusinessDateTime() {
        return businessDateTime;
    }

    public void setBusinessDateTime(String businessDateTime) {
        this.businessDateTime = businessDateTime;
    }

    public int getBusinessID() {
        return businessID;
    }

    public void setBusinessID(int businessID) {
        this.businessID = businessID;
    }

    public String getBusinessIp() {
        return businessIp;
    }

    public void setBusinessIp(String businessIp) {
        this.businessIp = businessIp;
    }

    public String getBusinessLog() {
        return businessLog;
    }

    public void setBusinessLog(String businessLog) {
        this.businessLog = businessLog;
    }

    public double getBusinessRate() {
        return businessRate;
    }

    public void setBusinessRate(double businessRate) {
        this.businessRate = businessRate;
    }

    public byte getBusinessType() {
        return businessType;
    }

    public void setBusinessType(byte businessType) {
        this.businessType = businessType;
    }

    public int getRelatingID() {
        return relatingID;
    }

    public void setRelatingID(int relatingID) {
        this.relatingID = relatingID;
    }

    public String getRelatingName() {
        return relatingName;
    }

    public void setRelatingName(String relatingName) {
        this.relatingName = relatingName;
    }

    public double getUserCredit() {
        return userCredit;
    }

    public void setUserCredit(double userCredit) {
        this.userCredit = userCredit;
    }

    public double getUserDeposit() {
        return userDeposit;
    }

    public void setUserDeposit(double userDeposit) {
        this.userDeposit = userDeposit;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public double getUserMark() {
        return userMark;
    }

    public void setUserMark(double userMark) {
        this.userMark = userMark;
    }

    public double getUserMoney() {
        return userMoney;
    }

    public void setUserMoney(double userMoney) {
        this.userMoney = userMoney;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
    
}
