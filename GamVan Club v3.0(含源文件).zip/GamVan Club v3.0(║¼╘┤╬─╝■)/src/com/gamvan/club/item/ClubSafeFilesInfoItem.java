/*
 * Created on 2005-9-29
 * Last modified on 2005-9-29
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

public class ClubSafeFilesInfoItem implements java.io.Serializable{

    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    protected int infoID = 0;
    protected String allowDomain = "";
    
    
    
    public String getAllowDomain() {
        return allowDomain;
    }
    public void setAllowDomain(String allowDomain) {
        this.allowDomain = allowDomain;
    }
    public int getInfoID() {
        return infoID;
    }
    public void setInfoID(int infoID) {
        this.infoID = infoID;
    }

    
}
