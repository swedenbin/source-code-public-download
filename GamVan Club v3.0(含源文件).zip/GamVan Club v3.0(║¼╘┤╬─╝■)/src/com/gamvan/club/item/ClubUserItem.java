/*
 * Created on 2005-6-22
 * Last modified on 2005-6-22
 * Powered by GamVan.com
 */
package com.gamvan.club.item;
import java.text.DecimalFormat;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com 
 */
public class ClubUserItem implements java.io.Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    protected int userID = 0;
    protected String userName = "";
    protected String userPass = "";
    protected String userName2 = "";
    protected byte userSex = 0;
    protected String userEmail = "";
    protected short userEmailOpen = 0;
    protected String userQuestion = "";
    protected String userAnswer = "";
    protected String userBirthday = "";
    protected String userWeb = "";
    protected String userQQ = "";
    protected String userArea = "";
    protected String userCity = "";
    protected String userWork = "";
    protected String userPen = "";
    protected String userIntro = "";
    protected int userUpfile = 0;
    protected String userTxt = "";
    protected String userRegTime = ""; 
    protected String userLastTime = "";
    protected int userLoginTimes = 0;
    protected String userRegip = "";
    protected String userLastip = "";
    
    protected double userMoney = 0
    , userMark = 0, userDeposit = 0,/*存款*/ userCredit = 0;
    protected int userTopicCount = 0;
    protected int userReCount = 0;
    protected boolean userIsDel = false;

    protected short userUpfileOpen = 0;
    protected int userUpfileSize = 0;
    protected String userPic = "";
    protected short userPicIs = 0;
    protected int userAreaId = 0;
    protected String userRegDate = "", userLastDate="";
    protected String userLastDateTime;

    private DecimalFormat df = new DecimalFormat(".##"); //控制小数点位数
    

    public double getUserMark(){
        userMark = Double.parseDouble(df.format(userMark));
        return this.userMark;
    }
    public double getUserMoney(){
        userMoney = Double.parseDouble(df.format(userMoney));
        return this.userMoney;
    }
    public double getUserCredit(){
        userCredit = Double.parseDouble(df.format(userCredit));
        return this.userCredit;
    }
    
    public String getUserAnswer() {
        return userAnswer;
    }
    public void setUserAnswer(String userAnswer) {
        this.userAnswer = userAnswer;
    }
    public String getUserArea() {
        if(userArea==null){
            userArea = "";
        }
        return userArea;
    }
    public void setUserArea(String userArea) {
        this.userArea = userArea;
    }
    public int getUserAreaId() {
        return userAreaId;
    }
    public void setUserAreaId(int userAreaId) {
        this.userAreaId = userAreaId;
    }
    public String getUserBirthday() {
        if(userBirthday==null){
            return "";
        }
        return userBirthday;
    }
    public void setUserBirthday(String userBirthday) {
        this.userBirthday = userBirthday;
    }
    public String getUserCity() {
        if(userCity==null){
            return "";
        }
        return userCity;
    }
    public void setUserCity(String userCity) {
        if(userCity==null){
            userCity = "";
        }
        this.userCity = userCity;
    }
    public double getUserDeposit() {
        return userDeposit;
    }
    public void setUserDeposit(double userDeposit) {
        this.userDeposit = userDeposit;
    }
    public String getUserEmail() {
        return userEmail;
    }
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
    public short getUserEmailOpen() {
        return userEmailOpen;
    }
    public void setUserEmailOpen(short userEmailOpen) {
        this.userEmailOpen = userEmailOpen;
    }
    public int getUserID() {
        return userID;
    }
    public void setUserID(int userID) {
        this.userID = userID;
    }
    public String getUserIntro() {
        if(userIntro==null){
            return "";
        }
        return userIntro;
    }
    public void setUserIntro(String userIntro) {
        this.userIntro = userIntro;
    }
    public boolean getUserIsDel() {
        return userIsDel;
    }
    public void setUserIsDel(boolean userIsDel) {
        this.userIsDel = userIsDel;
    }
    public String getUserLastDate() {
        if(userLastDate==null){
            userLastDate = "";
        }
        return userLastDate;
    }
    public void setUserLastDate(String userLastDate) {
        this.userLastDate = userLastDate;
    }
    public String getUserLastDateTime() {
        if(userLastDateTime==null){
            userLastDateTime = "";
        }
        return userLastDateTime;
    }
    public void setUserLastDateTime(String userLastDateTime) {
        this.userLastDateTime = userLastDateTime;
    }
    public String getUserLastip() {
        if(userLastip==null){
            userLastip = "";
        }
        return userLastip;
    }
    public void setUserLastip(String userLastip) {
        this.userLastip = userLastip;
    }
    public String getUserLastTime() {
        if(userLastTime==null){
            return "";
        }else{
            return userLastTime;
        }
        
    }
    public void setUserLastTime(String userLastTime) {
        if(userLastTime==null){
            this.userLastTime = "";
        }else{
            this.userLastTime = userLastTime;
        }
        
    }
    public int getUserLoginTimes() {
        return userLoginTimes;
    }
    public void setUserLoginTimes(int userLoginTimes) {
        this.userLoginTimes = userLoginTimes;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getUserName2() {
        if(userName2==null){
            return "";
        }
        return userName2;
    }
    public void setUserName2(String userName2) {
        this.userName2 = userName2;
    }
    public String getUserPass() {
        return userPass;
    }
    public void setUserPass(String userPass) {
        this.userPass = userPass;
    }
    public String getUserPen() {
        if(userPen==null){
            return "";
        }
        return userPen;
    }
    public void setUserPen(String userPen) {
        this.userPen = userPen;
    }
    public String getUserPic() {
        if(userPic==null){
            return "";
        }
        return userPic;
    }
    public void setUserPic(String userPic) {
        this.userPic = userPic;
    }
    public short getUserPicIs() {
        return userPicIs;
    }
    public void setUserPicIs(short userPicIs) {
        this.userPicIs = userPicIs;
    }
    public String getUserQQ() {
        if(userQQ==null){
            return "";
        }
        return userQQ;
    }
    public void setUserQQ(String userQQ) {
        
        this.userQQ = userQQ;
    }
    public String getUserQuestion() {
        return userQuestion;
    }
    public void setUserQuestion(String userQuestion) {
        this.userQuestion = userQuestion;
    }
    public int getUserReCount() {
        return userReCount;
    }
    public void setUserReCount(int userReCount) {
        this.userReCount = userReCount;
    }
    public String getUserRegDate() {
        return userRegDate;
    }
    public void setUserRegDate(String userRegDate) {
        this.userRegDate = userRegDate;
    }
    public String getUserRegip() {
        if(userRegip==null){
            return "";
        }
        return userRegip;
    }
    public void setUserRegip(String userRegip) {
        this.userRegip = userRegip;
    }
    public String getUserRegTime() {
        if(userRegTime==null){
            return "";
        }
        return userRegTime;
    }
    public void setUserRegTime(String userRegTime) {
        this.userRegTime = userRegTime;
    }
    public byte getUserSex() {
        return userSex;
    }
    public void setUserSex(byte userSex) {
        this.userSex = userSex;
    }
    public int getUserTopicCount() {
        return userTopicCount;
    }
    public void setUserTopicCount(int userTopicCount) {
        this.userTopicCount = userTopicCount;
    }
    public String getUserTxt() {
        if(userTxt==null){
            return "";
        }
        return userTxt;
    }
    public void setUserTxt(String userTxt) {
        this.userTxt = userTxt;
    }
    public int getUserUpfile() {
        return userUpfile;
    }
    public void setUserUpfile(int userUpfile) {
        this.userUpfile = userUpfile;
    }
    public short getUserUpfileOpen() {
        return userUpfileOpen;
    }
    public void setUserUpfileOpen(short userUpfileOpen) {
        this.userUpfileOpen = userUpfileOpen;
    }
    public int getUserUpfileSize() {
        return userUpfileSize;
    }
    public void setUserUpfileSize(int userUpfileSize) {
        this.userUpfileSize = userUpfileSize;
    }
    public String getUserWeb() {
        if(userWeb==null){
            return "";
        }
        return userWeb;
    }
    public void setUserWeb(String userWeb) {
        this.userWeb = userWeb;
    }
    public String getUserWork() {
        if(userWork==null){
            return "";
        }
        return userWork;
    }
    public void setUserWork(String userWork) {
        this.userWork = userWork;
    }
    public void setUserCredit(double userCredit) {
        this.userCredit = userCredit;
    }
    public void setUserMark(double userMark) {
        this.userMark = userMark;
    }
    public void setUserMoney(double userMoney) {
        this.userMoney = userMoney;
    }
 
    
    
    
    
} 
    