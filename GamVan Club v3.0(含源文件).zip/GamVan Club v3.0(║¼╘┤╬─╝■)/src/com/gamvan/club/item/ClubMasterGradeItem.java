/*
 * Created on 2005-8-21
 * Last modified on 2005-8-21
 * Powered by GamVan.com
 */
package com.gamvan.club.item;


/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubMasterGradeItem implements java.io.Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    protected int cmgID = 0;
    protected String cmgName = "";
    protected String cmgTxt = "";
    
    
    
    
    
    
    
    
    
    public int getCmgID() {
        return cmgID;
    }
    public void setCmgID(int cmgID) {
        this.cmgID = cmgID;
    }
    public String getCmgName() {
        return cmgName;
    }
    public void setCmgName(String cmgName) {
        this.cmgName = cmgName;
    }
    public String getCmgTxt() {
        return cmgTxt;
    }
    public void setCmgTxt(String cmgTxt) {
        this.cmgTxt = cmgTxt;
    }

}
