/*
 * Created on 2005-8-10
 * Last modified on 2005-8-10
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubBlackItem  implements java.io.Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    protected int blackId=0;
    protected String blackUserName = "";
    protected String blackInfo = "";
    protected String blackTxt = "";
    protected int blackDate=0;
    protected boolean blackOver=false;
    protected String byUserName="";
    protected String byAddTime="";
    protected String byUserIp = "";
    protected int ccID=0;
    protected int userID=0;
    protected int byUserID=0;
    
    

    public int getBlackId() {
        return blackId;
    }
    public void setBlackId(int blackId) {
        this.blackId = blackId;
    }
    public int getBlackDate() {
        return blackDate;
    }
    public void setBlackDate(int blackDate) {
        this.blackDate = blackDate;
    }
    public String getBlackInfo() {
        return blackInfo;
    }
    public void setBlackInfo(String blackInfo) {
        this.blackInfo = blackInfo;
    }
    public boolean getBlackOver() {
        return blackOver;
    }
    public void setBlackOver(boolean blackOver) {
        this.blackOver = blackOver;
    }
    public String getBlackTxt() {
        return blackTxt;
    }
    public void setBlackTxt(String blackTxt) {
        this.blackTxt = blackTxt;
    }
    public String getBlackUserName() {
        return blackUserName;
    }
    public void setBlackUserName(String blackUserName) {
        this.blackUserName = blackUserName;
    }
    public String getByAddTime() {
        return byAddTime;
    }
    public void setByAddTime(String byAddTime) {
        this.byAddTime = byAddTime;
    }
    public int getByUserID() {
        return byUserID;
    }
    public void setByUserID(int byUserID) {
        this.byUserID = byUserID;
    }
    public String getByUserIp() {
        return byUserIp;
    }
    public void setByUserIp(String byUserIp) {
        this.byUserIp = byUserIp;
    }
    public String getByUserName() {
        return byUserName;
    }
    public void setByUserName(String byUserName) {
        this.byUserName = byUserName;
    }
    public int getCcID() {
        return ccID;
    }
    public void setCcID(int ccID) {
        this.ccID = ccID;
    }
    public int getUserID() {
        return userID;
    }
    public void setUserID(int userID) {
        this.userID = userID;
    }
    
    
    
    
}
