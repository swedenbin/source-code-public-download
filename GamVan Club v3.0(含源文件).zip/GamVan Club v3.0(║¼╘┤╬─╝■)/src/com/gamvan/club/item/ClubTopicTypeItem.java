/*
 * Created on 2005-8-4
 * Last modified on 2005-8-4
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicTypeItem  implements java.io.Serializable{
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    protected int typeID = 0;
    protected int topicID = 0;
    protected short typeInfo = 0;
    protected double typeNum = 0;
    protected String userName = "";
    protected String addTime = "";
    protected int userID = 0;
    
    
    public String getAddTime() {
        return addTime;
    }
    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }
    public int getTopicID() {
        return topicID;
    }
    public void setTopicID(int topicID) {
        this.topicID = topicID;
    }
    public int getTypeID() {
        return typeID;
    }
    public void setTypeID(int typeID) {
        this.typeID = typeID;
    }
    public short getTypeInfo() {
        return typeInfo;
    }
    public void setTypeInfo(short typeInfo) {
        this.typeInfo = typeInfo;
    }
    public double getTypeNum() {
        return typeNum;
    }
    public void setTypeNum(double typeNum) {
        this.typeNum = typeNum;
    }
    public int getUserID() {
        return userID;
    }
    public void setUserID(int userID) {
        this.userID = userID;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    
    
    

}
