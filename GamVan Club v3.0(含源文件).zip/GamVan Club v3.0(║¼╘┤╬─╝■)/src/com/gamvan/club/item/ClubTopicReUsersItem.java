/*
 * Created on 2005-8-4
 * Last modified on 2005-8-4
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

public class ClubTopicReUsersItem implements java.io.Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    protected int reID = 0;
    protected int topicID = 0;
    protected String reUsers = "";
    
    
    public int getReID() {
        return reID;
    }
    public void setReID(int reID) {
        this.reID = reID;
    }
    public String getReUsers() {
        return reUsers;
    }
    public void setReUsers(String reUsers) {
        this.reUsers = reUsers;
    }
    public int getTopicID() {
        return topicID;
    }
    public void setTopicID(int topicID) {
        this.topicID = topicID;
    }
    
    
    
    
        
}
