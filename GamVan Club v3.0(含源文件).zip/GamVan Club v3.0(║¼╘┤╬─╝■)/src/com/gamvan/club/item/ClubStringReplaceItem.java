/*
 * Created on 2005-8-10
 * Last modified on 2005-8-10
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubStringReplaceItem implements java.io.Serializable{
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    protected int srID = 0;
    protected String replaceUserName = "";
    protected String replaceTopic = "";
    protected String replaceContent = "";
    protected String replaceMsgTopic = "";
    protected String replaceMsgContent = "";
    protected String replaceUserPen = "";
    
    
    public String getReplaceContent() {
        return replaceContent;
    }
    public void setReplaceContent(String replaceContent) {
        this.replaceContent = replaceContent;
    }
    public String getReplaceMsgContent() {
        return replaceMsgContent;
    }
    public void setReplaceMsgContent(String replaceMsgContent) {
        this.replaceMsgContent = replaceMsgContent;
    }
    public String getReplaceMsgTopic() {
        return replaceMsgTopic;
    }
    public void setReplaceMsgTopic(String replaceMsgTopic) {
        this.replaceMsgTopic = replaceMsgTopic;
    }
    public String getReplaceTopic() {
        return replaceTopic;
    }
    public void setReplaceTopic(String replaceTopic) {
        this.replaceTopic = replaceTopic;
    }
    public String getReplaceUserName() {
        return replaceUserName;
    }
    public void setReplaceUserName(String replaceUserName) {
        this.replaceUserName = replaceUserName;
    }
    public String getReplaceUserPen() {
        return replaceUserPen;
    }
    public void setReplaceUserPen(String replaceUserPen) {
        this.replaceUserPen = replaceUserPen;
    }
    public int getSrID() {
        return srID;
    }
    public void setSrID(int srID) {
        this.srID = srID;
    }
    
    
    
    
}
