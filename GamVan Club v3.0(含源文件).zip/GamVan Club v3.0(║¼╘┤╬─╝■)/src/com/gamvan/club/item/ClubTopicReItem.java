/*
 * Created on 2005-10-15
 * Last modified on 2005-10-15
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

import com.gamvan.tools.FormatDateTime;

public class ClubTopicReItem{

    private static final long serialVersionUID = 1L;
    
    public ClubContentReItem ccri = new ClubContentReItem();
    
    public ClubContentReItem getCcri() {
        return ccri;
    }

    public void setCcri(ClubContentReItem ccri) {
        this.ccri = ccri;
    }

    /* 格式化当前时间 */
    protected String now = FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    
    /* 数据库字段 */
    protected int topicID=0;
    protected int topicReID=0;
    protected int topicOrder=0; //topicOrder主题排序，可固定，回复树形排序
    protected short topicLayer=0;
    protected int topicTree=0;
    protected String topic="";
    protected String userName="";
    protected int ccID=0;
    protected int ccID1=0;
    protected int ccID2=0;

    protected String topicList="";
    protected short topicMood=0;
    protected short topicPro=0;//topicPro 锁定、禁止回复、精品。
    protected short topicType=0;
    protected double topicTypeNum=0; //特殊类型主题关联的积分或金币
    
    protected String topicAddTime=""; //购买、积分、求助特殊类型的主题关联的用户
    protected String topicAddip="";
    protected String topicLastReUser="";
    protected String topicLastReTime="";
    protected int topicViewCount=0;
    protected int topicReCount=0;
    protected int topicLen=0;

    protected int userID = 0;
    protected boolean topicIsPass = true; //帖子审核是否通过
    protected byte topicIsDel = 0; //帖子审核是否通过
    
    protected int contentID=0;
    
    protected String content="";
    protected boolean contentUserPen=false;
    protected boolean contentUrl=false;
    protected boolean contentImg=false;
    protected boolean contentEmail=false;
    protected byte contentCopyRight=0;
    
    /* 数据库字段结束 */

    public boolean getTopicIsPass() {
        return topicIsPass;
    }
    public void setTopicIsPass(boolean topicIsPass) {
        this.topicIsPass = topicIsPass;
    }
    public int getContentID() {
        return contentID;
    }
    public void setContentID(int contentID) {
        this.contentID = contentID;
    }

    public int getCcID() {
        return ccID;
    }
    public void setCcID(int ccID) {
        this.ccID = ccID;
    }
    public int getCcID1() {
        return ccID1;
    }
    public void setCcID1(int ccID1) {
        this.ccID1 = ccID1;
    }
    public int getCcID2() {
        return ccID2;
    }
    public void setCcID2(int ccID2) {
        this.ccID2 = ccID2;
    }

    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public byte getContentCopyRight() {
        return contentCopyRight;
    }
    public void setContentCopyRight(byte contentCopyRight) {
        this.contentCopyRight = contentCopyRight;
    }

    public boolean getContentEmail() {
        return contentEmail;
    }
    public void setContentEmail(boolean contentEmail) {
        this.contentEmail = contentEmail;
    }
    public boolean getContentImg() {
        return contentImg;
    }
    public void setContentImg(boolean contentImg) {
        this.contentImg = contentImg;
    }

    public boolean getContentUrl() {
        return contentUrl;
    }
    public void setContentUrl(boolean contentUrl) {
        this.contentUrl = contentUrl;
    }
    public boolean getContentUserPen() {
        return contentUserPen;
    }
    public void setContentUserPen(boolean contentUserPen) {
        this.contentUserPen = contentUserPen;
    }


    public String getNow() {
        return now;
    }
    public void setNow(String now) {
        this.now = now;
    }
    public String getTopic() {
        return topic;
    }
    public void setTopic(String topic) {
        this.topic = topic;
    }
    public String getTopicAddip() {
        return topicAddip;
    }
    public void setTopicAddip(String topicAddip) {
        this.topicAddip = topicAddip;
    }
    public String getTopicAddTime() {
        return topicAddTime;
    }
    public void setTopicAddTime(String topicAddTime) {
        this.topicAddTime = topicAddTime;
    }

    public int getTopicID() {
        return topicID;
    }
    
    public void setTopicID(int topicID) {
        this.topicID = topicID;
    }
    public String getTopicLastReTime() {
        return topicLastReTime;
    }
    public void setTopicLastReTime(String topicLastReTime) {
        this.topicLastReTime = topicLastReTime;
    }
    public String getTopicLastReUser() {
        return topicLastReUser;
    }
    public void setTopicLastReUser(String topicLastReUser) {
        this.topicLastReUser = topicLastReUser;
    }
    public short getTopicLayer() {
        return topicLayer;
    }
    public void setTopicLayer(short topicLayer) {
        this.topicLayer = topicLayer;
    }
    public int getTopicLen() {
        return topicLen;
    }
    public void setTopicLen(int topicLen) {
        this.topicLen = topicLen;
    }
    public String getTopicList() {
        return topicList;
    }
    public void setTopicList(String topicList) {
        this.topicList = topicList;
    }
    public short getTopicMood() {
        return topicMood;
    }
    public void setTopicMood(short topicMood) {
        this.topicMood = topicMood;
    }
    public int getTopicOrder() {
        return topicOrder;
    }
    public void setTopicOrder(int topicOrder) {
        this.topicOrder = topicOrder;
    }
    public short getTopicPro() {
        return topicPro;
    }
    public void setTopicPro(short topicPro) {
        this.topicPro = topicPro;
    }
    public int getTopicReCount() {
        return topicReCount;
    }
    public void setTopicReCount(int topicReCount) {
        this.topicReCount = topicReCount;
    }
    public int getTopicReID() {
        return topicReID;
    }
    public void setTopicReID(int topicReID) {
        this.topicReID = topicReID;
    }

    public int getTopicTree() {
        return topicTree;
    }
    public void setTopicTree(int topicTree) {
        this.topicTree = topicTree;
    }
    public short getTopicType() {
        return topicType;
    }
    public void setTopicType(short topicType) {
        this.topicType = topicType;
    }

    public double getTopicTypeNum() {
        return topicTypeNum;
    }
    public void setTopicTypeNum(double topicTypeNum) {
        this.topicTypeNum = topicTypeNum;
    }
    public int getTopicViewCount() {
        return topicViewCount;
    }
    public void setTopicViewCount(int topicViewCount) {
        this.topicViewCount = topicViewCount;
    }

    public int getUserID() {
        return userID;
    }
    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }

	public byte getTopicIsDel() {
		return topicIsDel;
	}

	public void setTopicIsDel(byte topicIsDel) {
		this.topicIsDel = topicIsDel;
	}
}
