/*
 * Created on 2005-9-20
 * Last modified on 2005-9-20
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

public class ClubFriendsItem  implements java.io.Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    protected int cfID = 0;
    protected String userMe = "";
    protected String userFriend = "";
    protected String addTime = "";
    protected String userMessage = "";
    protected String userIp = "";
    protected int userMeID = 0;
    protected int userFriendID = 0;
    protected int isOnLine = 0;
    
    
    public String getAddTime() {
        return addTime;
    }
    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }
    public int getCfID() {
        return cfID;
    }
    public void setCfID(int cfID) {
        this.cfID = cfID;
    }
    public int getIsOnLine() {
        return isOnLine;
    }
    public void setIsOnLine(int isOnLine) {
        this.isOnLine = isOnLine;
    }
    public String getUserFriend() {
        return userFriend;
    }
    public void setUserFriend(String userFriend) {
        this.userFriend = userFriend;
    }
    public int getUserFriendID() {
        return userFriendID;
    }
    public void setUserFriendID(int userFriendID) {
        this.userFriendID = userFriendID;
    }
    public String getUserIp() {
        return userIp;
    }
    public void setUserIp(String userIp) {
        this.userIp = userIp;
    }
    public String getUserMe() {
        return userMe;
    }
    public void setUserMe(String userMe) {
        this.userMe = userMe;
    }
    public int getUserMeID() {
        return userMeID;
    }
    public void setUserMeID(int userMeID) {
        this.userMeID = userMeID;
    }
    public String getUserMessage() {
        return userMessage;
    }
    public void setUserMessage(String userMessage) {
        this.userMessage = userMessage;
    }

    
}
