/*
 * Created on 2005-8-3
 * Last modified on 2005-8-3
 * Powered by GamVan.com
 */
package com.gamvan.club.item;


public class ClubUserGradeItem  implements java.io.Serializable{
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    protected int ugID = 0;
    protected String ugName = "";
    protected String ugTxt = "";
    
    public int getUgID() {
        return ugID;
    }
    public void setUgID(int ugID) {
        this.ugID = ugID;
    }
    public String getUgName() {
        return ugName;
    }
    public void setUgName(String ugName) {
        this.ugName = ugName;
    }
    public String getUgTxt() {
        return ugTxt;
    }
    public void setUgTxt(String ugTxt) {
        this.ugTxt = ugTxt;
    }
    
    
}
