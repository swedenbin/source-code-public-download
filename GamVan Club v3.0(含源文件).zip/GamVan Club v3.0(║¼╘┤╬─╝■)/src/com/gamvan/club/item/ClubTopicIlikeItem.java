/*
 * Created on 2005-7-30
 * Last modified on 2005-7-30
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicIlikeItem  implements java.io.Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    protected int likeID = 0;
    protected int topicID = 0;
    protected int myUserID = 0;
    protected String myUserName = "";
    protected String addTime = ""; //订阅时间
    protected String lastTime = ""; //自己最后访问的时候
    protected String topic = "" ; 
    protected String topicUserName = ""; //主题的最后被回复时间
    protected String topicLastReTime = "";
    protected int ccID = 0;
    protected int topicUserID = 0;
    
    
    public String getAddTime() {
        return addTime;
    }
    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }
    public int getCcID() {
        return ccID;
    }
    public void setCcID(int ccID) {
        this.ccID = ccID;
    }
    public String getLastTime() {
        return lastTime;
    }
    public void setLastTime(String lastTime) {
        this.lastTime = lastTime;
    }
    public int getLikeID() {
        return likeID;
    }
    public void setLikeID(int likeID) {
        this.likeID = likeID;
    }
    public int getMyUserID() {
        return myUserID;
    }
    public void setMyUserID(int myUserID) {
        this.myUserID = myUserID;
    }
    public String getMyUserName() {
        return myUserName;
    }
    public void setMyUserName(String myUserName) {
        this.myUserName = myUserName;
    }
    public String getTopic() {
        return topic;
    }
    public void setTopic(String topic) {
        this.topic = topic;
    }
    public int getTopicID() {
        return topicID;
    }
    public void setTopicID(int topicID) {
        this.topicID = topicID;
    }
    public String getTopicLastReTime() {
        return topicLastReTime;
    }
    public void setTopicLastReTime(String topicLastReTime) {
        this.topicLastReTime = topicLastReTime;
    }
    public int getTopicUserID() {
        return topicUserID;
    }
    public void setTopicUserID(int topicUserID) {
        this.topicUserID = topicUserID;
    }
    public String getTopicUserName() {
        return topicUserName;
    }
    public void setTopicUserName(String topicUserName) {
        this.topicUserName = topicUserName;
    }
    
    
    
}
