/*
 * Created on 2005-10-15
 * Last modified on 2005-10-15
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

public class ClubContentReItem implements java.io.Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    protected int contentID = 0;
   
    protected String content="";
    protected boolean contentUserPen=false;
    protected boolean contentUrl=false;
    protected boolean contentImg=false;
    protected boolean contentEmail=false;
    protected byte contentCopyRight=0; 
    protected byte contentIsDel = 0; //帖子是否被删除
    
    
    protected int topicReID=0;
    protected int topicID=0;
    
    
    public int getTopicReID() {
        return topicReID;
    }
    public void setTopicReID(int topicReID) {
        this.topicReID = topicReID;
    }

    public int getTopicID() {
        return topicID;
    }
    public void setTopicID(int topicID) {
        this.topicID = topicID;
    }
    
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public byte getContentCopyRight() {
        return contentCopyRight;
    }
    public void setContentCopyRight(byte contentCopyRight) {
        this.contentCopyRight = contentCopyRight;
    }
    public boolean getContentEmail() {
        return contentEmail;
    }
    public void setContentEmail(boolean contentEmail) {
        this.contentEmail = contentEmail;
    }

    public boolean getContentImg() {
        return contentImg;
    }
    public void setContentImg(boolean contentImg) {
        this.contentImg = contentImg;
    }
    public boolean getContentUrl() {
        return contentUrl;
    }
    public void setContentUrl(boolean contentUrl) {
        this.contentUrl = contentUrl;
    }
    
    public boolean getContentUserPen() {
        return contentUserPen;
    }
    
    public void setContentUserPen(boolean contentUserPen) {
        this.contentUserPen = contentUserPen;
    }
    

    public int getContentID() {
        return contentID;
    }
    public void setContentID(int contentID) {
        this.contentID = contentID;
    }
	public byte getContentIsDel() {
		return contentIsDel;
	}
	public void setContentIsDel(byte contentIsDel) {
		this.contentIsDel = contentIsDel;
	}
}



