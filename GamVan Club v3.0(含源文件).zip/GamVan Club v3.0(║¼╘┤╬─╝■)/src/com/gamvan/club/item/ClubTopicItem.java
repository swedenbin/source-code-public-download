/*
 * Created on 2005-6-18
 * Last modified on 2005-6-18
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicItem implements java.io.Serializable{

    private static final long serialVersionUID = 1L;

    //==============数据库字段==================
    protected int topicID=0;
    protected int topicReID=0;
    protected int topicOrder=0; //topicOrder主题排序，可固定，回复树形排序
    protected short topicLayer=0;
    protected int topicTree=0;
    protected String topic="";
    protected String userName="";
    protected int ccID=0;
    protected int ccID1=0;
    protected int ccID2=0;
    protected int moveCCID=0; //所在分类，moveCCID移动自某分类。
    protected String topicList="";
    protected short topicMood=0;
    protected short topicPro=0;//topicPro 锁定、禁止回复、精品。
    
    /* 主题类型 1积分浏览 2金币购买 3散分求助 4回复可见  5结贴状态 */
    protected short topicType=0;
    protected double topicTypeNum=0; //特殊类型主题关联的积分或金币
    
    protected String topicAddTime=""; //购买、积分、求助特殊类型的主题关联的用户
    protected String topicAddip="";
    protected String topicLastReUser="";
    protected String topicLastReTime="";
    protected int topicViewCount=0;
    protected int topicReCount=0;
    protected int topicLen=0;
    protected String moveUser="";
    protected String moveTime="";
    protected int userID = 0;
    protected boolean topicIsPass = true; //帖子审核是否通过
    protected byte topicIsDel = 0; //帖子是否被删除
    
    protected int contentID=0;
    
    protected String content="";
    protected boolean contentUserPen=false;
    protected boolean contentUrl=false;
    protected boolean contentImg=false;
    protected boolean contentEmail=false;
    protected byte contentCopyRight=0;
    

    //============数据库字段结束================
    
    protected static String message="";
    protected int topicTypeUserInfo=0; //购买、积分、求助特殊类型的主题关联的用户积分，金币得失情况
    protected int topicTypeInfo=0; //购买、积分、求助特殊类型的主题日志发生时该主题的类型
    
    protected static String userPass="";
    protected static String userPass2="";
    protected static String typeUserName=""; //型别记录的用户名
    
    protected static String topicColor="";
    protected static String topicBold="";
    protected static String contentEditInfo=""; //编辑信息。
    protected static String contentReUser=""; //回复过主题的用户
    protected static String topicTypeUsers="";
    protected static String act=""; //判断是编辑、添加、修过或是删除
    protected static String reUsers="";
    protected static String topicReUsers = "";
    protected static String menuStyle=""; //前台按钮控制的显示风格
    protected static String ccName=""; //文章所在版面

    protected static double userMark=0;
    protected static double userCredit=0;
    protected static double userMoney=0;
    protected static int cLeg = 0; //内容长度
    protected static int tLeg = 0; //主题长度   
    
    protected ClubContentItem cci;
    
    public ClubContentItem getCci() {
        return cci;
    }
    public void setCci(ClubContentItem cci) {
        this.cci = cci;
    }

    public boolean getTopicIsPass() {
        return topicIsPass;
    }
    public void setTopicIsPass(boolean topicIsPass) {
        this.topicIsPass = topicIsPass;
    }
    public int getContentID() {
        return contentID;
    }
    public void setContentID(int contentID) {
        this.contentID = contentID;
    }
    
    
    public int getCcID() {
        return ccID;
    }
    public void setCcID(int ccID) {
        this.ccID = ccID;
    }
    public int getCcID1() {
        return ccID1;
    }
    public void setCcID1(int ccID1) {
        this.ccID1 = ccID1;
    }
    public int getCcID2() {
        return ccID2;
    }
    public void setCcID2(int ccID2) {
        this.ccID2 = ccID2;
    }

    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public byte getContentCopyRight() {
        return contentCopyRight;
    }
    public void setContentCopyRight(byte contentCopyRight) {
        this.contentCopyRight = contentCopyRight;
    }
    

    
    
    public boolean getContentEmail() {
        return contentEmail;
    }
    public void setContentEmail(boolean contentEmail) {
        this.contentEmail = contentEmail;
    }
    public boolean getContentImg() {
        return contentImg;
    }
    public void setContentImg(boolean contentImg) {
        this.contentImg = contentImg;
    }

    public boolean getContentUrl() {
        return contentUrl;
    }
    public void setContentUrl(boolean contentUrl) {
        this.contentUrl = contentUrl;
    }
    public boolean getContentUserPen() {
        return contentUserPen;
    }
    public void setContentUserPen(boolean contentUserPen) {
        this.contentUserPen = contentUserPen;
    }
    public int getUserID() {
        return userID;
    }
    public void setUserID(int userID) {
        this.userID = userID;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public int getMoveCCID() {
        return moveCCID;
    }
    public void setMoveCCID(int moveCCID) {
        this.moveCCID = moveCCID;
    }
    public String getMoveTime() {
        return moveTime;
    }
    public void setMoveTime(String moveTime) {
        this.moveTime = moveTime;
    }
    public String getMoveUser() {
        return moveUser;
    }
    public void setMoveUser(String moveUser) {
        if(moveUser==null){
            this.moveUser = "";
        }else{
            this.moveUser = moveUser;
        }
    }

    public String getTopic() {
        return topic;
    }
    public void setTopic(String topic) {
        this.topic = topic;
    }
    public String getTopicAddip() {
        return topicAddip;
    }
    public void setTopicAddip(String topicAddip) {
        this.topicAddip = topicAddip;
    }
    public String getTopicAddTime() {
        return topicAddTime;
    }
    public void setTopicAddTime(String topicAddTime) {
        this.topicAddTime = topicAddTime;
    }

    public int getTopicID() {
        return topicID;
    }
    public void setTopicID(int topicID) {
        this.topicID = topicID;
    }
    public String getTopicLastReTime() {
        return topicLastReTime;
    }
    public void setTopicLastReTime(String topicLastReTime) {
        this.topicLastReTime = topicLastReTime;
    }
    public String getTopicLastReUser() {
        return topicLastReUser;
    }
    public void setTopicLastReUser(String topicLastReUser) {
        this.topicLastReUser = topicLastReUser;
    }
    public short getTopicLayer() {
        return topicLayer;
    }
    public void setTopicLayer(short topicLayer) {
        this.topicLayer = topicLayer;
    }
    public int getTopicLen() {
        return topicLen;
    }
    public void setTopicLen(int topicLen) {
        this.topicLen = topicLen;
    }
    public String getTopicList() {
        return topicList;
    }
    public void setTopicList(String topicList) {
        this.topicList = topicList;
    }
    public short getTopicMood() {
        return topicMood;
    }
    public void setTopicMood(short topicMood) {
        this.topicMood = topicMood;
    }
    public int getTopicOrder() {
        return topicOrder;
    }
    public void setTopicOrder(int topicOrder) {
        this.topicOrder = topicOrder;
    }
    public short getTopicPro() {
        return topicPro;
    }
    public void setTopicPro(short topicPro) {
        this.topicPro = topicPro;
    }
    public int getTopicReCount() {
        return topicReCount;
    }
    public void setTopicReCount(int topicReCount) {
        this.topicReCount = topicReCount;
    }
    public int getTopicReID() {
        return topicReID;
    }
    public void setTopicReID(int topicReID) {
        this.topicReID = topicReID;
    }

    public int getTopicTree() {
        return topicTree;
    }
    public void setTopicTree(int topicTree) {
        this.topicTree = topicTree;
    }
    public short getTopicType() {
        return topicType;
    }
    public void setTopicType(short topicType) {
        this.topicType = topicType;
    }
    public double getTopicTypeNum() {
        return topicTypeNum;
    }
    public void setTopicTypeNum(double topicTypeNum) {
        this.topicTypeNum = topicTypeNum;
    }
    public int getTopicViewCount() {
        return topicViewCount;
    }
    public void setTopicViewCount(int topicViewCount) {
        this.topicViewCount = topicViewCount;
    }
    
    
    
    /**************************************************/
    public int getTopicTypeInfo() {
        return topicTypeInfo;
    }
    public void setTopicTypeInfo(int topicTypeInfo) {
        this.topicTypeInfo = topicTypeInfo;
    }
    public String getTypeUserName() {
        return typeUserName;
    }
    public void setTypeUserName(String typeUserName) {
        this.typeUserName = typeUserName;
    }
    public double getUserCredit() {
        return userCredit;
    }
    public void setUserCredit(double userCredit) {
        this.userCredit = userCredit;
    }

    public double getUserMark() {
        return userMark;
    }
    public void setUserMark(double userMark) {
        this.userMark = userMark;
    }
    public double getUserMoney() {
        return userMoney;
    }
    public void setUserMoney(double userMoney) {
        this.userMoney = userMoney;
    }
    public String getUserPass() {
        return userPass;
    }
    public void setUserPass(String userPass) {
        this.userPass = userPass;
    }
    public String getUserPass2() {
        return userPass2;
    }
    public void setUserPass2(String userPass2) {
        this.userPass2 = userPass2;
    }
    
    public String getMenuStyle() {
        return menuStyle;
    }
    public void setMenuStyle(String menuStyle) {
        this.menuStyle = menuStyle;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public String getCcName() {
        return ccName;
    }
    public void setCcName(String ccName) {
        this.ccName = ccName;
    }
    public int getCLeg() {
        return cLeg;
    }
    public void setCLeg(int leg) {
        cLeg = leg;
    }
    public String getContentEditInfo() {
        return contentEditInfo;
    }
    public void setContentEditInfo(String contentEditInfo) {
        this.contentEditInfo = contentEditInfo;
    }
    public String getContentReUser() {
        return contentReUser;
    }
    public void setContentReUser(String contentReUser) {
        this.contentReUser = contentReUser;
    } 
    public String getReUsers() {
        return reUsers;
    }
    public void setReUsers(String reUsers) {
        this.reUsers = reUsers;
    }
    public int getTLeg() {
        return tLeg;
    }
    public void setTLeg(int leg) {
        tLeg = leg;
    }
    
    public String getTopicBold() {
        return topicBold;
    }
    public void setTopicBold(String topicBold) {
        this.topicBold = topicBold;
    }
    public String getTopicColor() {
        return topicColor;
    }
    public void setTopicColor(String topicColor) {
        this.topicColor = topicColor;
    }
    public String getTopicReUsers() {
        return topicReUsers;
    }
    public void setTopicReUsers(String topicReUsers) {
        this.topicReUsers = topicReUsers;
    }
    public int getTopicTypeUserInfo() {
        return topicTypeUserInfo;
    }
    public void setTopicTypeUserInfo(int topicTypeUserInfo) {
        this.topicTypeUserInfo = topicTypeUserInfo;
    }
    public String getTopicTypeUsers() {
        return topicTypeUsers;
    }
    public void setTopicTypeUsers(String topicTypeUsers) {
        this.topicTypeUsers = topicTypeUsers;
    }
	public byte getTopicIsDel() {
		return topicIsDel;
	}
	public void setTopicIsDel(byte topicIsDel) {
		this.topicIsDel = topicIsDel;
	}

    
}
