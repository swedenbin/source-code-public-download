/*
 * Created on 2005-8-19
 * Last modified on 2005-8-19
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

public class ClubMessageSendItem  implements java.io.Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    protected int cmID = 0;
    protected String cmSendUser = "";
    protected String cmTakeUser = "";
    
    protected String cmTopic = "";
    protected String cmContent = "";
    protected String cmUserIp = "";
    protected String cmAddTime = "";
    protected boolean cmIsSend = false;
    protected short cmOrder = 0;
    protected int cmReID = 0;
    protected int cmSendID = 0;
    protected int cmTakeID = 0;
    
    
    
    
    
    public String getCmAddTime() {
        return cmAddTime;
    }
    public void setCmAddTime(String cmAddTime) {
        this.cmAddTime = cmAddTime;
    }
    public String getCmContent() {
        return cmContent;
    }
    public void setCmContent(String cmContent) {
        this.cmContent = cmContent;
    }
    public int getCmID() {
        return cmID;
    }
    public void setCmID(int cmID) {
        this.cmID = cmID;
    }
    public boolean getCmIsSend() {
        return cmIsSend;
    }
    public void setCmIsSend(boolean cmIsSend) {
        this.cmIsSend = cmIsSend;
    }
    public short getCmOrder() {
        return cmOrder;
    }
    public void setCmOrder(short cmOrder) {
        this.cmOrder = cmOrder;
    }
    public int getCmReID() {
        return cmReID;
    }
    public void setCmReID(int cmReID) {
        this.cmReID = cmReID;
    }
    public int getCmSendID() {
        return cmSendID;
    }
    public void setCmSendID(int cmSendID) {
        this.cmSendID = cmSendID;
    }
    public String getCmSendUser() {
        return cmSendUser;
    }
    public void setCmSendUser(String cmSendUser) {
        this.cmSendUser = cmSendUser;
    }
    public int getCmTakeID() {
        return cmTakeID;
    }
    public void setCmTakeID(int cmTakeID) {
        this.cmTakeID = cmTakeID;
    }
    public String getCmTakeUser() {
        return cmTakeUser;
    }
    public void setCmTakeUser(String cmTakeUser) {
        this.cmTakeUser = cmTakeUser;
    }
    public String getCmTopic() {
        return cmTopic;
    }
    public void setCmTopic(String cmTopic) {
        this.cmTopic = cmTopic;
    }
    public String getCmUserIp() {
        return cmUserIp;
    }
    public void setCmUserIp(String cmUserIp) {
        this.cmUserIp = cmUserIp;
    }
    
    
    

}
