/*
 * Created on 2005-8-4
 * Last modified on 2005-8-4
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

public class ClubUseropItem  implements java.io.Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    protected int uoID = 0;
    protected String uoUser = "";
    protected int uoGradeID = 0;
    protected int uoCID = 0;
    protected byte uoIs = 0;
    protected String uoByUser = "";
    protected String uoByip = "";
    protected String uoByTime = "";
    protected int userID = 0;
    
    
    
    public String getUoByip() {
        return uoByip;
    }
    public void setUoByip(String uoByip) {
        this.uoByip = uoByip;
    }
    public String getUoByTime() {
        return uoByTime;
    }
    public void setUoByTime(String uoByTime) {
        this.uoByTime = uoByTime;
    }
    public String getUoByUser() {
        return uoByUser;
    }
    public void setUoByUser(String uoByUser) {
        this.uoByUser = uoByUser;
    }
    public int getUoCID() {
        return uoCID;
    }
    public void setUoCID(int uoCID) {
        this.uoCID = uoCID;
    }
    public int getUoGradeID() {
        return uoGradeID;
    }
    public void setUoGradeID(int uoGradeID) {
        this.uoGradeID = uoGradeID;
    }
    public int getUoID() {
        return uoID;
    }
    public void setUoID(int uoID) {
        this.uoID = uoID;
    }
    public byte getUoIs() {
        return uoIs;
    }
    public void setUoIs(byte uoIs) {
        this.uoIs = uoIs;
    }
    public String getUoUser() {
        return uoUser;
    }
    public void setUoUser(String uoUser) {
        this.uoUser = uoUser;
    }
    public int getUserID() {
        return userID;
    }
    public void setUserID(int userID) {
        this.userID = userID;
    }
    
    
    
    
    
    

}
