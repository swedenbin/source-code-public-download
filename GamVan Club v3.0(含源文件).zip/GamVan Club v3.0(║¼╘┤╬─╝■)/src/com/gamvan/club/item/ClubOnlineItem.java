/*
 * Created on 2005-8-19
 * Last modified on 2005-9-19
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

public class ClubOnlineItem  implements java.io.Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    protected int olID = 0;
    protected String sessionID = new String();
    protected String userName = new String();
    protected String userip = new String();
    protected String userArea = new String();
    protected String loginTime = new String("");
    protected String lastTime = new String();
    protected long lastYMDHMS = 0; //最后刷新时间，年月日时分秒组成的数字
    protected boolean userHide = false;
    protected int onUserID = 0;
    
    public String getLastTime() {
        return lastTime;
    }
    public void setLastTime(String lastTime) {
        this.lastTime = lastTime;
    }
    public String getLoginTime() {
        return loginTime;
    }
    public void setLoginTime(String loginTime) {
        this.loginTime = loginTime;
    }
    public int getOlID() {
        return olID;
    }
    public void setOlID(int olID) {
        this.olID = olID;
    }

    public int getOnUserID() {
        return onUserID;
    }
    public void setOnUserID(int onUserID) {
        this.onUserID = onUserID;
    }

    public String getSessionID() {
        return sessionID;
    }
    public void setSessionID(String sessionID) {
        this.sessionID = sessionID;
    }
    public String getUserArea() {
        return userArea;
    }
    public void setUserArea(String userArea) {
        this.userArea = userArea;
    }
    public boolean getUserHide() {
        return userHide;
    }
    public void setUserHide(boolean userHide) {
        this.userHide = userHide;
    }
    public String getUserip() {
        return userip;
    }
    public void setUserip(String userip) {
        this.userip = userip;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
	public long getLastYMDHMS() {
		return lastYMDHMS;
	}
	public void setLastYMDHMS(long lastYMDHMS) {
		this.lastYMDHMS = lastYMDHMS;
	}
}
