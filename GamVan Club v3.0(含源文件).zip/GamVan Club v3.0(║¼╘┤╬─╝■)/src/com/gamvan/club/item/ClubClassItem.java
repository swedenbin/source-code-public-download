/*
 * Created on 2005-7-1
 * Last modified on 2005-7-1
 * Powered by GamVan.com
 */
package com.gamvan.club.item;

public class ClubClassItem implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    protected int ccID = 0;
    protected int ccIDD; //分类或版面的上级ID
    protected String ccName=""; //分类或版面名称
    protected int ccOrder = 0; //分类或版面的排序ID 
    protected byte ccType = 0; //类型，判断是分类还是版面 0为分类 1为版面
    protected byte ccStyle = 0; //论坛的风格 0 为默认风格BBS， 1 为讨论区风格
    protected byte ccPro = 0; //分类或版面的属性
    protected boolean ccHidden = false; //是否隐藏 默认0不隐藏
    protected byte ccUpfilePass = 0; //判断是否打开了上传
    protected int ccUpfileMax = 0; //上传附件的最大限制，单位字节
    protected byte ccUgid = 10; //浏览版面所需的等级
    protected byte ccTopicNum = 30; //主题显示条数
    protected byte ccReplyNum = 100; //回复显示数
    protected int ccMostOnline = 0; //最多在线人数
    protected String ccSummary = ""; //分类或版面简介
    protected String ccUserPass = ""; //分类或版面的认证用户
    protected int ccTopic = 0; //主题统计
    protected int ccReply = 0; //回复统计
    protected boolean ccList = false;
    protected int ccTodayTopic = 0; //今日主题统计
    protected int ccTodayReply = 0; //今日回复统计
    protected int ccYesterTopic = 0; //昨日主题统计
    protected int ccYesterReply = 0; //昨日回复统计
    
    
    
    public boolean getCcHidden() {
        return ccHidden;
    }
    public void setCcHidden(boolean ccHidden) {
        this.ccHidden = ccHidden;
    }
    public int getCcID() {
        return ccID;
    }
    public void setCcID(int ccID) {
        this.ccID = ccID;
    }
    public int getCcIDD() {
        return ccIDD;
    }
    public void setCcIDD(int ccIDD) {
        this.ccIDD = ccIDD;
    }
    public boolean getCcList() {
        return ccList;
    }
    public void setCcList(boolean ccList) {
        this.ccList = ccList;
    }
    public int getCcMostOnline() {
        return ccMostOnline;
    }
    public void setCcMostOnline(int ccMostOnline) {
        this.ccMostOnline = ccMostOnline;
    }
    public String getCcName() {
        return ccName;
    }
    public void setCcName(String ccName) {
        this.ccName = ccName;
    }
    public int getCcOrder() {
        return ccOrder;
    }
    public void setCcOrder(int ccOrder) {
        this.ccOrder = ccOrder;
    }
    public byte getCcPro() {
        return ccPro;
    }
    public void setCcPro(byte ccPro) {
        this.ccPro = ccPro;
    }
    public int getCcReply() {
        return ccReply;
    }
    public void setCcReply(int ccReply) {
        this.ccReply = ccReply;
    }
    public byte getCcReplyNum() {
        return ccReplyNum;
    }
    public void setCcReplyNum(byte ccReplyNum) {
        this.ccReplyNum = ccReplyNum;
    }
    public byte getCcStyle() {
        return ccStyle;
    }
    public void setCcStyle(byte ccStyle) {
        this.ccStyle = ccStyle;
    }
    public String getCcSummary() {
        return ccSummary;
    }
    public void setCcSummary(String ccSummary) {
        this.ccSummary = ccSummary;
    }
    public int getCcTodayReply() {
        return ccTodayReply;
    }
    public void setCcTodayReply(int ccTodayReply) {
        this.ccTodayReply = ccTodayReply;
    }
    public int getCcTodayTopic() {
        return ccTodayTopic;
    }
    public void setCcTodayTopic(int ccTodayTopic) {
        this.ccTodayTopic = ccTodayTopic;
    }
    public int getCcTopic() {
        return ccTopic;
    }
    public void setCcTopic(int ccTopic) {
        this.ccTopic = ccTopic;
    }
    public byte getCcTopicNum() {
        return ccTopicNum;
    }
    public void setCcTopicNum(byte ccTopicNum) {
        this.ccTopicNum = ccTopicNum;
    }
    public byte getCcType() {
        return ccType;
    }
    public void setCcType(byte ccType) {
        this.ccType = ccType;
    }
    public byte getCcUgid() {
        return ccUgid;
    }
    public void setCcUgid(byte ccUgid) {
        this.ccUgid = ccUgid;
    }
    public int getCcUpfileMax() {
        return ccUpfileMax;
    }
    public void setCcUpfileMax(int ccUpfileMax) {
        this.ccUpfileMax = ccUpfileMax;
    }
    public byte getCcUpfilePass() {
        return ccUpfilePass;
    }
    public void setCcUpfilePass(byte ccUpfilePass) {
        this.ccUpfilePass = ccUpfilePass;
    }
    public String getCcUserPass() {
        return ccUserPass;
    }
    public void setCcUserPass(String ccUserPass) {
        this.ccUserPass = ccUserPass;
    }
    public int getCcYesterReply() {
        return ccYesterReply;
    }
    public void setCcYesterReply(int ccYesterReply) {
        this.ccYesterReply = ccYesterReply;
    }
    public int getCcYesterTopic() {
        return ccYesterTopic;
    }
    public void setCcYesterTopic(int ccYesterTopic) {
        this.ccYesterTopic = ccYesterTopic;
    }
   
     
}
