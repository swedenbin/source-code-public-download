/*
 * Created on 2006-1-10
 * Last modified on 2006-1-10
 * Powered by GamVan.com
 */
package com.gamvan.club.file;


public class ClubPageCfgItem {
	
	protected String pageRealPath = "";
	protected int pageMaxTopicID = 0;
	protected String pageFilePath = "\\club\\html";
	protected String pageFileExt = "html";
	
	protected int intervalHour_home = 3; //3小时更新一次首页, -2为不执行
	protected int intervalHour_list = 10; //10小时更新版面索引页 -2为不执行
	protected int intervalHour_page = 3; //3小时更新将最新帖子生成静态页 -2为不执行
	
	/**
	 * 相隔几小时启动定时器
	 * -1 每天启动
	 */
	protected int pageIntervalHour = -1; 
	
	/**
	 * 定时器每天的几点开始工作
	 */
	protected int pageScheduleHour = 0;
	
	
	public int getIntervalHour_home() {
		return intervalHour_home;
	}
	public void setIntervalHour_home(int intervalHour_home) {
		this.intervalHour_home = intervalHour_home;
	}
	public int getIntervalHour_list() {
		return intervalHour_list;
	}
	public void setIntervalHour_list(int intervalHour_list) {
		this.intervalHour_list = intervalHour_list;
	}
	public int getIntervalHour_page() {
		return intervalHour_page;
	}
	public void setIntervalHour_page(int intervalHour_page) {
		this.intervalHour_page = intervalHour_page;
	}
	public int getPageIntervalHour() {
		return pageIntervalHour;
	}
	public void setPageIntervalHour(int pageIntervalHour) {
		this.pageIntervalHour = pageIntervalHour;
	}
	public int getPageScheduleHour() {
		return pageScheduleHour;
	}
	public void setPageScheduleHour(int pageScheduleHour) {
		this.pageScheduleHour = pageScheduleHour;
	}
	public String getPageFileExt() {
		return pageFileExt;
	}
	public void setPageFileExt(String pageFileExt) {
		this.pageFileExt = pageFileExt;
	}
	public String getPageFilePath() {
		return pageFilePath;
	}
	public void setPageFilePath(String pageFilePath) {
		this.pageFilePath = pageFilePath;
	}
	public int getPageMaxTopicID() {
		return pageMaxTopicID;
	}
	public void setPageMaxTopicID(int pageMaxTopicID) {
		this.pageMaxTopicID = pageMaxTopicID;
	}
	public String getPageRealPath() {
		return pageRealPath;
	}
	public void setPageRealPath(String pageRealPath) {
		this.pageRealPath = pageRealPath;
	}
}
