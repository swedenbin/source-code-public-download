/*
 * Created on 2005-9-28
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.file;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.item.ClubSafeFileItem;
import com.gamvan.conn.ConnClub;
import com.gamvan.tools.FileOperate;
import com.gamvan.tools.FormatDateTime;
import com.gamvan.tools.TypeChange;

public class ClubSafeFileEdit extends ClubSafeFileItem{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String message = "";
    //格式化当前时间
    private String now= FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    
    public void safeFileDo(String act){
        fileNameAndPath = TypeChange.nullOfString(fileNameAndPath);
        fileNameAndPath = com.gamvan.net.URL.urlEncoder(fileNameAndPath,"UTF-8");
        fileExt = FileOperate.getFileExt(fileNameAndPath);
        if(fileNameAndPath.equals("")){
            message = "文件地址不能为空！";
            return;
        }
        
        if(fileExt.equals("")){
            message = "参数错误！操作被终止！";
            return;
        }
        
        if(act.equals("add")){
            safeFileAdd();
        }
        else if(act.equals("edit")){
            safeFileUpdate();
        }
        else{
            message = "参数不全操作将不被执行！";
            return; 
        }
    }
    
    
    public void safeFileAdd(){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        try{
            ClubSafeFileItem csfi = new ClubSafeFileItem();
            csfi.setFileNameAndPath(fileNameAndPath);
            csfi.setFileExt(fileExt);
            csfi.setFileDateTime(now);
            csfi.setFileByUser(fileByUser);
            csfi.setFileByUserID(fileByUserID);
            csfi.setFileByUserIp(fileByUserIp);
            csfi.setFileFrom(fileFrom);
            csfi.setFileIsOpen(fileIsOpen);
            session.save(csfi);
            tran.commit();
            session.clear();
            message = "文件添加成功！";
        }catch(HibernateException e){
            message = "文件添加成功！<br/>";
            message += e.toString();
            e.printStackTrace();
        }finally{
            ConnClub.closeSession();
        }
    }
    
    
    public void safeFileUpdate(){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubSafeFileItem set fileNameAndPath=?");
            hql.append(", fileExt=?");
            hql.append(", fileFrom=?");
            hql.append(", fileIsOpen=?");
            hql.append(" where fileID = ?");
            Query query = session.createQuery(hql.toString())
            .setString(0, fileNameAndPath)
            .setString(1, fileExt)
            .setString(2, fileFrom)
            .setBoolean(3, fileIsOpen)
            .setInteger(4, fileID)           
            ;
            query.executeUpdate();
            tran.commit();
            message = "文件更新成功！";
        }catch(HibernateException e){
            message = "文件更新成功！<br/>";
            message += e.toString();
        }     
    }
    
    
    /**
     * 单独更新文件开关
     *
     */
    public void updateIsOpen(){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubSafeFileItem set fileIsOpen=?");
            hql.append(" where fileID = ?");
            Query query = session.createQuery(hql.toString())
            .setBoolean(0, fileIsOpen)
            .setInteger(1, fileID)           
            ;
            query.executeUpdate();
            tran.commit();
            message = "文件更新成功！";
        }catch(HibernateException e){
            message = "文件更新成功！<br/>";
            message += e.toString();
        }       
    }
    
    
    /**
     * 实现单独删除为批量删除作准备
     * @param session
     * @param tran
     */
    public void safeFileDel(Session session,Transaction tran){
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("delete from ClubSafeFileItem where fileID = ?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, fileID)           
            ;
            query.executeUpdate();
            tran.commit();
            message = "文件删除成功！";
        }catch(HibernateException e){
            message = "文件删除成功！<br/>";
            message += e.toString();
        }
    }
    
    public void safeFilesDel(String fileids[]){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        int i = 0;
        if(fileids!=null){
            for(i=0; i<fileids.length; i++){
                fileID = TypeChange.stringToInt(fileids[i]);
                safeFileDel(session, tran);
            }
        }
        message = i + " 个文件被删除。";
    }
    
    
    
    public static void main (String args[]){
        ClubSafeFileEdit csfe = new ClubSafeFileEdit();
        csfe.setFileNameAndPath("httpom/sf/3.gif");
        csfe.safeFileDo("edit");
        System.out.println(csfe.getFileExt());     
        System.out.println(csfe.getMessage());    
        
    }
    
    public String getMessage() {
        return message;
    }

}
