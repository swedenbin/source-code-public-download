/*
 * Created on 2005-9-28
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.file;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;


import com.gamvan.club.item.ClubSafeFileItem;
import com.gamvan.conn.ConnClub;

public class ClubSafeFileCollection  extends ClubSafeFileItem{
    private String message = "";
    private static final long serialVersionUID = 1L;
    public ClubSafeFileItem safeFileInfo(){
        ClubSafeFileItem csfi = null;
        Session session = ConnClub.getSession();
        try{
            StringBuffer hql = new StringBuffer();
            hql.append("from ClubSafeFileItem ");

            hql.append(" where fileID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, fileID)
            ;
            List list = query.list();
            Iterator it = list.iterator();
            if(it.hasNext()){
                csfi = (ClubSafeFileItem)it.next();
            }else{
                csfi = null;
            }
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return csfi;
    }
    
   
    public List safeFileList(){
        List list = null;
        Session session = ConnClub.getSession();
        try{
            StringBuffer hql = new StringBuffer();
            hql.append("from ClubSafeFileItem ");

            hql.append(" order by fileID desc");
            Query query = session.createQuery(hql.toString())
            
            ;
            list = query.list();
            
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return list;
    }

    public int safeFileCount(){
        //计算从第几条记录开始读取数据   
        int i = 0;
        StringBuffer hql = new StringBuffer();
        Session session = ConnClub.getSession();
        try{
            hql.append("select count(*) from ClubSafeFileItem ");

            
            Query query = session.createQuery(hql.toString());
            Iterator iterate = query.iterate();
            Integer results = null;
            while(iterate.hasNext()){
                 results = (Integer) iterate.next();
                 i = results.intValue();
            }
         }catch(HibernateException e){
             e.printStackTrace();
         }
       return i;
    }
        
    public String getMessage() {
        return message;
    }

}
