/*
 * Created on 2006-1-11
 * Last modified on 2006-1-26
 * Powered by GamVan.com
 */
package com.gamvan.club.file;

import com.gamvan.tools.TypeChange;
import com.gamvan.tools.XmlOperate;

public class ClubPageCfg extends ClubPageCfgItem{
	
	private static String sep = java.io.File.separator;
	
	private XmlOperate xo ;
	public ClubPageCfg(String realpath){
		this.pageRealPath = realpath;
		getCfg();
	}
	
	public void pageCfg(){
		StringBuffer xmlpath = new StringBuffer();
		xmlpath.append(this.pageRealPath);
		xmlpath.append(sep);
		xmlpath.append(sep);
		xmlpath.append("WEB-INF");
		xmlpath.append(sep);
		xmlpath.append(sep);
		xmlpath.append("classes");
		xmlpath.append(sep);
		xmlpath.append(sep);
		xmlpath.append("gamvanclub.cfg.xml");
		xo = new XmlOperate(xmlpath.toString());
	}
	
	public void getCfg(){
		pageCfg();
		this.pageMaxTopicID = 
			TypeChange.stringToInt(
					xo.getChildText(
							xo.getElement("club-page"),"pageMaxTopicID")
							);
		this.pageFilePath = 
			xo.getChildText(
					xo.getElement("club-page"),"pageFilePath");
		
		this.pageFileExt = 
			xo.getChildText(
					xo.getElement("club-page"),"pageFileExt");
		
		this.pageMaxTopicID = 
			TypeChange.stringToInt(
					xo.getChildText(
							xo.getElement("club-page"),"pageMaxTopicID")
							);
		
		this.pageScheduleHour = 
			TypeChange.stringToInt(
					xo.getChildText(
							xo.getElement("club-page"),"pageScheduleHour")
							);
		
		this.intervalHour_home = 
			TypeChange.stringToInt(
					xo.getChildText(
							xo.getElement("club-page"),"intervalHour_home")
							);
		this.intervalHour_list = 
			TypeChange.stringToInt(
					xo.getChildText(
							xo.getElement("club-page"),"intervalHour_list")
							);
		this.intervalHour_page = 
			TypeChange.stringToInt(
					xo.getChildText(
							xo.getElement("club-page"),"intervalHour_page")
							);
		
	}

	public XmlOperate getXo() {
		return xo;
	}

	public void setXo(XmlOperate xo) {
		this.xo = xo;
	}
	
	public void updateInfo(String type, String s){
		xo.setChildText(xo.getElement("club-page"), type, s);
	}
	

}
