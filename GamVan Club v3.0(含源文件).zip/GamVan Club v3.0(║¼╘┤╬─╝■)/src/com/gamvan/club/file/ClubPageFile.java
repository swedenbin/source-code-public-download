/*
 * Created on 2006-1-9
 * Last modified on 2006-1-23
 * Powered by GamVan.com
 */
package com.gamvan.club.file;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.gamvan.club.ClubHtmlConst;
import com.gamvan.club.classed.ClubClassInfo;
import com.gamvan.club.classed.ClubClassResults;
import com.gamvan.club.item.ClubClassItem;
import com.gamvan.club.item.ClubContentItem;
import com.gamvan.club.item.ClubTopicItem;
import com.gamvan.club.topic.ClubContentResults;
import com.gamvan.club.topic.ClubTopicResults;
import com.gamvan.html.OutPrint;
import com.gamvan.tools.FileOperate;

public class ClubPageFile extends ClubPageCfgItem{
	
	private static final long serialVersionUID = 1L;
	
	private String sep = java.io.File.separator;
	
	private String template_page = "template_page.html";
	
	private ClubPageTemplate cptl = new ClubPageTemplate();
	
	private int maxTopicID = 0; //记录本次启动的最小开始主题ID
	private int maxTopicID2 = -1;
	
	private static ClubClassResults cclr = new ClubClassResults();

	private static FileOperate fo = new FileOperate();
	private ClubPageCfg cpc;
	
	private static final Logger logger = 
		Logger.getLogger(ClubPageFile.class.getName());
	
	private String pageArea(String path, String fileext
			, int ccid, int ccid1, int ccid2
			,String ccname, String ccname1, String ccname2
			, int ccidd, int ccidd1)
	{
		StringBuffer sb = new StringBuffer();
		sb.append(ClubHtmlConst.gamvan_menu("/club/",ClubHtmlConst.gamvan_classMenu(
				path, fileext, ccid, ccid1, ccid2
				, ccname, ccname1, ccname2
				, ccidd, ccidd1)));
		return sb.toString();
	}
	
	public ClubPageFile(){
		
	}
	
	public ClubPageCfg getCpc() {
		return cpc;
	}

	/**
	 * 初始化静态文件的扩展名已经生成的位置
	 * @param realpath 网站绝对路径
	 */
	public ClubPageFile(String realpath){
		cpc = new ClubPageCfg(realpath);
		this.pageFileExt = cpc.getPageFileExt(); //静态文件扩展名
		this.pageFilePath = cpc.getPageFilePath();//静态文件生成的相对根目录
		this.pageMaxTopicID = cpc.getPageMaxTopicID();
		this.pageRealPath = realpath; //社区首页生成目录
		this.pageFilePath = this.pageFilePath + sep;
		logger.info("读入基本信息：");
		logger.info(String.valueOf(this.pageMaxTopicID));
		logger.info(this.pageRealPath);
		logger.info(this.pageFilePath);
	}
	
	/**
	 * 创建首页
	 * @author GamVan Studio by 我容易么我
	 */
	public void createPage_home(){
		this.template_page="template_home.html";
		/** 读取文章显示页模版 */
		String template = 
			cptl.readTemplate(this.pageFilePath, this.template_page);
		template = cptl.analysisTemplate_topic(template);
		/** 替换完毕写入静态文件 */
		template = template.replace("###@","$");
		try {
			fo.createFile(this.pageRealPath+sep+"index.html", template, "UTF-8");
		} catch (Exception e) {
			logger.error("创建首页出错："+e.toString());
		}
	}
	
	/**
	 * 按给定条件取出主题集合
	 * @param ccid 版面ID
	 * @param totalrows 总行数
	 * @param tpro 主题的属性 1为精品
	 * @param ttype 主题的类型 3为最新提问 5为最新结贴
	 * @return
	 * @author GamVan Studio by 我容易么我
	 */
	public List classTopicList(int ccid, int totalrows
			, short ttype, short tpro)
	{
		ClubTopicResults ctr = new ClubTopicResults();
		ctr.setMaxTopicID(0);
		ctr.setCcID(ccid);
		ctr.setTopicReID(-1); //按照文章发表先后顺序倒序排列
		ctr.setTopicType(ttype);
		ctr.setTopicPro(tpro);
		List list = ctr.topicList(1, totalrows);
		return list;
	}
	
	
	/**
	 * 创建社区分类索引页静态文件
	 * @author GamVan Studio by 我容易么我
	 */
	public void createPage_classlist(){
		ClubClassItem cci = null;
		cclr.setCcID(3);
		List list = cclr.classAllList();
		//logger.info("共有 "+list.size()+" 个版面将会被更新！");
		for(int i=0; i<list.size();i++){
			cci = (ClubClassItem)list.get(i);
			//logger.info("版面：" + cci.getCcName());
			createPage_class(cci);
		}
		//logger.info("共有 "+list.size()+" 个版面被更新！");
	}
	
	/**
	 * 根据ClubClassItem对象生成这个
	 * @param cci
	 * @author GamVan Studio by 我容易么我
	 */
	public void createPage_class(ClubClassItem cci){
		ClubTopicResults ctr = new ClubTopicResults();
		ClubClassInfo ccio = new ClubClassInfo();
		int ccid=0, ccid1=0, ccid2=0, ccidd=0, ccidd1=0;
		String ccname="", ccname1="", ccname2="";
		ccid = cci.getCcID();
		ccidd = cci.getCcIDD();
		ccname = cci.getCcName();
		/** 如果版面属性为开发的或是主题的则继续执行，否则继续循环下一个版面 */
		if(cci.getCcPro()<2 && !cci.getCcHidden()
				&& cci.getCcUgid()==10
		){
			if(ccidd>0){//如果存在上级版面
				ccio.setCcID(ccidd);
				ClubClassItem cci1=ccio.getClubClassInfo();
				ccname1 = cci1.getCcName();
				ccid1 = ccidd;
				ccidd1 = cci1.getCcIDD();
				if(ccidd1>0){//如果存在上级版面
					ccio.setCcID(ccidd1);
					ClubClassItem cci2=ccio.getClubClassInfo();
					ccname2 = cci2.getCcName();
					ccid2 = ccidd1;
				}
			}
			//System.out.println(cci.getCcSummary());
			cptl.setCcID(ccid);
			cptl.setCcID1(ccid1);
			cptl.setCcID2(ccid2);
			cptl.setClassSummary(cci.getCcSummary());
			cptl.setClassName(ccname);
			cptl.setPageArea(pageArea("", this.pageFileExt
					,ccid ,ccid1, ccid2
					,ccname, ccname1, ccname2
					,ccidd, ccidd1)+"文章列表");
			
			/** 开始创建文件 */
			/** 读取文章显示页模版 */
			this.template_page = "template_class.html";
			String template = cptl.readTemplate(this.pageFilePath, this.template_page);
			/** 提取本版主题集合，生成版面文章索引页*/
			ctr.setCcID(ccid);
			ctr.setTopicReID(-1); //按照文章发表先后顺序倒序排列
			ctr.setTopicID(0);
			int totalrows = ctr.topicCount(); //文章总行数
			int totalpage = 0; //本版可分页数
			int pagenum = 50; //每页显示的行数
			if(totalrows%pagenum!=0){
				totalpage = totalrows/pagenum + 1;
		    }else{
		    	totalpage = totalrows/pagenum;
		    }
			if(totalpage<1)totalpage=1;
			for(int i=0; i<totalpage; i++){
				List list = ctr.topicList(i+1, pagenum);
				createPage_class(template, ccid, list, totalrows, i+1, pagenum);
			}
		}
	}
	
	/**
	 * 根据传入的文章主题集合生成版面文章索引页
	 * @param temp 模版文件
	 * @param topiclist 
	 * @param totalrows 总行数
	 * @param page 当前页
	 * @param pagenum 没页显示行数
	 * 2006-1-11 21:27:43 made in GamVan
	 */
	public void createPage_class(String temp, int ccid, List topiclist, int totalrows
			,  int page, int pagenum)
	{
		/**
		 * 得到分页标签
		 */
		cptl.setPageJump_class(OutPrint.pageJump(totalrows, page, pagenum
			, String.valueOf(ccid), this.pageFileExt));
		
		String template = 
			cptl.analysisTemplate_loop_topic(temp, topiclist, null);

		/** 替换完毕写入静态文件 */
		StringBuffer pagefilename = new StringBuffer();
		pagefilename.append(fo.createFolder(this.pageFilePath+"class")+sep);
		pagefilename.append(sep);
		if(page>1){
			pagefilename.append(ccid);
			pagefilename.append("_");
			pagefilename.append(page);
		}else{
			pagefilename.append(ccid);
		}
		pagefilename.append(".");
		pagefilename.append(this.pageFileExt);
		try {
			fo.createFile(pagefilename.toString(), template, "UTF-8");
		} catch (Exception e) {
			logger.error("创建版面出错："+e.toString());
		}
	}
	
	
	
	/**
	 * 创建文章内容页
	 * 2006-1-11 4:01:09 made in GamVan
	 */
	public void createPage_topic(){
		this.template_page = "template_page.html";
		if(this.pageMaxTopicID-50>0){
			this.pageMaxTopicID = this.pageMaxTopicID-50;
		}
		if(this.maxTopicID2!=-1){
			this.pageMaxTopicID = this.maxTopicID2;
		}
		logger.info("this.maxTopicID2:"+String.valueOf(this.maxTopicID2));
		topicList(0, this.pageMaxTopicID, 1, 0, 1, 1);
		cpc.updateInfo("pageMaxTopicID",String.valueOf(this.maxTopicID));
	}
	
	/**
	 * 循环文章生成文件
	 * @param ccid
	 * @param maxtopicid 如果等于0则全部重新生成，否则只生成ID大于此数值的文章
	 * @param page
	 * @param pagenum
	 * @param c 是否取内容
	 * @param r 是否取回复
	 * 2006-1-11 19:36:27 made in GamVan
	 */
	protected void topicList(int ccid, int maxtopicid, int page, int pagenum
			, int c,  int r)
	{
		 ClubTopicResults ctr = new ClubTopicResults();
		/** 读取文章显示页模版 */
		String template = cptl.readTemplate(this.pageFilePath, this.template_page);
		ctr.setMaxTopicID(maxtopicid);
		ctr.setCcID(ccid);
		ctr.setTopicReID(-1); //按照文章发表先后顺序倒序排列
		if(pagenum<1){
			pagenum = ctr.topicCount();
		}
		if(pagenum<1){
			return;
		}
		
		//logger.info("文章页生成开始，起始ID：" + maxtopicid);
		//logger.info("共读入文章：" + pagenum + "篇");
		List list = ctr.topicList(page, pagenum);
		//logger.info("共读入文章：" + list.size() + "篇");
		Iterator it = list.iterator();
		ClubTopicItem cti = null;
		ClubContentItem cci = null;
		ClubContentResults ccr = new ClubContentResults();
		ClubClassInfo ccio = new ClubClassInfo();
		ClubClassItem classitem;
		String content = "";
		boolean contentUrl = false;
		boolean contentImg = false;
		String template2 = "";
		
		while(it.hasNext()){
			StringBuffer pagefilename = new StringBuffer();
			cti = (ClubTopicItem)it.next();
			if(this.maxTopicID<cti.getTopicID()){
				this.maxTopicID = cti.getTopicID();
			}
			if(c==1){//判断是否取内容
				ccr.setTopicID(cti.getTopicID());
				cci = ccr.contentInfo();
				if(cci!=null){
					content = cci.getContent();
					contentUrl = cci.getContentUrl();
					contentImg = cci.getContentImg();
				}else{
					content = "";
				}
			}
			
			/** 配置出生成的文件名已经路径 */
			pagefilename.append(pageFolder(cti.getCcID(), cti.getTopicAddTime()));
			pagefilename.append(cti.getTopicID());
			pagefilename.append(".");
			pagefilename.append(this.pageFileExt);
			
			/** 提取文章版面信息 */
			ccio.setCcID(cti.getCcID());
			classitem = ccio.getClubClassInfo();
			if(classitem!=null){
				int ccid1=0, ccid2=0, ccidd=0, ccidd1=0;
				String ccname="", ccname1="", ccname2="";
				ccid = classitem.getCcID();
				ccidd = classitem.getCcIDD();
				ccname = classitem.getCcName();
				/** 如果版面属性为开发的或是主题的则继续执行，否则继续循环下一个版面 */
				if(classitem.getCcPro()<2 && !classitem.getCcHidden()
						&& classitem.getCcUgid()==10
				){
					if(ccidd>0){//如果存在上级版面
						ccio.setCcID(ccidd);
						ClubClassItem cci1=ccio.getClubClassInfo();
						ccname1 = cci1.getCcName();
						ccid1 = ccidd;
						ccidd1 = cci1.getCcIDD();
						if(ccidd1>0){//如果存在上级版面
							ccio.setCcID(ccidd1);
							ClubClassItem cci2=ccio.getClubClassInfo();
							ccname2 = cci2.getCcName();
							ccid2 = ccidd1;
						}
					}
					cptl.setPageArea(pageArea("../class/", this.pageFileExt
							,ccid ,ccid1, ccid2
							,ccname, ccname1, ccname2
							,ccidd, ccidd1));
					if(r==1){ //判断是否取回复
						/** 先替换文章回复标签 */
						template2 = topicList_re(template, cti.getTopicID(), 1, 100);
					}
					cptl.setCcID1(ccid1);
					cptl.setCcID2(ccid2);
					cptl.setCcID(cti.getCcID());
					cptl.setUserID(cti.getUserID());
					cptl.setUserName(cti.getUserName());
					cptl.setTopicID(cti.getTopicID());
					cptl.setTopicAddTime(cti.getTopicAddTime());
					cptl.setTopic(cti.getTopic());
					cptl.setTopicPro(cti.getTopicPro());
					cptl.setTopicType(cti.getTopicType());
					cptl.setTopicTypeNum(cti.getTopicTypeNum());
					
					cptl.setContent(content);
					cptl.setContentImg(contentImg);
					cptl.setContentUrl(contentUrl);
	
					/** 执行文章主题内容标签替换 */
					String temp = cptl.analysisTemplate_view(template2, null);
					/** 替换完毕写入静态文件 */
					 temp = temp.replace("###@","$");
					try {
						fo.createFile(pagefilename.toString(), temp, "UTF-8");
					} catch (Exception e) {
						logger.error("创建文章页出错："+e.toString());
					}
					/** 清理路径已经文件名已备循环使用 */
					//logger.info(pagefilename);
					pagefilename= null;
					//logger.info(fo.getMessage()+String.valueOf(cti.getTopicID())+cti.getTopic());
				}
			}
		}
		logger.info("文章页生成结束，结束ID："+this.maxTopicID);
	}
	
	protected String topicList_re(String template, int topicid,  int page, int pagenum)
	{
		ClubTopicResults ctr = new ClubTopicResults();
		String s = template;
		ctr.setTopicID(topicid);
		try{
			List tlist = ctr.topicReList(page, pagenum);
			List clist = ctr.contentReList(page, pagenum);
			s = cptl.analysisTemplate_loop_topic(template, tlist, clist);
			//System.out.println(s);
			tlist = null;
			clist = null;
		}catch(Exception e){
			logger.error(e.toString());
		}
		return s;
	}

	
	private String pageFolder(int ccid, String addtime)
	{
		addtime = addtime.substring(0, 7);
		addtime = addtime.replaceAll("-","");
		String s = fo.createFolder(this.pageFilePath+addtime)+sep;
		return s;
	}

	public int getMaxTopicID2() {
		return maxTopicID2;
	}

	public void setMaxTopicID2(int maxTopicID2) {
		this.maxTopicID2 = maxTopicID2;
	}
	
	
	/* test
	public static void main(String args[]){
		com.gamvan.conn.ConnClub.init();
		ClubPageFile cpf = new ClubPageFile("E:\\MYJAVA\\myWeb");
		//cpf.createPage_topic();
		//System.out.println(cpf.getPageFilePath());
		cpf.createPage_classlist();
		//cpf.createPage_home();
		com.gamvan.conn.ConnClub.closeSession2();
	}
	*/	
}



