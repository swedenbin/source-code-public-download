/*
 * Created on 2006-1-16
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.file;

import java.util.List;

import org.apache.log4j.Logger;

import com.gamvan.club.ClubStringReplaces;
import com.gamvan.club.item.ClubContentItem;
import com.gamvan.club.item.ClubContentReItem;
import com.gamvan.club.item.ClubTopicItem;
import com.gamvan.club.item.ClubTopicReItem;
import com.gamvan.club.topic.ClubTopicType;
import com.gamvan.tools.EncodeString;
import com.gamvan.tools.FileOperate;
import com.gamvan.tools.TypeChange;

public class ClubPageTemplate extends ClubPageItem{

	private static final long serialVersionUID = 1L;
	private StringBuffer sb = new StringBuffer();
	private ClubTopicType ctt = new ClubTopicType();
	private ClubStringReplaces csrs = new ClubStringReplaces();
	private EncodeString es = new EncodeString();
	
	private static final Logger logger = 
		Logger.getLogger(ClubPageTemplate.class.getName());
				
				
	public ClubPageTemplate(){

	}

	/**
	 * 读取模版文件
	 * @param filepath
	 * @param filename
	 * @return
	 * com.gamvan.club.file
	 */
	protected String readTemplate(String filepath, String filename)
	{	
		FileOperate fo = new FileOperate();
		return fo.readTxt(filepath+filename, "UTF-8");
	}
	
	/**
	 * 创建首页
	 * @param template
	 * @return
	 * com.gamvan.club.file
	 */
	public String analysisTemplate_topic(String template){
		template = template.replaceAll("\n","##n");
		template = template.replaceAll("\r","##r");
		/** 开始分析模版文件循环标签 */
		String cp = "<gv:forEach(\\p{Blank}*?)id=\"([\\d]*)\"(\\p{Blank}*?)" +
				"rows=\"([\\d]*)\"(\\p{Blank}*?)var=\"(.*?)\"" +
				"(\\p{Blank}*?)>(.*?)<\\/gv:forEach>";
		List list = EncodeString.matcherList(template, cp);
		//System.out.println(list);
		for(int i=0; i<list.size(); i++){ //取出所有循环标签
			String s = TypeChange.objOfString(list.get(i));
			s = s.replace("[","").replace("]","");
			
			//取出循环标签指定的版面ID
			int id = TypeChange.stringToShort(EncodeString.ubbPattern(s,cp,"$2")
					.replace("[","").replace("]",""));
			//取出指定显示的行数
			int rows = TypeChange.stringToInt(EncodeString.ubbPattern(s,cp,"$4")
					.replace("[","").replace("]",""));
			if(rows>1){	
				//根据版面ID取内容
				ClubPageFile cpf = new ClubPageFile();
				List topiclist = cpf.classTopicList(id, rows, (short)0, (short)0);
				/** 执行替换开始 */
				String ss = analysisTemplate_loop(list, cp, "$8", s, topiclist, null);
				template = template.replaceAll(s,ss);
			}	
		}
				
		/** 开始分析模版文件 高级循环标签 */
		cp = "<gv:forEach(\\p{Blank}*?)id=\"([\\d]*)\"(\\p{Blank}*?)" +
				"rows=\"([\\d]*)\"(\\p{Blank}*?)" +
				"type=\"([\\d]*)\"(\\p{Blank}*?)" +
				"pro=\"([\\d]*)\"(\\p{Blank}*?)" +
				"var=\"(.*?)\"(\\p{Blank}*?)>" +
				"(.*?)<\\/gv:forEach>";
		list = EncodeString.matcherList(template, cp);
		for(int i=0; i<list.size(); i++){ //取出所有循环标签
			String s = TypeChange.objOfString(list.get(i));
			s = s.replace("[","").replace("]","");
			//取出循环标签指定的版面ID
			int id = TypeChange.stringToInt(EncodeString.ubbPattern(s,cp,"$2")
					.replace("[","").replace("]",""));
			//取出指定显示的行数
			int rows = TypeChange.stringToInt(EncodeString.ubbPattern(s,cp,"$4")
					.replace("[","").replace("]",""));
			//取出指定的主题型别
			short type = TypeChange.stringToShort(EncodeString.ubbPattern(s,cp,"$6")
					.replace("[","").replace("]",""));
			//取出指定主题属性
			short pro = TypeChange.stringToShort(EncodeString.ubbPattern(s,cp,"$8")
					.replace("[","").replace("]",""));
			if(rows>1){	
				//根据版面ID取内容
				ClubPageFile cpf = new ClubPageFile();
				List topiclist = cpf.classTopicList(id, rows, type, pro);
				
				/** 执行替换开始 */
				String ss = analysisTemplate_loop(list, cp, "$12", s, topiclist, null);
				template = template.replaceAll(s, ss);
			}	
		}
		template = template.replaceAll("##n","\n");
		template = template.replaceAll("##r","\r");
		return template;
	}
	
	/**
	 * 替换文章显示页内容
	 * @param template
	 * @param cpi
	 * @return
	 * com.gamvan.club.file
	 */
	public String analysisTemplate_view(String template, ClubPageItem cpi){
		template = template.replaceAll("\n","##n");
		template = template.replaceAll("\r","##r");
		template = template.replace("$","###@");
		template = templatePublic(template);
		//String cp = EncodeString.matcherStr(str, "<gv:view>(.*?)<\\/gv:view>", "");
		List list = EncodeString.matcherList(template,"<gv:view>(.*?)<\\/gv:view>");
		String s1, s2;
		for(int i=0; i<list.size(); i++){
			s1 = TypeChange.objOfString(list.get(i));
			s2 = analysisTemplate_page(s1, cpi);
			//System.out.println(template.indexOf(s1));
			template = template.replace(s1,s2);
			//System.out.println(template.indexOf(s2));
		}
		template = EncodeString.ubbPattern
			(template,"<gv:view>(.*?)<\\/gv:view>","$1");
		template = template.replace("###@","$");
		template = template.replaceAll("##n","\n");
		template = template.replaceAll("##r","\r");
		return template;
	}
		
	/**
	 * 根据传入的主题List替换循环体内标签
	 * @param template
	 * @param topiclist
	 * @param contentlist
	 * @return
	 * com.gamvan.club.file
	 */
	public String analysisTemplate_loop_topic(String template, List topiclist
			, List contentlist)
	{
		if(template ==null||template .equals("")||topiclist==null)
		{
            return "";
        }
		template = template.replaceAll("\n","##n");
		template = template.replaceAll("\r","##r");
		String cp = "<gv:forEach(\\p{Blank}*?)var=\"(.*?)\"(\\p{Blank}*?)>(.*?)<\\/gv:forEach>";
		List list = EncodeString.matcherList(template, cp);
		/** 执行替换开始 */
		template = analysisTemplate_loop(list, cp, "$4", template, topiclist, contentlist);
		
		template = templatePublic(template);
		
		template = template.replace("###@","$");
		template = template.replaceAll("##n","\n");
		template = template.replaceAll("##r","\r");
		return template;
	}
	
	/**
	 * 模版循环标签部分，根据var部分判断是回复表还是主题表，循环的次数根据List数组长度
	 * @param list 模版文件内所有匹配cp的循环标签的集合，这样可以允许一个页面内出现多个循环标签
	 * @param cp 匹配循环标签的正则表达式
	 * @param si 循环标签内正则匹配的内容 如$1、$3等
	 * @param template 模版文件数据
	 * @param topiclist 主题数组
	 * @param contentlist 内容数组
	 * @return
	 * com.gamvan.club.file
	 */
	public String analysisTemplate_loop(List list, String cp, String si
			,  String template
			, List topiclist, List contentlist)
	{
		if(template ==null || template .equals(""))
		{
            return "";
        }
		if(topiclist==null)
		{
			return EncodeString.ubbPattern(template,cp,si);
		}
		if(list.size()<1){
			return EncodeString.ubbPattern(template,cp,si);
		}
		boolean isRe = true;
		StringBuffer sb = new StringBuffer();
		String s = "";
		/**
		 * 模版里的多个循环标签一一提取出来做替换
		 */
		for(int i=0; i<list.size(); i++){
			String temp1 = TypeChange.objOfString(list.get(i));
			String temp = EncodeString.ubbPattern(temp1, cp, si);
			/**
			 * 根据var值确定是主题表内容还是回复表内容
			 */
			if(temp1.indexOf("var=\"re\"")!=-1){
				isRe = true;
			}else if(temp1.indexOf("var=\"t\"")!=-1){
				isRe = false;
			}else{
				temp1 = "";
			}
			/**
			 * List循环替换循环标签内的内容，放入到sb临时字符串内，最后一次性替换模版里的内容
			 */
			for(int i2=0; i2<topiclist.size(); i2++){
				
				if(isRe){
					try{
						ClubTopicReItem ctri = (ClubTopicReItem)topiclist.get(i2);
						topicID = ctri.getTopicID();
						topicID_re = ctri.getTopicReID();
						topic_re = ctri.getTopic();
						topicID_re = ctri.getTopicReID();
						topicAddTime_re = ctri.getTopicAddTime();
						userID_re = ctri.getUserID();
						userName_re = ctri.getUserName();
						ccID = ctri.getCcID();
						if(contentlist!=null){
							ClubContentReItem ccri = (ClubContentReItem)contentlist.get(i2);
							content_re = ccri.getContent();
							contentUrl_re = ccri.getContentUrl();
							contentImg_re = ccri.getContentImg();
						}
					}catch(Exception e){
						logger.error("提取回复表文章出错："+e.toString());
					}
				}else{
					try{
						ClubTopicItem cti = (ClubTopicItem)topiclist.get(i2);
						ccID = cti.getCcID();
						ccID1 = cti.getCcID1();
						ccID2 = cti.getCcID2();
						topicID = cti.getTopicID();
						topic = cti.getTopic();
						topicAddTime = cti.getTopicAddTime();
						userID = cti.getUserID();
						userName = cti.getUserName();
						if(contentlist!=null){
							ClubContentItem cci = (ClubContentItem)contentlist.get(i2);
							content = cci.getContent();
							contentUrl = cci.getContentUrl();
							contentImg = cci.getContentImg();
						}
						//logger.info(topicID+"："+topic);
					}catch(Exception e){
						logger.error("提取主题表文章出错："+e.toString());
					}
				}
				try{
					s = analysisTemplate_page(temp, null);
					sb.append(s);
				}catch(Exception e){
					
				}
			}
			
			try{
				template = template.replaceAll(temp1,sb.toString());
				sb.delete(0,sb.length());
			}catch(Exception e){
			}
			
		}
		return template;
	}
	
	/**
	 * 分析模版帖子标签部分
	 * @param template
	 * @param cpi
	 * @return
	 * com.gamvan.club.file
	 */
	public String analysisTemplate_page(String template, ClubPageItem cpi)
	{
        if(template ==null || template .equals("")){
            return "";
        }
        if(cpi!=null){
			topicID_re = cpi.getTopicID_re();
			topic_re = cpi.getTopic_re();
			topicID_re = cpi.getTopicID_re();
			topicAddTime_re = cpi.getTopicAddTime_re();
			userID_re = cpi.getUserID_re();
			userName_re = cpi.getUserName_re();
			content_re = cpi.getContent_re();
			contentUrl_re = cpi.getContentUrl_re();
			contentImg_re = cpi.getContentImg_re();
			
			topicID = cpi.getTopicID();
			topic = cpi.getTopic();
			topicAddTime = cpi.getTopicAddTime();
			userID = cpi.getUserID();
			userName = cpi.getUserName();
			content = cpi.getContent();
			contentUrl = cpi.getContentUrl();
			contentImg = cpi.getContentImg();
        }
        
        pageHtmlEncoder();
        topic = topic.replace("$","###@");
        content = content.replace("$","###@");
        topic_re = topic_re.replace("$","###@");
        content_re = content_re.replace("$","###@");
        template  = 
        	EncodeString.ubbPattern(template 
        			, "<gv:out(\\p{Blank}*?)value=\"topicID\"(\\p{Blank}*?)\\/>",String.valueOf(topicID)); 
        
        /*template  = 
        	EncodeString.ubbPattern(template 
        			, "<gv:out(\\p{Blank}*?)value=\"topic\"(\\p{Blank}*?)\\/>",topic); 
        */
        List list = EncodeString.matcherList(template, "<gv:out(\\p{Blank}*?)value=\"topic\"(\\p{Blank}*?)\\/>");
        for(int i=0; i<list.size(); i++){
        	String s = TypeChange.objOfString(list.get(i));
          	template  = template.replace(s, topic);
        }
        
        list = EncodeString.matcherList(template, "<gv:out(\\p{Blank}*?)value=\"topic_re\"(\\p{Blank}*?)\\/>");
        for(int i=0; i<list.size(); i++){
        	String s = TypeChange.objOfString(list.get(i));
        	//System.out.println(topic_re);
        	template  = template.replaceAll(s, topic_re);
        }
       
        template  = 
        	EncodeString.ubbPattern(template 
        			, "<gv:out(\\p{Blank}*?)value=\"URL_topic\"(\\p{Blank}*?)\\/>",URL_topic); 
        
        template  = EncodeString.ubbPattern(template 
    			, "<gv:out(\\p{Blank}*?)value=\"content\"(\\p{Blank}*?)\\/>",content); 

        template  = EncodeString.ubbPattern(template 
    			, "<gv:out(\\p{Blank}*?)value=\"userName\"(\\p{Blank}*?)\\/>",userName); 
        
        template  = EncodeString.ubbPattern(template 
    			, "<gv:out(\\p{Blank}*?)value=\"URL_userName\"(\\p{Blank}*?)\\/>",URL_userName); 
        
        
        template  = EncodeString.ubbPattern(template 
    			, "<gv:out(\\p{Blank}*?)value=\"topicAddTime\"(\\p{Blank}*?)\\/>",topicAddTime); 

        template  = 
        	EncodeString.ubbPattern(template 
        			, "<gv:out(\\p{Blank}*?)value=\"topicID_re\"(\\p{Blank}*?)\\/>",String.valueOf(topicID_re));
        
        //template  = EncodeString.ubbPattern(template 
        			//, "<gv:out(\\p{Blank}*?)value=\"topic_re\"(\\p{Blank}*?)\\/>",topic_re); 
        
        template  = EncodeString.ubbPattern(template 
    			, "<gv:out(\\p{Blank}*?)value=\"content_re\"(\\p{Blank}*?)\\/>",content_re); 
        
        template  = EncodeString.ubbPattern(template 
    			, "<gv:out(\\p{Blank}*?)value=\"userName_re\"(\\p{Blank}*?)\\/>",userName_re); 
        
        template  = EncodeString.ubbPattern(template 
    			, "<gv:out(\\p{Blank}*?)value=\"URL_userName_re\"(\\p{Blank}*?)\\/>",URL_userName_re);
        
        template  = EncodeString.ubbPattern(template 
    			, "<gv:out(\\p{Blank}*?)value=\"topicAddTime_re\"(\\p{Blank}*?)\\/>",topicAddTime_re); 
        
        template  = EncodeString.ubbPattern(template 
    			, "<gv:out(\\p{Blank}*?)value=\"pageArea\"(\\p{Blank}*?)\\/>",pageArea);
        
        template  = EncodeString.ubbPattern(template 
    			, "<gv:out(\\p{Blank}*?)value=\"ccName\"(\\p{Blank}*?)\\/>", ccName);
 
        return template;   
	}
	
	private String templatePublic(String template){
		List list = EncodeString.matcherList(template
				,"<gv:out(\\p{Blank}*?)value=\"pageJump_topic\"(\\p{Blank}*?)\\/>");
		for(int i=0; i<list.size(); i++){
			template = template.replaceAll(TypeChange.objOfString(list.get(i)),pageJump_topic);
		}
		
		list = EncodeString.matcherList(template
				,"<gv:out(\\p{Blank}*?)value=\"pageArea\"(\\p{Blank}*?)\\/>");
		for(int i=0; i<list.size(); i++){
			template = template.replaceAll(TypeChange.objOfString(list.get(i)),pageArea);
		}

		list = EncodeString.matcherList(template
				,"<gv:out(\\p{Blank}*?)value=\"pageJump_class\"(\\p{Blank}*?)\\/>");
		for(int i=0; i<list.size(); i++){
			template = template.replaceAll(TypeChange.objOfString(list.get(i)),pageJump_class);
		}
		
		list = EncodeString.matcherList(template
				,"<gv:out(\\p{Blank}*?)value=\"ccID\"(\\p{Blank}*?)\\/>");
		for(int i=0; i<list.size(); i++){
			template = template.replaceAll(TypeChange.objOfString(list.get(i)),String.valueOf(ccID));
		}
		list = EncodeString.matcherList(template
				,"<gv:out(\\p{Blank}*?)value=\"ccID1\"(\\p{Blank}*?)\\/>");
		for(int i=0; i<list.size(); i++){
			template = template.replaceAll(TypeChange.objOfString(list.get(i)),String.valueOf(ccID1));
		}
		
		list = EncodeString.matcherList(template
				,"<gv:out(\\p{Blank}*?)value=\"ccID2\"(\\p{Blank}*?)\\/>");
		for(int i=0; i<list.size(); i++){
			template = template.replaceAll(TypeChange.objOfString(list.get(i)),String.valueOf(ccID2));
		}
		
		list = EncodeString.matcherList(template
				,"<gv:out(\\p{Blank}*?)value=\"classSummary\"(\\p{Blank}*?)\\/>");
		for(int i=0; i<list.size(); i++){
			template = template.replaceAll(TypeChange.objOfString(list.get(i)),classSummary);
		}
		return template;
	}
	
	/**
	 * 
	 * 
	 * com.gamvan.club.file
	 */
	private void pageHtmlEncoder(){
		this.topic = EncodeString.htmlEncoder(this.topic.trim());
		this.topic_re = EncodeString.htmlEncoder(this.topic_re.trim());
		
		sb.append("<a href=\"");
		sb.append("/club/userInfo.jsp?userID=");
		sb.append(userID);
		sb.append("\"  target=\"_blank\">");
		sb.append(userName);
		sb.append("</a>");
		URL_userName = sb.toString();
		sb.delete(0, sb.length());

		sb.append("<a href=\"");
		sb.append("/club/pages/");
		sb.append(EncodeString.Gsubstring(topicAddTime,0,7,"UTF-8").replaceAll("-",""));
		sb.append("/");
		sb.append(topicID);
		sb.append(".html");
		sb.append("\"  ");
		sb.append(" title=\"");
		sb.append(topic);
		sb.append("\" target=\"_blank\">");
		sb.append(this.topic);
		sb.append("</a>");
		URL_topic = sb.toString();	
		sb.delete(0, sb.length());
		
		sb.append("<a href=\"");
		sb.append("/club/userInfo.jsp?userID=");
		sb.append(userID_re);
		sb.append("\"  target=\"_blank\">");
		sb.append(userName_re);
		sb.append("</a>");
		URL_userName_re = sb.toString();
		sb.delete(0, sb.length());
		
		topicAddTime = topicAddTime.replace(".0","");
		topicAddTime_re = topicAddTime_re.replace(".0","");
		
		
		if(!this.content.equals("")){
			content = EncodeString.htmlEncoder(content.trim());
			es.setUbbImg(contentImg);
			es.setUbbUrl(contentUrl);
			this.content = es.ubbEncoder(content.trim());
			/** 检测特殊类型的主题 */
			if(topicType==4){
				 ctt.setTopicTypeNum(-1);
			}else{
				 ctt.setTopicTypeNum(topicTypeNum);
			}
			ctt.setTopicType(topicType);
	        ctt.setUserTypeNum(0);
	        this.content = ctt.encoderType(this.content);
	        this.content = csrs.srContent(this.content,"");
		}
		
		if(!this.content_re.equals("")){
			content_re = EncodeString.htmlEncoder(content_re.trim());
			es.setUbbImg(contentImg_re);
			es.setUbbUrl(contentUrl_re);
			this.content_re = es.ubbEncoder(content_re.trim());
			this.content_re = csrs.srContent(this.content_re,"");
		}
        /** 社区过滤字符 */
        this.topic = csrs.srContent(this.topic,"");
        this.topic_re = csrs.srContent(this.topic_re,"");
	}
	
	/* test
	public static void main(String args[]){
		ClubPageTemplate cpt = new ClubPageTemplate();
		cpt.setTopic("++");
		String str = "erter<gv:view>\n\r  234324  \n\r</gv:view>ert";
		str=str.replaceAll("\r","");
		str = str.replaceAll("\n","");
		System.out.println(EncodeString.matcherStr(str, "<gv:view>(.*?)</gv:view>", "\n"));
	}
	*/
}
