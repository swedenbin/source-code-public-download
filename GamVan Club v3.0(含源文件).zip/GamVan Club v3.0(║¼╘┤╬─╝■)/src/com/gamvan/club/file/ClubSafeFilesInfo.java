/*
 * Created on 2005-9-29
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.file;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;


import com.gamvan.club.item.ClubSafeFilesInfoItem;
import com.gamvan.conn.ConnClub;

public class ClubSafeFilesInfo  extends ClubSafeFilesInfoItem{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String message = "";
    
    
    public ClubSafeFilesInfoItem getSafeFilesInfo(){
        ClubSafeFilesInfoItem csfii = null;
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("from ClubSafeFilesInfoItem ");
            Query query = session.createQuery(hql.toString())
            ;
            List list = query.list();
            Iterator it = list.iterator();
            if(it.hasNext()){
                csfii  = (ClubSafeFilesInfoItem)it.next();
            }
        }catch(HibernateException e){
            message = e.toString();
        }
        return csfii;
    }
    
    
    
    public void fileInfoUpdate(){
        allowDomain = allowDomain.replaceAll("\r","");       
        allowDomain = allowDomain.replaceAll("\n","");
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        StringBuffer hql = new StringBuffer();
        try{
            hql.append("update ClubSafeFilesInfoItem set allowDomain=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, allowDomain)
            ;
            query.executeUpdate();
            tran.commit();
            message = "更新成功！";
        }catch(HibernateException e){
            message = "更新成功！<br/>";
            message += e.toString();
            e.printStackTrace();
        }finally{
            ConnClub.closeSession();
        } 
    }
    

    public String getMessage() {
        return message;
    }
    
    /*test
    public static void main(String args[]){
        ClubSafeFilesInfo csfi = new ClubSafeFilesInfo();
        csfi.fileInfoUpdate();
    }
    */
}
