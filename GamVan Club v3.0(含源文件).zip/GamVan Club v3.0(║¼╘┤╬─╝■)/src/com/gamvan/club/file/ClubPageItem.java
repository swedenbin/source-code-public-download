/*
 * Created on 2006-1-10
 * Last modified on 2006-1-16
 * Made in GamVan
 * www.GamVan.com
 */
package com.gamvan.club.file;

public class ClubPageItem  implements java.io.Serializable
{
	private static final long serialVersionUID = 1L;

	protected String ccName = "";
	protected int ccID = 0;
	protected String ccName1 = "";
	protected int ccID1 = 0;
	protected String ccName2 = "";
	protected int ccID2 = 0;
	protected int topicID = 0;
	protected String topic = "";
	protected String content = "";
	protected int userID = 0;
	protected String userName = "";
	protected String topicAddTime = "";
	protected int topicType = 0;
	protected double topicTypeNum = 0;
	protected short topicPro = 0;
	
	
	protected int topicID_re = 0;
	protected String topic_re = "";
	protected String content_re = "";
	protected int userID_re = 0;
	protected String userName_re = "";
	protected String topicAddTime_re = "";
	
	protected String pageArea = ""; //用户位置导航
	protected String pageJump_topic = ""; //文章分页导航
	protected String pageJump_class = ""; //版面分页导航
	
	protected String URL_topic = "";
	protected String URL_userName = "";
	protected String URL_topicAddTime = "";
	
	protected String URL_userName_re = "";
	protected String URL_topicID_re = "";
	protected String URL_topicAddTime_re = "";
	
	protected String className = "";
	protected String classSummary = "";
	
	protected boolean contentUrl = false;
	protected boolean contentImg = false;
	protected boolean contentUrl_re = false;
	protected boolean contentImg_re = false;
	
	
	public boolean getContentImg() {
		return contentImg;
	}
	public void setContentImg(boolean contentImg) {
		this.contentImg = contentImg;
	}
	public boolean getContentImg_re() {
		return contentImg_re;
	}
	public void setContentImg_re(boolean contentImg_re) {
		this.contentImg_re = contentImg_re;
	}
	public boolean getContentUrl() {
		return contentUrl;
	}
	public void setContentUrl(boolean contentUrl) {
		this.contentUrl = contentUrl;
	}
	public boolean getContentUrl_re() {
		return contentUrl_re;
	}
	public void setContentUrl_re(boolean contentUrl_re) {
		this.contentUrl_re = contentUrl_re;
	}
	public short getTopicPro() {
		return topicPro;
	}
	public void setTopicPro(short topicPro) {
		this.topicPro = topicPro;
	}
	public int getTopicType() {
		return topicType;
	}
	public void setTopicType(int topicType) {
		this.topicType = topicType;
	}
	public double getTopicTypeNum() {
		return topicTypeNum;
	}
	public void setTopicTypeNum(double topicTypeNum) {
		this.topicTypeNum = topicTypeNum;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getURL_topic() {
		return URL_topic;
	}
	public void setURL_topic(String url_topic) {
		URL_topic = url_topic;
	}
	public String getURL_topicAddTime() {
		return URL_topicAddTime;
	}
	public void setURL_topicAddTime(String addTime) {
		URL_topicAddTime = addTime;
	}
	public String getURL_topicAddTime_re() {
		return URL_topicAddTime_re;
	}
	public void setURL_topicAddTime_re(String addTime_re) {
		URL_topicAddTime_re = addTime_re;
	}
	public String getURL_topicID_re() {
		return URL_topicID_re;
	}
	public void setURL_topicID_re(String url_topicid_re) {
		URL_topicID_re = url_topicid_re;
	}
	public String getURL_userName() {
		return URL_userName;
	}
	public void setURL_userName(String name) {
		URL_userName = name;
	}
	public String getURL_userName_re() {
		return URL_userName_re;
	}
	public void setURL_userName_re(String name_re) {
		URL_userName_re = name_re;
	}
	public String getPageArea() {
		return pageArea;
	}
	public void setPageArea(String pageArea) {
		this.pageArea = pageArea;
	}
	public int getCcID() {
		return ccID;
	}
	public void setCcID(int ccID) {
		this.ccID = ccID;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getContent_re() {
		return content_re;
	}
	public void setContent_re(String content_re) {
		this.content_re = content_re;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getTopic_re() {
		return topic_re;
	}
	public void setTopic_re(String topic_re) {
		this.topic_re = topic_re;
	}
	public String getTopicAddTime() {
		return topicAddTime;
	}
	public void setTopicAddTime(String topicAddTime) {
		this.topicAddTime = topicAddTime;
	}
	public String getTopicAddTime_re() {
		return topicAddTime_re;
	}
	public void setTopicAddTime_re(String topicAddTime_re) {
		this.topicAddTime_re = topicAddTime_re;
	}
	public int getTopicID() {
		return topicID;
	}
	public void setTopicID(int topicID) {
		this.topicID = topicID;
	}
	public int getTopicID_re() {
		return topicID_re;
	}
	public void setTopicID_re(int topicID_re) {
		this.topicID_re = topicID_re;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public int getUserID_re() {
		return userID_re;
	}
	public void setUserID_re(int userID_re) {
		this.userID_re = userID_re;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserName_re() {
		return userName_re;
	}
	public void setUserName_re(String userName_re) {
		this.userName_re = userName_re;
	}
	public String getCcName() {
		return ccName;
	}
	public void setCcName(String ccName) {
		this.ccName = ccName;
	}
	public String getPageJump_class() {
		return pageJump_class;
	}
	public void setPageJump_class(String pageJump_class) {
		this.pageJump_class = pageJump_class;
	}
	public String getPageJump_topic() {
		return pageJump_topic;
	}
	public void setPageJump_topic(String pageJump_topic) {
		this.pageJump_topic = pageJump_topic;
	}
	public int getCcID1() {
		return ccID1;
	}
	public void setCcID1(int ccID1) {
		this.ccID1 = ccID1;
	}
	public int getCcID2() {
		return ccID2;
	}
	public void setCcID2(int ccID2) {
		this.ccID2 = ccID2;
	}
	public String getCcName1() {
		return ccName1;
	}
	public void setCcName1(String ccName1) {
		this.ccName1 = ccName1;
	}
	public String getCcName2() {
		return ccName2;
	}
	public void setCcName2(String ccName2) {
		this.ccName2 = ccName2;
	}
	public String getClassSummary() {
		return classSummary;
	}
	public void setClassSummary(String classSummary) {
		this.classSummary = classSummary;
	}
}
