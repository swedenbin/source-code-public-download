/* 
 * 2005-12-20
 * Made in GamVan
 */
package com.gamvan.club.search;

import com.gamvan.tools.TypeChange;
import com.gamvan.tools.XmlOperate;

/**
 * 社区全文检索初始化配置
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubSearchCfg extends ClubSearchItem{

	private String realPath = "";
	private String sep = java.io.File.separator;
	
	//private static final Logger logger = Logger.getLogger(CreateIndex.class.getName());
	
	private XmlOperate xo ;
	
	public void searchCfg(){
		StringBuffer xmlpath = new StringBuffer();
		xmlpath.append(realPath);
		xmlpath.append(sep);
		xmlpath.append(sep);
		xmlpath.append("WEB-INF");
		xmlpath.append(sep);
		xmlpath.append(sep);
		xmlpath.append("classes");
		xmlpath.append(sep);
		xmlpath.append(sep);
		xmlpath.append("gamvanclub.cfg.xml");
		xo = new XmlOperate(xmlpath.toString());
	}

	public void getCfg(){
		this.searchMaxTopicID = 
			TypeChange.stringToInt(
					xo.getChildText(
							xo.getElement("club-search"),"searchMaxTopicID")
							);
		this.searchCreateIndex = 
			xo.getChildText(
					xo.getElement("club-search"),"searchCreateIndex");
		
		this.searchIndexPath = 
			xo.getChildText(
					xo.getElement("club-search"),"searchIndexPath");
		
		this.searchScheduleHour = 
			TypeChange.stringToInt(
					xo.getChildText(
							xo.getElement("club-search"),"searchScheduleHour")
							);
	}

	/**
	 * 更新配置信息
	 * 2005-12-22 23:45:33 Made In GamVan
	 * com.gamvan.club.search
	 */
	public void updateInfo(String type, String s){
		xo.setChildText(xo.getElement("club-search"), type, s);
	}

	public String getRealPath() {
		return realPath;
	}

	public void setRealPath(String realPath) {
		this.realPath = realPath;
	}
}
