/* 
 * 2005-12-20
 * Made in GamVan
 */
package com.gamvan.club.search;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.gamvan.IndexOperate;
import org.apache.lucene.index.IndexWriter;

import com.gamvan.club.item.ClubContentItem;
import com.gamvan.club.item.ClubContentReItem;
import com.gamvan.club.item.ClubTopicItem;
import com.gamvan.club.item.ClubTopicReItem;
import com.gamvan.club.topic.ClubContentResults;
import com.gamvan.club.topic.ClubTopicResults;

/**
 * 创建索引
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class CreateIndex extends ClubSearchItem{
	private ClubTopicResults ctr = new ClubTopicResults();
	private int topicID = 0; //索引记录的最后一条主题ID
	private int appendIndexCount = 0; //追加索引数目
	private ClubSearchCfg csc = new ClubSearchCfg();
	private static final Logger logger = Logger.getLogger(CreateIndex.class.getName());
	
	/**
	 * 根据配置信息判断是追加还是创建索引
	 * @return
	 * 2005-12-23 13:50:39 Made In GamVan
	 * com.gamvan.club.search
	 */
	public IndexWriter createOrAppendIndex(){
		IndexWriter writer = null;
		if(searchCreateIndex.equals("true")){
			writer = IndexOperate.createIndex(this.searchIndexPath);
		}else{
			writer = IndexOperate.appendIndex(this.searchIndexPath);
		}
		return writer;
	}
	
	/**
	 * 初始化各项参数
	 * 2005-12-28 13:02:05 Made In GamVan
	 * com.gamvan.club.search
	 */
	public void indexCfg(String realpath){
		/* 初始化基本信息 */
		
		csc.setRealPath(realpath);
		csc.searchCfg();
		csc.getCfg();
		//System.out.println(csc.getSearchIndexPath());
		this.searchIndexPath = csc.getSearchIndexPath();
		this.topicID = csc.getSearchMaxTopicID();
		this.searchCreateIndex = csc.getSearchCreateIndex(); //用以判断是追加还是创建索引
		this.searchScheduleHour = csc.getSearchScheduleHour();
	}
	
	/**
	 * 执行创建或者更新索引
	 * @throws IOException
	 * 2005-12-23 13:42:39 Made In GamVan
	 * com.gamvan.club.search
	 */
	public void indexRun() throws IOException{
		IndexWriter writer = createOrAppendIndex();
		if(writer==null){
			logger.error("初始化失败！");
			return;
		}
		ctr.setMaxTopicID(topicID); 
		ctr.setTopicReID(-1);
		this.appendIndexCount = ctr.topicCount();
		List list = ctr.topicList(1, this.appendIndexCount); 
		if(list==null){
			logger.error("本次任务更新索引 0 条");
		}else{
			this.topicList(list, writer);
			logger.error("本次更新索引：" + appendIndexCount + " 条");
		}
	}
	
	/**
	 * 
	 * @param list
	 * @param writer
	 * 2005-12-24 0:46:27 Made In GamVan
	 * com.gamvan.club.search
	 */
	private void topicList(List list, IndexWriter writer){
		if(list==null){
			logger.info("没有提取到文章内容");
			return;
		}
		ClubContentResults ccr = new ClubContentResults();
		ClubContentItem cci;
		int topicid = 0;
		String  topic = "";
		String addtime = "";
		String lasttime = "";
		String content = "";
		int userid = 0;
		String username = "";
		int ccid = 0;
		int lasttopicid = 0;
		Iterator it = list.iterator();
		while(it.hasNext()){
			content = "";
			ClubTopicItem cti = (ClubTopicItem)it.next();
			topicid = cti.getTopicID();
			this.topicID = topicid;
			if(lasttopicid==0){
				lasttopicid = topicid;
			}
			ccid = cti.getCcID();
			userid = cti.getUserID();
			topic = cti.getTopic().trim();
			username = cti.getUserName();
			addtime = cti.getTopicAddTime();
			lasttime = cti.getTopicLastReTime();
			
			ccr.setTopicID(topicid);
			cci = ccr.contentInfo();
			if(cci!=null){
				content = cci.getContent();
				if(content!=null){
					content = content.trim();
				}else{
					content = "";
				}
			}
			try {
				writer.addDocument(document(topicid, 0
						, topic, content
						, ccid, userid, username
						, addtime, lasttime
				));
			}catch(Exception e) {
				logger.error("更新主题索引出错"+ topicid + e.toString());
				e.printStackTrace();
			}
			try {
				topicReList(topicid, writer);
			} catch (Exception e) {
				logger.error(e.toString());
			}
		}
		if(lasttopicid>0){
			csc.updateInfo("searchCreateIndex","false"); //更新索引文件为追加，下次索引不再创建
			csc.updateInfo("searchMaxTopicID",String.valueOf(lasttopicid)); //更新配置文件最后主题ID
		}
	}
	
	
	
	private void topicReList(int tid, IndexWriter writer) 
		throws Exception
	{
		ClubTopicResults ctr = new ClubTopicResults();
		
		ctr.setTopicID(tid);
		ctr.setTopicIsDel((byte)0);
		int i = ctr.topicReCount(tid);
		List list = ctr.topicReList(1,i);
		if(list==null){
			logger.info("没有提取到主题回复,主题ID："+tid);
		}else{
			Iterator it = list.iterator();
			int topicreid = 0;
			String content = "";
			while(it.hasNext()){
				this.appendIndexCount += 1;
				ClubTopicReItem ctri = (ClubTopicReItem)it.next();
				topicreid = ctri.getTopicReID();
				
				ClubContentResults ccrr = new ClubContentResults();
				ccrr.setTopicReID(topicreid);
				ClubContentReItem ccri = ccrr.contentReInfo();
				if(ccri!=null){
					content = ccri.getContent();
					if(content!=null){
						content = content.trim();
					}else{
						content = "";
					}
				}
	
				try {
					writer.addDocument(document(tid, topicreid
							, ctri.getTopic().trim(), content.trim()
							, ctri.getCcID(), ctri.getUserID()
							, ctri.getUserName()
							, ctri.getTopicAddTime(), ctri.getTopicAddTime()
					));
				}catch(Exception e) {
					logger.error("更新回复索引出错"+topicreid+ctri.getTopic()+e.toString());
					e.printStackTrace();
				}	
			}
		}
	}
	
	public Document document(int topicid, int topicreid
			, String topic, String content
			, int ccid, int userid, String username
			, String addtime, String lasttime)
	{
		Document doc = new Document();
		doc.add(Field.Text("topicID", topicid));
		doc.add(Field.Text("topicReID", topicreid));
		doc.add(Field.Text("topic", topic));
		doc.add(Field.Text("content", content));
		doc.add(Field.Text("ccID", ccid));
		doc.add(Field.Text("userID", userid));
		doc.add(Field.Text("userName", username));
		doc.add(Field.Text("topicAddTime", addtime));
		doc.add(Field.Text("topicLastReTime", lasttime));
		return doc;
	}
	

	public int getAppendIndexCount() {
		return appendIndexCount;
	}
	
	
	public static void main(String args[]) throws Exception{
		com.gamvan.conn.ConnClub.init();
		CreateIndex ci = new CreateIndex(); 
		ci.indexCfg("E:\\MYJAVA\\myWeb"); //初始化配置信息
		ci.indexRun();
	}
	
}
