/* 
 * 2005-12-22
 * Made in GamVan
 */
package com.gamvan.club.search;

import java.io.IOException;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.cjk.CJKAnalyzer;
import org.apache.lucene.queryParser.MultiFieldQueryParser;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Searcher;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubSearch {
	private int topicID = 0;
	private String topic = "";
	private String content = "";
	private String userName = "";
	private String topicAddTime = "";
	private String topicLastTime = "";
	private int ccID = 0;
	private String ccName = "";
	private int totalrows = 0;
	Query query = null;
	private String realPath = "";
	
	public ClubSearch(String s){
		this.realPath = s;
	}
	
	/**
	 * 
	 * @param fields
	 * @param keys
	 * @return
	 * 2005-12-22 20:01:16 Made In GamVan
	 * com.gamvan.club.search
	 * @throws IOException 
	 */
	public Hits clubSearchHits(String[] fields, String keys) 
		throws IOException
	{
		Hits hits = null;
		if(fields==null || keys==null
					|| keys.trim().equals("")){
			return null;
		}
		/** 初始化索引路径 */
		com.gamvan.club.search.ClubSearchCfg csc = new com.gamvan.club.search.ClubSearchCfg();
		csc.setRealPath(realPath);
		csc.searchCfg();
		csc.getCfg();
		
		String clubIndexPath = csc.getSearchIndexPath();
		Searcher searcher = new IndexSearcher(clubIndexPath); //索引目录
		
		/** */
		Analyzer analyzer = new CJKAnalyzer();
		try {
			query = MultiFieldQueryParser.parse(keys, fields, analyzer);
			hits = searcher.search(query);
			totalrows = hits.length();
		} catch (ParseException e) {
			hits = null;
			e.printStackTrace();
		}
		return hits;
	}


	public Query getQuery() {
		return query;
	}

	public int getCcID() {
		return ccID;
	}

	public void setCcID(int ccID) {
		this.ccID = ccID;
	}

	public String getCcName() {
		return ccName;
	}

	public void setCcName(String ccName) {
		this.ccName = ccName;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public String getTopicAddTime() {
		return topicAddTime;
	}

	public void setTopicAddTime(String topicAddTime) {
		this.topicAddTime = topicAddTime;
	}

	public int getTopicID() {
		return topicID;
	}

	public void setTopicID(int topicID) {
		this.topicID = topicID;
	}

	public String getTopicLastTime() {
		return topicLastTime;
	}
	
	public void setTopicLastTime(String topicLastTime) {
		this.topicLastTime = topicLastTime;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getTotalrows() {
		return totalrows;
	}
}
