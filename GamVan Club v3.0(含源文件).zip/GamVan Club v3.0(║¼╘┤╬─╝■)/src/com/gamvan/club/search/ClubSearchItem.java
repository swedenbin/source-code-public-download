/* 
 * Created on 2006-1-5
 * Last modified on 2006-1-5
 * Made in GamVan 今晚制造
 * www.GamVan.com
 */
package com.gamvan.club.search;
/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubSearchItem {
	protected String searchIndexPath = ""; //社区索引保存目录
	protected int searchMaxTopicID = 0; //已经记录过索引的最后主题ID
	protected String searchCreateIndex = "true"; //判断是创建索引还是更新索引
	protected int searchScheduleHour = 0; //索引更新时间
	protected String xmlPath = "";
	
	
	public String getSearchCreateIndex() {
		return searchCreateIndex;
	}
	public void setSearchCreateIndex(String searchCreateIndex) {
		this.searchCreateIndex = searchCreateIndex;
	}
	public String getSearchIndexPath() {
		return searchIndexPath;
	}
	public void setSearchIndexPath(String searchIndexPath) {
		this.searchIndexPath = searchIndexPath;
	}
	public int getSearchMaxTopicID() {
		return searchMaxTopicID;
	}
	public void setSearchMaxTopicID(int searchMaxTopicID) {
		this.searchMaxTopicID = searchMaxTopicID;
	}
	public int getSearchScheduleHour() {
		return searchScheduleHour;
	}
	public void setSearchScheduleHour(int searchScheduleHour) {
		this.searchScheduleHour = searchScheduleHour;
	}
	public String getXmlPath() {
		return xmlPath;
	}
	public void setXmlPath(String xmlPath) {
		this.xmlPath = xmlPath;
	}
}
