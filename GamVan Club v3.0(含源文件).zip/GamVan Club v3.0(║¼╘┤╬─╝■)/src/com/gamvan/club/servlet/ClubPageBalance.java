/* 
 * 2005-11-13
 * Made in GamVan
 */
package com.gamvan.club.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.gamvan.club.dao.impl.ClubTopicImpl;
import com.gamvan.club.item.ClubTopicItem;
import com.gamvan.club.item.ClubUserItem;
import com.gamvan.club.topic.ClubTopicTypes;
import com.gamvan.club.user.ClubUserParameter;
import com.gamvan.club.user.ClubUsers;
import com.gamvan.html.OutPrint;
import com.gamvan.tools.TypeChange;
import com.gamvan.util.ParamUtils;

/**
 * 结帖散分
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubPageBalance  extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /* 格式化当前时间 */
    private ClubTopicTypes ctt = new ClubTopicTypes();
    private ClubUserParameter cup = new ClubUserParameter();
    
	public void doPost(HttpServletRequest request,HttpServletResponse response)
    	throws ServletException, IOException 
    {
		/* 当前操作用户的登陆ID */
		HttpSession httpsession = request.getSession();
		//String gvUserLogined = TypeChange.objOfString(httpsession.getAttribute("gvUserLogined"));
		//int gvUserID = TypeChange.stringToInt(ArrayEdit.getTextsInfo(gvUserLogined,0,";"));
		java.util.HashMap gvUserLogined = TypeChange.objToHashMap(httpsession.getAttribute("gvUserLogined"));
		int gvUserID = ParamUtils.getHashMapInt(gvUserLogined, "gvUserID");
		
		/* 贴子ID */
		int topicID = ParamUtils.getIntParameter(request, "tID");
		/* 提交页面回复的起始楼层 */
		int storey_1 = ParamUtils.getIntParameter(request, "storey_1");
		/* 提交页面回复的结束楼层 */
		int storey_2 = ParamUtils.getIntParameter(request, "storey_2");

		response.setContentType("text/HTML;charset=UTF-8"); 
		StringBuffer sb = new StringBuffer();
		PrintWriter out = response.getWriter();
		out.println("<html><head>");
		out.println("<STYLE type=text/css media=screen>@import url(/club/GVinc/main.css);</STYLE>");
		out.println("<title>");
		out.println("社区结贴 Powered by www.GamVan.com ");
		out.println("</title></head><body>");
		
		ClubTopicItem cti = null;
		ClubTopicImpl ctim = new ClubTopicImpl();
		cti = ctim.topicInfo(topicID);
		if(cti==null){
			out.print(OutPrint.prtCenter("主题不存在或已被删除！","",2));
			out.close();
			if(true)return;
			return ;
		}

		double topicTypeNum = cti.getTopicTypeNum(); //贴子设定散出的分数
		short topicType = cti.getTopicType(); //贴子类型必须为3
		/* 权限判断 */
		if(gvUserID!=cti.getUserID()){
			out.print(OutPrint.prtCenter("对不起，系统只允许帖子的主人结贴散分！","",2));
			out.close();
			if(true)return;
			return ;	
		}
		
		/* 已经散出的分数 */
		double topicTypeNumed = 0;
		try{
			topicTypeNumed = ctt.topicTypeNumed(topicID,(short)3);
		}catch(Exception e){
			
		}
		
		if(topicType==5 || topicTypeNumed>=topicTypeNum){
			ctim.topicTypeUpdate(topicID, (short)5);
			out.print(OutPrint.prtCenter("该问题已经结贴...","",2));
			out.close();
			if(true)return;
			return ;
		}
		
		int giveUser = 0;
		double giveMark = 0;
		double givedMark = 0; //计算本次提交散出的分数
		String userName = "";
		ClubUserItem cui = null;
		ClubUsers cu = new ClubUsers();
		for(int i=storey_1; i<=storey_2; i++){
			giveUser = ParamUtils.getIntParameter(request,"giveUser_"+i);
			giveMark = ParamUtils.getDoubleParameter(request,"giveMark_"+i);
			if(giveUser!=gvUserID)
			givedMark = givedMark + giveMark;
		}
		
		if(givedMark<=0){
			out.print(OutPrint.prtCenter("对不起，系统不允许您散出负分或零分！","",2));
			out.close();
			if(true)return;
			return ;	
		}
		/**
		 * 如果本次散分加上已经散出分数的总合大于贴子设定的散分总数则终止程序 
		 */
		if(givedMark + topicTypeNumed > topicTypeNum){
			sb.append("本贴您设定散出的积分数为：");
			sb.append(topicTypeNum);
			sb.append("<br/>本次您总共散出的积分数为：");
			sb.append(givedMark);
			sb.append("<br/>之前您已经散出的积分总数为：");
			sb.append(topicTypeNumed);
			sb.append("<br/>主题设定的散出分数小于您当前操作散出的总分，请返回重新给每位回复者分配积分！");
			out.print(OutPrint.prtCenter(sb.toString(),"",2));
			out.close();
			if(true)return;
			return ;
		}
		
		
		/* 扣除帖子主人的分数 */
		cup.setNoEditmk(1); /* 更新积分 */
		cup.setNoEditmn(0); /* 更新金币 */
		cup.setNoEditc(0); /* 更新信誉 */
		cup.setActType(2); /* 设置累加更新方式 */
		cup.setUserMark(-givedMark);
		cup.userParameter(gvUserID);
		
		
		/**
		 * 循环为每位回复者加分
		 */
		for(int i=storey_1; i<=storey_2; i++){
			giveUser = ParamUtils.getIntParameter(request,"giveUser_"+i);
			giveMark = ParamUtils.getDoubleParameter(request,"giveMark_"+i);
			if(giveUser!=gvUserID && giveMark>0 && giveUser>0){
				cui = cu.userInfo(giveUser);
				if(cui!=null){
					userName = cui.getUserName();
	        		
	        		cup.setNoEditmk(1); /* 更新积分 */
	        		cup.setNoEditmn(0); /* 更新金币 */
	        		cup.setNoEditc(0); /* 更新信誉 */
	        		cup.setActType(2); /* 设置累加更新方式 */
	        		cup.setUserMark(giveMark);
	        		cup.userParameter(giveUser);
	        		
	        		ctt.setTopicID(topicID);
	        		ctt.setUserID(giveUser);
	        		ctt.setUserName(userName);
	        		ctt.setTypeNum(giveMark);
	        		ctt.setTypeInfo((short)3);
	        		ctt.topicTypeAdd();
				}
			}
		}
		/**
		 * 如果本次散分加上已经散出分数的总合等于贴子设定的散分总数则更新贴子状态为结贴
		 */
		if(givedMark + topicTypeNumed == topicTypeNum){
			ctim.topicTypeUpdate(topicID, (short)5);
			out.print(
					OutPrint.prtCenter("该问题已经结贴，感谢您的诚信！","",2)
					);
			out.close();
			if(true)return;
			return ;
		}else{
			sb.append("本贴您设定散出的积分数为：");
			sb.append(topicTypeNum);
			sb.append("<br/>本次您总共散出的积分数为：");
			sb.append(givedMark);
			sb.append("<br/>您还差：");
			sb.append(topicTypeNum - givedMark - topicTypeNumed);
			sb.append(" 即可结贴");
			out.print(
					OutPrint.prtCenter(sb.toString(),"",2)
					);
			out.close();
			if(true)return;
			return ;
		}
	}

}
