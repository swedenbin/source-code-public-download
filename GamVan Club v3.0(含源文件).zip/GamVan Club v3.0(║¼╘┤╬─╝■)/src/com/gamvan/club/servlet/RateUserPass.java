/* 
 * 2005-12-14
 * Made in GamVan
 */
package com.gamvan.club.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gamvan.tools.EncodeString;
/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class RateUserPass extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private int rate = 0;
	
	/**
	 * 口令强弱等级判定,强度算法有待商戳，功能基本实现
	 * @param pass
	 * @return
	 * 2005-12-14 16:55:03 Made In GamVan
	 * com.gamvan.club.servlet
	 */
	public int rateUserPass(String pass){
		/*
		 * i 值指示口令等级
		 * 0 不合法口令
		 * 1 太短
		 * 2 弱
		 * 3 一般
		 * 4 很好
		 * 5 极佳
		 */
		int i = 0;
		if(pass==null || pass.length()==0){
			return 0;
		}
		int hasLetter = EncodeString.matcherStr(pass,"[a-zA-Z]","").length();
		int hasNumber = EncodeString.matcherStr(pass,"[0-9]","").length();	
		int passLen = pass.length();
		if(passLen>=6){
			/* 如果仅包含数字或仅包含字母 */
			if((passLen-hasLetter)==0 || (passLen-hasNumber)==0){
				if(passLen<8){
					i = 2;
				}else {
					i = 3;
				}
			}
			/* 如果口令大于6位且即包含数字又包含字母 */
			else if(hasLetter>0 && hasNumber>0){ 
				if(passLen>=10){
					i = 5;
				}else if(passLen>=8){
					i = 4;
				}else{
					i = 3;
				}
			}
			/* 如果既不包含数字又不包含字母 */
			else if(hasLetter==0 && hasNumber==0){
				if(passLen>=7){
					i = 5;
				}else{
					i = 4;
				}
			}
			/* 字母或数字有一方为0 */
			else if(hasNumber==0||hasLetter==0){
				if((passLen-hasLetter)==0 || (passLen-hasNumber)==0){
					i = 2;
				}
				/* 
				 * 字母数字任意一种类型小于6且总长度大于等于6
				 * 则说明此密码是字母或数字加任意其他字符组合而成
				 */
				else{
					if(passLen>8){
						i = 5;
					}else if(passLen==8){
						i = 4;
					}else{
						i = 3;
					}
				}
			}
		}else{ //口令小于6位则显示太短
			if(passLen>0){
				i = 1; //口令太短
			}else{
				i = 0;
			}
		}
		return i;
	}
	
	public void service(HttpServletRequest request,HttpServletResponse response)
		throws ServletException, IOException 
	{
		String userPass = request.getParameter("passwd");
		rate = rateUserPass(userPass);
		response.setContentType("text/HTML;charset=UTF-8"); 
		PrintWriter out = response.getWriter();
		out.print(rate);
		out.close();
		if(true)return;
		return ;
	}

}
