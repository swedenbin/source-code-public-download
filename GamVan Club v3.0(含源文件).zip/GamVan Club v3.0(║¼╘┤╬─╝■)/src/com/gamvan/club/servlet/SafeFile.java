/*
 * Created on 2005-9-28
 * Made In GamVan
 */
package com.gamvan.club.servlet;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.OutputStream;

import java.net.HttpURLConnection;
import java.net.URL;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.gamvan.club.file.ClubSafeFileCollection;
import com.gamvan.club.file.ClubSafeFilesInfo;
import com.gamvan.club.item.ClubSafeFileItem;
import com.gamvan.club.item.ClubSafeFilesInfoItem;
import com.gamvan.tools.TypeChange;

public class SafeFile extends HttpServlet {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String fileUrl = "";
    private String fileLongName = "theFile";
    private String fileExt = "";
    URL urlfile = null;
    HttpURLConnection httpUrl = null;      
    BufferedInputStream bis = null;
    OutputStream os = null;
    
    
    public String getAllowDomain(){
        String str = "";
        ClubSafeFilesInfo csfi = new ClubSafeFilesInfo();
        ClubSafeFilesInfoItem csfii =
            (ClubSafeFilesInfoItem)csfi.getSafeFilesInfo();
        if(csfii!=null){
            str = csfii.getAllowDomain();
        }
        return str;       
    }
    
    public void service(HttpServletRequest request,HttpServletResponse response)
        throws ServletException, IOException {
        HttpSession session = request.getSession();
        
        /*********文件访问域名地址**********/
        StringBuffer fileDomain = new StringBuffer();
        fileDomain.append("http://");
        fileDomain.append(request.getServerName());
        if(request.getServerPort()!=80){
            fileDomain.append(":");
            fileDomain.append(request.getServerPort());
        }
        //fileDomain.delete(0, fileDomain.length());
        //错误的文件链接
        String errFile = fileDomain + "/upFiles/club/errFile.wma";
        //盗链的文件链接重定向
        String safeFile = fileDomain + "/upFiles/club/safeFile.wma";  
        if(fileExt.equals("mp3")
                || fileExt.equals("mpeg")
                || fileExt.equals("mpg")
                || fileExt.equals("avi")
                || fileExt.equals("wma")
                || fileExt.equals("wav")
                || fileExt.equals("mid")
                || fileExt.equals("rm")
                || fileExt.equals("rmvb")                
        ){  
            response.setContentType("text/x-msdownload");
            response.addHeader("Content-Disposition","attachment; filename=\"" + fileLongName+ "." + fileExt + "\"");
            
        }
        else if(fileExt.equals("gif")
                || fileExt.equals("jpeg")
                || fileExt.equals("jpg")
                || fileExt.equals("bmp")
                || fileExt.equals("png") 
                || fileExt.equals("psd") 
        )
        {
            //错误的文件链接
            errFile = fileDomain + "/upFiles/club/errFileImg.gif";
            //盗链的文件链接重定向
            safeFile = fileDomain + "/upFiles/club/safeFileImg.gif"; 
            
            response.setContentType("APPLICATION/OCTET-STREAM;charset=UTF-8"); 
            response.setHeader("Content-Disposition", "attachment; filename=\""+ fileLongName+ "." + fileExt +" \""); 
        }
        else{
            response.setContentType("text/x-msdownload");
            response.addHeader("Content-Disposition","attachment; filename=\"" + fileLongName+ "." + fileExt + "\""); 
        }

        

        /******************获取文件真实路径**********************/
        int fileID = TypeChange.stringToInt(request.getParameter("id"));
        ClubSafeFileCollection csfc = new ClubSafeFileCollection();
        csfc.setFileID(fileID);
        ClubSafeFileItem csfi = (ClubSafeFileItem)csfc.safeFileInfo();
        if(csfi!=null){
            fileUrl = csfi.getFileNameAndPath();
            fileUrl = com.gamvan.net.URL.urlDecoder(fileUrl,"UTF-8");
            fileExt = csfi.getFileExt();
        }else{
            fileUrl = errFile;
        }
        
        //response.setContentType("text/HTML;charset=UTF-8"); 
        /*
        PrintWriter out = response.getWriter();
        out.println(fileUrl);
        */
        
        
        
        /*********************************************/  
        /* 用URL来源无法判断正确媒体文件所以下面改用session
        String beforeURL = request.getHeader("referer"); //判断URL来源
        String allowDomain = getAllowDomain();
        boolean bea = ArrayEdit.unTxtsArray(allowDomain, beforeURL, "|");
        if(!bea){
            fileUrl = safeFile;
        }
        */
        
        if(session.getAttribute("gvUserID")==null){
                fileUrl = safeFile;
        }
        
        /*
        ServletContext sc = getServletContext();   
        RequestDispatcher rd = sc.getRequestDispatcher(fileUrl + "/"); //定向的页面   
        rd.forward(request, response);  
        */
        
        /*
        if(fileExt.equals("rm")
                || fileExt.equals("rmvb")){
            response.setContentType("text/HTML;charset=UTF-8"); 
            response.sendRedirect(fileUrl);
        }else{
           
        }
        */
        
        
        //连接指定的网络资源  
        //获取网络输入流  
        try{
            urlfile = new URL(fileUrl);
            httpUrl = (HttpURLConnection)urlfile.openConnection();
            httpUrl.connect();  
            bis = new BufferedInputStream(httpUrl.getInputStream()); 
        }catch(Exception e){
            //资源连接错误
            urlfile = new URL(errFile.toString());
            httpUrl = (HttpURLConnection)urlfile.openConnection();  
            httpUrl.connect();          
            bis = new BufferedInputStream(httpUrl.getInputStream()); 
        }
        
        os = response.getOutputStream(); 
        byte[] b = new byte[1024]; 
        int i = 0; 
        while((i = bis.read(b))>0) 
        { 
            os.write(b, 0, i); 
        } 
        os.close(); 
        bis.close(); 
        httpUrl.disconnect();
    }

}
