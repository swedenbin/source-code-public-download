/* 
 * Created on 2005-12-31
 * Last modified on 2005-12-31
 * Made in GamVan 今晚制造
 * www.GamVan.com
 */
package com.gamvan.club.web;

import com.gamvan.club.ClubInfo;
import com.gamvan.tools.ArrayEdit;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubErrors {
	
	public static boolean isPass(String txt, int num){
		boolean ispass = false;
		try{
			ispass = ArrayEdit.txtsArray(txt,num,"|");
		}catch(Exception e){
			ispass = false;
		}
		return ispass;
	}
	
	public static String errs(int eID, String txt){
		ClubInfo c = new ClubInfo();
		com.gamvan.club.item.ClubInfoItem ci = c.clubInfo();
		StringBuffer sb = new StringBuffer();
		sb.append("<html><head><title>");
		sb.append(ci.getClubTitle());
		sb.append(" - 信息提示</title>");
		sb.append("<STYLE type=text/css media=screen>@import url(./GVinc/GamVanClubStyle.css);</STYLE>");
		sb.append("</head><body>");
		sb.append("<script language=\"javascript\" type=\"text/javascript\" src=\"GVscriptInc/topBar.js\"></script>");
		sb.append("<script language=\"javascript\" src=\"./GVscript/errs.js\"></script>");
		sb.append("<DIV class=\"line\"></DIV><DIV class=\"list_table_0\">");
		sb.append("<strong>您的位置</strong>&gt;&gt;<a href=\"index.jsp\" target=\"_parent\">社区首页</a>&gt;&gt;<a href=\"main.jsp\">进站画面</a>&gt;&gt;信息提示");
		sb.append("</DIV><DIV class=\"line\"></DIV><script language=\"javascript\">tabline(1,2,\"#ffffff\");</script>");
		sb.append("<table width=\"100%\" border=\"0\" align=\"center\" cellpadding=\"4\" cellspacing=\"1\" class=\"tab\">");
		sb.append("<tr><td class=\"bg2\"><script language=\"JavaScript\">errTxt("+ eID +");</script>");
		sb.append("<span style=\"color:#ff0000\">");
		sb.append(txt);
		sb.append("</span><hr size=\"1\">");
		sb.append("请认真查看社区帮助文档，如果您的问题仍然无法解决，请联系讨论组勤杂工！");
		sb.append("</td></tr><tr><td align=\"center\" class=\"bg2\">");
		sb.append("<a href=javascript:history.go(-1)>返回上一步＞＞＞</a></td></tr></table>");
		sb.append(com.gamvan.club.ClubHtmlConst.Gfoot(ci.getClubCopyRight(),ci.getClubYear()));
		sb.append("</body></html>");
		return sb.toString();
	}
}
