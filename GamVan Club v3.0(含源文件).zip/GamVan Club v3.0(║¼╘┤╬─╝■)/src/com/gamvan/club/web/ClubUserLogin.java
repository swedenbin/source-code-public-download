/* 
 * Created on 2005-12-30
 * Last modified on 2005-12-30
 * Made in GamVan 今晚制造
 * www.GamVan.com
 */
package com.gamvan.club.web;

import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import com.gamvan.club.item.ClubUserItem;
import com.gamvan.club.item.ClubUseropItem;
import com.gamvan.club.user.ClubUserop;
import com.gamvan.club.user.ClubUsers;
import com.gamvan.tools.FormatDateTime;
import com.gamvan.tools.TypeChange;
import com.gamvan.util.ParamUtils;

/**
 * 用户登录信息WEB初始化
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubUserLogin {
	private static HttpSession httpsession = null;	
	private static HashMap gvUserLogined = null;
	private static ClubUsers cus = new ClubUsers();
	//private static final Logger logger = Logger.getLogger(ClubUserLogin.class.getName());
	/**
	 * 初始化用户登陆信息
	 * @param req
	 * 2005-12-30 14:29:20 Made In GamVan
	 * com.gamvan.club.filters
	 */
	public static void loginInit(HttpServletRequest req){
		httpsession = req.getSession();
		gvUserLogined = TypeChange.objToHashMap(httpsession.getAttribute("gvUserLogined"));
		String gvUserPass = "";
		String gvUserName = "";
		String gvUserTxt = "";
		int gvUserGradeID = 8;
		int gvUserID = 0;
		ClubUserItem cui = null;
		if(gvUserLogined==null){
			gvUserLogined = new HashMap();
			gvUserID = TypeChange.stringToInt(ParamUtils.getCookieValue(req, "gvUserID", "0"));
			if(gvUserID>0){
				gvUserPass = 
					ParamUtils.getCookieValue(req, "gvUserPass", "");
				gvUserName = 
					ParamUtils.getCookieValue(req, "gvUserName", "");
				gvUserName = com.gamvan.net.URL.urlDecoder(gvUserName,"UTF-8");
				cui = cus.userLogin(gvUserID, gvUserPass, 1);
				if(cui!=null){
					gvUserTxt = cui.getUserTxt();
					ClubUserop cuo = new ClubUserop();
					ClubUseropItem cuoi = cuo.useropInfo(gvUserName,0);
					if(cuoi!=null){
						gvUserGradeID = cuoi.getUoGradeID();
						if(gvUserGradeID==0){
							gvUserGradeID = 8;
						}		
					}else{
						gvUserGradeID = 8;
					}
					gvUserLogined.put("gvUserCredit", new Double(cui.getUserCredit()));
					gvUserLogined.put("gvUserMark", new Double(cui.getUserMark()));
					gvUserLogined.put("gvUserMoney", new Double(cui.getUserMoney()));
					gvUserLogined.put("gvUserUpfile", new Integer(cui.getUserUpfile()));
					gvUserLogined.put("gvUserUpfileOpen", new Short(cui.getUserUpfileOpen()));
					gvUserLogined.put("gvUserUpfileSize", new Integer(cui.getUserUpfileSize()));
				}
			}else{
				gvUserName="";
				gvUserPass="";
				gvUserID = 0;
				gvUserGradeID = 10;
			}
			gvUserLogined.put("gvUserID", new Integer(gvUserID));
			gvUserLogined.put("gvUserName", gvUserName);
			gvUserLogined.put("gvUserPass", gvUserPass);
			gvUserLogined.put("gvUserTxt", gvUserTxt);
			gvUserLogined.put("gvUserLoginTime", FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss"));
			gvUserLogined.put("gvUserGradeID", new Integer(gvUserGradeID));
			httpsession.setAttribute("gvUserLogined", gvUserLogined);
		}else{

		}
	}
	
	/* 
	public static void loginPost(HttpServletRequest request){
		httpsession = request.getSession();
	}
	*/
}
