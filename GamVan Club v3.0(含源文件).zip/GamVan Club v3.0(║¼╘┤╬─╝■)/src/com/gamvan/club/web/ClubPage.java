/* 
 * Created on 2005-12-30
 * Last modified on 2005-12-30
 * Made in GamVan 今晚制造
 * www.GamVan.com
 */
package com.gamvan.club.web;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.gamvan.tools.TypeChange;
import com.gamvan.util.ParamUtils;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubPage {
	
	private static final long serialVersionUID = 1L;
	
	private HttpServletRequest request;
	private HttpServletResponse response;

	private Object topicObject = null;
	private Object contentObject = null;

	private byte ccStyle = 0;
	private boolean isRe = false;
	
	private int gvUserID = 0;
	private static HttpSession httpsession = null;	
	private static String gvUserLogined = null;
	
	private boolean pageRun= true;
	private String message = "";
	
	/*
	public static void main(String args[]) throws IOException{
		com.gamvan.conn.ConnClub.init();
		com.gamvan.club.topic.ClubTopicInfo cti = 
			new com.gamvan.club.topic.ClubTopicInfo();
		System.out.print(cti.topicInfo(4883,4920, (byte)1));
	}
	*/
	
	public ClubPage(HttpServletRequest request
			, HttpServletResponse response) throws IOException{
		this.request = request;
		this.response = response;
		httpsession = request.getSession();
		gvUserLogined = 
			TypeChange.objOfString(httpsession.getAttribute("gvUserLogined"));
		if(gvUserLogined.equals("")){
			gvUserID = TypeChange.stringToInt(
					ParamUtils.getCookieValue(request, "gvUserID", "0"));
		}
		
	}
	
	public boolean clubPage(){
		int reID = ParamUtils.getIntParameter(request,"reID");
		int tID = ParamUtils.getIntParameter(request,"tID");
		if(tID<=0){
			pageRun = false;
			message = com.gamvan.club.web.ClubErrors.errs(3, "你所请求的文章不存在或已被删除");
		}
		com.gamvan.club.topic.ClubTopicInfo cti = 
			new com.gamvan.club.topic.ClubTopicInfo();
		topicObject = cti.topicInfo(tID, reID, ccStyle);
		contentObject = cti.contentInfo();
		if(topicObject==null){
			pageRun = false;
			message = com.gamvan.club.web.ClubErrors.errs(3, "你所请求的文章不存在或已被删除");
		}else{
			cti.topicUpdate(tID, reID, ccStyle); //浏览次数加1
		}
		return pageRun;
	}
	

	public byte getCcStyle() {
		return ccStyle;
	}

	public void setCcStyle(byte ccStyle) {
		this.ccStyle = ccStyle;
	}

	public boolean getIsRe() {
		return isRe;
	}

	public void setIsRe(boolean isRe) {
		this.isRe = isRe;
	}

	public Object getContentObject() {
		return contentObject;
	}

	public void setContentObject(Object contentObject) {
		this.contentObject = contentObject;
	}

	public Object getTopicObject() {
		return topicObject;
	}

	public void setTopicObject(Object topicObject) {
		this.topicObject = topicObject;
	}

	public String getMessage() {
		return message;
	}

	public boolean getPageRun() {
		return pageRun;
	}
	
}
