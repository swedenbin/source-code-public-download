package com.gamvan.club;
import com.gamvan.club.item.ClubStringReplaceItem;
import com.gamvan.club.manage.ClubStringReplace;
import java.util.StringTokenizer;

public class ClubStringReplaces extends ClubStringReplaceItem{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String message = "";
    
    public ClubStringReplaces(){
        ClubStringReplace csr = new ClubStringReplace();
        ClubStringReplaceItem csri = new ClubStringReplaceItem();
        csri = (ClubStringReplaceItem) csr.replaceSelect();
        this.replaceUserPen = csri.getReplaceUserPen();
        this.replaceTopic = csri.getReplaceTopic();
        this.replaceContent = csri.getReplaceContent();
        this.replaceMsgTopic = csri.getReplaceMsgTopic();
        this.replaceMsgContent = csri.getReplaceMsgContent();
        csri= null;
    }
    
    
    /**
     * 
     * @param str
     * @param rep
     * @return
     */
    public String srUserPen(String str, String rep){
        if(str!=null && !str.equals("")){
            if(!rep.trim().equals("")){
                replaceUserPen = rep;
            }
            StringTokenizer st1 = new StringTokenizer(replaceUserPen, "\n");
            String[] sts1 = new String[st1.countTokens()];
            try{
                for(int i1=0; st1.hasMoreTokens(); i1++){
                    sts1[i1] = st1.nextToken().trim();
                   
                    StringTokenizer st2 = new StringTokenizer(sts1[i1], "|");
                    String[] sts2 = new String[st2.countTokens()];
                     for(int i2=0; st2.hasMoreTokens(); i2++){
                         sts2[i2] = st2.nextToken().trim();
                     }
                    str = str.replaceAll(sts2[0],sts2[1]);
                }
             }catch(Exception e){
                message = e.toString();
            }            
        }
        return str;
    }
  
    
    /**
     * 
     * @param str
     * @param rep
     * @return
     */
    public String srTopic(String str, String rep){
        if(str!=null && !str.equals("")){
            if(!rep.trim().equals("")){
                this.replaceTopic = rep;
            }
            StringTokenizer st1 = new StringTokenizer(replaceTopic, "\n");
            String[] sts1 = new String[st1.countTokens()];
            try{
                for(int i1=0; st1.hasMoreTokens(); i1++){
                    sts1[i1] = st1.nextToken().trim();
                   
                    StringTokenizer st2 = new StringTokenizer(sts1[i1], "|");
                    String[] sts2 = new String[st2.countTokens()];
                     for(int i2=0; st2.hasMoreTokens(); i2++){
                         sts2[i2] = st2.nextToken().trim();
                     }
                    str = str.replaceAll(sts2[0],sts2[1]);
                }
             }catch(Exception e){
                message = e.toString();
            }            
        }
        return str;
    }
    
    
    /**
     * 
     * @param str
     * @param rep
     * @return
     */
    public String srContent(String str, String rep){
        if(str!=null && !str.equals("")){
            if(!rep.trim().equals("")){
                this.replaceContent = rep;
            }
            StringTokenizer st1 = new StringTokenizer(replaceContent, "\n");
            String[] sts1 = new String[st1.countTokens()];
            try{
                for(int i1=0; st1.hasMoreTokens(); i1++){
                    sts1[i1] = st1.nextToken().trim();
                    StringTokenizer st2 = new StringTokenizer(sts1[i1], "|");
                    String[] sts2 = new String[st2.countTokens()];
                     for(int i2=0; st2.hasMoreTokens(); i2++){
                         sts2[i2] = st2.nextToken().trim();
                     }
                    str = str.replaceAll(sts2[0],sts2[1]);
                }
             }catch(Exception e){
                message = e.toString();
            }            
        }
        return str;
    }
    
    /**
     * 
     * @param str
     * @param rep
     * @return
     */
    public String srMsgTopic(String str, String rep){
        if(str!=null && !str.equals("")){
            if(!rep.trim().equals("")){
                this.replaceMsgTopic = rep;
            }
            StringTokenizer st1 = new StringTokenizer(replaceMsgTopic, "\n");
            String[] sts1 = new String[st1.countTokens()];
            try{
                for(int i1=0; st1.hasMoreTokens(); i1++){
                    sts1[i1] = st1.nextToken().trim();
                    StringTokenizer st2 = new StringTokenizer(sts1[i1], "|");
                    String[] sts2 = new String[st2.countTokens()];
                     for(int i2=0; st2.hasMoreTokens(); i2++){
                         sts2[i2] = st2.nextToken().trim();
                     }
                    str = str.replaceAll(sts2[0],sts2[1]);
                }
             }catch(Exception e){
                message = e.toString();
            }            
        }
        return str;
    }
    
    /**
     * 
     * @param str
     * @param rep
     * @return
     */
    public String srMsgContent(String str, String rep){
        if(str!=null && !str.equals("")){
            if(!rep.trim().equals("")){
                replaceMsgContent = rep;
            }
            StringTokenizer st1 = new StringTokenizer(replaceMsgContent, "\n");
            String[] sts1 = new String[st1.countTokens()];
            try{
                for(int i1=0; st1.hasMoreTokens(); i1++){
                    sts1[i1] = st1.nextToken().trim();
                    StringTokenizer st2 = new StringTokenizer(sts1[i1], "|");
                    String[] sts2 = new String[st2.countTokens()];
                     for(int i2=0; st2.hasMoreTokens(); i2++){
                         sts2[i2] = st2.nextToken().trim();
                     }
                    str = str.replaceAll(sts2[0],sts2[1]);
                }
             }catch(Exception e){
                message = e.toString();
            }            
        }
        return str;
    }
    
    /*
    public static void main(String args[]){
        //ClubStringReplaces csr = new ClubStringReplaces();
    }
    */
    public String getMessage(){
        return this.message;
    }
}
