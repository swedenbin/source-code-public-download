/*
 * Created on 2005-8-19
 * Made In GamVan
 */
package com.gamvan.club.message;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.StringTokenizer;

import com.gamvan.club.dao.impl.ClubMessageSendImpl;
import com.gamvan.club.item.ClubMessageSendItem;
import com.gamvan.club.item.ClubUserItem;
import com.gamvan.club.user.ClubUsers;
import com.gamvan.tools.EncodeString;
import com.gamvan.tools.FormatDateTime;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubMessageSend extends ClubMessageSendItem{
    private static final long serialVersionUID = 1L;
    
    /* 格式化当前时间 */
    private String now= FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    private String message = "";
    private int isPost = 0;
    private ClubMessageSendImpl cmsim = new ClubMessageSendImpl();
    
    public void setIsPost(int isPost) {
        this.isPost = isPost;
    }

    /**
     * 
     * @param page
     * @param pageNum
     * @return
     * 2005-11-4 5:00:56 Made In GamVan
     */
    public List sendList(int page, int pageNum){
        List list = null;        
        try{
        	list = cmsim.messageSendList(page, pageNum, cmSendID, cmIsSend);
        }catch(Exception e){
            message = e.toString();
        }
        return list;
    }

    /**
     * 统计总数为了分页
     * @return
     * 2005-11-4 5:01:28 Made In GamVan
     */
    public int sendCount(){
        int i = 0;
        try{
        	i = cmsim.messageSendCount(cmSendID, cmIsSend);
        }catch(Exception e){
        }
        return i;
    }
    

    
    /* 废弃此方法
    public void sendDels(String cmid){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        try{
            Connection con=session.connection();  
            PreparedStatement stmt=con.prepareStatement("delete from GVclubMessageSend  where cmID in ("+ cmid +")");  
            int i = stmt.executeUpdate();  
            tran.commit(); 
            message = i + " 条记录被成功删除!";
        }catch(Exception e){
            
        }
    }
    */
    
    public boolean sendDel(String cmids[]){
        boolean bea = false;
        if(cmids==null){
            message = "请选定你要删除的短消息。";
            return bea;
        }       
        Collection clt = new ArrayList();
        for(int i=0; i<cmids.length; i++){
        	clt.add(cmids[i]);
        }
        try{
        	int i = cmsim.messageSendDel(clt);
        	message = String.valueOf(i)+" 条消息被成功删除！";
        }catch(Exception e){
        	message = "消息删除失败！";
        }
        return bea;
    } 

    public void sendDel_userid(int userid){
    	cmsim.messageSendDel_userid(userid);
    }
    
    
    /**
     * 从草稿箱将消息状态更改为发送
     * @param cmid
     * 2005-11-4 14:26:18 Made In GamVan
     */
    public void sendUpdate(int cmid){
        cmsim.messageIsSendUpdate(cmid, true);
    }
    
    /**
     * 社区消息信息
     * @param cmid
     * @return
     * 2005-11-4 14:28:20 Made In GamVan
     */
    public ClubMessageSendItem sendMessageInfo(int cmid){
        ClubMessageSendItem cmsi = null;
        try{
        	cmsi = cmsim.messageSendInfo(cmid);
        }catch(Exception e){
            message = e.toString();
        }
        return cmsi;
    }
    
    /**
     * 2005-11-4 14:29:20 Made In GamVan
     */
    public void sendAdd(){
        try{
            cmsim.setCmSendUser(cmSendUser);
            cmsim.setCmTakeUser(cmTakeUser);
            cmsim.setCmTopic(cmTopic);
            cmsim.setCmContent(cmContent);
            cmsim.setCmUserIp(cmUserIp);
            cmsim.setCmAddTime(now);
            cmsim.setCmIsSend(cmIsSend);
            cmsim.setCmOrder(cmOrder);
            cmsim.setCmReID(cmReID);           
            cmsim.setCmSendID(cmSendID);
            cmsim.setCmTakeID(cmTakeID);
            cmsim.messageSendAdd();
        }catch(Exception e){
            message = e.toString();
        }
    }
    
    /**
     * 从发件箱或草稿箱 发至收件箱
     * @param cmid
     * 2005-11-4 14:29:33 Made In GamVan
     */
    public void sendToTake(int cmid){
        ClubMessageSendItem cmsi = (ClubMessageSendItem)sendMessageInfo(cmid);
        ClubMessageTake cmt = new ClubMessageTake();
        cmt.setCmTopic(cmsi.getCmTopic());
        cmt.setCmContent(cmsi.getCmContent());
        cmt.setCmUserIp(cmsi.getCmUserIp());
        cmt.setCmAddTime(now);
        cmt.setCmIsTake(false);
        cmt.setCmOrder(cmsi.getCmOrder());
        cmt.setCmReID(cmsi.getCmReID());           
        cmt.setCmSendID(cmsi.getCmSendID());
        cmt.setCmTakeID(cmsi.getCmTakeID());
        cmt.setCmSendUser(cmsi.getCmSendUser());
        cmt.setCmTakeUser(cmsi.getCmTakeUser());
        cmt.takeAdd();
        message = "1 条短消息发送成功！<br>";
        
    }

    /**
     * 批量发送短消息
     * @param uNames 接收以逗号为间隔的接收方用户名 循环检测逐一发送
     * @return
     * 2005-11-4 14:47:55 Made In GamVan
     */
    public boolean sendMessages(String uNames){
        boolean bea = false;
        int count = 0;
        ClubMessageTake cmt = new ClubMessageTake();
        cmt.setCmTopic(cmTopic);
        cmt.setCmContent(cmContent);
        cmt.setCmUserIp(cmUserIp);
        cmt.setCmAddTime(now);
        cmt.setCmIsTake(false);
        cmt.setCmOrder(cmOrder);
        cmt.setCmReID(cmReID);           
        cmt.setCmSendID(cmSendID);

        ClubUsers cu = new ClubUsers();
        ClubUserItem cui = null;
        StringTokenizer st = new StringTokenizer(uNames,",");
        String[] uName = new String[st.countTokens()];
        if(uNames.equals("")||cmTopic.equals("")){
            message = "收件人ID、标题不能为空。";
            return false;
        }
        
        if(EncodeString.Glength(cmTopic)>100 || EncodeString.Glength(cmContent)>1000){
            message = "操作发生错误，您的主题或内容过长！<br/>短消息主题内容最大长度100字符，内容不能最大长度1000字符！";
            return false;
        }
        
        try{
            for(int i=0;st.hasMoreTokens();i++){ /* 提取用户名 */
                uName[i] = st.nextToken().trim();
                cui = null;
                cui = cu.userInfo(uName[i]);
                if(cui!=null){ /* 判断短消息接收ID是否为注册用户 */
                    cmTakeID = cui.getUserID();
                    this.cmTakeUser = uName[i];
                    switch(isPost){
                        case 0:     /* 直接发送 */
                            cmt.setCmTakeID(cmTakeID);
                            cmt.setCmSendUser(cmSendUser);
                            cmt.setCmTakeUser(cmTakeUser);
                            cmt.takeAdd();
                            break;
                        case 1:     /* 发件箱保留副本 */
                             this.cmIsSend = true;
                             sendAdd();
                             cmt.setCmTakeID(cmTakeID);
                             cmt.setCmSendUser(cmSendUser);
                             cmt.setCmTakeUser(cmTakeUser);
                             cmt.takeAdd();
                             break;
                        case 2:     /* 草稿箱不发送 */
                            this.cmIsSend = false;
                            cmt.setCmTakeID(cmTakeID);
                            sendAdd();
                            break;
                    } 
                    count ++;
                }else{
                    message+= uName[i] + " 不是注册用户发送失败！<br>";
                }
            }
             message += String.valueOf(count) + " 条短消息发送成功！<br>";
        }catch(Exception e){
            message = e.toString();
        }
        return bea;        
    }
    
    public String getMessage() {
        return message;
    }

    /*
    public static void main(String args[]){
        //System.out.print(EncodeString.Glength("woa爱你们o"));
        //ClubMessageSend cms = new ClubMessageSend();
     
    }
    */
}
