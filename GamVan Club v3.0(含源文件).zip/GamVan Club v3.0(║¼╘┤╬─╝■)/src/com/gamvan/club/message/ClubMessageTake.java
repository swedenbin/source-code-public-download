/*
 * Created on 2005-8-19
 * Made In GamVan
 */
package com.gamvan.club.message;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.gamvan.club.dao.impl.ClubMessageTakeImpl;
import com.gamvan.club.item.ClubMessageTakeItem;
import com.gamvan.tools.FormatDateTime;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubMessageTake extends ClubMessageTakeItem{

    private static final long serialVersionUID = 1L;
    
    /* 格式化当前时间 */
    private String now= FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    private String message = "";
    
    private ClubMessageTakeImpl cmtim = new ClubMessageTakeImpl();
    
    public void takeAdd(){
        try{
            cmtim.setCmSendUser(cmSendUser);
            cmtim.setCmTakeUser(cmTakeUser);
            cmtim.setCmTopic(cmTopic);
            cmtim.setCmContent(cmContent);
            cmtim.setCmUserIp(cmUserIp);
            cmtim.setCmAddTime(now);
            cmtim.setCmIsTake(cmIsTake);
            cmtim.setCmOrder(cmOrder);
            cmtim.setCmReID(cmReID);           
            cmtim.setCmSendID(cmSendID);
            cmtim.setCmTakeID(cmTakeID);
            cmtim.messageTakeAdd();
        }catch(Exception e){
            message = e.toString();
        }
    }
    
    /**
     * @param cmid
     * 2005-11-4 17:24:53 Made In GamVan
     * com.gamvan.club.message
     */
    public void takeUpdate(int cmid){
        try{
            cmtim.messageIsTakeUpdate(cmid, true);           
        }catch(Exception e){
            message = e.toString();
        }
    }

    /**
     * @param cmids
     * @return
     * 2005-11-4 17:25:10 Made In GamVan
     * com.gamvan.club.message
     */
    public boolean takeDel(String cmids[]){
        boolean bea = false;
        if(cmids==null){
            message = "请选定你要删除的短消息。";
            return bea;
        }       
        Collection clt = new ArrayList();
        for(int i=0; i<cmids.length; i++){
            //cmid.append("," + cmids[i]);
            clt.add(cmids[i]);
        }
        try{
	        int i = cmtim.messageTakeDel(clt);
	        message = String.valueOf(i)+" 条消息被成功删除！";
        }catch(Exception e){
        	message = "消息删除失败！";
        }
        return bea;
    }  
    
    public void takeDel_userid(int userid){
    	cmtim.messageTakeDel_userid(userid);
    }
    
    /**
     * 根据接收用户ID读取收件箱消息列表
     * @param page
     * @param pageNum
     * @return
     * 2005-11-4 17:11:22 Made In GamVan
     */
    public List takeList(int page, int pageNum){
    	List list = null;
        try{
            list = cmtim.messageTakeList(page, pageNum, cmTakeID, null);
        }catch(Exception e){
            message = e.toString();
        }
        return list;
    }
    
    
    /**
     * 统计总数为了分页
     * @return
     * 2005-11-4 17:14:37 Made In GamVan
     * com.gamvan.club.message
     */
    public int takeCount(){
        int i = 0;
        try{
            i = cmtim.messageTakeCount(cmTakeID, null);
        }catch(Exception e){
            message = e.toString();
        }
        return i;
    }
    
    
    /**
     * 根据消息ID列出所有回复此消息的消息列表
     * @param page
     * @param pageNum
     * @return
     * 2005-11-4 17:17:44 Made In GamVan
     * com.gamvan.club.message
     */
    public List takeReList(int page, int pageNum){
        List list = null;        
        if(cmReID==0){
            return null;
        }
        try{
            list = cmtim.messageTakeReList(page, pageNum, cmReID);        
        }catch(Exception e){
            list = null;
            message = e.toString();
        }
        return list;
    }
    
    /**
     * 统计为了分页
     * @return
     * 2005-11-4 17:21:26 Made In GamVan
     * com.gamvan.club.message
     */
    public int takeReCount(){
        int i = 0;
        if(cmReID==0){
            return 0;
        }
        try{
            i = cmtim.messageTakeReCount(cmReID);       
        }catch(Exception e){
            message = e.toString();
        }
        return i;
    } 
    
    /**
     * 查询用户是否有新短消息。
     * @param takeid 接收方用户注册ID
     * @return
     * @throws Exception
     */
    public ClubMessageTakeItem newMessage(int takeid){
        ClubMessageTakeItem cmti = null;
        try{
        	List list = cmtim.messageTakeList(1, 10, takeid, new Boolean(false));
            Iterator it = list.iterator();
            if(it.hasNext()){
                cmti = (ClubMessageTakeItem)it.next();
            }
        }catch(Exception e){
            message = e.toString();
        }
        return cmti;
    }
    
    
    /**
     * 提取消息详细内容
     * @param cmid
     * @return
     * 2005-11-4 18:39:32 Made In GamVan
     * com.gamvan.club.message
     */
    public ClubMessageTakeItem takeMessageInfo(int cmid){
        ClubMessageTakeItem cmti = null;
        try{
            cmti = cmtim.messageTakeInfo(cmid);
        }catch(Exception e){
            message = e.toString();
        }
        return cmti;
    }
    
    
    public String getMessage() {
        return message;
    }
    
    
    /* test
    public static void main(String args[]){
        ClubMessageTake cmk = new ClubMessageTake();
        ClubMessageTakeItem cmti = null;
        cmti = (ClubMessageTakeItem)cmk.takeMessageInfo(137);
        System.out.print(cmti.getCmTopic());
    
    }
    */
    /* 废弃此方法
    public void takeDels(String cmid){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        try{
            Connection con=session.connection();  
            PreparedStatement stmt=con.prepareStatement("delete from GVclubMessageTake where cmID in ("+ cmid +")");  
            int i = stmt.executeUpdate();  
            tran.commit(); 
            message = i + " 条记录被成功删除!";
        }catch(Exception e){
            message = "执行删除发生意外错误：<br/>"+e.toString();
        }
    }
    */ 
    
}
