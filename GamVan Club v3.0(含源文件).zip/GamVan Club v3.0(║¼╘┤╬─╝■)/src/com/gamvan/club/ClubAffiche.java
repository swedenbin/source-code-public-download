package com.gamvan.club;
import java.util.Iterator;
import java.util.List;
import com.gamvan.club.dao.impl.ClubAfficheImpl;
import com.gamvan.club.item.ClubAfficheItem;
import com.gamvan.html.OutPrint;

/**
 * 
 * Created on 2006-1-22
 * Powered by GamVan.com
 */
public class ClubAffiche extends ClubAfficheItem{
    private static final long serialVersionUID = 1L;
    private String message = "";
    private ClubAfficheImpl caim = new ClubAfficheImpl();
    
    /**
     * 生成论坛版面一条条滚动的公告HTML
     * @param
     * @return
     * 2006-1-22 18:52:35
     * @author GamVan Studio by 我容易么我
     */
    public String afficheMarquee(int ccid, int num){
        StringBuffer temp = new StringBuffer();
        ClubAfficheItem cai = null;
        try{
             StringBuffer temp2 = new StringBuffer();
             List list = caim.afficheList(1, num, ccid);
             Iterator it = list.iterator();
             temp2.append("<script language=\"javascript\">");
             temp2.append("var marqueeContent=new Array();");
             int i = 0;
             String dateHtml = "";
             while(it.hasNext()){
                 cai = (ClubAfficheItem)it.next();
                 dateHtml = OutPrint.isDateHtml(cai.getCaAddTime());
                 temp2.append("marqueeContent["+i+"]='<a href=clubAfficheInfo.jsp?ccID="+ ccid + "&caID="+ cai.getCaID());
                 temp2.append(" target=_blank>" + cai.getCaTopic() +"</a>&nbsp;");
                 temp2.append("<span style=color:#990066 >"+ dateHtml + "</span><br>';");
                 i++;
             }
             temp2.append("</script>");
             temp.append(temp2);
         }catch(Exception e){
             e.printStackTrace();
             temp.append("暂无公告！");
         }
        temp.append("<script language=\"javascript\" src=\"./GVscript/marquee.js\"></script>");         
        return temp.toString();
    }
    
   /**
    * 分页显示
    * @param
    * @return
    * 2006-1-22 18:53:35
    * @author GamVan Studio by 我容易么我
    */
    public List afficheList(int page, int pageNum){
        List list = null;
        try{
            list = caim.afficheList(page, pageNum, ccID);
        }catch(Exception e){
             e.printStackTrace();
       }
       return list;
    }
    
    /**
     * 
     * @param
     * @return
     * 2006-1-22 18:46:31
     * @author GamVan Studio by 我容易么我
     */
    public int afficheCount(){
       /* 计算从第几条记录开始读取数据 */   
       int i = caim.afficheCount(ccID);
       return i;
    }

    public String getMessage() {
        return message;
    }
    
    /* test
     public static void main(String args[]){
         ClubAffiche ca = new ClubAffiche();
         ca.setCcID(1);
         try {
             System.out.print(ca.afficheMarquee(1,10));
         } catch (Exception e) {
             e.printStackTrace();
         }
     }
     */    
}