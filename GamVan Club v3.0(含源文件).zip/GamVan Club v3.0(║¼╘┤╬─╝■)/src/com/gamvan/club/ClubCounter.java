package com.gamvan.club;

import com.gamvan.club.dao.impl.ClubCounterImpl;
import com.gamvan.club.item.ClubCounterItem;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubCounter extends ClubCounterItem{

    private static final long serialVersionUID = 1L;
    private static ClubCounterImpl ccil = new ClubCounterImpl();
    
    /**
     * 
     * @param hits
     * @param tpv
     * @param ct
     * @param cr
     * @param cb
     * @param cg
     * @param cm
     * @param nu
     * com.gamvan.club
     */
    public void counterUpdate(int hits, int tpv, int ct, int cr,
            int cb, int cg, int cm, String nu)
    {
    	ccil.counterUpdate(hits, tpv, ct, cr, cb, cg, cm, nu);
    }
    
 
    public ClubCounterItem clubCounterInfo(){
    	ClubCounterItem cci = ccil.clubCounterInfo();
    	return cci;
    }

    /*
    public static void main(String args[]){
        ConnClub.init();
        ClubCounter ccu = new ClubCounter();
        System.out.print(ccu.clubCounterInfo());
    }
    */
}


