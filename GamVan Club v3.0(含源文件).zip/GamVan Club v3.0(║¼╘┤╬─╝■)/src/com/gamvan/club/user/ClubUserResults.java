/*
 * Created on 2005-7-9
 * Made In GamVan
 */
package com.gamvan.club.user;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.gamvan.club.dao.impl.ClubUserImpl;
import com.gamvan.club.item.ClubUserItem;
import com.gamvan.conn.ConnClub;

public class ClubUserResults extends ClubUserItem{
    
    private static final long serialVersionUID = 1L;
    private String keys = "";
    private String keys_ip = "";
    private int order = 0;
    private ClubUserImpl cuim = new ClubUserImpl();
    
    public void setKeys_ip(String keys_ip) {
        this.keys_ip = keys_ip;
    }

    public void setKeys(String keys) {
        this.keys = keys;
    }


    public List userList(int page, int pageNum){
        List list = null;
        try{
        	list = 
        	cuim.userList(page, pageNum, order, keys, keys_ip, userSex, userAreaId);
        }catch(HibernateException e){
            e.printStackTrace();
        }      
        return list;
    }
    
    
    public int userCount(){
        int i = 0;
        try{
            i = cuim.userCount(keys, keys_ip, userSex, userAreaId);
        }catch(HibernateException e){
            i = 0;
            e.printStackTrace();
        }       
        return i;
    }  
 
    
    /**
     * 
     * @param PageNum 每页显示数量    
     * @param page 当前页
     * @return
     * @throws Exception
     */
    public Collection userQuery(int userid)
    {
        Collection collection = new ArrayList();
        Session session = ConnClub.getSession();
         try{
             Criteria criteria = session.createCriteria(ClubUserItem.class);
             criteria.add(Restrictions.eq("userID", new Integer(userid)));
             List list = criteria.list();
             Iterator it = list.iterator();
             while(it.hasNext()){
                 ClubUserItem cui = (ClubUserItem)it.next();
                 collection.add(cui);
             }
        }catch(HibernateException e){
  
        }
       return collection; 
    }
    
    /**
     * 
     * @param page 当前页
     * @param pageNum 每页显示数目
     * @return Collection
     */
    public Collection userQuery(int page, int pageNum)
    {
        /* 计算从第几条记录开始读取数据 */
        int startRow = pageNum * page - pageNum;
        int endRow  = pageNum;
        
        Collection clt = new ArrayList();
        Session session = ConnClub.getSession();
         try{
             Criteria criteria = session.createCriteria(ClubUserItem.class);
             criteria.addOrder(Order.desc("userID"));
             criteria.setFirstResult(startRow); //从第N条开始读取
             criteria.setMaxResults(endRow); //从到第N条结束
             List list = criteria.list();
             Iterator it = list.iterator();
             while(it.hasNext()){
                 ClubUserItem cui = (ClubUserItem)it.next();
                 clt.add(cui);
             }  
        }catch(Exception e){
            
        }
       return clt; 
    } 

    /**
     * @return
     * 2005-11-5 20:21:51 Made In GamVan
     * com.gamvan.club.user
     */
    public ClubUserItem userInfo(){
        ClubUserItem cui = null;
        try{
            cui = cuim.userInfo(this.userID);
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return cui;
    }

    /* test
    public static void main(String args[]){
        ClubUserCollection cuc = new ClubUserCollection();
        cuc.setKeys_ip("61");
        cuc.userList(1,30);
    }
    */
}
