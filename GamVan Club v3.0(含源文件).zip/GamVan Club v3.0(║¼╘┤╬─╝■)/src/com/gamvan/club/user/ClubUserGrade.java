/*
 * Created on 2005-8-3
 * Made In GamVan
 */
package com.gamvan.club.user;
import java.util.Iterator;
import java.util.List;

import com.gamvan.club.item.ClubUserGradeItem;
import com.gamvan.conn.*;

import org.hibernate.CacheMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class ClubUserGrade extends ClubUserGradeItem{
    private static final long serialVersionUID = 1L;
    private String message;
    public void ugNameUpdate(){
        if(ugName==null || ugName.trim().equals("")){
            message = "发生错误，更新操作中止：等级名称不能为空";
            return;
        }
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        Transaction tran = session.beginTransaction();
        try{
            hql.append("update ClubUserGradeItem set ugName=? ");
            hql.append(" where ugID=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, ugName)
            .setInteger(1, ugID)
            ;

            query.executeUpdate();
            tran.commit();
            message = "更新成功！";
        }catch(HibernateException e){
            message =  "更新失败！<br/>" + e.toString();
        }
    }

    /**
     * 
     * @param ugID
     * @throws Exception
     */
    public void userGradeEdit(int ugid){
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        Transaction tran = session.beginTransaction();
        try{
            hql.append("update ClubUserGradeItem set ugTxt=? ");
            hql.append(" where ugID=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, ugTxt)
            .setInteger(1, ugid)
            ;
            query.executeUpdate();
            tran.commit();
            message = "更新成功！";
        }catch(HibernateException e){
            message =  "更新失败！<br/>" + e.toString();
        }finally{
            ConnClub.closeSession();
        }
    }
    
    /**
     * 
     */
    public ClubUserGradeItem userGradeInfo(int ugid){
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        ClubUserGradeItem cugi = new ClubUserGradeItem();
        try{
            hql.append("from ClubUserGradeItem where ugID=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, ugid);
            //启用查询缓存
            query.setCacheable(true); 
            //为查询指定其命名的缓存区域
            query.setCacheRegion("gradeCache");
            //* 从二级缓存读写数据
            query.setCacheMode(CacheMode.NORMAL);
            List list = query.list();
            Iterator it = list.iterator();
            if(it.hasNext()){
                cugi =  (ClubUserGradeItem)it.next();
            }else{
                cugi = null;
            }
            session.flush();
        }catch(Exception e){
            cugi = null;
        }
        return cugi;
    } 
    
    /**
     * 
     * @return
     */
    public List userGradeList(){
        List list = null;
        Session session = ConnClub.getSession();
         try{
            StringBuffer hql = new StringBuffer();
            hql.append("from ClubUserGradeItem order by ugID");
            Query query = session.createQuery(hql.toString());
            //启用查询缓存
            query.setCacheable(true); 
            //为查询指定其命名的缓存区域
            query.setCacheRegion("gradeCache");
            //* 从二级缓存读写数据
            query.setCacheMode(CacheMode.NORMAL);
            list = query.list();
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return list;
    } 
    
   /* test 
    public static void main(String args[]){
        ClubUserGrade cug = new ClubUserGrade();
        cug.userGradeList();

        
    }   
    */

    public String getMessage(){
        return this.message;
    }
}
