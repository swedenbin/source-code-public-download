/*
 * Made in GamVan
 * 注册用户参数修改
 */
package com.gamvan.club.user;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.item.ClubUserItem;
import com.gamvan.conn.ConnClub;


/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubUserParameter extends ClubUserItem{

    private static final long serialVersionUID = 1L;
    
    /**
     * no...int类型判断是否更新某项
     */
    private int noEditc=0, noEditmn=0, noEditmk=0, noEdituf;
    
    /* 注册信息更新方式 2累加更新  1覆盖更新 */
    private int actType = 0;
    
    private int noEditufz=0;
    
    /* 判断是否更新上传权限 */
    private int noEditup = 0;
    
    private String message = new String();

    
    
    
    /**
     * 这个方法关系复杂放在DAO里没什么意义。
     * @param username
     * 2005-11-3 22:56:49 Made In GamVan
     */
    public void userParameter(String username){
       int i = 0;
       StringBuffer hql = new StringBuffer();
       ClubUsers cu = new ClubUsers();
       try{
           if(username.equals("*")){
               hql.append("update ClubUserItem set userName=userName");
               if(noEditup!=-1){
                   hql.append(", userUpfileOpen="+ userUpfileOpen +"");
                   hql.append(", userPicIs="+ userPicIs +"");
               }
               if(actType==1){
                   if(noEditc==1){
                       hql.append(", userCredit="+ userCredit +"");
                   }
                   if(noEditmn==1){
                       hql.append(", userMoney="+ userMoney +"");
                   }
                   if(noEditmk==1){
                       hql.append(", userMark="+ userMark +"");
                   }
                   if(noEdituf==1){
                       hql.append(", userUpfile="+ userUpfile +"");
                   }
                   if(noEditufz==1){
                       hql.append(", userUpfileSize="+ userUpfileSize +"");
                   }   
               }else if(actType==2){
                   if(noEditc==1){
                       hql.append(", userCredit= userCredit + "+ userCredit +"");
                   }
                   if(noEditmn==1){
                       hql.append(", userMoney= userMoney + "+ userMoney +"");
                   }
                   if(noEditmk==1){
                       hql.append(", userMark= userMark + "+ userMark +"");
                   } 
                   if(noEdituf==1){
                       hql.append(", userUpfile= userUpfile + "+ userUpfile +"");
                   } 
                   if(noEditufz==1){
                       hql.append(", userUpfileSize= userUpfileSize + "+ userUpfileSize +"");
                   }    
               }
               try{
	               Session session = ConnClub.getSession();
	               Transaction tran = session.beginTransaction();
	               Query query = session.createQuery(hql.toString())                ;
	               i = query.executeUpdate();
	               tran.commit();
               }catch(Exception e){
                   message = "系统遭遇一个美丽的错误，操作被意外中止！<br/>"+e.toString();
               }
           }else{
               ClubUserItem cui = null;
               cui = cu.userInfo(username);
               if(cui==null){
                   message = "操作失败，用户ID：<strong>"+ username +"</strong> 没有注册或已被删除！";
               }else{
                       hql.append("update ClubUserItem set userName=userName");
                       if(noEditup!=-1){
                           hql.append(", userUpfileOpen="+ userUpfileOpen +"");
                           hql.append(", userPicIs="+ userPicIs +"");
                       }  
                       if(actType==1){
                           if(noEditc==1){
                               hql.append(", userCredit="+ userCredit +"");
                           }
                           if(noEditmn==1){
                               hql.append(", userMoney="+ userMoney +"");
                           }
                           if(noEditmk==1){
                               hql.append(", userMark="+ userMark +"");
                           }
                           if(noEdituf==1){
                               hql.append(", userUpfile="+ userUpfile +"");
                           }
                           if(noEditufz==1){
                               hql.append(", userUpfileSize="+ userUpfileSize +"");
                           }   
                       }else if(actType==2){
                           if(noEditc==1){
                               hql.append(", userCredit= userCredit + "+ userCredit +"");
                           }
                           if(noEditmn==1){
                               hql.append(", userMoney= userMoney + "+ userMoney +"");
                           }
                           if(noEditmk==1){
                               hql.append(", userMark= userMark + "+ userMark +"");
                           } 
                           if(noEdituf==1){
                               hql.append(", userUpfile= userUpfile + "+ userUpfile +"");
                           } 
                           if(noEditufz==1){
                               hql.append(", userUpfileSize= userUpfileSize + "+ userUpfileSize +"");
                           }    
                       }
                        hql.append("  where userName=?");
                    try{
                        Session session = ConnClub.getSession();
                        Transaction tran = session.beginTransaction();
                        Query query = session.createQuery(hql.toString())
                        .setString(0, username);
                        i = query.executeUpdate();
                        tran.commit();
                        //message = hql.toString();
                   }catch(Exception e){
                       message = "系统遭遇一个美丽的错误，操作被意外中止！<br/>"+e.toString();
                   }
               }
           }
           message = i + " 条记录更新成功！";
       }catch(Exception e){
           message = "系统遭遇一个美丽的错误，操作被意外中止！<br/>"+e.toString();
       }       
    }
    
    
    
    
    /**
     * @param username
     * 2005-11-3 22:56:49 Made In GamVan
     */
    public void userParameter(int userid){
       int i = 0;
       StringBuffer hql = new StringBuffer();
       ClubUsers cu = new ClubUsers();
       try{
           if(userid==-1){
               hql.append("update ClubUserItem set userName=userName");
               if(noEditup!=-1){
                   hql.append(", userUpfileOpen="+ userUpfileOpen +"");
                   hql.append(", userPicIs="+ userPicIs +"");
               }
               if(actType==1){
                   if(noEditc==1){
                       hql.append(", userCredit="+ userCredit +"");
                   }
                   if(noEditmn==1){
                       hql.append(", userMoney="+ userMoney +"");
                   }
                   if(noEditmk==1){
                       hql.append(", userMark="+ userMark +"");
                   }
                   if(noEdituf==1){
                       hql.append(", userUpfile="+ userUpfile +"");
                   }
                   if(noEditufz==1){
                       hql.append(", userUpfileSize="+ userUpfileSize +"");
                   }   
               }else if(actType==2){
                   if(noEditc==1){
                       hql.append(", userCredit= userCredit + "+ userCredit +"");
                   }
                   if(noEditmn==1){
                       hql.append(", userMoney= userMoney + "+ userMoney +"");
                   }
                   if(noEditmk==1){
                       hql.append(", userMark= userMark + "+ userMark +"");
                   } 
                   if(noEdituf==1){
                       hql.append(", userUpfile= userUpfile + "+ userUpfile +"");
                   } 
                   if(noEditufz==1){
                       hql.append(", userUpfileSize= userUpfileSize + "+ userUpfileSize +"");
                   }    
               }
               try{
	               Session session = ConnClub.getSession();
	               Transaction tran = session.beginTransaction();
	               Query query = session.createQuery(hql.toString())                ;
	               i = query.executeUpdate();
	               tran.commit();
               }catch(Exception e){
                   message = "系统遭遇一个美丽的错误，操作被意外中止！<br/>"+e.toString();
               }
           }else{
               ClubUserItem cui = null;
               cui = cu.userInfo(userid);
               if(cui==null){
                   //message = "操作失败，用户没有注册或已被删除！";
               }else{
                       hql.append("update ClubUserItem set userName=userName");
                       if(noEditup!=-1){
                           hql.append(", userUpfileOpen="+ userUpfileOpen +"");
                           hql.append(", userPicIs="+ userPicIs +"");
                       }  
                       if(actType==1){
                           if(noEditc==1){
                               hql.append(", userCredit="+ userCredit +"");
                           }
                           if(noEditmn==1){
                               hql.append(", userMoney="+ userMoney +"");
                           }
                           if(noEditmk==1){
                               hql.append(", userMark="+ userMark +"");
                           }
                           if(noEdituf==1){
                               hql.append(", userUpfile="+ userUpfile +"");
                           }
                           if(noEditufz==1){
                               hql.append(", userUpfileSize="+ userUpfileSize +"");
                           }   
                       }else if(actType==2){
                           if(noEditc==1){
                               hql.append(", userCredit= userCredit + "+ userCredit +"");
                           }
                           if(noEditmn==1){
                               hql.append(", userMoney= userMoney + "+ userMoney +"");
                           }
                           if(noEditmk==1){
                               hql.append(", userMark= userMark + "+ userMark +"");
                           } 
                           if(noEdituf==1){
                               hql.append(", userUpfile= userUpfile + "+ userUpfile +"");
                           } 
                           if(noEditufz==1){
                               hql.append(", userUpfileSize= userUpfileSize + "+ userUpfileSize +"");
                           }    
                       }
                        hql.append("  where userID=?");
                    try{
                        Session session = ConnClub.getSession();
                        Transaction tran = session.beginTransaction();
                        Query query = session.createQuery(hql.toString())
                        .setInteger(0, userid);
                        i = query.executeUpdate();
                        tran.commit();
                   }catch(Exception e){
                       message = "系统遭遇一个美丽的错误，操作被意外中止！<br/>"+e.toString();
                   }
               }
           }
           message = i + " 条记录更新成功！";
       }catch(Exception e){
           message = "系统遭遇一个美丽的错误，操作被意外中止！<br/>"+e.toString();
       }       
    }
    
    
    
    
    /* test 
    public static void main(String args[]){
        ClubUserParameter cup = new ClubUserParameter();
        cup.setUserUpfileSize(10);
        cup.setNoEditufz(1);
        cup.setActType(2); //用户参数累加
        cup.userParameter("今晚在线");
        System.out.print(cup.getMessage());
    }
    */
    
    
    public String getMessage(){
        return this.message;
    }
 
    public void setNoEditc(int noEditc){
        this.noEditc=(noEditc);
    }
    public void setNoEditmn(int noEditmn){
        this.noEditmn=(noEditmn);
    }
    public void setNoEdituf(int noEdituf){
        this.noEdituf = (noEdituf);
    }
    
    public void setNoEditmk(int noEditmk){
        this.noEditmk = noEditmk;
    } 
    
    public void setActType(int actType){
       this.actType = actType;
    } 

    
    public void setNoEditufz(int noEditufz){
        this.noEditufz = noEditufz;
    }

    public void setNoEditup(int noEditup) {
        this.noEditup = noEditup;
    } 


}
