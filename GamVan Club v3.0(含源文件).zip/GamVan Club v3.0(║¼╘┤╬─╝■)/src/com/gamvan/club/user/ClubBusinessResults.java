/*
 * Created on 2005-10-10
 * Made In GamVan
 */
package com.gamvan.club.user;

import java.util.List;

import com.gamvan.club.dao.impl.ClubBusinessImpl;
import com.gamvan.club.item.ClubBusinessItem;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubBusinessResults extends ClubBusinessItem{
    private static final long serialVersionUID = 1L;
    private ClubBusinessImpl cbim = new ClubBusinessImpl();
    
    public List businessList(int page, int pageNum){
    	List list = null;
        try{
            list = cbim.businessList(page, pageNum, userID, businessType);
        }catch(Exception e){
            e.printStackTrace();            
        }
        return list;
    }

    
    public int businessCount(){
        int i = 0;
        try{
            i = cbim.businessCount(userID, businessType);
        }catch(Exception e){
            e.printStackTrace();            
        }
        return i;
    }
}
