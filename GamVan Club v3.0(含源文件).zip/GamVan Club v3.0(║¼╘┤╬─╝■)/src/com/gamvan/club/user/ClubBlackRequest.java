package com.gamvan.club.user;

import com.gamvan.tools.FormatDateTime;
public class ClubBlackRequest {
    private String message = "";
    //格式化当前时间
    private String now= FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    
}