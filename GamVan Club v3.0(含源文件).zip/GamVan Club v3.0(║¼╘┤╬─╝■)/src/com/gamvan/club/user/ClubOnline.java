package com.gamvan.club.user;

import java.util.List;

import com.gamvan.club.dao.impl.ClubOnlineImpl;
import com.gamvan.club.item.ClubOnlineItem;
import com.gamvan.tools.FormatDateTime;
import com.gamvan.tools.TypeChange;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubOnline extends ClubOnlineItem{
    private static final long serialVersionUID = 1L;
    
    private String message = "";
    private int timeOut = 120; //设置超时退出
    private String now= FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    private int onlines = 0;
    private ClubOnlineImpl colim = new ClubOnlineImpl();
    private long ymdhms = 0; //最后动作
    private long ymdhms_ = 120; //超时
	
    /*
    public static void main(String args[]){
    	 System.out.println(ymdhms);
    	 System.out.println(FormatDateTime.dateAdd("s",-6000,"ddHHmmss"));
    }
    */
    
    private void getYmdhms(){
    	String YMDHMS = FormatDateTime.formatDateTime("yMMddHHmm");
    	this.ymdhms = TypeChange.stringToInt(YMDHMS); //最后动作
    	this.ymdhms_ = TypeChange.stringToInt(
    			FormatDateTime.dateAdd("s",-timeOut,"yMMddHHmm")); //超时
    }
    
    /**
     * 更新或者添加在线人员
     * 2005-12-1 21:19:30 Made In GamVan
     * com.gamvan.club.user
     */
    public void onlineUpdate(){
    	getYmdhms();
        if(isOnline(2)){
        	colim.onlineUpdate(2, sessionID, userip, onUserID, userName, now, ymdhms, userArea);
        }else{
        	colim.onlineAdd(sessionID, userip
            		, onUserID, userName
            		, userHide, now
            		, now, ymdhms, userArea
            		);
        }
        /* 清理超时人员离线 */
        offline();
        this.onlines = colim.onlineCount();
    }
    
    private void offline(){
    	getYmdhms();
    	colim.onlineDelTimeout(ymdhms_);
    }
    
    /**
     * 在线人员列表
     * @param page
     * @param pageNum
     * @return
     * 2005-12-1 21:27:29 Made In GamVan
     * com.gamvan.club.user
     */
    public List onlineList(int page, int pageNum){
        List list = null;  
        try{
            list = colim.onlineList(page, pageNum);
        }catch(Exception e){
            e.printStackTrace();
        }
        return list;
    }
    
    /**
     * 确定是否在线
     * @param type 1按用户Ip, 2按照sessionid, 3用户ID
     * @return
     * 2005-12-2 0:13:50 Made In GamVan
     * com.gamvan.club.user
     */
    public boolean isOnline(int type){
        boolean bea = false;
        try{
        	if(type==1){
                if(colim.onlineInfo(null,userip,0)!=null){
                	bea = true;
                }
        	}
        	else if(type==2){
                if(colim.onlineInfo(sessionID,null,0)!=null){
                	bea = true;
                }
        	}
        	else if(type==3){
        		com.gamvan.club.item.ClubOnlineItem coli = 
        			colim.onlineInfo(null,null,onUserID);
                if(coli!=null){
                	this.userHide = coli.getUserHide();
                	bea = true;
                }
        	}
        }catch(Exception e){
            message = e.toString();
        }
        return bea;
    }
    
    
    public String getMessage(){
        return this.message;
    }
    public int getOnlines() {
        return onlines;
    }
    public void setOnlines(int onlines) {
        this.onlines = onlines;
    }
    public void setTimeOut(int timeOut) {
        this.timeOut = timeOut;
    }
    
    /*
    public static void main(String args[]){
        ClubOnline col = new ClubOnline();
        col.allOnlines();
    }
    */
}
