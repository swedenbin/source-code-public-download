/*
 * Created on 2005-9-20
 * Made In GamVan
 */
package com.gamvan.club.user;

import java.util.List;

import com.gamvan.club.dao.impl.ClubFriendsImpl;
import com.gamvan.club.item.ClubFriendsItem;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubFriendsResults  extends ClubFriendsItem{
    private static final long serialVersionUID = 1L;
    private ClubFriendsImpl cfim  = new ClubFriendsImpl();
    
    /**
     * 
     * @param page
     * @param pageNum
     * @return
     * 2005-12-1 18:55:00 Made In GamVan
     * com.gamvan.club.user
     */
    public List  myFriendsList(int page, int pageNum){
        List list = null;
        try{
            list = cfim.friendsList(page, pageNum, " order by cfID desc", userMeID, -1);   
        }catch(Exception e){
            list = null;
        }
        return list;
    }
    
    /**
     * 
     * @return
     * 2005-12-1 18:55:04 Made In GamVan
     * com.gamvan.club.user
     */
    public int  myFriendsListCount(){
        int i = 0;
        i = cfim.friendsCount(userMeID, -1, "");
        return i;
    }
}
