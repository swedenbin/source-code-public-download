/*
 * Created on 2005年2月2日, 下午9:24
 * Last modified on 2005-12-27
 * Made in GamVan 今晚制造 
 * www.GamVan.com
 */
package com.gamvan.club.user;
import com.gamvan.club.dao.impl.ClubUserImpl;
import com.gamvan.club.message.ClubMessageSend;
import com.gamvan.club.message.ClubMessageTake;
import com.gamvan.club.topic.ClubTopicManage;
import com.gamvan.tools.TypeChange;

/**
 * 用户删除部分暂时没有对用户短消息，以及用户订阅的文章删除。
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubUserDel {
    String act = "0", message=""; //判断删除类型 1逻辑删除 2物理删除
    int doTopic = 0;
    private final ClubTopicManage ctm = new ClubTopicManage();
    private final ClubMessageSend cms = new ClubMessageSend();
    private final ClubMessageTake cmt = new ClubMessageTake();
    private final ClubUserImpl cuim = new ClubUserImpl();
    
    public void userDel(String userids[]){
        int userid = 0;
        for (int i = 0; i < userids.length; i++) {
            //uid += "," + userids[i]; //将取得的用户ID数组转换成,分割的字符串数组
            // 取得每个ID的用户名开始
            userid = TypeChange.stringToInt(userids[i]);
            //判断动作
            if(act.equals("1")){
                delUsers1(userid, true);//逻辑删除
            }
            else if(act.equals("2")){
                delUsers2(userid);//物理删除用户
            }
            else if(act.equals("3")){
                delUsers1(userid, false);//恢复逻辑删除
            }
            userTopicID(userid);
        } 
        if(message.equals("")){ 
            message="所选用户已被成功删除！";
        }
    }
    
    /**
     * 对用户发表的文章执行操作
     * @param userid
     */
    public void userTopicID(int userid){
        if(doTopic==1){
            ctm.topicFieldUpdate_userid(userid,1,2); //删除主题
            ctm.topicFieldUpdateRe_userid(userid,1,2); //删除回复
        }
        else if(doTopic==2){
            ctm.topicFieldUpdate_userid(userid,5,0); //屏闭主题
            ctm.topicFieldUpdateRe_userid(userid,5,0); //屏闭回复
        }
        else if(doTopic==3){
            ctm.topicFieldUpdate_userid(userid,0,2); //恢复被删除、屏闭的发言
            ctm.topicFieldUpdateRe_userid(userid,0,2); 
        }
        message = "操作成功";
    }

    
    /**
     * 标记删除用户
     * @param userid
     * @param isDel
     * @return
     */
    public boolean delUsers1(int userid, boolean isdel){
        boolean bea = false;
        try{
            cuim.userUpdate_isDel(userid, isdel);
        }catch(Exception e){
            message = e.toString();
            e.printStackTrace();
        }
        return bea;
    }
    
    
    /**
     * 物理删除用户
     * @param userid
     * @return
     * 2005-12-27 11:03:55 Made In GamVan
     * com.gamvan.club.user
     */
    public boolean delUsers2(int userid){
        boolean bea = false;
        try{
           bea = cuim.userDel(userid);
        }catch(Exception e){
            message = e.toString();
        }
        /* 删除用户短消息相关数据 */
        cms.sendDel_userid(userid);
        cmt.takeDel_userid(userid);
        return bea;
    }
    
    
    public String getMessage(){
        return this.message;
    }
    public void setAct(String act){
        this.act = act;
    }

    public void setDoTopic(int doTopic) {
        this.doTopic = doTopic;
    }
}
