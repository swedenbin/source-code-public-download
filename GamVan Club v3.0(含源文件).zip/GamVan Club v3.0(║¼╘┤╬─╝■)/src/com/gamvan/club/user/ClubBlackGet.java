/*
 * ClubBlackList.java
 * www.GamVan.com
 * Created on 2005年3月1日, 上午2:12
 */
package com.gamvan.club.user;
import com.gamvan.club.item.ClubBlackItem;
import com.gamvan.conn.*;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
public class ClubBlackGet extends ClubBlackItem{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    ConnClub bridge = new ConnClub();
    
    
    /**
     * 
     * @param uName
     * @param info
     * @return
     */
    public Object clubBlackSelect(String uName){
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();  
        ClubBlackItem cbi = new ClubBlackItem();
        try{
            hql.append("from ClubBlackItem where ");
            hql.append(" blackUserName=?");
            hql.append(" and ccID=?");
            hql.append(" order by blackOver, blackDate desc, blackId desc");
            Query query = session.createQuery(hql.toString())
            .setString(0, uName)
            .setInteger(1, ccID);
            ;
            Iterator it = query.iterate();
            if(it.hasNext()){
               cbi = (ClubBlackItem)it.next();
            }else{
                cbi = null;
            }
            /*
            sqlCommand = "select * From GVclubBlackList ";
            sqlCommand += " where blackUserName=? and datediff(d,byAddTime,getdate()) < "
            + " blackDate and blackOver=0 order by blackOver, blackDate desc, bID desc";
            */
        }catch(Exception e){
            cbi = null;
        }finally{
            
        }
        return cbi;
    }
    
    public Object clubBlackSelect(int userid){
        //ConnClub bridge = new ConnClub();
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();  
        ClubBlackItem cbi = new ClubBlackItem();
        try{
            hql.append("from ClubBlackItem as cbi where");
            hql.append(" cbi.userID=?");
            hql.append(" and cbi.ccID=? ");
            
            hql.append(" order by blackOver, blackId desc");
            Query query =  session.createQuery(hql.toString())
            .setInteger(0, userid)
            .setInteger(1, ccID)
            ;
            List list = query.list();
            //Iterator it = query.iterate();
            Iterator it = list.iterator();
            if(it.hasNext()){
                cbi = (ClubBlackItem)it.next();
            }
            else{
                cbi = null;
            }
        }catch(Exception e){
            e.printStackTrace();
            cbi = null;
        }finally{
            ConnClub.closeSession();
        }
        return cbi;
        
    }

    //=========================================================
    public Object clubBlackBid(int bid){
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();  
        ClubBlackItem cbi = new ClubBlackItem();
        try{
            hql.append("from ClubBlackItem where blackId=?");
            Query query = session.createQuery(hql.toString())
            .setInteger(0, bid)
            ;
            Iterator it = query.iterate();
            if(it.hasNext()){
                cbi = (ClubBlackItem)it.next();
            }else{
                cbi = null;
            }
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            ConnClub.closeSession();
        }
        return cbi;
    }

    /* test
    public static void main(String args[]){
        ClubBlackGet cbg = new ClubBlackGet();
        ClubBlackItem cbi = new ClubBlackItem();
        cbg.setCcID(7);
        cbi = (ClubBlackItem)cbg.clubBlackSelect(2437);
        System.out.print(cbi.getBlackDate());
    }
    */
        
   
    
    
}
