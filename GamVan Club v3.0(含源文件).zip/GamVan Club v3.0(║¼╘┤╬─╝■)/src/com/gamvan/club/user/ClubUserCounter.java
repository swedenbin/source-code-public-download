/* 
 * 2005-11-18
 * Made in GamVan
 */
package com.gamvan.club.user;

import java.util.Iterator;
import java.util.List;

import com.gamvan.club.group.GroupCollection;
import com.gamvan.club.group.GroupEdit;
import com.gamvan.club.item.GroupItem;
import com.gamvan.conn.ConnClub;

/**
 * 批量统计用户地区人数
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubUserCounter {
	private String message = "";
	
	private ClubUserResults cur = new ClubUserResults();
	private GroupEdit ge = new GroupEdit();
	private GroupCollection gc = new GroupCollection();
	
	public void userCounter(String act){
		if(act.equals("1")){
			userAreaCount();
		}
		
	}
	
	
	/**
	 * 批量统计
	 * @param page 当前页
	 * @param pageNum 每页的人数
	 * 2005-11-18 1:57:05 Made In GamVan
	 * com.gamvan.club.user
	 */
	public void userAreaCount(){
		int i = 0;
		int all = 0;
		gc.setGroupLayer(0);
		gc.setGroupType(1);
		List list = gc.groupList();
		try{	
			Iterator it = list.iterator();
			int user_areaid = 0;
			while(it.hasNext()){
				GroupItem gi = (GroupItem)it.next();
				user_areaid = gi.getGroupID();
				cur.setUserSex((byte) -1);
				cur.setUserAreaId(user_areaid);
				i = cur.userCount();
				ge.groupCountUpdate(user_areaid, i, 2);
				all += i;
				ConnClub.getSession().evict(gi);
			}		
			message = "总共统计到注册时正确填写地区的用户数 "+all+" 个";
		}catch(Exception e){
			e.printStackTrace();
			message = e.toString();
		}
	}
	
	/* test
	public static void main(String args[]){
		ConnClub.init();
		ClubUserAreaCount cuac = new ClubUserAreaCount();
		cuac.userAreaCount();
		ConnClub.closeSession2();
	}
	*/
	
	public String getMessage() {
		return message;
	}
}
