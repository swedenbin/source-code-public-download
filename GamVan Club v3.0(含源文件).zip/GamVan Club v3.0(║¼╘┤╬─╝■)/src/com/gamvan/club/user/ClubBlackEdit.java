/*
 * ClubBlackEdit.java
 * Created on 2005年3月6日, 下午6:11
 */
package com.gamvan.club.user;

public class ClubBlackEdit {
    String message = new String();

}
