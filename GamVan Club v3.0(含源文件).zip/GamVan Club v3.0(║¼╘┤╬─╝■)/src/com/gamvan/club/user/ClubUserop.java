/*
 * Made in GamVan
 * 社区用户管理员相关
 */
package com.gamvan.club.user;

import java.util.List;

import com.gamvan.club.dao.impl.ClubUseropImpl;
import com.gamvan.club.item.ClubUserGradeItem;
import com.gamvan.club.item.ClubUserItem;
import com.gamvan.club.item.ClubUseropItem;
import com.gamvan.club.user.ClubUsers;
import com.gamvan.tools.FormatDateTime;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubUserop extends ClubUseropItem{
    private static final long serialVersionUID = 1L;
    /* 格式化当前时间 */
    private String now= FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    /* 用户等级的权限信息 */
    private String userGradeName = "未知";
    private String userGradeTxt = "";      
    private int userGradeID = 0;
    private int userGradeCID = 0;
    private byte classType = 0; //论坛版面的类型， 1为分类 2 为版面
    private ClubUseropImpl cuoim = new ClubUseropImpl();
    private String message = "";
    
    public String getMessage() {
		return message;
	}

	/**
     * 
     * @param ccid
     * @param ccid1
     * @param ccid2
     * @return
     * 2005-12-3 22:05:00 Made In GamVan
     * com.gamvan.club.user
     */
    public List useropList(int ccid, int ccid1, int ccid2){
        List list = null;
        try{
            list = cuoim.useroplist(1, 100, ccid, ccid1, ccid2);
        }catch(Exception e){
            list = null;
        }
        return list;
    }

    /**
     * 
     * @param uoIDs
     * @return
     * 2005-12-3 22:04:35 Made In GamVan
     * com.gamvan.club.user
     */
    public boolean useropDel(String[] uoIDs){
        boolean temp = false;
        try{
        	int i = cuoim.useropDels(uoIDs);
        	if(i>0){
        		temp = true;
        	}
        }catch(Exception e){
             temp = false;
        }
        return temp;
    }
    
    /**
     * 
     * @param act
     * @return
     */
    public void useropEdit(String act){
        ClubUsers cu = new ClubUsers();
        String userName = uoUser;
        userName = uoUser;
        ClubUserItem cui = null;
        cui = cu.userInfo(userName);
        if(cui!=null){
            userID = cui.getUserID();
            if(act.equals("add")){
                useropAdd();
            }else{
                useropUpdate();
           }    
        }else{
            message = "用户“" + userName + "”尚未注册或已被删除！";
        }
    }
    
    /**
     * 
     * @return
     * 2005-12-3 22:07:25 Made In GamVan
     * com.gamvan.club.user
     */
    private void useropUpdate(){
    	boolean bea = 
    		cuoim.useropUpdate(uoID, userID, uoUser, uoGradeID, uoCID, uoIs, uoByUser, uoByip, now);
    	if(bea){
    		message = "信息更新成功！";
    	}else{
    		message = "信息更新失败！";
    	}
    }
    
    /**
     * 
     * @return
     * 2005-12-3 21:46:01 Made In GamVan
     * com.gamvan.club.user
     */
    public void useropAdd(){
        try{
        	cuoim.useropAdd(userID,uoUser, uoGradeID, uoCID, uoIs, uoByUser, uoByip, now);
        	message = "操作成功！";
        }catch(Exception e){
        	message = "遭遇意外，操作失败！请重新尝试！";
        }

    }
    
    public ClubUseropItem useropInfo(int uoid){
        ClubUseropItem cuoi = null;
        try{
            cuoi = cuoim.useropInfo(uoid);
        }catch(Exception e){

        }
        return cuoi;
    }
    
 
    public ClubUseropItem useropInfo(String uouser, int uocid)
    {
        ClubUseropItem cuoi = null;
        try{
            cuoi = cuoim.useropInfo(uouser, uocid, uocid, uocid);
        }catch(Exception e){
            e.printStackTrace();
        }
        return cuoi;
    }
    
    
    
    /**
     * 循环找出用户是否在等级，是否符合所指定的管理版面
     * 取最高的等级ID
     * @param userid
     * @param ccid
     * @param ccid1
     * @param ccid2
     * @return
     */
    public ClubUseropItem useropInfo(int userid, int ccid, int ccid1, int ccid2)
    {
        if(userid<1){
            return null;
        }
        ClubUseropItem cuoi = null;
        try{
        	cuoi = cuoim.useropInfo(userid, ccid, ccid1, ccid2);
            if(cuoi!=null){
            	userGradeCID = cuoi.getUoCID();
	            userGradeID = cuoi.getUoGradeID();
            }
         }catch(Exception e){
            e.printStackTrace();
        }
        return cuoi;
    }
    
    /**
     * 获取用户权限信息返回String
     * @param userid 用户ID
     * @param ccid
     * @param ccid1
     * @param ccid2
     * @param ugid 当前用户的等级ID
     * @return
     */
    public void userGradeInfo(int userid, int ccid, int ccid1, int ccid2)
    {
        useropInfo(userid, ccid, ccid1, ccid2);
		if(this.userGradeID==0){
			if(userid>0){
				this.userGradeID = 8; //注册用户
				this.userGradeName = "注册用户";
			}else{
				this.userGradeID = 10; //过客
				this.userGradeName = "今晚过客";
			}
		}
        ClubUserGradeItem cugi = new ClubUserGradeItem();
        ClubUserGrade cug = new ClubUserGrade();
        cugi = cug.userGradeInfo(this.userGradeID);
        if(cugi!=null){
            this.userGradeName = cugi.getUgName();
            this.userGradeTxt = cugi.getUgTxt(); 
        }else{
            this.userGradeName = "未知";
        } 
    }
    
    public void setClassType(byte classType) {
        this.classType = classType;
    }

    public String getUserGradeName() {
        return userGradeName;
    }

    public int getUserGradeID() {
        return userGradeID;
    }

    public String getUserGradeTxt() {
        return userGradeTxt;
    }
    
    /* test
    public static void main(String args[]){
        ClubUserop cuo = new ClubUserop();
        System.out.println(cuo.useropList(16, 6, 0));
    }
    */
}

