/*
 * Made in GamVan
 * 注册用户相关信息
 * 登陆，查询，参数更新都在此类！
 */
package com.gamvan.club.user;

import com.gamvan.tools.*;
import com.gamvan.club.ClubCounter;
import com.gamvan.club.ClubInfo;
import com.gamvan.club.ClubRule;
import com.gamvan.club.manage.ClubStringReplace;
import com.gamvan.club.dao.impl.ClubUserImpl;
import com.gamvan.club.item.ClubInfoItem;
import com.gamvan.club.item.ClubRuleItem;
import com.gamvan.club.item.ClubUserItem;


/**
 * 社区用户资料逻辑层相关方法
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubUsers extends ClubUserItem {
	
    private static final long serialVersionUID = 1L;
    /* 收集信息 */
    private String message=""; 
    private String act = "";
    /* 格式化当前时间 */
    private String now= FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    private ClubUserImpl cuim = new ClubUserImpl();

    /**
     * 验证用户登录
     * @param uID 用户ID编号
     * @param uPass
     * @param es 参数判断密码是否加密
     * @return ClubUserItem 返回对象，验证失败返回NULL
     */
    public ClubUserItem userLogin(int uID, String uPass, int es){
       if(es==0){
            uPass = EncodeString.encodeString("md5of16",uPass);
       }
       if(uID<=0){
    	   return null;
       }
       ClubUserItem cui = new ClubUserItem();
       try{
           cui = cuim.userLogin(uID, uPass);
           if(cui!=null){
               if(cui.getUserIsDel()){
                   message = "此用户ID已被管理员删除！";
                   return null;
               }
               message = "登陆成功！";
               userLoginUpdate(cui.getUserID(), this.userLastip);
           }else{
               message = "登陆失败，用户名或密码错误！";
           }
           
       }catch(Exception e){
           cui = null;
           message = "系统出现意外错误，登陆失败!<br/>"+e.toString();
       }
        return cui;
    }
      
    /**
     * 验证用户登录
     * @param uName
     * @param uPass
     * @param es 参数判断密码是否加密
     * @return ClubUserItem
     */
    public ClubUserItem userLogin(String uName, String uPass, int es){
        if(uName==null||uPass==null){
            message = "用户名、密码均不能为空";
            return null;
        }
        if(uName.equals("")||uPass.equals("")){
            message = "用户名、密码均不能为空";
            return null;
        }
       if(es==0){
            uPass = EncodeString.encodeString("md5of16",uPass);
       }
       ClubUserItem cui = null;
       try{
           cui = cuim.userLogin(uName, uPass);
           if(cui!=null){
               if(cui.getUserIsDel()){
                   message = "此用户ID已被管理员删除！";
                   return null;
               }
               message = "登陆成功！";
               userLoginUpdate(cui.getUserID(), this.userLastip);
           }else{
               message = "登陆失败，用户名或密码错误！";
           }
           
       }catch(Exception e){
           cui = null;
           message = "系统出现意外错误，登陆失败!<br/>"+e.toString();
       }
        return cui;
    }
    
    
    /**
     * 更新用户头像
     * @param userid
     * @param userpic
     * @return
     * 2005-11-5 18:28:08 Made In GamVan
     * com.gamvan.club.user
     */
    public boolean  userHeadUpdate(int userid,String userpic){
       boolean tempbea = false;
        try{
        	cuim.userHeadUpdate(userid, userpic);
            tempbea = true;
            message = "头像更新成功！";
        }catch(Exception e){
            message = e.toString();
        }
       return tempbea;
    }
    

    /**
     * 更新用户登录次数，以及根据社区制度更新用户积分等各项参数
     * @param uID
     * @param userLastip
     * @return
     * 2005-11-5 17:33:30 Made In GamVan
     * com.gamvan.club.user
     */
    public void userLoginUpdate(int uid, String lastip){
       String txts = new String("");
       ClubRule cr = new ClubRule(); //社区制度
       ClubRuleItem cri = null;
       cri = cr.ruleInfo();
       txts = cri.getCrMark();
       userMark = ArrayEdit.txtsList(txts,14,"|");
       txts = "";
       txts = cri.getCrMoney();
       userMoney = ArrayEdit.txtsList(txts,14,"|");
       txts = "";
       txts = cri.getCrCredit();
       userCredit = ArrayEdit.txtsList(txts,14,"|");  
       try{
    	   /* 登录成功后更新用户信息 */
           cuim.userLoginUpdate
           (uid, lastip, now, userMark, userMoney, userCredit);
       }catch(Exception e){
           message = e.toString();
       }
    }
    
  
    /**
     * 根据用户名返回用户信息
     * @param uName
     * @return
     * 2005-11-5 17:49:10 Made In GamVan
     * com.gamvan.club.user
     */
    public ClubUserItem userInfo(String uname){
        if(uname==null || uname.equals("")){
            uname = userName;
        }
        ClubUserItem cui = null;
        try{
            cui = cuim.userInfo(uname);
        }catch(Exception e){
            cui = null;
        }
        return cui;
        
    }
    
    /**
     * 根据用户ID返回用户信息
     * @param uID
     * @return
     * 2005-11-5 17:49:40 Made In GamVan
     * com.gamvan.club.user
     */
    public ClubUserItem userInfo(int uid){
        if(uid==0){
            uid = userID;
        }
        if(uid<=0){
        	return null;
        }
        ClubUserItem cui = null;
        try{
            cui = cuim.userInfo(uid);
        }catch(Exception e){
            e.printStackTrace();
            cui = null;
        }  
        return cui;
    }
     
    
    /**
     * 用户注册信息提交，判断是注册还是更新，并执行相关动作。
     * @return
     * 2005-11-5 17:50:22 Made In GamVan
     * com.gamvan.club.user
     */
    public synchronized  boolean userRegPost(){
        boolean bea = false;
        ClubStringReplace csr = new ClubStringReplace();
        String str = new String();
        str = csr.haveReplace(userName);
        if(str!=null && !str.equals("")){
            message = "您注册的用户名或笔名含有本站限定的过滤字符 <strong>"+str+
            "</strong> 注册进程被终止！<br><br>请返回重新填写";   
            return false;
        }
        if(EncodeString.Glength(userName)>20){
            message = "用户名最多不能超过20个字符";
            return false;
        }
        /***********安全过滤***********/
        userName = EncodeString.htmlEncoder(userName);
        userName2 = EncodeString.htmlEncoder(userName2);
        userEmail = EncodeString.htmlEncoder(userEmail);
        userQQ = EncodeString.htmlEncoder(userQQ);
        userWork = EncodeString.htmlEncoder(userWork);
        userWeb = EncodeString.htmlEncoder(userWeb);
        userArea = EncodeString.htmlEncoder(userArea);
        userCity = EncodeString.htmlEncoder(userCity);
        userBirthday = EncodeString.htmlEncoder(userBirthday);
        /***************************/
        ClubUserItem cui = userInfo(userName);
        if(act.equals("add")){
            if(cui!=null){
            	message = "社区内已有同名用户存在，请换名注册！";
            	return false;
            }
            bea = userAdd();
        }
        else if(act.equals("edit")){
            if(cui==null){
            	message = "社区内无此用户或次用户已被删除，不能执行更新！";
            	return false;
            }
            bea = userUpdate();
        }
        return bea;
    }
    
    
    /**
     * 修改用户注册资料
     * @return
     * 2005-11-5 17:50:35 Made In GamVan
     * com.gamvan.club.user
     */
    public synchronized  boolean userUpdate(){
        boolean bea = false;
        if(userName==null || userName.equals("")
                || userPass==null || userPass.equals("")
                || userEmail==null || userEmail.equals(""))
        {
            message = "用户名，密码，用户信箱均不能为空。请认真填写。";
            return false;
        } 
        userPass = EncodeString.encodeString("md5of16",userPass);
        try{
            cuim.setUserName(userName);
            cuim.setUserPass(userPass);
            cuim.setUserName2(userName2);
            cuim.setUserSex(userSex);
            cuim.setUserEmail(userEmail);
            cuim.setUserEmailOpen(userEmailOpen);
            cuim.setUserQuestion(userQuestion);
            cuim.setUserAnswer(userAnswer);
            cuim.setUserWeb(userWeb);
            cuim.setUserQQ(userQQ);
            cuim.setUserArea(userArea);
            cuim.setUserCity(userCity);
            cuim.setUserWork(userWork);
            cuim.setUserPen(userPen);
            cuim.setUserIntro(userIntro);
            cuim.setUserUpfile(userUpfile);
            cuim.setUserTxt("");
            cuim.setUserRegTime(now);
            cuim.setUserLastTime(now);
            cuim.setUserLoginTimes(0);
            cuim.setUserRegip(userRegip);
            cuim.setUserLastip(userLastip);
            cuim.setUserMoney(userMoney);
            cuim.setUserMark(userMark);
            cuim.setUserDeposit(0); //用户存款
            cuim.setUserCredit(userCredit);         
            cuim.setUserTopicCount(0);
            cuim.setUserReCount(0);
            cuim.setUserIsDel(false);
            cuim.setUserUpfileOpen(userUpfileOpen);
            cuim.setUserUpfileSize(userUpfileSize);
            cuim.setUserPic(userPic);
            cuim.setUserPicIs(userPicIs);
            cuim.setUserAreaId(userAreaId);
            cuim.userUpdate(userID);
            bea = true;
            message = "资料更新成功！";         
        }catch(Exception e){
            message = "资料更新失败：" + e.toString();
        }
        return bea;
    }
    
    
    /**
     * 向社区内添加新用户
     * @return
     * 2005-11-5 17:50:46 Made In GamVan
     * com.gamvan.club.user
     */
    public boolean userAdd(){
        boolean bea = false;
        if(userName==null || userName.equals("")
                || userPass==null || userPass.equals("")
                || userEmail==null || userEmail.equals("")
        ){
            message = "用户名，密码，用户信箱均不能为空。请认真填写。";
            return false;
        }
        userPass = EncodeString.encodeString("md5of16",userPass);
        ClubInfo ci = new ClubInfo();
        ClubInfoItem cii = ci.clubInfo();
        if(cii!=null){
            userUpfile = cii.getClubUpfileUser(); /* 取出用户默认上传空间大小 */
        }else{
            userUpfile = 1024; /* 取出用户默认上传空间大小 */
        }        
        /* 用户注册社区默认参数 积分，金币， 信誉 */
        String txts = "";
        ClubRule cr = new ClubRule(); /* 社区制度 */
        try {
            ClubRuleItem cri = null;
            cri = cr.ruleInfo();
            txts = cri.getCrMark();
            userMark = ArrayEdit.txtsList(txts,15,"|");
            txts = "";
            txts = cri.getCrMoney();
            userMoney = ArrayEdit.txtsList(txts,15,"|");
            txts = "";
            txts = cri.getCrCredit();
            userCredit = ArrayEdit.txtsList(txts,15,"|");   
        } catch (Exception e) {
            
        }
        userAnswer = EncodeString.encodeString("md5of16",userAnswer);
        try{
            cuim.setUserName(userName);
            cuim.setUserPass(userPass);
            cuim.setUserName2(userName2);
            cuim.setUserSex(userSex);
            cuim.setUserEmail(userEmail);
            cuim.setUserEmailOpen(userEmailOpen);
            cuim.setUserQuestion(userQuestion);
            cuim.setUserAnswer(userAnswer);
            cuim.setUserWeb(userWeb);
            cuim.setUserQQ(userQQ);
            cuim.setUserArea(userArea);
            cuim.setUserCity(userCity);
            cuim.setUserWork(userWork);
            cuim.setUserPen(userPen);
            cuim.setUserIntro(userIntro);
            cuim.setUserUpfile(userUpfile);
            cuim.setUserTxt("");
            cuim.setUserRegTime(now);
            cuim.setUserLastTime(now);
            cuim.setUserLoginTimes(0);
            cuim.setUserRegip(userRegip);
            cuim.setUserLastip(userLastip);
            cuim.setUserMoney(userMoney);
            cuim.setUserMark(userMark);
            cuim.setUserDeposit(0); //用户存款
            cuim.setUserCredit(userCredit);         
            cuim.setUserTopicCount(0);
            cuim.setUserReCount(0);
            cuim.setUserIsDel(false);
            cuim.setUserUpfileOpen(userUpfileOpen);
            cuim.setUserUpfileSize(userUpfileSize);
            cuim.setUserPic(userPic);
            cuim.setUserPicIs(userPicIs);
            cuim.setUserAreaId(userAreaId);
            ClubUserItem cui = cuim.userAdd();
            if(cui==null){
                bea = false;
                message = "注册失败！";
                return bea;
            }
            this.userID = cui.getUserID();
            bea = true;
            ClubCounter ccu = new ClubCounter();
            if(userSex==1){
                ccu.counterUpdate(0, 0, 0, 0, 1, 0, 0, userName);
            }else{
                ccu.counterUpdate(0, 0, 0, 0, 0, 1, 0, userName);
            }
            /* 更新用户所在地区的人数统计 */
            com.gamvan.club.group.GroupEdit ge = new com.gamvan.club.group.GroupEdit();
            ge.groupCountUpdate(userAreaId, 1, 1);
            message = "恭喜您，注册成功！欢迎您加入我们！";
        }catch(Exception e){
            message = "用户注册信息出错：" + e.toString();
        }
        return bea;
    }
    

    /**
     * 更新用户发帖回帖等各项参数
     * @param userid 用户ID	
     * @param uMark 积分
     * @param uMoney 金币
     * @param uCredit 信誉
     * @param isRe 是否为回复
     * @param tCount 主题或回复的累加数，一般只为1
     * 2005-11-5 18:16:37 Made In GamVan
     * com.gamvan.club.dao
     */
    public boolean userUpdate(int userid, double uMark, double uMoney,
        double uCredit, int isRe, int tCount)
   {
       boolean tempbea = false;
       try{
    	   cuim.userUpdate(userid, uMark, uMoney, uCredit, isRe, tCount);
           tempbea = true;
       }catch(Exception e){
    	   e.printStackTrace();
           tempbea = false;
           message = e.toString();
       }
       return tempbea;
    }


	/**
	 * 根据制定位置的社区制度提取社区制度信息并进行相关操作
	 * @param userid 用户ID
	 * @param num 社区制度
	 * @param isRe 是否为回复
	 * @param tCount 主题或回复的加减数一般为1
	 * @return
	 * 2005-11-5 18:26:06 Made In GamVan
	 * com.gamvan.club.user
	 */
    public boolean userUpdate(int userid, int num, int isRe, int tCount){
        String txts = new String("");
        if(num>0){
            ClubRule cr = new ClubRule(); //社区制度
            ClubRuleItem cri = null;
            cri = cr.ruleInfo();
            txts = cri.getCrMark();
            userMark = ArrayEdit.txtsList(txts,num,"|");
            txts = "";
            txts = cri.getCrMoney();
            userMoney = ArrayEdit.txtsList(txts,num,"|");
            txts = "";
            txts = cri.getCrCredit();
            userCredit = ArrayEdit.txtsList(txts,num,"|");
        }
        else if(num==-1){

        }
        else if(num==0){
            userMark = 0;
            userMoney = 0;
            userCredit = 0;
        }
        boolean tempbea = false;
        try{
        	cuim.userUpdate
        	(userid, userMark, userMoney, userCredit, isRe, tCount);
            tempbea = true;
        }catch(Exception e){
            tempbea = false;
            message = e.toString();
            e.printStackTrace();
        }
       return tempbea;
    }
    
    public String getMessage(){
        return this.message;
    }
    
   /* test
    public static void main(String args[]){
        com.gamvan.conn.ConnClub.init();
        ClubUsers cu = new ClubUsers();
        System.out.println(cu.userLogin("今晚在线","111111",1));
        com.gamvan.conn.ConnClub.closeSession2();
    }
   */

    public String getAct() {
        return act;
    }

    public void setAct(String act) {
        this.act = act;
    }  
}