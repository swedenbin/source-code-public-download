/*
 * Created on 2005-9-4
 * Made In GamVan
 */
package com.gamvan.club.user;

import java.util.Random;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.ClubInfo;
import com.gamvan.club.item.ClubInfoItem;
import com.gamvan.club.item.ClubUserItem;
import com.gamvan.conn.ConnClub;
import com.gamvan.tools.EncodeString;
import com.gamvan.tools.Gmail;
/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubUserFindPass extends ClubUserItem{
    private static final long serialVersionUID = 1L;

    private String message = "";
    private String question = "";
    private String answer = "";
    
    private Gmail gm = new Gmail();
    private ClubInfo ci = new ClubInfo();
    
    
    public void findPass(){
        ClubUserItem cui = null;
        ClubUsers cu = new ClubUsers();
        cui = cu.userInfo(userName);
        if(cui!=null){
            userID = cui.getUserID();
            userQuestion = cui.getUserQuestion();
            userAnswer = cui.getUserAnswer();  
            userEmail = cui.getUserEmail();
        }else{
            message = "用户名：" + userName + " 不存在！";
            return;
        }
        
        if(userQuestion==null || userQuestion.trim().equals("")){
            message = "糟糕，这个用户名没有密码保护！";
            return;
        }
        answer = EncodeString.encodeString("md5of16",answer);
        
        if(!userQuestion.equals(question) || !userAnswer.equals(answer)){
            message = "Sorry，密码提示问题或答案不符，请重新尝试或向管理员求助！";
            return;
        }else{
            StringBuffer content = new StringBuffer();
            Random ran = new Random();
            userPass = String.valueOf(Math.abs(ran.nextInt()%100000));
            ClubInfoItem cii = null;
            cii = ci.clubInfo();
            String clubSmtp = cii.getClubSmtp();
            String clubSmtpID = cii.getClubSmtpID();
            String clubSmtpPass = cii.getClubSmtpPass();
            String clubSmtpPort = cii.getClubSmtpPort();
            int clubSmtpSSL = cii.getClubSmtpSSL();
            int clubSmtpUsePass = cii.getClubSmtpUsePass();
            String clubName = cii.getClubName();
            String clubEmailSend = cii.getClubEmailSend();
            String clubEmail = cii.getClubEmail();
            
            if(clubSmtpUsePass==1){
                gm.setNeedAuth("true");
            }else{
                gm.setNeedAuth("false");
            }
            gm.setSmtpServer(clubSmtp);
            gm.setSmtpID(clubSmtpID);
            gm.setSmtpPass(clubSmtpPass);
            gm.setSmtpPort(clubSmtpPort); //验证服务器端口
            gm.setNeedSSL(clubSmtpSSL); //验证服务器要加密
            gm.setFromEmail(clubEmail);
            gm.setFromName(clubEmailSend);           
            gm.setToEmail(userEmail);
            gm.setToName(userName);
            gm.setSubject("来自<"+clubName+">  的密码找回提示");
            
            content.append("您在 "+ clubName + " 执行了密码找回，以下是系统为您生成的新密码！<br/>");
            content.append(userPass);
            content.append("<br/>请牢记，并使用新密码登陆！");
            
            gm.setContent(content.toString());
            boolean bea = gm.mailSender();
            if(bea){
                userPassUpdate(userName, userPass);
            }else{
                message = "密码找回失败，无法发送Email通知您的新密码！<br/>";
                message += gm.getMessage();
            }
        }      

    }
    
    public void userPassUpdate(String username, String userpass){
        userpass = EncodeString.encodeString("md5of16",userpass);
        Session session = ConnClub.getSession();
        StringBuffer hql = new StringBuffer();
        Transaction tran = session.beginTransaction();
        try{
            hql.append("update ClubUserItem set userPass=?");
            hql.append(" where userName=?");
            Query query = session.createQuery(hql.toString())
            .setString(0, userpass)
            .setString(1, username);
            query.executeUpdate();
            tran.commit();
            message = "密码找回成功，已经发送到注册信箱！";
        }catch(HibernateException e){
            message = e.toString();
        }  
    }
    
    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public void setQuestion(String question) {
        this.question = question;
    }
    public String getMessage() {
        return message;
    }

}
