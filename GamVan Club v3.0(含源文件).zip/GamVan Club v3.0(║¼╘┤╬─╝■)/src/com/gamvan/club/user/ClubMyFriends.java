/*
 * ClubMyFriends.java
 * Made In GamVan
 * Created on 2005年4月7日, 下午3:39
 */
package com.gamvan.club.user;
import java.util.StringTokenizer;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gamvan.club.dao.impl.ClubFriendsImpl;
import com.gamvan.club.item.ClubFriendsItem;
import com.gamvan.club.item.ClubUserItem;
import com.gamvan.club.message.ClubMessageSend;

import com.gamvan.conn.ConnClub;
import com.gamvan.tools.FormatDateTime;
import com.gamvan.tools.TypeChange;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubMyFriends extends ClubFriendsItem{
    private static final long serialVersionUID = 1L;
    private int friendOnlineCount=0;
    private String postMsg ="";
    private String message = "";
    /* 格式化当前时间 */
    private String now = FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    private ClubUsers cu = new ClubUsers();
    private ClubFriendsImpl cfim  = new ClubFriendsImpl();
    

    /* 更新用户是否在线配合CLubOnlie类 */
    public void friendOnline(){
   
    }
 
    /**
     * 
     * @param userfriendid
     * @param isOnline
     * 2005-11-5 20:18:12 Made In GamVan
     * com.gamvan.club.user
     */
    public void friendOnlineUpdate(int userfriendid, int isOnline){
        Session session = ConnClub.getSession();
        Transaction tran = session.beginTransaction();
        String hql = "";
        try{
            hql = "update ClubFriendsItem set isOnline=? where userMeID=? and userFriendID=?";
            Query query = session.createQuery(hql)
            .setInteger(0,isOnline)
            .setInteger(1, userMeID)
            .setInteger(2, userfriendid);
            query.executeUpdate();
            tran.commit();
            friendOnlineCount = friendOnlineCount + isOnline;
        }catch(Exception e){
            
        }       
    }
    
    /**
     * 
     * @param userMeID
     * @param userFriendID
     * @return
     * 2005-11-5 20:18:06 Made In GamVan
     * com.gamvan.club.user
     */
    public boolean friendSelect(int meid, int friendid){
        boolean bea = false;
        try{
        	if(cfim.friendsInfo(meid, friendid)!=null){
        		bea = true;
        	}
        }catch(Exception e){
            bea = false;
        }       
        return bea;
    }
     
    /**
     * 
     * @param usermeid
     * @param userfriend
     * @return
     * 2005-11-5 22:11:44 Made In GamVan
     * com.gamvan.club.user
     */
    public boolean friendSelect(int meid, String friendname){
        boolean bea = false;
        try{
        	if(cfim.friendsInfo(meid, friendname)!=null){
        		bea = true;
        	}
        }catch(Exception e){
            bea = false;
        }        
        return bea;
    }
    
    
    /**
     * 批量添加好友，半角逗号,为分割符。
     * @param userFriend
     * @return
     */
    public boolean friendsInsert(String userFriend){
        boolean bea = false;
        message = "";
        if(userFriend==null || userFriend.equals("")){
            message = "朋友ID不能为空！";
            return false;
        }
        StringTokenizer st = new StringTokenizer(userFriend,",");
        String[] userFriends = new String[st.countTokens()];
        try{
            for(int i=0; st.hasMoreTokens(); i++){
                userFriends[i] = st.nextToken().trim();
                friendInsert(userFriends[i], userMe);
            }
        }catch(Exception e){
            message = e.toString();
        }       
        return bea;
    }

    /**
     * 添加好友
     * @param userfriend
     * @param userMe
     * @return
     * 2005-11-5 22:11:51 Made In GamVan
     * com.gamvan.club.user
     */
    public boolean friendInsert(String userfriend, String userme){
        boolean bea = false;
        if(friendSelect(userMeID, userfriend)){
            message += userfriend + " 已存在在您的好友列表，添加操作被终止！<br/>";
            return false;
        }
        try{
            ClubUserItem cui = null;
            cui = cu.userInfo(userfriend);
            if(cui!=null){ //判断ID是否为注册用户
                this.userFriendID = cui.getUserID(); //取得用户数据库ID号
            }else{
                message += userfriend + " 此ID不是注册用户，添加失败！<br/>";
                return false;
            } 
            cfim.friendsAdd(userMeID, userme, this.userFriendID, userfriend, now, userMessage, userIp, 0);
            bea = true;
            message += userfriend + " 被您加为好友<br/>";   
            if(postMsg.equals("1")){
                ClubMessageSend cm = new ClubMessageSend();
                cm.setCmContent(userMessage);
                cm.setCmTopic("社区提醒： 来自 " + userMe + " 的短消息");
                cm.setCmUserIp("0.0.0.0");
                cm.setCmReID(0);
                cm.setCmSendUser(userMe);
                cm.setCmIsSend(true);
                cm.setCmOrder((short)0);
                cm.setIsPost(0);
                cm.setCmTakeUser(userfriend);
                cm.setCmSendID(userMeID);
                cm.setCmTakeID(this.userFriendID);
                cm.sendMessages(userfriend); //执行发送
                message +=  cm.getMessage() + "<br/>";
            } 
        }catch(HibernateException e){
                message = e.toString();
                bea = false;
        }
        return bea;
    }
    
    /**
     * 批量删除好友
     * @param cfIDs
     * @return
     * 2005-11-5 22:11:58 Made In GamVan
     * com.gamvan.club.user
     */
    public boolean friendDel(String[] cfIDs){
        boolean bea = false;
        int delCount=0;
        int delid = 0;
        for(int i=0; i<cfIDs.length; i++){
            delCount++;
            delid = TypeChange.stringToInt(cfIDs[i]);
            cfim.friendsDel(delid);
        }     
        message = delCount + " 个好友被删除！";
        return bea;        
    }
    
    /**
     * 删除好友
     * @param cfid
     * 2005-12-1 17:26:27 Made In GamVan
     * com.gamvan.club.user
     */
    public void friendDel(int cfid){
        try{
            cfim.friendsDel(cfid);
        }catch(Exception e){
            message = e.toString();
        }
    }
    
    public String getMessage(){
        return this.message;
    }
    
    public void setPostMsg(String postMsg){
        if(postMsg==null){
            this.postMsg = "0";
        }else{
            this.postMsg = postMsg;
        }
    }
    public void setUserMessage(String userMessage){
        if(userMessage==null){
            this.userMessage = "";
        }else{
            this.userMessage = userMessage;
        }
    }
    
    public int getFriendOnlineCount(){
        return this.friendOnlineCount;
    }
    
   /*
    public static void main(String args[]){
        ClubMyFriends cmf = new ClubMyFriends();
        cmf.setUserIp("0.0.0.0");
        cmf.setUserMeID(1);
        cmf.setUserMe("今晚在线");
        cmf.setPostMsg("1");
        cmf.setUserMessage("ddddddddddddddddddddddd");
        cmf.friendsInsert("今晚在线,123,dg");
        System.out.print(cmf.getMessage());
    }
    */
}
