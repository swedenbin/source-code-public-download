/*
 * Created on 2005-10-9
 * Made In GamVan
 */
package com.gamvan.club.user;

import com.gamvan.club.ClubRule;
import com.gamvan.club.dao.impl.ClubBusinessImpl;
import com.gamvan.club.item.ClubBusinessItem;
import com.gamvan.club.item.ClubRuleItem;
import com.gamvan.club.item.ClubUserItem;
import com.gamvan.tools.Arith;
import com.gamvan.tools.ArrayEdit;
import com.gamvan.tools.FormatDateTime;

/**
 * 社区用户交易处理
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubBusinessEdit extends ClubBusinessItem{
    private static final long serialVersionUID = 1L;
    private String message = "";
    /* 格式化当前时间 */
    private String now= FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    /* 提前取出用户更项信息用来和交易提交的参数计算 */
    private double userCredit2 = 0; //信誉
    private double userMark2 = 0; //积分
    private double userMoney2 = 0; //金币
    private double userDeposit2 = 0; //帐户存款
    /* ************************************ */
    
    private String credit = "";
    private String mark = "";
    private String money = "";

    private ClubUsers cu = new ClubUsers();
    private ClubBusinessImpl cbim = new ClubBusinessImpl();
    
    public void businessDo(){
        getUserInfo();
        getClubRuleInfo();
        if(businessType==1){
            if(userMark <= 0){
                message = "本次操作无效！";
                return;
            }
            markToMoney();
        }
        else if(businessType==2){
            if(userMoney <= 0){
                message = "本次操作无效！";
                return;
            } 
            moneyToMark();
        }
        else{
            message = "你操作的内容不明确，请返回重新操作！";
            return;
        }
    }
    
       
    /**
     * 取操作用户积分和金币
     * 2005-11-5 20:30:53 Made In GamVan
     * com.gamvan.club.user
     */
    public void getUserInfo(){
        
        ClubUserItem cui = null;
        cui = cu.userInfo(userID);
        if(cui!=null){
            this.userCredit2 = cui.getUserCredit();
            this.userMark2 = cui.getUserMark();
            this.userMoney2 = cui.getUserMoney();
            this.userDeposit2 = cui.getUserDeposit();
            this.userName = cui.getUserName();
        }else{
            message = "用户信息提取失败！操作被终止！";
            return ;
        }
    }
    
    /**
     * 取社区存款利率，积分兑换金币的比率等。
     * 2005-11-5 20:30:43 Made In GamVan
     * com.gamvan.club.user
     */
    public void getClubRuleInfo(){
        ClubRule cr = new ClubRule();
        ClubRuleItem cri = cr.ruleInfo();
        if(cri!=null){
            credit = cri.getCrCredit();
            mark = cri.getCrMark();
            money = cri.getCrMoney();        
        }else{
            message = "社区制度信息提取失败！操作被终止！";
            return ; 
        }
        
    }
    
    
    /**
     * 积分转金币
     * 按照提交的积分数计算出可以兑换多少个金币，精确到.00
     */
    public void markToMoney(){
        if(userMark2 < userMark){
            message = "您请求兑换成金币的积分不够，兑换请求被驳回！";
            return;
        }        
        //积分兑换金币的比率
        this.businessRate = ArrayEdit.txtsList(mark,17,"|");
        //兑率为0则表示功能关闭
        if(this.businessRate==0){
            message = "社区积分兑换金币功能暂时关闭！";
            return;
        }
        
        //算出提交的积分可以兑换多少金币
        this.userMoney = Arith.mul(userMark,this.businessRate);
        this.userMark = -userMark; //转为负值表示被扣除
        this.businessLog = "积分兑换金币";
        this.relatingID = userID;
        this.relatingName = userName;
        businessAdd();
        
        //执行用户参数更新操作
        cu.setUserMark(this.userMark);
        cu.setUserMoney(this.userMoney);
        cu.setUserCredit(this.userCredit);
        cu.userUpdate(userID, -1, -1, 0);
        message = "操作成功！<br/>";
        message += "您已将 " + -userMark + " 的积分兑换成了 " + userMoney + " 个金币";
    }
    
    /**
     * 金币转积分
     * 2005-11-5 20:32:07 Made In GamVan
     * com.gamvan.club.user
     */
    public void moneyToMark(){
        if(userMoney2 < userMoney){
            message = "您请求兑换成积分的金币不够，兑换请求被驳回！";
            return;
        }        
        //积分兑换金币的比率
        this.businessRate = ArrayEdit.txtsList(money,17,"|");
        if(this.businessRate==0){
            message = "社区金币购买积分功能暂时关闭！";
            return;
        }
        //算出提交的金币可以兑换成多少积分
        this.userMark = Arith.mul(userMoney,this.businessRate);
        this.userMoney = -userMoney; //转为负值表示被扣除
        this.businessLog = "金币兑换积分";
        this.relatingID = userID;
        this.relatingName = userName;
        businessAdd();
        
        //执行用户参数更新操作
        cu.setUserMark(this.userMark);
        cu.setUserMoney(this.userMoney);
        cu.setUserCredit(this.userCredit);
        cu.userUpdate(userID, -1, -1, 0);
        message = "操作成功！<br/>";
        message += "您用 " + -userMoney + " 个金币购买了 " + userMark + " 分";
    }
    
    
    
    public void businessAdd(){
        try{
            cbim.setUserID(userID);
            cbim.setUserName(userName);
            cbim.setBusinessDateTime(now);
            cbim.setBusinessType(businessType);
            cbim.setBusinessIp(businessIp);
            cbim.setBusinessRate(this.businessRate);
            cbim.setUserCredit(this.userCredit);
            cbim.setUserMark(this.userMark);
            cbim.setUserMoney(this.userMoney);
            cbim.setBusinessLog(this.businessLog);
            cbim.setRelatingName(this.relatingName);
            cbim.setRelatingID(this.relatingID);
        }catch(Exception e){
            message = e.toString();
            return;
        }
    }
    
    public String getMessage() {
        return message;
    }
    
}
