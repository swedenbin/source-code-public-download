/*
 * Created on 2005-8-21
 * Last modified on 2005-8-21
 * Powered by GamVan.com
 */
package com.gamvan.club.tag;

import java.io.IOException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;

public class ClubAdTag  extends TagSupport{
    private static final long serialVersionUID = 1L;
    private String type="";
    private String value="";
    private String property="";
    private int idIs = 0;
    private int linkId = 0;
    
    public void setLinkId(int linkId) {
        this.linkId = linkId;
    }
    public void setIdIs(int idIs) {
        this.idIs = idIs;
    }
    public void setType(String s){
        this.type = s;
    }
    public void setValue(String s){
        this.value = s.trim();
    }

    public void setProperty(String s){
        this.property = s;
    }

    
    public int doStartTag() throws JspTagException{
        return SKIP_BODY;
    }

    public int doEndTag() throws JspTagException{ 
        StringBuffer sb = new StringBuffer();
        
        if(type.equals("showad")){
            if(value.substring(0,2).equals("./")){
                value = value.replace("./","../");
            }else if((!value.substring(0,2).equals("./")||!value.substring(0,1).equals("/"))&&(!value.substring(0,4).equals("http"))){
                value += "../";
            }
            
            sb.append("<script language=\"javascript\">");
            sb.append("showad(\"");
            sb.append(value);
            sb.append("\",\"");
            sb.append(property);
            sb.append("\",");
            sb.append(idIs);
            sb.append(",");
            sb.append(linkId);
            sb.append(");</script>");
        }

        else{
            sb.append(value);
        }
    
        outWrite(sb);
        sb.delete(0, sb.length());
        return EVAL_PAGE;
    }



    public void outWrite(String s){
        try {
            pageContext.getOut().write(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void outWrite(StringBuffer s){
        try {
            pageContext.getOut().write(s.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
