/*
 * Created on 2005-8-3
 * Made In GamVan
 */
package com.gamvan.club.tag;

import java.io.IOException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;

public class ClubClassTag  extends TagSupport{
    private static final long serialVersionUID = 1L;

    private String type="";
    private String value="";
    private String property="";
    private boolean bea = false;
    private String name="";
    private int idIs = 0;
    private int linkId = 0;
    private String url;
    boolean isAfter = false;
    
    public void setLinkId(int linkId) {
        this.linkId = linkId;
    }
    public void setIdIs(int idIs) {
        this.idIs = idIs;
    }
    public void setType(String s){
        this.type = s;
    }
    public void setValue(String s){
        this.value = s.trim();
    }

    public void setProperty(String s){
        this.property = s;
    }

    public void setBea(boolean bea) {
        this.bea = bea;
    }
    
    
    public void setName(String s){
        this.name = s;
    }
    
    public void setUrl(String s){
        this.url = s;
    }
    
    
    public int doStartTag() throws JspTagException{
        return SKIP_BODY;
    }

    public int doEndTag() throws JspTagException{
        StringBuffer sb = new StringBuffer("");
        if(type.equals("option")){
            sb.append("<option value=\"");
            sb.append(idIs);
            sb.append("\" ");
            if(idIs==linkId){
                sb.append(" selected");
            }
            sb.append(">");
            if(!property.equals("")){
                sb.append(property);
            }
            sb.append(value);
            sb.append("</option>");
        }
        
        else if(type.equals("className")){
        	if(value!=null){
	            sb.append("<a href=\"");
	            if(url!=null)
	            sb.append(url);
	            
	            sb.append("clubClass.jsp?ccID=");
	            sb.append(idIs);
	            sb.append("\" ");
	            if(property.equals("")){
	                sb.append(" target=\"_self\">");
	            }else{
	                sb.append(" target=\"");
	                sb.append(property);
	                sb.append("\">");
	            }
	            sb.append(value);
	            sb.append("</a>");
        	}
            
        }
        else if(type.equals("classType")){
            if(idIs==0){
                sb.append("<font color=#bb0000>分类</font>");
            }else{
                sb.append("<font color=#000099>版面</font>");
            }
        }
        else if(type.equals("classHidden")){
            if(bea){
                sb.append("<font color=#cccccc>隐藏</font>");
            }else{
                sb.append("<font color=#000099>不隐藏</font>");
            }
        }
        else if(type.equals("classPro")){
            switch(idIs){
                case 0: sb.append("开放的");
                break;
                case 1: sb.append("主题的");
                break;
                case 2: sb.append("锁定的");
                break;
                case 3: sb.append("认证的");
                break;
                case 4: sb.append("链接的");
                break; 
            }
        }
        else if(type.equals("classStyle")){
            if(idIs==0){
                sb.append("<font color=#000099>BBS风格</font>");
            }else{
                sb.append("<font color=#006600>讨论区风格</font>");
            }
        }     
        else if(type.equals("htmlEdit")){
                sb.append("<a href=\"clubClassEdit.jsp?ccID=");
                sb.append(idIs);
                sb.append("\">配置</a>");
        }     
            
        else if(type.equals("htmlDel")){
            sb.append("<a onClick=\"javascript:gConfirm('确定要删除此分类吗，删除后将不能恢复！','clubClassList.jsp?act=del&ccID=");
            sb.append(idIs);
            sb.append("');\" href=\"#\">删除</a>");

        }  
        else if(type.equals("htmlCheckbox")){
            sb.append("<input name=\"ccID\" type=\"checkbox\" id=\"ccID\" value=\"");
            sb.append(idIs);
            sb.append("\"/>");

        }  
        
        else {
            sb.append(value);
        }
        
        outWrite(sb);
        sb.delete(0, sb.length());
        return EVAL_PAGE;
    }



    public void outWrite(String s){
        try {
            pageContext.getOut().write(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void outWrite(StringBuffer s){
        try {
            pageContext.getOut().write(s.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
