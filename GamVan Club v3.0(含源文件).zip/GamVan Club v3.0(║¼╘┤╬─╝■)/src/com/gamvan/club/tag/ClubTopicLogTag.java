/* 
 * Created on 2006-1-24
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.tag;

import java.io.IOException;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;

import com.gamvan.tools.EncodeString;

public class ClubTopicLogTag extends TagSupport{

	private static final long serialVersionUID = 1L;
	
	private String type="";
    private String value="";
    private String property="";
    private int idIs = 0;
    private int linkId = 0;
    private String url;
    private int ccID = 0;
    private boolean bea = false;
    
    
	public void setBea(boolean bea) {
		this.bea = bea;
	}
	public void setCcID(int ccID) {
		this.ccID = ccID;
	}
	public void setIdIs(int idIs) {
		this.idIs = idIs;
	}
	public void setLinkId(int linkId) {
		this.linkId = linkId;
	}
	public void setProperty(String property) {
		this.property = property;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public void setValue(String value) {
		this.value = value;
	}
    public int doStartTag() throws JspTagException{
        return SKIP_BODY;
    }
    
    public int doEndTag() throws JspTagException{
        StringBuffer sb = new StringBuffer();
        value = EncodeString.htmlEncoder(value);
        if(type.equals("topic")){
        	sb.append("<a href=\"");
            if(url!=null){
                sb.append(url);
            }else{
                sb.append("clubPage.jsp?ccStyle=1");
            }
            sb.append("&tID="+ idIs +"");
            if(linkId>0){
                sb.append("&reID=");
                sb.append(linkId);
            }
            if(ccID>0){
                sb.append("&ccID=");
                sb.append(ccID);
            } 
            sb.append("\" ");
            if(!property.equals("")){
                sb.append(" target=\""+ property +"\"");
            }
            sb.append(">"); 
            sb.append(value);
            sb.append("</a>");
        }
        else if(type.equals("userName")){
        	StringBuffer sb1 = new StringBuffer("");
        	sb1.append("<a href=\"userInfo.jsp?userID=");
	        sb1.append(idIs);
	        sb1.append("\" ");
	        if(property!=null && !property.equals("")){
		        sb1.append(" target=\"");
		        sb1.append(property);
		        sb1.append("\"");
	        }
	        sb1.append(">");
	        sb1.append(value);
	        sb1.append("</a>");
	        if(linkId>0){
	        	sb.append("〖");
	        	sb.append(sb1);
	        	sb.append("〗");
	        }else{
	        	sb.append("【");
	        	sb.append(sb1);
	        	sb.append("】");
	        }
        }
        else if(type.equals("byUser")){
        	if(linkId!=0 || bea){
	        	sb.append("<a href=\"userInfo.jsp?userID=");
		        sb.append(idIs);
		        sb.append("\" ");
		        if(property!=null && !property.equals("")){
			        sb.append(" target=\"");
			        sb.append(property);
			        sb.append("\"");
		        }
		        sb.append(">");
		        sb.append(value);
		        sb.append("</a>");
        	}
        }
        else if(type.equals("htmlCheckbox")){
            if(property==null || property.equals("")){
                property = "topicLogID";
            }
            sb.append("<input name=\"");
            sb.append(property);
            sb.append("\"  id=\"");
            sb.append(property);
            sb.append("\" type=\"checkbox\"  value=\"");
            sb.append(idIs);
            sb.append("\">");
        }
        
        else if(type.equals("topicLogTxt")){
            sb.append(value);
        }
        
        else{
            sb.append(value);
        }

        outWrite(sb);
        sb.delete(0, sb.length());
        sb = null;
        return EVAL_PAGE;
    }

   
    public void outWrite(String s){
        try {
            pageContext.getOut().write(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void outWrite(StringBuffer s){
        try {
            pageContext.getOut().write(s.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
