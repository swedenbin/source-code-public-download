/*
 * Created on 2005-7-28
 * Last modified on 2006-1-21
 * Powered by GamVan.com
 */
package com.gamvan.club.tag;
import java.io.IOException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;
import com.gamvan.club.ClubInfo;
import com.gamvan.club.ClubStringReplaces;
import com.gamvan.club.item.ClubInfoItem;
import com.gamvan.html.OutPrint;
import com.gamvan.tools.ArrayEdit;
import com.gamvan.tools.EncodeString;
import com.gamvan.tools.FormatDateTime;
import com.gamvan.tools.TypeChange;
/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicTag  extends TagSupport{
    private static final long serialVersionUID = 1L;
    
    private ClubStringReplaces csrs = new ClubStringReplaces();
    private String type="";
    private String value="";
    private String property="";
    private boolean bea = false;
    private String style="";
    private int idIs = 0;
    private int linkId = 0;
    private String url;
    private boolean isAfter = false;
    private int ccID = 0;
    private int pro = 0;
    private byte isDel = 0;
    
    public void setPro(int pro) {
		this.pro = pro;
	}

	public int getLinkId() {
        return linkId;
    }

    public void setCcID(int ccID) {
        this.ccID = ccID;
    }
    
    public void setLinkId(int linkId) {
        this.linkId = linkId;
    }
    public void setIdIs(int idIs) {
        this.idIs = idIs;
    }
    public void setType(String s){
        this.type = s;
    }
    public void setValue(String s){
        this.value = s.trim();
    }

    public void setProperty(String s){
        this.property = s;
    }

    public void setBea(boolean bea) {
        this.bea = bea;
    }
    
    
    public void setStyle(String s){
        this.style = s;
    }
    
    public void setUrl(String s){
        this.url = s;
    }

	public void setIsDel(byte isDel) {
		this.isDel = isDel;
	}
    
    public int doStartTag() throws JspTagException{
        return SKIP_BODY;
    }

    public int doEndTag() throws JspTagException{
        StringBuffer sb = new StringBuffer();
        if(type.equals("topic")){
        	if(isDel==1){
        		value="<font color=\"#666666\">&lt;该主题已被删除&gt;</font>";
        	}
        	else if(pro==5){
        		value="<font color=\"#ff0000\">==&lt;该主题被禁止显示&gt;==</font>";
        	}
        	else{
	            value = EncodeString.htmlEncoder(value);
	            value = csrs.srTopic(value,"");
        	}
            String s0 = "";
            String s1 = "";
            if(style!=null){
	            if(style.equals("|1")){
		            s0 = "";
		            s1 = "1";
	            }
	            else if(!style.equals("|") && !style.equals("")){
		            s0 = ArrayEdit.getTextsInfo(style, 0, "|");
		            s1 = ArrayEdit.getTextsInfo(style, 1, "|");
	            }
            }
            if(bea){ //判断是否加连接
                sb.append("<a href=\"");
                if(url!=null){
                    sb.append(url);
                }else{
                    sb.append("clubPage.jsp?ccStyle=1");
                }
                sb.append("&tID="+ idIs +"");
                if(linkId>0){
                    sb.append("&reID=");
                    sb.append(linkId);
                }
                if(ccID>0){
                    sb.append("&ccID=");
                    sb.append(ccID);
                } 
                sb.append("\" ");
                if(!property.equals("")){
                    sb.append(" target=\""+ property +"\"");
                }
                sb.append(">"); 
                if(!s0.equals("")||!s1.equals("")){
                	sb.append("<span style=\"");
                	if(!s0.equals("")){
                		sb.append("color:");
                		sb.append(s0);
                		sb.append(";");
                	}
                	if(s1.equals("1")){
                		sb.append("font-weight: bold;");
                	}
                	sb.append("\">");
                	sb.append(value);
                	sb.append("</span>");
                }else{
                	sb.append(value);
                }
                sb.append("</a>");
            }else{
                sb.append(value);
            }
        }
        
        else if(type.equals("topicPro")){
            if(idIs==1){
                sb.append("<font color=\"#ff000\">精品</font>");
            }
            else if(idIs==2){
                sb.append("<font color=\"#000099\">锁定</font>");
            }
            else if(idIs==4){
                sb.append("<font color=\"#cccccc\">禁显</font>");
            }
            
        }
        
        else if(type.equals("htmlCheckbox")){
            if(property==null || property.equals("")){
                property = "topicID";
            }
            sb.append("<input name=\"");
            sb.append(property);
            sb.append("\"  id=\"");
            sb.append(property);
            sb.append("\" type=\"checkbox\"  value=\"");
            sb.append(idIs);
            sb.append("\">");
        }
        
        else if(type.equals("topicIsPass")){
            if(bea){
                sb.append("<font color=\"#ff0000\">");
                sb.append(value);
                sb.append("</font>");
            }else{
                sb.append(value);
            }
            
        }
        
        else if(type.equals("userName")){
	        sb.append("<a href=\"userInfo.jsp?userID=");
	        sb.append(idIs);
	        sb.append("\" ");
	        if(property!=null && !property.equals("")){
		        sb.append(" target=\"");
		        sb.append(property);
		        sb.append("\"");
	        }
	        sb.append(">");
	        sb.append(value);
	        sb.append("</a>");
        }
        else if(type.equals("topicAddTime")){
            sb.append(OutPrint.isDateHtml(value));
        }
        
        else if(type.equals("topicLastReTime")){
            sb.append(OutPrint.isDateHtml(value));
        }
        
        else if(type.equals("dateTime")){
            sb.append(OutPrint.isDateHtml(value));
        }
        
        else if(type.equals("img_listMood")){
            if(value.equals("0")){
                value = "1";
            }
            sb.append("<img alt=\"心情\" src=\"GVimgs/GamVanMood/");
            sb.append(value);
            sb.append(".gif\"  align=\"absmiddle\" />");
        }
        
        else if(type.equals("img_listType")){
            switch(idIs){
                case 1:
                    sb.append("<img border=\"0\" onmouseover=\"showlayer(event, '"+ value +"分可见帖') ;\" onmouseout=\"hidelayer();\" src=\"GVimgs/topicPro/mark.gif\" align=\"absmiddle\" />");
                    break;
                case 2:
                    sb.append("<img border=\"0\" onmouseover=\"showlayer(event, '"+ value +"金币购买帖') ;\" onmouseout=\"hidelayer();\"  src=\"GVimgs/topicPro/money.gif\" align=\"absmiddle\" />");
                    break;
                case 3:
                    sb.append("<img border=\"0\" onmouseover=\"showlayer(event, '"+ value +"分求助帖') ;\" onmouseout=\"hidelayer();\"  src=\"GVimgs/topicPro/help.gif\" align=\"absmiddle\" />");
                    break;
                case 4:
                    sb.append("<img border=\"0\"  onmouseover=\"showlayer(event, '隐藏内容回复后可见') ;\" onmouseout=\"hidelayer();\" src=\"GVimgs/topicPro/hide.gif\" align=\"absmiddle\" />");
                    break;
                case 5:
                    sb.append("<img border=\"0\"  onmouseover=\"showlayer(event, '"+ value +"分求助帖&lt;已经结贴&gt;') ;\" onmouseout=\"hidelayer();\" src=\"GVimgs/topicPro/helpok.gif\" align=\"absmiddle\" />");
                    break; 
            }
        }
        
        else if(type.equals("img_listHot")){
	        int clubHotTopic = 0;
	        int clubHotRe = 0;
            ClubInfo ci = new  ClubInfo();
            ClubInfoItem cim = ci.clubInfo();
            if(cim!=null){
            	clubHotTopic = cim.getClubHotTopic();
            	clubHotRe = cim.getClubHotRe();
            }
            if((clubHotTopic!=0 && idIs > clubHotTopic) || (clubHotRe!=0 && TypeChange.stringToInt(value)>clubHotRe))
            {
                sb.append("<img border=\"0\" alt=\"热门主题\" src=\"GVimgs/topicPro/hot.gif\" align=\"absmiddle\" />");
            }
        }
        
        else if(type.equals("img_listNew")){
            sb.append("<a href=\"" + url + "");
            if(ccID>0){
                sb.append("&ccID=");
                sb.append(ccID);
            }
            sb.append("&tID="+ linkId +"\" target=\"_blank\">");
            if(idIs>0){
                
                if(idIs==1){
                    sb.append("<img border=\"0\" alt=\"新窗口开启\" src=\"GVimgs/topicPro/up1.gif\" align=\"absmiddle\" />");
                }else if(idIs==2){
                    sb.append("<img border=\"0\" alt=\"新窗口开启\" src=\"GVimgs/topicPro/up2.gif\" align=\"absmiddle\" />");
                }else if(idIs==3){
                    sb.append("<img border=\"0\" alt=\"新窗口开启\" src=\"GVimgs/topicPro/up3.gif\" align=\"absmiddle\" />");
                }
                
            }else{
                switch(TypeChange.stringToInt(value)){
                    case 1 :
                        sb.append("<img border=\"0\" alt=\"新窗口开启\" src=\"GVimgs/topicPro/best.gif\" align=\"absmiddle\" />");
                        break;
                    case 2 :
                        sb.append("<img border=\"0\" alt=\"新窗口开启\" src=\"GVimgs/topicPro/lock.gif\" align=\"absmiddle\" />");
                        break;
                    default:
                        //OutPrint.isDateHtml(property);
                        isAfter = FormatDateTime.dateCompare(property);
                        if(isAfter){
                            sb.append("<img border=\"0\" alt=\"新窗口开启\" src=\"GVimgs/topicPro/old.gif\" align=\"absmiddle\" />");
                        }else{
                            sb.append("<img border=\"0\" alt=\"新窗口开启\" src=\"GVimgs/topicPro/new.gif\" align=\"absmiddle\" />");
                        }
                    //}
                }
            }
            sb.append("</a>");
        }
        
        else if(type.equals("img_listClick")){
            sb.append("<img id=\"icon_");
            sb.append(idIs);
            sb.append("\"  onclick=\"loadTree(");
            sb.append(idIs);
            sb.append(",\'GVinc/ccStyle0_1.jsp?ccID=");
            sb.append(value);
            sb.append("&tID=");
            sb.append(idIs);
            sb.append("&ipage=1\');\"");
            sb.append(" alt=\"点击展开本主题所有回复\"   src=\"GVimgs/tree/t1.gif\" align=\"absmiddle\" ");
            sb.append(" style=\"cursor:hand;\" />");
        }
        
        else if(type.equals("img_iLike")){
            bea = FormatDateTime.secondCompare(value, property);
            if(!bea){
                sb.append("<img src=\"GVimgs/topicPro/old.gif\" align=\"absmiddle\" />");
            }else{
                sb.append("<img src=\"GVimgs/topicPro/new.gif\" align=\"absmiddle\" />");
            }            
        }

        else if(type.equals("tree_list")){
                String txt1="", txt = "", temp="";
                int td =  TypeChange.stringToInt(value); // topicTree
                temp = String.valueOf(td);
                temp = temp.substring((temp.length()-1),temp.length());
                if(TypeChange.stringToInt(temp)%2==0){
                    txt += "<span class=\"pageTree\">└</span>";
                }else{
                    txt += "<span class=\"pageTree\">├</span>";
                    td=td-1;
                }
                for(int ii=idIs/*topicLayer*/;ii>1;ii--){
	                td = td/2;
	                temp = String.valueOf(td);
	                temp = temp.substring((temp.length()-1),temp.length()); 
	                if(TypeChange.stringToInt(temp)%2 != 0){
		                txt =  "<span class=\"pageTree\">│</span>" + txt;
		                td = td-1;
	                }else{
	                	txt =  "&nbsp;&nbsp;&nbsp;&nbsp;" + txt ;
	                }
                }
                txt += txt1;
                sb.append(txt);
                txt = "";
                td = 0;
        }
        
        else if(type.equals("topicLen")){
            value = ("<span style=\"color:#000099\">" + value);
            value +=(" chars</span>");
            if(idIs>0){
                sb.append("<a href=\"");
                sb.append(url);
                sb.append("&tID="+idIs+"&reID="+linkId+"&act=re\">");
                sb.append(value);
                sb.append("</a>");
            }else{
                sb.append(value);
            }
        }
   
        else if(type.equals("topicScript")){
            value = EncodeString.htmlEncoder(value);
            value = csrs.srTopic(value,"");
            String value2 = value;
            if(linkId>0 && linkId < EncodeString.Glength(value)){
                value = EncodeString.Gsubstring(value, 1, linkId, "UTF-8");
            }
            sb.append("document.write(\"<a href=");
            if(url!=null){
                sb.append(url);
            }else{
                sb.append("clubPage.jsp?ccStype=1");
            }
            sb.append("&tID="+ idIs +"");
            /*if(linkId>0){
                sb.append("&reID=");
                sb.append(linkId);
            }
            */
            if(ccID>0){
                sb.append("&ccID=");
                sb.append(ccID);
            } 
            if(property!=null && !property.equals("")){
                sb.append(" target=");
                sb.append(property);
                sb.append("");
            }
            sb.append(" title=\\\"");
            sb.append(value2);
            sb.append("\\\">");
            sb.append(value);
            sb.append("</a>\");");
        }
        else if(type.equals("img_listMoodScript")){
            if(value.equals("0")){
                value = "1";
            }
            sb.append("document.write(\"<img alt=心情 src=GVimgs/GamVanMood/");
            sb.append(value);
            sb.append(".gif  align=absmiddle />\");");
        }

        else{
            sb.append(value);
        }
        outWrite(sb);
        sb.delete(0, sb.length());
        return EVAL_PAGE;
    }

   
    public void outWrite(String s){
        try {
            pageContext.getOut().write(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void outWrite(StringBuffer s){
        try {
            pageContext.getOut().write(s.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
