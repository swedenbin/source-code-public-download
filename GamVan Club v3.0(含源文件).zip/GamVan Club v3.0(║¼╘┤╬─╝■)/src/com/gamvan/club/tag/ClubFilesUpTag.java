/*
 * Created on 2005-8-30
 * Made In GamVan
 */
package com.gamvan.club.tag;

import java.io.IOException;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;

import com.gamvan.html.OutPrint;
import com.gamvan.tools.EncodeString;

public class ClubFilesUpTag  extends TagSupport{
    private static final long serialVersionUID = 1L;

    private String type="";
    private String value="";
    private String property="";
    private boolean bea = false;
    private String name="";
    private int idIs = 0;
    private int linkId = 0;
    private String url;
    
    EncodeString es = new EncodeString();
    
    public void setLinkId(int linkId) {
        this.linkId = linkId;
    }
    public void setIdIs(int idIs) {
        this.idIs = idIs;
    }
    public void setType(String s){
        this.type = s;
    }
    public void setValue(String s){
        this.value = s.trim();
    }

    public void setProperty(String s){
        this.property = s;
    }

    public void setBea(boolean bea) {
        this.bea = bea;
    }
    
    
    public void setName(String s){
        this.name = s;
    }
    
    public void setUrl(String s){
        this.url = s;
    }
    
    
    public int doStartTag() throws JspTagException{
        return SKIP_BODY;
    }

    public int doEndTag() throws JspTagException{
        StringBuffer sb = new StringBuffer();      
        if(type.equals("fileName")){
            if(url!=null && !url.equals("")){
                url = url.replace("/upFiles","");
                sb.append("<a href=\"");
                sb.append(url);
                sb.append("\" ");
                sb.append(" title=\"");
                sb.append(property);
                sb.append("\" ");
                sb.append("  target=\"_blank\">");
                sb.append(value);
                sb.append("</a>");
            }else{
                sb.append(value);
            }
        }
        
        else if(type.equals("byUser")){
            sb.append("<a href=\"");
            if(url!=null&&!url.equals("")){
                sb.append(url);
            }
            sb.append("userInfo.jsp?userID=");
            sb.append(idIs);
            sb.append("\" target=\"_blank\">");
            sb.append(value);
            sb.append("</a>");
        }
        
        else if(type.equals("ccName")){
            sb.append("<a href=\"");
            if(url!=null&&!url.equals("")){
                sb.append(url);
            }
            sb.append("clubClass.jsp?ccID=");
            sb.append(idIs);
            sb.append("\" target=\"blank\">");
            sb.append(value);
            sb.append("</a>");
            
        }

        else if(type.equals("dateTime")){
            value = OutPrint.isDateHtml(value);
            sb.append(value);
        }
        
        else if(type.equals("htmlCheckbox")){
            sb.append("<input name=\"cfID\" type=\"checkbox\" id=\"cfID\" value=\"");
            sb.append(idIs);
            sb.append("\">");
        }
        
        else if(type.equals("fileSafeUrl")){
            sb.append(property);
            sb.append("/file.gv?id=");
            sb.append(idIs);
        }
        
        else{
            sb.append(value);
        }
        
        outWrite(sb);
        sb.delete(0, sb.length());
        return EVAL_PAGE;
    }



    public void outWrite(String s){
        try {
            pageContext.getOut().write(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void outWrite(StringBuffer s){
        try {
            pageContext.getOut().write(s.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


