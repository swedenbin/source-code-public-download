/*
 * Created on 2005-8-7
 * Made In GamVan
 */
package com.gamvan.club.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import com.gamvan.club.classed.ClubClassInfo;
import com.gamvan.club.item.ClubClassItem;
import com.gamvan.club.item.ClubUserGradeItem;
import com.gamvan.club.user.ClubUserGrade;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubUseropTag  extends TagSupport{
    private static final long serialVersionUID = 1L;
    private String type="";
    private String value="";
    private String property="";
    private boolean bea = false;
    private String name="";
    private int idIs = 0;
    private int linkId = 0;
    private String url;
    private ClubUserGrade cug = new ClubUserGrade();
    private ClubUserGradeItem cugi = null;
    private ClubClassInfo cci = new ClubClassInfo();
    private ClubClassItem ccit = null;
    
    public int doStartTag() throws JspException {
        return SKIP_BODY;
    }
    
    
    public int doEndTag() throws JspException {
        
        StringBuffer sb = new StringBuffer();
        if(type.equals("htmlCheckbox")){
            sb.append("<input name=\"uoID\" type=\"checkbox\" id=\"uoID\" value=\"");
            sb.append(idIs);
            sb.append("\">");
         }
        
        else if(type.equals("htmlEdit")){
            sb.append("<a href=\"");
            if(url!=null){
                sb.append(url);
            }
            sb.append("clubUseropEdit.jsp?uoID=");
            sb.append(idIs);
            sb.append("&ccID=");
            sb.append(linkId);
            sb.append("&ugID=");
            sb.append(property);
            sb.append("&act=edit\">编辑</a>");
        }
        
        else if(type.equals("uoUser")){
            sb.append("<a href=\"");
            if(url!=null){
                sb.append(url);
            }
            sb.append("userInfo.jsp?userID=");
            sb.append(idIs);
            sb.append("\">");
            sb.append(value);
            sb.append("</a>");
        }
        else if(type.equals("uoByUser")){
            sb.append("<a href=\"");
            if(url!=null){
                sb.append(url);
            }
            sb.append("userInfo.jsp?userID=");
            sb.append(idIs);
            sb.append("\" target=\"_blank\">");
            sb.append(value);
            sb.append("</a>");
        }
        
        else if(type.equals("uoGradeName")){
            if(idIs>0){
                cugi = cug.userGradeInfo(idIs);
                if(cugi!=null){
                    sb.append(cugi.getUgName());
                }else{
                    sb.append("<font color=\"#cccccc\">无法判断</font>");
                }
            }else if(idIs==0){
                sb.append("无法判断");
            }
        } 
        
        else if(type.equals("uoCcName")){
            if(idIs>0){
                cci.setCcID(idIs);
                ccit = cci.getClubClassInfo();
                if(ccit!=null){
                    sb.append("<a href=\"");
                    if(url!=null){
                        sb.append(url);
                    }
                    sb.append("clubClass.jsp?ccID=");
                    sb.append(idIs);
                    sb.append("\" target=\"_blank\" >");
                    sb.append(ccit.getCcName());
                    sb.append("</a>");
                }else{
                    sb.append("<font color=\"#cccccc\">无法获取</font>");
                }
            }else{
                sb.append("全部版面");
            }
        } 
        
        else if(type.equals("uoIs")){
            if(idIs==1){
                sb.append("<font color=\"#ff0000\">开通</font>");
            }else{
                sb.append("<font color=\"#000000\">关闭</font>");
            }
        }
        
        
        else{
            sb.append(value);
        }      
        
        outWrite(sb);
        sb.delete(0, sb.length());
        ccit = null;

        return EVAL_PAGE;
    }

    public void outWrite(StringBuffer s){
        try {
            pageContext.getOut().write(s.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public boolean getBea() {
        return bea;
    }


    public void setBea(boolean bea) {
        this.bea = bea;
    }


    public int getIdIs() {
        return idIs;
    }


    public void setIdIs(int idIs) {
        this.idIs = idIs;
    }


    public int getLinkId() {
        return linkId;
    }


    public void setLinkId(int linkId) {
        this.linkId = linkId;
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public String getProperty() {
        return property;
    }


    public void setProperty(String property) {
        this.property = property;
    }


    public String getType() {
        return type;
    }


    public void setType(String type) {
        this.type = type;
    }


    public String getUrl() {
        return url;
    }


    public void setUrl(String url) {
        this.url = url;
    }


    public String getValue() {
        return value;
    }


    public void setValue(String value) {
        this.value = value;
    } 

}
