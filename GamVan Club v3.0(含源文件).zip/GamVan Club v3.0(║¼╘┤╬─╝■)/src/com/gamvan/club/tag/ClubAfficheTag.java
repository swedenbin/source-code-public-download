/*
 * Created on 2005-8-6
 * Last modified on 2005-8-21
 * Powered by GamVan.com
 */
package com.gamvan.club.tag;

import java.io.IOException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;
import com.gamvan.tools.EncodeString;

public class ClubAfficheTag extends TagSupport{
    private static final long serialVersionUID = 1L;
    private String type="";
    private String value="";
    private String property="";
    private boolean bea = false;
    private String name="";
    private int idIs = 0;
    private int linkId = 0;
    private String url;
    boolean isAfter = false;
  
    public void setLinkId(int linkId) {
        this.linkId = linkId;
    }
    public void setIdIs(int idIs) {
        this.idIs = idIs;
    }
    public void setType(String s){
        this.type = s;
    }
    public void setValue(String s){
        this.value = s.trim();
    }

    public void setProperty(String s){
        this.property = s;
    }

    public void setBea(boolean bea) {
        this.bea = bea;
    }
    
    
    public void setName(String s){
        this.name = s;
    }
    
    public void setUrl(String s){
        this.url = s;
    }
    
    
    public int doStartTag() throws JspTagException{
        return SKIP_BODY;
    }

    public int doEndTag() throws JspTagException{
    	EncodeString es = new EncodeString();
        StringBuffer sb = new StringBuffer();
        if(type.equals("caTopic")){
            sb.append("<a href=\"");
            if(url!=null){
                sb.append(url);
            }
            sb.append("clubAfficheInfo.jsp?caID=");
            sb.append(idIs);
            sb.append("&ccID=");
            sb.append(linkId);
            sb.append("\" target=\"_blank\">");
            sb.append(value);
            sb.append("</a>");
        }
        
        else if(type.equals("caContent")){
            value = EncodeString.htmlEncoder(value);
            value = es.ubbEncoder(value);
            sb.append(value);
        }
        
        else if(type.equals("caAddTime")){
            sb.append(value.replace(".0",""));
        }
        
        else if(type.equals("caDays")){
            if(idIs>0){
                sb.append(idIs);
                sb.append(" 天");
            }else{
                sb.append("长期有效");
            }
        }
        
        else if(type.equals("htmlCheckbox")){
            sb.append("<input name=\"caID\" type=\"checkbox\" id=\"caID\" value=\"");
            sb.append(idIs);
            sb.append("\" />");
        }
        else if(type.equals("htmlEdit")){
            sb.append("<a href=\"clubAfficheEdit.jsp?caID=");
            sb.append(idIs);
            sb.append("&ccID=");
            sb.append(linkId);
            sb.append("&act=edit\" />编辑</a>");
        } 
        
        else {
            sb.append(value);
        }
        
        outWrite(sb);
        sb.delete(0, sb.length());
        return EVAL_PAGE;
    }



    public void outWrite(String s){
        try {
            pageContext.getOut().write(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void outWrite(StringBuffer s){
        try {
            pageContext.getOut().write(s.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

