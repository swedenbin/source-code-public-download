/*
 * Created on 2005-7-30
 * Last modified on 2006-1-21
 * Powered by GamVan.com
 */
package com.gamvan.club.tag;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;

import com.gamvan.club.topic.ClubTopicLogInfo;
import com.gamvan.club.topic.ClubTopicType;
import com.gamvan.club.ClubStringReplaces;
import com.gamvan.tools.EncodeString;

public class ClubTopicPageTag extends TagSupport{
    private static final long serialVersionUID = 1L;
    private ClubStringReplaces csrs = new ClubStringReplaces();
    
    private ClubTopicLogInfo ctli = new ClubTopicLogInfo();
    private ClubTopicType ctt = new ClubTopicType();
    
    private String type="";
    private String value="";
    private String property="";
    private boolean bea = false;
    private boolean bea_img = false;
    private boolean bea_url = false;
    private String name="";
    private int idIs = 0;
    private int reidIs = 0;
    private int linkId = 0;
    private int pro = 0;
    private String url;
    boolean isAfter = false;
    private int tpType=0;
    private double tpTypeNum=0;
    private double tpUserNum=0;
    private byte isDel = 0;
    
    
	public void setIsDel(byte isDel) {
		this.isDel = isDel;
	}
    public void setTpType(int tpType) {
        this.tpType = tpType;
    }
    public void setTpTypeNum(double tpTypeNum) {
        this.tpTypeNum = tpTypeNum;
    }
    public void setTpUserNum(double tpUserNum) {
        this.tpUserNum = tpUserNum;
    }
    
    
    public void setBea_img(boolean bea_img) {
        this.bea_img = bea_img;
    }
    public void setBea_url(boolean bea_url) {
        this.bea_url = bea_url;
    }
    public void setLinkId(int linkId) {
        this.linkId = linkId;
    }
    public void setIdIs(int idIs) {
        this.idIs = idIs;
    }
    public void setType(String s){
        this.type = s;
    }
    public void setValue(String s){
        this.value = s.trim();
    }

    public void setProperty(String s){
        this.property = s;
    }

    public void setBea(boolean bea) {
        this.bea = bea;
    }
    
    
    public void setName(String s){
        this.name = s;
    }
    
    public void setUrl(String s){
        this.url = s;
    }
    
    
    public int doStartTag() throws JspTagException{
        return SKIP_BODY;
    }

    public int doEndTag() throws JspTagException{
        if(value==null){
            value = "";
        }
        EncodeString es = new EncodeString();
        StringBuffer sb = new StringBuffer();
        if(type.equals("contentCopyRight")){
            switch(idIs){
            case 1:
                sb.append("<hr width=\"100%\" size=\"1\" noshade=\"noshade\" />");
                sb.append("作者声明：该文版权归作者个人所有，<strong>");
                sb.append(name);
                sb.append("</strong>享有网络发表权，其他网站、媒体未经许可，不得以任何形式转载！");
                break;
            case 2:
                sb.append("<hr width=\"100%\" size=\"1\" noshade=\"noshade\" />");
                sb.append("作者声明：该文版权为网络共享，大家喜欢的话可以任意转载，传抄……");
                break;
            case 3:
                sb.append("<hr width=\"100%\" size=\"1\" noshade=\"noshade\" />");
                sb.append("作者声明：该文在未经商业用途的情况下，可任意转载，传抄……");
                break;
            }             
        }
        else if(type.equals("content")){
            value = EncodeString.htmlEncoder(value);
            es.setUbbImg(bea_img);
            es.setUbbUrl(bea_url);
            value = es.ubbEncoder(value);
            
            ctt.setTopicType(tpType);
            ctt.setTopicTypeNum(tpTypeNum);
            ctt.setUserTypeNum(tpUserNum);
            value = ctt.encoderType(value);
            value = csrs.srContent(value,"");
            
            sb.append("<DIV class=\"content\">");
            if(value.length()<1){
                value="<font color=\"#cccccc\">这头懒 ^&^ , 啥也没写 ^_^</font>";
            }
            if(pro==5){ // topicPro
                if(bea){
                    sb.append("<font color=\"#ff0000\">该用户发言已被屏闭，您有权限强行浏览该贴！</font>");
                    sb.append("<hr width=\"100%\" size=\"1\" noshade=\"noshade\" />");
                    sb.append(value);
                }else{
                    sb.append("<font color=\"#ff0000\">==&lt;该主题被禁止显示&gt;==</font><br><br>");
                }
            }
            else if(isDel==1){
                if(bea){
                    sb.append("<strong><font color=\"#666666\">此主题已被删除，您有权限强行浏览该贴！</font></strong>");
                    sb.append("<hr width=\"100%\" size=\"1\" noshade=\"noshade\" />");
                    sb.append("<font color=\"#666666\">");
                    sb.append(value);
                    sb.append("</font>");
                }else{
                    sb.append("<font color=\"#666666\"><strong>此主题已被删除！</strong></font>");
                }
            }
            else{
                sb.append(value);
            } 
            sb.append("</DIV>");
            
        }
        else if(type.equals("topicLog")){
            if(ctli.pageLogInfoHtml(idIs, linkId)){
                sb.append(ctli.getPrtHtml());
            }
        }
        else if(type.equals("contentUserPen")){
            if(bea) {
                value = EncodeString.htmlEncoder(value);
                value = es.ubbEncoder(value);
                sb.append("<hr width=\"100%\" size=\"1\" noshade=\"noshade\" />");
                sb.append(value);
            }
        }
        else if(type.equals("img_userWeb")){
        	if(!value.equals("")){
	        	sb.append("<a href=\"");
	        	sb.append(value);
	        	sb.append("\" target=\"_blank\"><img alt=\"查看个人主页\" src=\"GVimgs/pages/1.gif\" border=\"0\" /></a>");
           	}
        }
        else if(type.equals("img_userInfo")){
        	if(idIs>0){
        		sb.append("<a href=\"userInfo.jsp?userID=");
        		sb.append(idIs);
        		sb.append("\"  target=\"_blank\"><img alt=\"查看用户信息\" src=\"GVimgs/pages/2.gif\" border=\"0\" /></a>");
        	}
        }
        else if(type.equals("img_userEmail")){
        	if(idIs>0){
        		sb.append("<a onClick=\"return openPop(this,500,400,100,200);\" ");
        		sb.append(" href=\"emailSend.jsp?userID=");
        		sb.append(idIs);
        		sb.append("\" target=\"_self\"><img alt=\"给用户发送Email\" src=\"GVimgs/pages/3.gif\" border=\"0\" /></a>");
        	}
        }
        else if(type.equals("img_re")){
        	sb.append("<a href=\"clubPost.jsp?ccID=");
        	sb.append(linkId);
        	sb.append("&tID=");
        	sb.append(idIs);
        	sb.append("&reID=");
        	sb.append(reidIs);
        	sb.append("&act=re\" target=\"_self\"><img alt=\"回复主题\" src=\"GVimgs/pages/7.gif\" border=\"0\" /></a>");
        }
        else if(type.equals("img_quote")){
        	sb.append("<a href=\"clubPost.jsp?ccID=");
        	sb.append(linkId);
        	sb.append("&tID=");
        	sb.append(idIs);
        	sb.append("&reID=");
        	sb.append(reidIs);
        	sb.append("&act=re&ac=quote\" target=\"_self\"><img alt=\"回复主题\" src=\"GVimgs/pages/8.gif\" border=\"0\" /></a>");
        }
        else{
            sb.append(value);
        }
        outWrite(sb);
        sb.delete(0, sb.length());
        return EVAL_PAGE;
    }


    public String isDateHtml(String sb){
        String d = "";
        String t = "";
        sb = sb.replace(".0","");
        d = sb.substring(0, sb.indexOf(" "));
        t = sb.substring(sb.indexOf(" ")+1, sb.length());
        String ts=""; 
        
        boolean isAfter;
        try{
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
            String isDate = sdf.format(new java.util.Date());   
            java.util.Date date1 ;
            java.util.Date date0 ;
            ts= (d);
            date1 = sdf.parse(ts);
            date0 = sdf.parse(isDate);
            isAfter = date0.after(date1);   
            if(!isAfter){
                ts=("<span style=\"color:#cc0000;font-weight: bold;\">今天</span> ");
                ts+=(" <span style=color:#990066>"+t);  
                ts=(ts.substring(0,(ts.length()-3)));
                ts+=("</span>");                
            }else{
               ts+=(" <span style=color:#990066>"+t);
               ts=(ts.substring(2,(ts.length()-3)));
               ts+=("</span>");
            }
            this.isAfter = isAfter;
        }catch(ParseException e){
            
        }
        return ts;       
    }
    
    
    public void outWrite(String s){
        try {
            pageContext.getOut().write(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void outWrite(StringBuffer s){
        try {
            pageContext.getOut().write(s.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void setPro(int pro) {
        this.pro = pro;
    }
	public void setReidIs(int reidIs) {
		this.reidIs = reidIs;
	}


}
