/*
 * Created on 2005-7-10
 * Last modified on 2005-7-10
 * Powered by GamVan.com
 */
package com.gamvan.club.tag;

import java.io.IOException;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;

import com.gamvan.html.OutPrint;
import com.gamvan.net.URL;
import com.gamvan.tools.EncodeString;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubUserTag extends TagSupport{
    
    private static final long serialVersionUID = 1L;
    
    private String type="";
    private String value="";
    private String property="";
    private boolean bea = false;
    private String name="";
    private int idIs = 0;
    private String url;

    public void setIdIs(int idIs) {
        this.idIs = idIs;
    }
    public void setType(String s){
        this.type = s.trim();
    }
    public void setValue(String s){
        this.value = s.trim();
    }

    public void setProperty(String s){
        this.property = s;
    }

    public void setBea(boolean bea) {
        this.bea = bea;
    }
    
    
    public void setName(String s){
        this.name = s.trim();
    }
    
    public void setUrl(String s){
        this.url = s;
    }
    
    public int doStartTag() throws JspTagException{
        return SKIP_BODY;
    }
    
    public int doEndTag() throws JspTagException{
        StringBuffer sb = new StringBuffer();
        EncodeString es = new EncodeString();
        if(type.equals("userSex")){
            if(value.equals("1")){
                sb.append("男");
            }else if(value.equals("2")){
                sb.append("<font color=\"#cc0099\">女</font>");
            }
            else if(value.equals("0")){
                sb.append("保密");
            }     
            
        }

        else if(type.equals("userName")){
            value = EncodeString.htmlEncoder(value);
           if(bea){
               sb.append("<font color=\"#aaaaaa\">");
               sb.append(value);
               sb.append("</font>");
           }else{
               if(idIs>0){
                   sb.append("<a href=\"");
                   if(url!=null){
                       sb.append(url);
                   }
                   sb.append("userInfo.jsp?userID="+idIs+"\" target=\"_blank\">"+ value + "</a>");
               }else{
                   sb.append(value);
               }
           } 
       }
       else if(type.equals("userName2")){
    	   value = EncodeString.htmlEncoder(value);
    	   if(!value.equals("")){
    		   if(bea){
                   sb.append("<font color=\"#aaaaaa\">");
                   sb.append(value);
                   sb.append("</font>");
               }else{
                   if(idIs>0){
                       sb.append("<a href=\"");
                       if(url!=null){
                           sb.append(url);
                       }
                       sb.append("userInfo.jsp?userID=");
                       sb.append(idIs);
                       sb.append("\" target=\"_blank\" style=\"color:#009900\">");
                       sb.append(value);
                       sb.append("</a>");
                   }else{
                	   sb.append("<span style=\"color:#009900\">");
                       sb.append(value);
                       sb.append("</span>");
                   }
               }  
    	   }
       }
       else if(type.equals("userEmail")){
           if(idIs==0){
               sb.append(value);
           }else if(idIs==1){
               if(bea){
                   sb.append(value);
               }else{
                   sb.append("<font color=\"#ff0000\">好友可见</font>");
               }
           }else if(idIs==2){
               sb.append("<font color=\"#990000\">已设置保密</font>");
           }
           
       }
        
       else if(type.equals("userWeb")){
           if(value.indexOf("http://")==-1 && !value.equals("")){
               value= "http://" + value;
           }
           if(url!=null){
               if(url.indexOf("http")==-1 || url.indexOf("ftp")==-1){
                   sb.append("<a href=\""+value+"\" target=\"_blank\">"+value+"</a>");
               }else{
                   sb.append("<a href=\""+url+"\" target=\"_blank\">"+value+"</a>");
               }
           }else{
               sb.append(value);
           }    
       }
        
       else if (type.equals("userPen")||type.equals("userIntro")){
           value = EncodeString.htmlEncoder(value);
           value = es.ubbEncoder(value);
           sb.append(value);

       }
       
       else if(type.equals("userRegTime")||type.equals("userLastTime")){
           if(value!=null && !value.equals("null")){
               value = value.substring(0,value.lastIndexOf("."));
           }
           sb.append(value);
       }
       
       else if(type.equals("dateTime")){
           value = OutPrint.isDateHtml(value);
           sb.append(value);
       }   

       else if(type.equals("userPic")){
    	   if(value!=null&&!value.equals("")){
	           if(bea){ //显示图片 否则显示路径
	               value = "<img src=\""+ value +"\" border=\"0\" onload=\"javascript:if(this.width > 120){this.width = 120};\"/>";
	           }
	           sb.append(value);
    	   }else{
    		   sb.append("");
    	   }
       }
             
       else if(type.equals("htmlCfID")){
           sb.append("<input type=\"checkbox\" name=\"cfID\" value=\"");
           sb.append(idIs);
           sb.append("\">");
       }
        
       else if(type.equals("htmlCheckbox")){
           sb.append("<input type=\"checkbox\" name=\"");
           sb.append(property);
           sb.append("\" value=\"");
           sb.append(idIs);
           sb.append("\" />");
       }
        
       
       else if(type.equals("isOnLine")){
           if(idIs==1){
               sb.append("<font color=\"#FF0000\">在线</font>");
           }else{
               sb.append("<font color=\"#666666\">离线</font>");
           }
       }
       
       else if(type.equals("imgMessage")){
           property = URL.urlEncoder(property,"UTF-8");
           sb.append("<a ");
           sb.append(" onClick=\"return openPop(this,700,500,100,200);\" ");
           sb.append(" href=\"userBox.jsp?act=write");
           if(!property.equals("")){
               sb.append("&userName=");
               sb.append(property);
           }else{
               sb.append("&userID=");
               sb.append(idIs);
           }
           sb.append("\" target=\"blank\">");
           sb.append("<img src=\"./GVimgs/pages/4.gif\" border=\"0\"/></a>");
       }
        
       else if(type.equals("imgFriend")){
           property = URL.urlEncoder(property,"UTF-8");
           sb.append("<a ");
           sb.append(" onClick=\"return openPop(this,700,500,100,200);\" ");
           sb.append(" href=\"myFriendAdd.jsp?");
           if(!property.equals("")){
               sb.append("userName=");
               sb.append(property);
           }else{
               sb.append("userID=");
               sb.append(idIs);
           }
           sb.append("\" target=\"blank\">");
           sb.append("<img src=\"./GVimgs/pages/5.gif\" border=\"0\"/></a>");
       }
        
        
        
        
       else if(type.equals("businessType")){
           switch(idIs){
           case 1:
               sb.append("积分兑换金币");
               break;
           case 2:
               sb.append("金币购买积分");
               break;
           case 3:
               sb.append("转赠他人");
               break; 
           case 4:
               sb.append("购买物品");
               break;
           case 5:
               sb.append("存入银行");
               break; 
           }
       }
        
       else if(type.equals("businessLog")){
           value = EncodeString.htmlEncoder(value);
           sb.append(value);
       }
        
        
       else{
           sb.append(value);
       }
        outWrite(sb.toString());
        sb.delete(0, sb.length());
        return EVAL_PAGE;
    }
    

    public void outWrite(String s){
        try {
            pageContext.getOut().write(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
