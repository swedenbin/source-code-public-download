/*
 * Created on 2005-8-20
 * Made In GamVan
 */
package com.gamvan.club.tag;

import java.io.IOException;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;

import com.gamvan.html.OutPrint;
import com.gamvan.tools.EncodeString;

public class ClubMessageTag  extends TagSupport{
    
    private static final long serialVersionUID = 1L;

    private String type="";
    private String value="";
    private String property="";
    private boolean bea = false;
    private String name="";
    private int idIs = 0;
    private int linkId = 0;
    private String url;
    boolean isAfter = false;
    
    public void setLinkId(int linkId) {
        this.linkId = linkId;
    }
    public void setIdIs(int idIs) {
        this.idIs = idIs;
    }
    public void setType(String s){
        this.type = s;
    }
    public void setValue(String s){
        this.value = s.trim();
    }

    public void setProperty(String s){
        this.property = s;
    }

    public void setBea(boolean bea) {
        this.bea = bea;
    }
    
    
    public void setName(String s){
        this.name = s;
    }
    
    public void setUrl(String s){
        this.url = s;
    }
    
    
    public int doStartTag() throws JspTagException{
        return SKIP_BODY;
    }
    
    public int doEndTag() throws JspTagException{
        StringBuffer sb = new StringBuffer();
        if(type.equals("topic")){
            value = EncodeString.htmlEncoder(value);
            sb.append("<a href=\"userMessage.jsp?cmID=");
            sb.append(idIs);
            sb.append("&cmReID=");
            sb.append(linkId);
            sb.append("&act=");
            sb.append(property);
            sb.append("\">");
            sb.append(value);
        }
        else if(type.equals("content")){
        	EncodeString es = new EncodeString();
            value = EncodeString.htmlEncoder(value);
            value = es.ubbEncoder(value);
            if(value.equals("")){
               value ="<font color=\"#cccccc\">这头懒 ^&^ , 啥也没写 ^_^</font>";
            }            
            sb.append(value);
        }
        else if(type.equals("datetime")){
            value = OutPrint.isDateHtml(value);
            sb.append(value);
        }
        
        else if(type.equals("htmlReImg")){
            sb.append("<a onclick=\"return openPop(this,500,300,200,300)\" ");
            sb.append(" href=\"userReMessage.jsp?cmID=");
            sb.append(idIs);
            sb.append("&cmReID=");
            sb.append(linkId);
            sb.append("#re\"><img src=\"GVimgs/pages/15.gif\" border=\"0\"/>");
            sb.append("</a>");
        }
        
        else if(type.equals("htmlSendImg")){
            sb.append("<a href=\"userBox.jsp?act=send&action=send&cmID=");
            sb.append(idIs);
            sb.append("\"><img src=\"GVimgs/pages/15.gif\" border=\"0\"  alt=\"发送\"/>");
            sb.append("</a>");
        } 
        
        else if(type.equals("htmlCheckbox")){
            sb.append("<input name=\"cmID\" type=\"checkbox\" id=\"cmID\" value=\"");
            sb.append(idIs);
            sb.append("\" />");
        }
        
        else if(type.equals("htmlIsTake")){
            if(bea){
                sb.append("<img src=\"GVimgs/userBox/lookyes.gif\" alt=\"已读\"/>");
            }else{
                sb.append("<img src=\"GVimgs/userBox/lookno.gif\"  alt=\"未读\"/>");
            }
        }
        
        else if(type.equals("htmlIsSend")){
            if(bea){
                sb.append("<img src=\"GVimgs/userBox/lookyes.gif\" alt=\"已发送\"/>");
            }else{
                sb.append("<img src=\"GVimgs/userBox/lookno.gif\"  alt=\"未发送\"/>");
            }
        }
        
        else{
            sb.append(value);
        }
        
        
        
        outWrite(sb);
        sb.delete(0, sb.length());
        return EVAL_PAGE;
    }



    public void outWrite(String s){
        try {
            pageContext.getOut().write(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void outWrite(StringBuffer s){
        try {
            pageContext.getOut().write(s.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
