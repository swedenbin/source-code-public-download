/*
 * Created on 2005-8-3
 * Last modified on 2005-8-3
 * Powered by GamVan.com
 */
package com.gamvan.club.tag;

import java.io.IOException;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;

public class ClubUserGradeTag   extends TagSupport{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String type="";
    private String value="";
    private String property="";
    private boolean bea = false;
    private String name="";
    private int idIs = 0;
    private int linkId = 0;
    private String url;
    
    /*
     *  (non-Javadoc)
     * @see javax.servlet.jsp.tagext.Tag#doStartTag()
     */
    public int doStartTag() throws JspTagException{
        return SKIP_BODY;
    }
    /*
     *  (non-Javadoc)
     * @see javax.servlet.jsp.tagext.Tag#doEndTag()
     */
    public int doEndTag() throws JspTagException{
        StringBuffer sb = new StringBuffer();
        if(type.equals("option")){
            sb.append("<option value=\"");
            sb.append(idIs);
            sb.append("\"");
            if(idIs==linkId){
                sb.append(" selected");
            }
            sb.append(">");
            sb.append(value);
            sb.append("</option>");
         }
        
        
        else if(type.equals("linkOption")){
            sb.append("<option value=\"clubUserGrade.jsp?ugID=");
            sb.append(idIs);
            sb.append("\"");
            if(idIs==linkId){
                sb.append(" selected");
            }
            sb.append(">");
            sb.append(value);
            sb.append("</option>");

        }
        
        else if(type.equals("linkOption2")){
            sb.append("<option value=\"");
            if(url!=null){
                sb.append(url);
            }
            sb.append("&ugid="+idIs);
            sb.append("&ugID="+idIs);
            sb.append("\"");
            if(idIs==linkId){
                sb.append(" selected");
            }
            sb.append(">");
            sb.append(value);
            sb.append("</option>");

        }        
        
        else{
            sb.append(value);
        }        
        outWrite(sb);
        sb.delete(0, sb.length());
        return EVAL_PAGE;
    }

    /**
     * 
     * @param s
     */
    public void outWrite(String s){
        try {
            pageContext.getOut().write(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 
     * @param s
     */
    public void outWrite(StringBuffer s){
        try {
            pageContext.getOut().write(s.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    } 
    
    public boolean getBea() {
        return bea;
    }
    public void setBea(boolean bea) {
        this.bea = bea;
    }
    public int getIdIs() {
        return idIs;
    }
    public void setIdIs(int idIs) {
        this.idIs = idIs;
    }
    public int getLinkId() {
        return linkId;
    }
    public void setLinkId(int linkId) {
        this.linkId = linkId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getProperty() {
        return property;
    }
    public void setProperty(String property) {
        this.property = property;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getUrl() {
        return url;
    }
    public void setUrl(String url) {
        this.url = url;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
    
    
}
