package com.gamvan.club;
import com.gamvan.club.dao.impl.ClubInfoImpl;
import com.gamvan.club.item.ClubInfoItem;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubInfoEdit extends ClubInfoItem{
  
    private static final long serialVersionUID = 1L;
    private String message = "";
    private ClubInfoImpl ciim = new ClubInfoImpl();
    
    /**
     * 更新社区回复表的最后一条主题的ID 用于主题表主题排序
     * @param id
     * 2005-12-3 15:41:48 Made In GamVan
     * com.gamvan.club
     */
    public void updateLastReID(int id){
        try{
            ciim.clubLastReIDUpdate(id);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    /**
     * 更新注册协议
     * 2005-12-3 15:38:18 Made In GamVan
     * com.gamvan.club
     */
    public void updateRegAgree(){
        try{
            ciim.clubRegAgreeUpdate(clubRegAgree);
            message = "用户注册协议更新成功！";
        }catch(Exception e){
            message = e.toString();
        }      
    }
    
    /**
     * 更新社区基本信息
     * 2005-12-3 15:41:54 Made In GamVan
     * com.gamvan.club
     */
    public void setClubInfoEdit(){
        try{
            ciim.setClubName(clubName);
            ciim.setClubUrl(clubUrl);
            ciim.setClubTitle(clubTitle);
            ciim.setClubMenu(clubMenu);
            ciim.setClubMeta(clubMeta);
            ciim.setClubSmtp(clubSmtp);
            ciim.setClubSmtpID(clubSmtpID);
            ciim.setClubSmtpPass(clubSmtpPass);
            ciim.setClubUpfileOpen(clubUpfileOpen);
            ciim.setClubUpfileMax(clubUpfileMax);
            ciim.setClubUpfileExt(clubUpfileExt);
            ciim.setClubUpfileUser(clubUpfileUser);
            ciim.setClubCopyRight(clubCopyRight);
            ciim.setClubYear(clubYear);
            ciim.setClubUserPic(clubUserPic);
            ciim.setClubSmtpPort(clubSmtpPort);
            ciim.setClubSmtpSSL(clubSmtpSSL);
            ciim.setClubRefreshPage(clubRefreshPage);
            ciim.setClubHotTopic(clubHotTopic);
            ciim.setClubHotRe(clubHotRe);
            ciim.setClubUpfileDomain(clubUpfileDomain);
            ciim.setClubTopicIsPass(clubTopicIsPass);
            ciim.setClubEmail(clubEmail);
            ciim.setClubEmailSend(clubEmailSend);
            ciim.clubInfoUpdate();
            message = "社区信息更新成功";
        }
        catch(Exception e){
            message = e.toString();
        }
    }

    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
}
