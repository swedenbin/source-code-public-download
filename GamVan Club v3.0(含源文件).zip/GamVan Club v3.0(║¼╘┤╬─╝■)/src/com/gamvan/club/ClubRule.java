/*
 * Made in GamVan
 * 社区制度相关信息
 */
package com.gamvan.club;

import com.gamvan.club.dao.impl.ClubRuleImpl;
import com.gamvan.club.item.ClubRuleItem;

import org.hibernate.HibernateException;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubRule extends ClubRuleItem{
    private static final long serialVersionUID = 1L;
    private String message = "";
    private ClubRuleImpl crim = new ClubRuleImpl();
    
    public ClubRuleItem ruleInfo(){
        ClubRuleItem cri = null;
        try{
            cri = crim.ruleInfo();
        }catch(HibernateException e){
            message= e.toString();
        }
        return cri;        
    }
    
    
    public void ruleUpdate(){
    	crim.ruleUpdate(crCredit, crMark, crMoney);
    	message = "社区制度更新完成！";
    }
    

    public String getMessage() {
        return message;
    }


   /*
    public static void main(String args[]){
        ConnClub.init();
        ClubRule cr = new ClubRule(); //社区制度
        ClubRuleItem cri = null;
        cri = cr.ruleInfo();
        System.out.println(cri);
        cri = cr.ruleInfo();
        System.out.println(cri);
        System.out.println(cr.getMessage());
    }
    */
}
