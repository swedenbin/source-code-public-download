package com.gamvan.club.topic;

import com.gamvan.club.dao.impl.ClubContentImpl;
import com.gamvan.club.dao.impl.ClubTopicImpl;
import com.gamvan.club.item.ClubContentItem;
import com.gamvan.club.item.ClubContentReItem;
import com.gamvan.club.item.ClubTopicItem;
import com.gamvan.club.item.ClubTopicReUsersItem;
import com.gamvan.club.item.ClubTopicTypeItem;
import com.gamvan.club.item.ClubUserItem;
import com.gamvan.club.user.ClubUsers;
import com.gamvan.tools.FormatDateTime;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicInfo extends ClubTopicItem{
 
    private static final long serialVersionUID = 1L;
    private ClubTopicImpl ctiml = new ClubTopicImpl();
    private ClubContentImpl cciml = new ClubContentImpl();
    private ClubUsers cu = new ClubUsers();
    private ClubTopicTypes ctts = new ClubTopicTypes();
    private ClubContentItem cci;
    private ClubContentReItem ccri;
    private Object obj = null;
    
    /* 格式化当前时间 */
    private String now = FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    
    
    /**
     * 返回已经支付过的金额 
     * @param tid
     * @param userid
     * @param typeinfo 主题类型 1积分浏览 2金币购买 3散分求助
     * @param typenum
     * @return
     * @throws Exception
     */
    public double selectTopicType(int tid, int userid, short typeinfo, double typenum){
        double du = 0;
        ClubTopicTypeItem ctti = null;
        ctts.setUserID(userid);
        ctts.setTypeID(typeinfo);
        ctts.setTopicID(tid);
        ctti = ctts.topicTypeInfo();
        if(ctti!=null)
            du = ctti.getTypeNum();
        return du;
    }
    
    
    /* test
    public static void main(String args[]){
        ConnClub.init();
        ClubTopicInfo cti = new ClubTopicInfo();
        cti.
        
    }
    */
    

    /**
     * 当用户没有购买过当前主题时执行添加操作
     * @param tid
     * @param userid
     * @param typeinfo 主题类型 1积分浏览 2金币购买 3散分求助
     * @param typenum
     * @return
     * @throws Exception
     */
    public boolean addTopicType(int tid, int userid, short typeinfo, double typenum)
    {
        boolean bea = false;
        if(userid<=0){
        	 message = "您尚未登陆，或登陆超时！请重新登陆！";
        	 return bea;
        }
        if(typenum==0){
        	return bea;
        }
            try{
                if(typeinfo==2){ //金钱贴扣除用户今币
                    ClubUserItem cui = new ClubUserItem();
                    cui = cu.userInfo(userid);
                    typeUserName = cui.getUserName();
                    if(cui.getUserMoney()<typenum){
                        message = "您的金币不足，而且无法透支，本次交易失败！";
                    }else{
                        // 扣除购买人的金币
                        cu.userUpdate(userid,0,-typenum,0,3,0); 
                        
                        //取帖子主人
                        ClubTopicItem ctim = new ClubTopicItem();
                        ctim = null;
                        ctim = ctiml.topicInfo(tid);
                        
                        //给帖子主人增加收入
                        if(ctim!=null){
                            cu.userUpdate(ctim.getUserID(),0,typenum,0,3,0);
                        }
                        bea = true;
                        ctts.setTopicID(tid);
                        ctts.setTypeID(typeinfo);
                        ctts.setTypeNum(typenum);
                        ctts.setUserName(typeUserName);
                        ctts.setAddTime(now);
                        ctts.setUserID(userid);
                        ctts.topicTypeAdd();
                    }
                }
            }catch(Exception e){
                message = e.toString() + "系统出现意外错误，请重新尝试，如果不成功请联系在线勤杂工！";
            }
        return bea;
    }
   
    
    
    /**
     * 当用户购买过主题执行更新操作
     * @param tid
     * @param userid
     * @param typeinfo
     * @param typenum
     * @return
     * @throws Exception
     */
    public boolean updateTopicType(int tid, int userid, short typeinfo, double typenum)
    {
        boolean bea = false;
        double payed = selectTopicType(tid, userid, typeinfo, typenum);
        if(userid==0){
        	 message = "您尚未登陆，或登陆超时！请重新登陆！";
        	 return bea;
        }
        try{
            if(typeinfo==2){ 
                ClubUserItem cui = new ClubUserItem();
                cui = cu.userInfo(userid);
                typeUserName = cui.getUserName();
                typenum=typenum-payed;
                if(cui.getUserMoney()<typenum){ // 判断用户所有金币是否足够购买本贴
                    message = "您的金币不足，而且无法透支，本次交易失败！";
                }else{
                    
                    //返回已经支付过的金额 selectTopicType(tid, username, typeinfo, typenum);
                    //金钱贴扣除购买用户今币.
                    cu.userUpdate(userid,0,-typenum,0,3,0);
                    
                    //取帖子主人
                    ClubTopicItem ctim = new ClubTopicItem();
                    ctim = null;
                    ctim = ctiml.topicInfo(tid);
                    
                    //给帖子主人增加收入
                    if(ctim!=null){
                        cu.userUpdate(ctim.getUserID(),0,typenum,0,3,0);
                    }
                      
                    //………………………………
                    bea = true; //购买成功
                    /*
                    sqlCommand = "update GVclubTopicType set typeNum=typ" +
                            "eNum+?, addTime=?, userName=? where userID=? an" +
                            "d topicID=? and typeInfo=?";
                            */     
                    ctts.setTopicID(tid);
                    ctts.setTypeID(typeinfo);
                    ctts.setTypeNum(typenum+payed);
                    ctts.setUserName(typeUserName);
                    ctts.setAddTime(now);
                    ctts.setUserID(userid);
                    ctts.typeUpdate();
                }
            }
        }catch(Exception e){
            message = e.toString() + "系统出现意外错误，请重新尝试，如果不成功请联系在线勤杂工！";
        }
        return bea;
    }
    
    /**
     * 找出主题的所有回复人以被追加
     * @param topicid
     * @return
     * 2005-11-30 22:26:21 Made In GamVan
     * com.gamvan.club.topic
     */
    public ClubTopicReUsersItem selectReUsers(int topicid){
        ClubTopicReUsersItem ctrui = null;
        ClubTopicReUsers ctru = new ClubTopicReUsers();
        try{
            ctrui = ctru.topicReUsers(topicid);
            if(ctrui!=null){
            	this.reUsers = ctrui.getReUsers();
            }
         }catch(Exception e){
            message = e.toString();
        }
        return ctrui;
    }
    
    
    /**
     * 
     * @param tID
     * @param reID
     * @param ccStyle
     * 2005-11-6 1:13:03 Made In GamVan
     * com.gamvan.club.topic
     */
    public void topicUpdate(int tID, int reID, byte ccStyle){
        if(ccStyle==0){
            ctiml.topicUpdateVcount(tID); //更新View 主题表
        }else{
            if(reID>0){
                ctiml.topicReUpdateVcount(tID); //更新View 回复表
            }else{
                ctiml.topicUpdateVcount(tID); //更新View 主题表
            }
        }
    }

    /**
     * 
     * @param tid
     * @param reid
     * @param ccStyle
     * @return
     * 2005-11-6 1:12:50 Made In GamVan
     * com.gamvan.club.topic
     */
    public Object topicInfo(int tid, int reid, byte ccStyle){
        if(ccStyle==1){
            if(reid>0){
            	this.obj = (cciml.contentReInfo(reid));
                com.gamvan.club.item.ClubTopicReItem c 
                	= ctiml.topicReInfo(reid);
                return c;
            }else{
            	this.obj = (cciml.contentInfo(tid));
                com.gamvan.club.item.ClubTopicItem c 
            	= ctiml.topicInfo(tid);
                return c;
            }            
        }else{
        	this.obj = cciml.contentInfo(tid);
            return ctiml.topicInfo(tid);
        }
    }
    
    public Object contentInfo(){
    	return this.obj;
    }
    

    public ClubContentItem getCci() {
        return cci;
    }

    public void setCci(ClubContentItem cci) {
        this.cci = cci;
    }

    public ClubContentReItem getCcri() {
        return ccri;
    }

    public void setCcri(ClubContentReItem ccri) {
        this.ccri = ccri;
    }
}