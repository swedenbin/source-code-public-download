/*
 * Created on 2005-6-26
 * Made In GamVan
 */
package com.gamvan.club.topic;
import java.util.List;

import org.apache.log4j.Logger;

import com.gamvan.club.dao.impl.ClubContentImpl;
import com.gamvan.club.dao.impl.ClubTopicImpl;
import com.gamvan.club.dao.impl.ClubTopicListImpl;
import com.gamvan.club.item.ClubContentReItem;
import com.gamvan.club.item.ClubTopicItem;

/**
 * update on 2005-9-1
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicResults extends ClubTopicItem{
    private static final long serialVersionUID = 1L;
    private String ccStyle = "0";
    private String menuStyle = "";
    private String topicKeys = "";
    private int pageRows;
    private int totalPage;
    private int isRe = 0; 
    private ClubTopicImpl ctim = new ClubTopicImpl();
    private ClubContentImpl cciml = new ClubContentImpl();
    private ClubTopicListImpl ctlim = new ClubTopicListImpl();
    private int maxTopicID = 0;
    private static final Logger logger = 
    	Logger.getLogger(ClubTopicResults.class.getName());
    /**
     * 我的主题
     * @param page
     * @param pageNum
     * @return
     */
    public List myTopicList(int page, int pageNum){
        List list = null;
        if(topicLayer==0){
            list = ctim.userTopicList(userID, page, pageNum);
        }else{
            list = ctim.userTopicReList(userID, page, pageNum);
        }
        return list;
    }
    
    public int myTopicCount(){
        int i = 0;
        if(topicLayer==0){
        	ctlim.setTopicIsDel(topicIsDel);
            i = ctim.userTopicCount(userID);
        }else if(topicLayer>0){
        	ctlim.setTopicIsDel(topicIsDel);
            i = ctim.userTopicReCount(userID);
        }           
        return i;         
    }

    /**
     * 获取回复表详细内容
     * @return
     */
    public ClubContentReItem contentReItem(){
        ClubContentReItem ccrItem =
        	cciml.contentReInfo(topicReID);
        return ccrItem;
    }
    
    /**
     * 主题搜索集合
     * @param page
     * @param pageNum
     * @return
     */
    public List topicSearch(int page, int pageNum){
        StringBuffer hql = new StringBuffer();
        List list = null;
        try{
            hql.append(" order by topicID desc");
            ctlim.setTopicPro(topicPro); //主要用来判断是否提取精品文章列表。
            ctlim.setCcID(ccID);
            ctlim.setTopicIsPass(true);
            ctlim.setSearchKey(topicKeys);
            ctlim.setUserName(userName);
            if(isRe==0){
            	ctlim.setTopicIsDel(topicIsDel);
                list = ctlim.topicList(page, pageNum, hql.toString());
            }else{
            	ctlim.setTopicIsDel(topicIsDel);
                list = ctlim.topicReList(0, page, pageNum, hql.toString());
            }
        }catch(Exception e){
            list = null;
            message = e.toString();
        }
        return list;
    }
    
    /**
     * 查询数统计
     * @param topicid
     * @return
     */
    public int topicSearchCount(){
        int i = 0;
        try{
            ctlim.setSearchKey(topicKeys);
            ctlim.setTopicPro(topicPro); //主要用来判断是否提取精品文章列表。
            ctlim.setCcID(ccID);
            ctlim.setTopicIsPass(true);
            ctlim.setUserName(userName);
            if(isRe==0){
            	ctlim.setTopicIsDel(topicIsDel);
                i = ctlim.topicCount("");
            }else{
            	ctlim.setTopicIsDel(topicIsDel);
                i = ctlim.topicReCount(0, "");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return i;         
    }

     /**
       * @param page 当前页
       * @param pageNum 每页显示行数
      */
     public List topicList(int page, int pageNum){
         List list = null;
         StringBuffer hql = new StringBuffer();
         try{
             if(maxTopicID>0){
              	hql.append(" and topicID > ");
              	hql.append(maxTopicID);
             }
             if(menuStyle.equals("CurAsk")){ //最新提问
                 hql.append(" and topicType=3 ");
             }
             else if(menuStyle.equals("CurAnswer")){ //最新结贴
                 hql.append(" and topicType=5 ");
             }
             else if(topicReID==-1){ //按发帖先后顺序 倒序排列
                 hql.append(" order by topicID desc");
             }
             else{
                  if(menuStyle.equals("CurTopic")){ //最新主题
                     hql.append(" order by topicOrder desc, topicID desc");
                 }
                 else if(menuStyle.equals("CurHot")){
                     hql.append(" order by topicOrder desc, topicReCount desc, topicViewCount desc,  topicID desc");
                 }
                 else{
                     hql.append(" order by topicOrder desc, topicReID desc, topicID desc");
                 }
             }
             ctlim.setSearchKey(null);
             ctlim.setTopicIsDel(topicIsDel);
             ctlim.setTopicPro(topicPro); //主要用来判断是否提取精品文章列表。
             ctlim.setTopicType(topicType);
             ctlim.setCcID(ccID);
             ctlim.setTopicIsPass(true);
             //System.out.println(hql.toString());
             list = ctlim.topicList(page, pageNum, hql.toString());
             hql = null;
         }catch(Exception e){
             message = e.toString();
         }
         return list;
     }
      
     /**
      * 主题总数统计
      * @return
      */
     public int topicCount(){
         int i = 0;
         StringBuffer hql = new StringBuffer();
         try{
        	 if(maxTopicID>0){
               	hql.append(" and topicID > ");
               	hql.append(maxTopicID);
             }
             if(menuStyle.equals("CurAsk")){ //最新提问
                 hql.append(" and topicType=3 ");
             }
             else if(menuStyle.equals("CurAnswer")){ //最新结贴
                 hql.append(" and topicType=5 ");
             }
             ctlim.setTopicIsDel(topicIsDel);
             ctlim.setSearchKey(null);
             ctlim.setTopicPro(topicPro); //主要用来判断是否提取精品文章列表。
             ctlim.setCcID(ccID);
             ctlim.setTopicIsPass(true);
             i = ctlim.topicCount(hql.toString());
             hql = null;
         }catch(Exception e){

         }
         return i;         
     }

     /**
      * 调用帖子list集合
      * @param page
      * @param pageNum
      * @param ccid
      * @param tPro
      * @return
      */
     
     public List topicImportList(int page, int pageNum, int order, int ccid, int tpro){
    	 ctlim.setTopicIsDel(topicIsDel);
    	 List list = ctlim.topicImportList(page, pageNum, order, ccid, tpro);
    	 return list;
     }
     
     public List contentReList(int page, int pageNum){
    	 List list = null;
    	 try{
    		 list = cciml.contentReList(page, pageNum, topicID);
    	 }catch(Exception e){
    		 
    	 }
    	 return list;
     }
     
     /**
      * 查询回复
      * @param page 当前页
      * @param pageNum 每页显示行数
     */
    public List topicReList(int page, int pageNum){
        List list =  null;
        try{
            StringBuffer hql = new StringBuffer();
            hql.append(" order by ");
            if(ccStyle.equals("0")){ //平板形浏览回复
            	hql.append(" topicReID ");
            }else{
                hql.append(" topicOrder"); //树形浏览回复
            }
            ctlim.setTopicIsDel(topicIsDel);
            list = ctlim.topicReList(topicID, page, pageNum, hql.toString());
            hql = null;
        }catch(Exception e){
        	logger.error(e.toString());
            message = e.toString();
        }
        return list;
    }
    
     /**
      * 回复数统计
      * @param tid
      * @return
      */
     public int topicReCount(int tid){
         int i = 0;
         StringBuffer hql = new StringBuffer();
         try{
        	 ctlim.setTopicIsDel(topicIsDel);
             i = ctlim.topicReCount(tid, hql.toString()); 
             hql = null;
         }catch(Exception e){
             return 0;
         }
         return i;
     }
   
     
   /*
    public static void main(String[] args){
        com.gamvan.conn.ConnClub.init();
        ClubTopicResults ctr = new ClubTopicResults();
        try{
            ctr.setTopicID(5541);
            List list = ctr.contentReList(1,20);
            list.iterator();
            //java.util.ArrayList a[] = new java.util.ArrayList();
            for(int i=0;i<list.size();i++){
            	ClubContentReItem c = (ClubContentReItem)list.get(i);
            	System.out.println(c.getTopicReID());
            }
        }catch(Exception e){
            System.out.print(e.toString());
        } 
    }
    */
   
  	public String getMenuStyle() {
	    return menuStyle;
	}

	public void setMenuStyle(String menuStyle) {
	    this.menuStyle = menuStyle;
    }

    public int getCcID() {
	    return ccID;
    }

    public void setCcID(int ccID) {
        this.ccID = ccID;
    }



    public void setCcStyle(String ccStyle) {
	    this.ccStyle = ccStyle;
	}

    public int getPageRows() {
        return pageRows;
    }


    public int getTotalPage() {
        return totalPage;
    }

    public String getTopicKeys() {
        return topicKeys;
    }

    public void setMaxTopicID(int maxTopicID) {
		this.maxTopicID = maxTopicID;
	}

	public void setTopicKeys(String topicKeys) {
        this.topicKeys = topicKeys;
    }
    public void setIsRe(int isRe) {
        this.isRe = isRe;
    }
}

