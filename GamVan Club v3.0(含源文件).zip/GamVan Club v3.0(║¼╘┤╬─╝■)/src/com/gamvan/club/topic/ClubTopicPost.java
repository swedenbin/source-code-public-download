/* 
 * 2005-1-10
 * Last modified on 2006-1-23
 * Powered by GamVan.com
 */
package com.gamvan.club.topic;

import java.util.List;

import com.gamvan.club.ClubCounter;
import com.gamvan.club.classed.ClubClassInfo;
import com.gamvan.club.dao.impl.ClubTopicImpl;
import com.gamvan.club.item.ClubTopicItem;
import com.gamvan.club.item.ClubTopicReItem;
import com.gamvan.club.item.ClubTopicReUsersItem;
import com.gamvan.club.item.ClubUserItem;
import com.gamvan.club.user.ClubUsers;
import com.gamvan.html.OutPrint;
import com.gamvan.tools.ArrayEdit;
import com.gamvan.tools.EncodeString;
import com.gamvan.tools.FormatDateTime;
import com.gamvan.tools.TypeChange;


public class ClubTopicPost extends ClubTopicItem{
    private static final long serialVersionUID = 1L;
    private String now = FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    private String act = "";
    private double userMark = 0;
    
    private static ClubCounter ccu = new ClubCounter();//社区统计
    private static ClubClassInfo cci = new ClubClassInfo();//社区主题、回复统计
    private static ClubTopicImpl ctim = new ClubTopicImpl();
    private static ClubTopicReUsersItem ctrui = new ClubTopicReUsersItem();
    private static ClubTopicReUsers ctru = new ClubTopicReUsers();
    
    public String getAct() {
        return act;
    }
    public void setAct(String act) {
        this.act = act;
    }

	/**
	 * 
	 * @param ccID2
	 * @param ccID1
	 * @return
	 * @author GamVan Studio by 我容易么我
	 */
    public boolean topicPost(int ccID2, int ccID1){
        boolean bea = false;
        if(userName.equals("")||userPass.equals("")){
        	message =  OutPrint.prtCenter("用户名、密码不能为空！","",2);
        	return false;
        }
        if(topic.equals("")){
        	String s = content.replace("\n","").replace("\r","");
        	List list = EncodeString.matcherList(s,"\\[(.*?)\\]");
        	for(int i=0; i<list.size(); i++){
        		s = s.replace(TypeChange.objOfString(list.get(i)),"");
        	}
        	if(list.size()>0){
        		s = s.replace("[","").replace("]","");
        	}
        	topic = EncodeString.Gsubstring(s, 0, 50, "UTF-8");
        	if(list.size()==0){
        		/* 如果内容长度小于或等于30，则直接用上面的主题作内容！*/
            	if(EncodeString.Glength(s)<=30){
            		content = "";
            	}
        	}
        }
        if(this.topic!=null){
        	tLeg = EncodeString.Glength(this.topic);
        }else{
        	tLeg = 0;
        }
        if(this.content!=null){
        	cLeg = EncodeString.Glength(this.content);
        }else{
        	cLeg = 0;
        }
        ClubUsers cu = new ClubUsers();
        if(tLeg>100 || cLeg>20000){
            message = "系统错误，主题不能超过100字符，内容最多不能超过20000字符！";
            message +="<br />当前主题： " + tLeg +" 个字符";
            message +="<br />当前内容： " + cLeg +" 个字符";
            message = OutPrint.prtCenter(message,"",2);
        }
        else if(tLeg==0&&cLeg==0){
        	message = "标题和内容请任选一项填写，不能全部为空！";
        	message = OutPrint.prtCenter(message,"",2);
        }  
        else{
        	bea = userLogin();
        	if(bea){
	        	if(topicType==3 && topicTypeNum>this.userMark){
	            	message = OutPrint.prtCenter("您的积分不足，无法发起 "+topicTypeNum+" 求助贴","",2);
	            	return false;        	
	            }
	            if(act.equals("add")){
	                cci.classCounter(ccID, 1, 0); //社区主题、回复统计
	                cu.userUpdate(userID, 1, 0, 1); //更新社区制度信息
	                bea = topicAdd();
	            }
	            else if(act.equals("re")){
	                cci.classCounter(ccID, 0, 1); //社区主题、回复统计
	                cu.userUpdate(userID,2, 1, 1); //更新社区制度信息
	                bea = topicRe();
	            }
	            else if(act.equals("edit")){
	                /* 用户ID，制度数组，判断主题or回复 */
	                cu.userUpdate(userID, 3, 0, 0); //更新社区制度信息
	                bea = topicEdit();
	            } 
        	}
        }
        if(!bea){
            if(message.equals("")){
                message = "系统出现意外错误，请重新尝试，如果不成功请联系在线勤杂工！";
                message = OutPrint.prtCenter(message,"",2);
            }
        }
        return bea;
    }

    /**
     * 更新主题被回复的人员
     * @param id
     * 2005-11-7 20:45:12 Made In GamVan
     * com.gamvan.club.topic
     */
    public void editReUsers(int id){
         try{
                if(isReUsers(id)){
                    if(!ArrayEdit.txtsArray(topicReUsers, userName, "|")){
                        ctru.setReUsers(topicReUsers + "|" + userName);
                        ctru.reUsersUpdate(id);
                    }
                }else{
                    ctru.setReUsers(userName);
                    ctru.reUsersAdd(id);
                }
        }catch(Exception e){
            
        }
    }
    
    /**
     * 判断是否已经记录回复人员名单
     * @param id
     * @return
     * @author GamVan Studio by 我容易么我
     */
    public boolean isReUsers(int id){
        boolean bea = false;
        try{
            ctru.setTopicID(id);
            ctrui = ctru.topicReUsers(id);
            if(ctrui!=null){
                topicReUsers = ctrui.getReUsers();
                bea = true;
            }else{
                bea = false;
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return bea;
    }
    
    
    
    /**
     * 主题回复设置
     * @return
     * 2005-11-7 20:45:28 Made In GamVan
     * com.gamvan.club.topic
     */
    private  boolean topicRe(){
        boolean bea = false;
        editReUsers(topicID); //记录所有回复人员
        
        /* 更新订阅次主题的最后回复时间 */
        ClubTopicIlike ctil = new ClubTopicIlike();
        ctil.ilikeUpdateLastReTime(topicID); 
        
        int tTree = 0;
        if(topicReID==0){ 
            /* 取主题信息 */
        	ClubTopicItem ctit = new ClubTopicItem();
            ctit = ctim.topicInfo(topicID);
            if(ctit!=null){
                topicOrder = ctit.getTopicOrder();
                topicLayer = ctit.getTopicLayer();
                topicTree = ctit.getTopicTree();
                topicReCount = ctit.getTopicReCount();
            }
        }else{  
            /* 取回复信息 */
        	ClubTopicReItem ctrit = new ClubTopicReItem();
            ctrit = ctim.topicReInfo(topicReID);
            if(ctrit!=null){
                topicOrder = ctrit.getTopicOrder();
                topicLayer = ctrit.getTopicLayer();
                topicTree = ctrit.getTopicTree();
                topicReCount = ctrit.getTopicReCount();
            }
        }
        topicReUpdate(this.topicID); /* 更新回复排序 */
        if(topicReID==0){
            this.topicOrder=1;
            ctim.topicUpdateRcount(this.topicID); /* 更新主题表回复次数 */
        }else{
            
            this.topicOrder++;
            ctim.topicReUpdateRcount(this.topicReID); /* 更新主题回复次数 */
        }
        if(topicReCount>0){
           tTree = (this.topicTree * 2 +1 );
        }else{
           tTree = this.topicTree * 2;
        }
        this.topicTree = tTree;
        this.topicLayer += 1;
        bea = topicAdd();
        return bea;
    } 
    
    
    /**
     * 更新回复排序
     * @param id
     * 2005-11-7 20:46:28 Made In GamVan
     * com.gamvan.club.topic
     */
    private void topicReUpdate(int id){
        try{
        	ctim.topicReUpdateOrder(id, topicReID, topicOrder);
        }catch(Exception e){
            message = "系统出现意外错误，请重新尝试，如果不成功请联系在线勤杂工！";
        }
    }
    
    
    /**
     * 
     * @return
     * 2005-11-7 20:46:50 Made In GamVan
     * com.gamvan.club.topic
     */
    public boolean topicEdit(){
        boolean bea = false;
        try{
            ctim.setTopicID(topicID);
            ctim.setTopicReID(topicReID);
            ctim.setTopic(topic);
            ctim.setTopicList(topicColor + "|" + topicBold);
            ctim.setTopicMood(topicMood);
            ctim.setTopicType(topicType);
            ctim.setTopicTypeNum(topicTypeNum);
            ctim.setTopicLen(cLeg);
            ctim.setContent(content);
            ctim.setContentUserPen(contentUserPen);
            ctim.setContentUrl(contentUrl);
            ctim.setContentImg(contentImg);
            ctim.setContentEmail(contentEmail);
            ctim.setContentCopyRight(contentCopyRight);
            try{
                if(topicReID>0){
                    ctim.topicReUpdate(topicReID);
                }else{
                    ctim.topicUpdate(topicID);
                }
                bea = true;
                message = "帖子更新成功！";
            }catch(Exception e){
                message = e.toString();
            }
        }catch(Exception e){
            e.printStackTrace();
            bea = false;
            message = "系统出现意外错误，请重新尝试，如果不成功请联系在线勤杂工！";
        }
        return bea;
    } 
    
    
    public boolean topicAdd(){
        boolean bea = false;
        if(topicColor==null){
            topicColor="";
        }
        if(topicBold==null){
            topicBold="";
        }
        try{
            ctim.setTopicID(topicID);
            ctim.setTopicReID(topicReID);
            ctim.setTopicOrder(topicOrder);
            ctim.setTopicLayer(topicLayer);
            ctim.setTopicTree(topicTree);
            ctim.setTopic(topic);
            ctim.setUserName(userName);
            ctim.setCcID(ccID);
            ctim.setCcID2(ccID2);
            ctim.setCcID1(ccID1);
            ctim.setMoveCCID(moveCCID);
            ctim.setTopicList(topicColor + "|" + topicBold);
            ctim.setTopicMood(topicMood);
            ctim.setTopicPro(topicPro);
            ctim.setTopicType(topicType);
            ctim.setTopicTypeNum(topicTypeNum);
            ctim.setTopicAddTime(now);
            ctim.setTopicAddip(topicAddip);
            ctim.setMoveTime(now);
            ctim.setMoveUser("");
            ctim.setTopicViewCount(0);
            ctim.setTopicReCount(0);
            ctim.setTopicLen(cLeg);
            ctim.setUserID(userID);
            ctim.setTopicIsPass(topicIsPass);
            ctim.setTopicLastReTime(now);
            ctim.setTopicLastReUser("");

            ctim.setContent(content);
            ctim.setContentUserPen(contentUserPen);
            ctim.setContentUrl(contentUrl);
            ctim.setContentImg(contentImg);
            ctim.setContentEmail(contentEmail);
            ctim.setContentCopyRight(contentCopyRight);
            ctim.setTopicIsDel((byte)0);
            
            if(act.equals("add")){
				//更新主题表topicReID,为回复表最后一条记录的ID，用于排序规则。
                ctim.topicAdd();
                this.topicID = ctim.getTopicID();
                ctim.topicID_reID(this.topicID);
             }else if(act.equals("re")){
                ctim.topicReAdd();
                this.topicReID = ctim.getTopicReID();
                ctim.topicUpdateLastInfo(topicID, topicReID, now, userName);
            }
            bea = true;
            if(this.topicReID>0){
                ccu.counterUpdate(0, 0, 0, 1, 0, 0, 0, "");
            }else{
                ccu.counterUpdate(0, 0, 1, 0, 0, 0, 0, "");
            }
            
        }catch(Exception e){
            e.printStackTrace();
            bea = false;
            message = "系统出现意外错误，请重新尝试，如果不成功请联系在线勤杂工！";
        }
        return bea;
    }

    public boolean userLogin(){
        boolean bea = false;
        ClubUsers cu = new ClubUsers();
        ClubUserItem cui = null;
        if(!userPass.equals(userPass2)){
            //重新加密密码验证登陆
            cui = cu.userLogin(userName, userPass, 0); 
        }else{
            //不加密验证登陆
            cui = cu.userLogin(userName, userPass, 1);
        }
        if(cui!=null){
            bea = true;
            this.userID = cui.getUserID();
            this.userMark = cui.getUserMark();
        }
        cui = null;
        message = OutPrint.prtCenter(cu.getMessage(),"",2);
        return bea;
    }
 
    /*
    public static void main(String args[]){
        com.gamvan.conn.ConnClub.init();
        ClubTopicPost ctp = new ClubTopicPost();
        ctp.setAct("add");
        ctp.setUserName("咔咔");
        ctp.setUserID(0);
        ctp.setUserPass("111111");
        ctp.setUserPass2("1111111");
        ctp.setTopic("ssssssssssssssssssss");
        ctp.setTopicColor("");
        ctp.setTopicBold("");
        ctp.setCcID(23);
        ctp.setCcID1(3);
        ctp.setCcID2(0);
        ctp.setMoveCCID(0);
        ctp.setTopicMood((short) 1);
        ctp.setTopicType((short) 0);
        ctp.setTopicTypeNum(0);
        ctp.setTopicAddip("");
        ctp.setTopicIsPass(true);
        ctp.setContent("啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊");
        ctp.setContentUserPen(true);
        ctp.setContentUrl(true);
        ctp.setContentImg(true);
        ctp.setContentEmail(true);
        ctp.setContentCopyRight((byte) 1);
        ctp.setTopicID(12);
        ctp.setTopicReID(0);
        ctp.topicPost(0,0);
        System.out.print(ctp.getMessage());
    }
    */
    
}
