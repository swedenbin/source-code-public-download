/*
 * Made In GamVan
 * Created on 2005年9月2日
 */
package com.gamvan.club.topic;

import java.util.Iterator;
import java.util.List;

import com.gamvan.club.ClubCounter;
import com.gamvan.club.classed.ClubClassInfo;
import com.gamvan.club.dao.impl.ClubContentImpl;
import com.gamvan.club.dao.impl.ClubTopicImpl;
import com.gamvan.club.dao.impl.ClubTopicListImpl;
import com.gamvan.club.item.ClubTopicItem;
import com.gamvan.club.item.ClubTopicReItem;
import com.gamvan.club.user.ClubUsers;
import com.gamvan.conn.ConnClub;

/**
 * 删除帖子，复杂的业务逻辑
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicDel extends ClubTopicItem{
    private static final long serialVersionUID = 1L;
    
    private String message = new String();
    private static final ClubCounter ccu = new ClubCounter();//社区统计
    private static final ClubClassInfo cci = new ClubClassInfo();//社区主题、回复统计
    private static final ClubUsers cu = new ClubUsers();
    private static final ClubTopicImpl ctim = new ClubTopicImpl();
    private static final ClubTopicReUsers ctru = new ClubTopicReUsers();
    private static final ClubTopicTypes ctts = new ClubTopicTypes();
    private static final ClubContentImpl ccim = new ClubContentImpl();
    
    private boolean isRe = false; 
    
    /**
     * 接收来此显示层传递的帖子ID数组，分析方法执行相关动作
     * @param act 传递动作类型
     * @param ids
     * 2005-11-30 0:45:00 Made In GamVan
     * com.gamvan.club.topic
     */
    public void topicDels(String act, String[] ids){
        int id = 0;
        if(ids==null){
            message = "请选择你要操作的主题。";
            return;
        }
        try{
            if(act.equals("1")){ //执行还原
                for(int i=0; i<ids.length; i++){
                    id = Integer.parseInt(ids[i]);
                    topicGarbage(id, this.isRe, (byte)0);
                }
                
            }else if(act.equals("2")){ //执行删除文章
                for(int i=0; i<ids.length; i++){
                    id = Integer.parseInt(ids[i]);
                    topicDel(id);
                }
            }else{
                message = "请选择您将要操作的内容！";
            }
        }catch(Exception e){
            message = e.toString();
        }
    }
    
    
    
    /**
     * 回收站操作 放入或还原这个帖子。
     * 应用于批量删除帖子，不对用户积分、金币等等作增减
     * @param id
     * @param isRe 确定是否为回复
     */
    public void topicGarbage(int id, boolean isRe, byte del){
        int i = 0;       
        if(del==(byte)0){
            i = 1;
        }
        else if(del==(byte)1){
            i = -1;
        }
        if(!isRe){ //如果是主题
            ClubTopicItem ctit = ctim.topicInfo(id);
            if(ctit!=null){
                userID = ctit.getUserID();
                cu.userUpdate(userID, 0, 0, i);
                ctim.topicIsDelUpdate(id, del);
            }
        }else{
            ClubTopicReItem ctit = ctim.topicReInfo(id);
            if(ctit!=null){
                userID = ctit.getUserID();
                cu.userUpdate(userID, 0, 1, i);
                ctim.topicIsDelUpdate_re(id, del); //将回复主题标记删除
                ccim.contentReDel_(id, del); //将回复内容标记删除
            }
        }
    }

    /**
     * 应用于单独删除帖子，同时更新用户积分、金币等参数
     * @param id
     * @param isRe
     * @param del
     * @param usermark 积分
     * @param usermoney 金币
     * @param usercredit 信誉
     * com.gamvan.club.topic
     */
    public void topicGarbage(int id, boolean isRe, byte del
    		,double usermark, double usermoney
    		, double usercredit)
    {
        int i = 0;       
        if(del==(byte)0){
            i = 1;
        }
        else if(del==(byte)1){
            i = -1;
        }
        int userid;
        if(!isRe){ //如果是主题
            ClubTopicItem ctit = ctim.topicInfo(id);
            if(ctit!=null){
            	userid = ctit.getUserID();
                cu.userUpdate(userid, usermark, usermoney, usercredit, 0, i);
                ctim.topicIsDelUpdate(id, del);
            }
        }else{ //如果是回复
            ClubTopicReItem ctit = ctim.topicReInfo(id);
            if(ctit!=null){
            	userid = ctit.getUserID();
                cu.userUpdate(userid, usermark, usermoney, usercredit, 1, i);
                ctim.topicIsDelUpdate_re(id, del); //将回复主题标记删除
                ccim.contentReDel_(id, del); //将回复内容标记删除
            }
        }
    }
    

    /**
     * 
     * @param isRe
     * @param ccid
     * @param userid
     * 2005-11-30 14:06:32 Made In GamVan
     * com.gamvan.club.topic
     */
    public void delCount(boolean isRe, int ccid, int userid){
        try{
            if(!isRe){
                //cu.userUpdate(userid, 5, 0, -1);
                cci.classCounter(ccid, -1, 0);
                ccu.counterUpdate(0, 0, -1, 0, 0, 0, 0, "");               
            }else{
                //cu.userUpdate(userid, 5, 1, -1);
                cci.classCounter(ccid, 0, -1);
                ccu.counterUpdate(0, 0, 0, -1, 0, 0, 0, "");    
            }
        }catch(Exception e){
            message = e.toString();
        }
        
    }
    
    /**
     * 
     * @param id
     * 2005-11-30 14:06:27 Made In GamVan
     * com.gamvan.club.topic
     */
    public void topicDel(int id){      
        /**
         * 如果删除的是主题则要循环出主题的所有回复一一删之。 
         */
        int reid = 0;
        if(!isRe){
            ClubTopicListImpl ctlim = new ClubTopicListImpl();
            ClubTopicReItem ctri = null;
            List list = ctlim.topicReList(id, 1, 1000, "");
            Iterator it = list.iterator();
            while(it.hasNext()){
                ctri = (ClubTopicReItem)it.next();
                reid = ctri.getTopicReID();
                ConnClub.getSession().evict(ctri);
                runDel(reid, true);
            }
        }
        runDel(id, isRe);
        
    }
    
    /**
     * 执行删除
     * @param id
     * @param isRe
     * @return
     * 2005-11-30 2:04:30 Made In GamVan
     * com.gamvan.club.topic
     */
    public boolean runDel(int id, boolean isRe){
        if(!isRe){ //如果是主题
            ClubTopicItem ctit = ctim.topicInfo(id);
            if(ctit!=null){
                userID = ctit.getUserID();
                ccID = ctit.getCcID();
            }
        }else{
            ClubTopicReItem ctit = ctim.topicReInfo(id);
            if(ctit!=null){
                userID = ctit.getUserID();
                ccID = ctit.getCcID();
            } 
        }      
        delCount(isRe, ccID, userID); //更新社区统计信息
        boolean bea = false;
        ctru.reUsersDel(id); //删除该贴的回复人员名单信息
        ctts.topicTypeDel(id); //删除特殊类型帖子的相关记录
		if(isRe){
			ctim.topicReDel(id);
		}else{
			ctim.topicDel(id);
		}
        bea = true;
        message = "文章删除成功！";
        return bea;
    }
    
    public void setIsRe(boolean isRe) {
        this.isRe = isRe;
    }
    
    public String getMessage(){
        return this.message;
    }

}
