/*
 * Created on 2005-8-4
 * Made In GamVan
 */
package com.gamvan.club.topic;

import com.gamvan.club.dao.impl.ClubContentImpl;
import com.gamvan.club.item.ClubContentItem;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubContentPost extends ClubContentItem{
    private static final long serialVersionUID = 1L;
    private ClubContentImpl ccim = new ClubContentImpl();
    
    public void contentAdd(){
        try{
        	ccim.setContent(content);
        	ccim.setTopicID(topicID);
        	ccim.setContentUserPen(contentUserPen);
        	ccim.setContentUrl(contentUrl);
        	ccim.setContentImg(contentImg);
        	ccim.setContentEmail(contentEmail);
        	ccim.setContentCopyRight(contentCopyRight);
        	ccim.contentAdd();         
        }catch(Exception e){
            e.printStackTrace();
        } 
    }
}
