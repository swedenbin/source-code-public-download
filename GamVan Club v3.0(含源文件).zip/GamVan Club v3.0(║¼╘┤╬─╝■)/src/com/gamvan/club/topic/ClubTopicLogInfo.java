/*
 * Created on 2005-5-29
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.topic;

import java.util.Iterator;
import java.util.List;

import com.gamvan.club.dao.impl.ClubTopicLogImpl;
import com.gamvan.club.item.ClubTopicLogItem;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicLogInfo  extends ClubTopicLogItem{
    private static final long serialVersionUID = 1L;
    private String message = ""; //收集信息
    private String prtHtml = ""; //输出在页面上的信息
    private ClubTopicLogImpl ctlim = new ClubTopicLogImpl();

    /**
     * 
     * @param tid
     * @param reid
     * @return
     * 2005-12-1 0:00:54 Made In GamVan
     * com.gamvan.club.topic
     */
	public boolean pageLogInfoHtml(int tid, int reid){
		boolean bea = false;
        ClubTopicLogItem ctli = null;
        StringBuffer temp = new StringBuffer("");
        List list = null;
		try{
            if(reid>0){
                list = ctlim.topicLogList(reid, 1, 1);
            }else{
            	list = ctlim.topicLogList(tid, 0, 1);
            }
            if(list==null){
            	return false;
            }
            Iterator it = list.iterator();
            while(it.hasNext()){
            	ctli = (ClubTopicLogItem)it.next();
                topicLogTxt = ctli.getTopicLogTxt();
                topicLogByUserID = ctli.getTopicLogByUserID();
                topicLogByUserName = ctli.getTopicLogByUserName();
                userCredit = ctli.getUserCredit();
                userMark = ctli.getUserMark();
                userMoney = ctli.getUserMoney();
                topicLogSo = ctli.getTopicLogSo();
                topicLogByUserList = ctli.getTopicLogByUserList();
                temp.append("<UL>");
                temp.append("<li><strong>"+ topicLogSo +"</strong></li>");
                temp.append("<br/>");
                temp.append("<li>信誉：<span style=\"color:green; font-weight: bold;\">");
                if(userCredit>0){temp.append("+");}
                temp.append(String.valueOf(userCredit));
                temp.append("</span>&nbsp;&nbsp;&nbsp;&nbsp;积分：<span style=\"color:blue; font-weight: bold;\">");
                if(userMark>0){temp.append("+");}
                temp.append(String.valueOf(userMark));
                temp.append("</span>&nbsp;&nbsp;&nbsp;&nbsp;金币：<span style=\"color:#bb0000; font-weight: bold;\">");
                if(userMoney>0){temp.append("+");}
                temp.append(String.valueOf(userMoney));
                temp.append("</span></li>");    
                if(topicLogTxt!=null && !topicLogTxt.equals("")){
                	temp.append("<li>");
                    temp.append(topicLogTxt);
                    if(topicLogByUserList>0){
                       temp.append("<em>&nbsp;&nbsp;&nbsp;&nbsp;By:</em>"+topicLogByUserName);
                    }
                    temp.append("</li>");
                 }else{
                    if(topicLogByUserList>0){
                       temp.append("<li>");
                       temp.append("<em>&nbsp;&nbsp;&nbsp;&nbsp;By:</em>"+topicLogByUserName);
                       temp.append("</li>");
                    }                   
                 }
                 temp.append("</UL>");
                 ctli = null;
            	 bea = true;
                }
                prtHtml = temp.toString();
            }catch(Exception e){
    			message = e.toString();
    			prtHtml = "日志打印错误";
    		}
		return bea;
	}
 
	public String getMessage(){
		return this.message;
	}
	public String getPrtHtml(){
		return this.prtHtml;
	}
}
