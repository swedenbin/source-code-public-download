package com.gamvan.club.topic;

import java.util.List;

import com.gamvan.club.dao.impl.ClubTopicIlikeImpl;
import com.gamvan.club.item.ClubTopicIlikeItem;
import com.gamvan.club.item.ClubTopicItem;
import com.gamvan.tools.FormatDateTime;
import com.gamvan.tools.TypeChange;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicIlike extends ClubTopicIlikeItem{
    private static final long serialVersionUID = 1L;
    private String message = "";

    /* 格式化当前时间 */
    private String now = FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    
    private ClubTopicIlikeImpl ctilim = new ClubTopicIlikeImpl();
    
    /**
     * 订阅主题
     * @param topicid
     * @return
     * 2005-11-30 14:12:44 Made In GamVan
     * com.gamvan.club.topic
     */
    public boolean addIlike(int topicid){
        boolean bea = false;
        try{
        	if(ctilim.ilikeAdd(topicid, topic, myUserID, myUserName
        			, topicUserID, topicUserName, now
        			, now, topicLastReTime, ccID
        	)!=null){
        		bea = true;
        	}
            message = topic+"<br/><br/>订阅成功！";
        }catch(Exception e){
            message = "订阅主题过程中发生意外错误，本次操作失败！<br/>详细信息：" + e.toString();
        }
        return bea;
    }
    
    /**
     * 更新订阅主题的最后查看时间
     * @param topicid
     * @param userid
     * @return
     */
    public boolean ilikeUpdateLastTime(int topicid, int userid){
        boolean bea = false;
        if(userid>0 && topicid>0){
        	ctilim.ilikeUpdateLastTime(topicid, userid, now);
        }else{
        	return false;
        }
        return bea;
    }
    
    /**
     * 
     * @param topicid
     * @return
     * 2006-1-5 14:00:28 Made In GamVan
     * com.gamvan.club.topic
     */
    public boolean ilikeUpdateLastReTime(int topicid){
        boolean bea = false;
        if(topicid>0){
        	ctilim.ilikeUpdateLastReTime(topicid, now);
        }else{
        	return false;
        }
        return bea;
    }
    
    /**
     * 
     * @param ids
     * @return
     * 2005-11-30 16:07:26 Made In GamVan
     * com.gamvan.club.topic
     */
    public boolean delLike(String[] ids){
        boolean bea = false;
        int id = 0;
        for(int i=0; i<ids.length; i++){
            id = TypeChange.stringToInt((ids[i]));
            try{
                ctilim.ilikeDel(id, 0); //按主键方式删除订阅信息
                bea = true;
            }catch(Exception e){
                message =e.toString();
            }
        }
        if(bea){
             message = "操作成功!";
        }else{
            message = "操作中断，遭遇错误!";
        }
        return bea;
    }
    
    /**
     * 
     * @param topicid
     * @param myuserid
     * @return
     * 2005-11-30 15:51:20 Made In GamVan
     * com.gamvan.club.topic
     */
    public boolean doLike(int topicid, int myuserid){
        boolean bea = false;
        ClubTopicInfo cti = new ClubTopicInfo();
        ClubTopicItem ctim = (ClubTopicItem)cti.topicInfo(topicid, 0, (byte)0);
        if(ctim!=null){
            topic = ctim.getTopic();
            topicUserID = ctim.getUserID();
            topicUserName = ctim.getUserName();
            topicLastReTime = ctim.getTopicLastReTime();
            ccID = ctim.getCcID();
            if(ilikeInfo(topicid, myuserid)){
                message = topic + "<br/><br/>操作终止！您已经订阅过本主题！";
            }else{
                bea = addIlike(topicid);
            }
        }else{
            message = "你所收藏的主题不存在或已被删除。";
            bea = false;
        }
        return bea;
    }
    
    /**
     * 判断用户是否订阅过帖子并返回主键
     * @param topicid
     * @param myuserid
     * @return
     * 2005-11-30 15:50:52 Made In GamVan
     * com.gamvan.club.topic
     */
    public boolean ilikeInfo(int topicid, int myuserid){
        boolean bea = false;
        try{
	        if(ctilim.ilikeInfo(topicid, myuserid)!=null){
	        	bea = true;
	        }
        }catch(Exception e){
            
        }
        return bea;
    }
    
    
    /**
     * 
     * @param page
     * @param pageNum
     * @return
     * 2005-11-30 16:00:00 Made In GamVan
     * com.gamvan.club.topic
     */
    public List myLikeTopicList(int page, int pageNum){
        List list = null;
        try{
        	list = ctilim.ilikeList(page, pageNum, -1, myUserID);
        }catch(Exception e){
            
        }
        return list;
    }
    
    /**
     * 
     * @return
     * 2005-11-30 16:03:17 Made In GamVan
     * com.gamvan.club.topic
     */
    public int myLikeTopicListCount(){
        int i = ctilim.ilikeCount(-1, myUserID);
        return i;
    } 
    
    /*
    public static void main(String args[]){
        ClubTopicIlike ctil = new ClubTopicIlike();
        ctil.setMyUserID(3);
        ctil.setMyUserName("123");
        ctil.doLike(5, 3);
    }
    */

    public String getMessage(){
        return this.message;
    }
    public void setMyUserID(int myUserID){
        this.myUserID = myUserID;
    }
    public void setMyUserName(String myUserName){
        this.myUserName = myUserName;
    }
    public void setTopicID(int topicID){
        this.topicID = topicID;
    }
    public int getLikeID(){
        return this.likeID;
    }
    public int getMyUserID(){
        return this.myUserID;
    }
    public String getTopicUserName(){
        return this.topicUserName;
    }
    public int getTopicID(){
        return this.topicID;
    }
    public String getTopicLastReTime(){
        return this.topicLastReTime;
    }
}
