/*
 * Created on 2005-7-30
 * Last modified on 2005-12-27
 * Made In GamVan 今晚制造
 * www.GamVan.com
 */
package com.gamvan.club.topic;

import org.apache.log4j.Logger;

import com.gamvan.club.dao.impl.ClubContentImpl;
import com.gamvan.club.item.ClubContentItem;
import com.gamvan.club.item.ClubContentReItem;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubContentResults extends ClubContentItem{
    private static final long serialVersionUID = 1L;
    
    private ClubContentImpl ccim = new ClubContentImpl();
    
    private static final Logger logger = 
    	Logger.getLogger(ClubContentResults.class.getName());
    
    
    public ClubContentItem contentInfo(){
        ClubContentItem cci = null;
        try{
            cci = ccim.contentInfo(topicID);
        }catch(Exception e){
        	logger.error(e.toString());
            e.printStackTrace();
        }
        return cci;
    }
    
    public ClubContentReItem contentReInfo(){
        ClubContentReItem ccri = null;
        try{
            ccri = ccim.contentReInfo(topicReID);
        }catch(Exception e){
            e.printStackTrace();
        }
        return ccri;
    }
    

    /*
    public String getContentInfo(HashMap hm, String str){
        if(hm==null||str==null||str.trim().equals("")){
            return "";
        }else{
            return hm.get(str).toString();
        }
 
    }
    */
   /*
    public static void main(String args[]){
        ClubContentCollection ccc=new ClubContentCollection();
        ccc.setTopicID(5298);
        HashMap hm = new HashMap();
        hm = ccc.contentHashMap();
        //System.out.print(ccc.contentHashMap());
        System.out.print(ccc.getContentInfo(hm,"topicID"));
        
    }
    */
    
    /* 废弃此方法
    public HashMap contentHashMap(){
        HashMap hm = new HashMap();
        Session session = ConnClub.getSession();
        ClubContentItem cci = new ClubContentItem();
        try{
            String hql = "from ClubContentItem where topicID=?";
            Query query = session.createQuery(hql)
            .setInteger(0, topicID);
            List list = query.list();
            Iterator iterator = list.iterator();
            if(iterator.hasNext()){
                cci = (ClubContentItem)iterator.next();
                //System.out.print(cci.getContentID());
                hm.put("contentID", new Integer(cci.getContentID()));
                hm.put("topicID", new Integer(cci.getTopicID()));
                hm.put("content", cci.getContent());
                hm.put("contentUserPen", new Boolean(cci.getContentUserPen()));
                hm.put("contentUrl", new Boolean(cci.getContentUrl()));
                hm.put("contentImg", new Boolean(cci.getContentImg()));
                hm.put("contentEmail", new Boolean(cci.getContentEmail()));
                hm.put("contentCopyRight", new Byte(cci.getContentCopyRight()));
            }else{
                hm = null;
            }
            iterator.remove();
            session.flush();
        }catch(HibernateException e){
            e.printStackTrace();
        }
        return hm;
    }
    */
}
