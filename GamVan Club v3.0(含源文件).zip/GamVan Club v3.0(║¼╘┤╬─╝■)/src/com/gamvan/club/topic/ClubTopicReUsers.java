/*
 * Created on 2005-8-4
 * Made In GamVan
 */
package com.gamvan.club.topic;

import com.gamvan.club.dao.impl.ClubTopicReUsersImpl;
import com.gamvan.club.item.ClubTopicReUsersItem;

/**
 * 处理帖子用户回复
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicReUsers extends ClubTopicReUsersItem{
    private static final long serialVersionUID = 1L;
    private ClubTopicReUsersImpl ctruim = new ClubTopicReUsersImpl();
    
    /**
     * 添加回复人员
     * @param tid
     */
    protected void reUsersAdd(int tid){
        try{
        	ctruim.reUsersAdd(tid, reUsers);
        }catch(Exception e){
            
        }
    } 
    
    /**
     * 
     * @param tid
     * 2005-11-30 0:43:00 Made In GamVan
     * com.gamvan.club.topic
     */
    protected void reUsersUpdate(int tid){
        try{      
        	ctruim.reUsersUpdate(tid, reUsers);     
        }catch(Exception e){
            
        }
    }
    
    /**
     * 
     * @return
     * 2005-11-30 0:42:57 Made In GamVan
     * com.gamvan.club.topic
     */
    protected ClubTopicReUsersItem topicReUsers(int topicid){
    	ClubTopicReUsersItem ctrui = null;
        try{
        	ctrui = ctruim.reUsersInfo(topicid);   
        }catch(Exception e){
            
        }
        return ctrui;      
    }
    
    /**
     * 
     * @param tid
     * 2005-11-30 0:50:41 Made In GamVan
     * com.gamvan.club.topic
     */
    public void reUsersDel(int tid){
    	ctruim.reUsersDel(tid);
    }
    
    /*
	public static void main(String args[]){
		ClubTopicReUsers c = new ClubTopicReUsers();
		ConnClub.init();
		c.setTopicID(1);
		System.out.print(c.topicReUsers());
	}
	*/

}
