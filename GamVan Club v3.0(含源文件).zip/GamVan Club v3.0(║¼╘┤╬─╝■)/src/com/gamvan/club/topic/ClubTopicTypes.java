/*
 * Created on 2005-8-4
 * Made In GamVan
 */
package com.gamvan.club.topic;

import java.util.List;

import com.gamvan.club.dao.impl.ClubTopicTypeImpl;
import com.gamvan.club.item.ClubTopicTypeItem;
import com.gamvan.tools.FormatDateTime;


/**
 * 特殊类型贴子操作
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicTypes extends ClubTopicTypeItem{
    private static final long serialVersionUID = 1L;
    
    /* 格式化当前时间 */
    private String now= FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    
    private ClubTopicTypeImpl cttim = new ClubTopicTypeImpl();
    
    public ClubTopicTypeItem topicTypeInfo(){
        ClubTopicTypeItem ctti = null;
        try{
        	ctti = cttim.topicTypeInfo(topicID, userID, typeInfo);
        }catch(Exception e){
            ctti = null;
        }
        return ctti;
    }
    
    /**
     * 
     * 
     * 2005-11-13 0:36:28 Made In GamVan
     * com.gamvan.club.topic
     */
    public void topicTypeAdd() {
        try{
        	cttim.setTopicID(topicID);
        	cttim.setTypeInfo(typeInfo);
        	cttim.setTypeNum(typeNum);
        	cttim.setUserID(userID);
        	cttim.setUserName(userName);
        	cttim.setAddTime(now);
        	cttim.topicTypeAdd();        
        }catch(Exception e){
            e.printStackTrace();
        }        
    }
    
    /**
     * 
     * 
     * 2005-11-13 0:45:32 Made In GamVan
     * com.gamvan.club.topic
     */
    public void typeUpdate(){
        try{
        	cttim.setAddTime(now);
        	cttim.setTypeNum(typeNum);
        	cttim.setUserName(userName);
        	cttim.topicTypeUpdate(topicID, userID, typeInfo);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
    /**
     * 发购买贴获得的金币数，或是提问贴送出的积分数
     * @param topicid
     * @param typeinfo 贴子类型
     * @return
     * 2005-11-13 15:24:56 Made In GamVan
     * com.gamvan.club.topic
     */
    public double topicTypeNumed(int topicid, short typeinfo){
    	double d = 0;
        try{
        	d = cttim.topicTypeNumed(topicid, typeinfo);
        }catch(Exception e){
        	e.printStackTrace();
        }
    	return d;
    }
    
    
    /**
     * 
     * @param topicid
     * @param typeinfo
     * @return
     * 2005-11-14 8:59:25 Made In GamVan
     * com.gamvan.club.topic
     */
    public List topicTypeList(int topicid, short typeinfo){
    	if(typeinfo==5){
    		typeinfo = 3;
    	}
    	List list = null;
    	try{
    		list = cttim.topicTypeList(topicid, typeinfo);
    	}catch(Exception e){
        	e.printStackTrace();
        }
    	return list;
    }
    
    /**
     * 删除特殊类型帖子的相关记录
     * @param topicid
     * 2005-11-30 2:01:53 Made In GamVan
     * com.gamvan.club.topic
     */
    public void topicTypeDel(int topicid){
    	cttim.topicTypeDel(topicid);
    }
    
    
    /* test
    public static void main(String args[]){
    	ConnClub.init();
        ClubTopicTypes ctts = new ClubTopicTypes();
        ctts.typeUpdate();
        ConnClub.closeSession2();
    }
    */
}
