/*
 * Created on 2005-5-28
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.topic;

import java.util.List;

import org.apache.log4j.Logger;

import com.gamvan.club.dao.impl.ClubTopicLogImpl;
import com.gamvan.club.item.ClubTopicLogItem;
import com.gamvan.club.user.ClubUsers;
import com.gamvan.tools.FormatDateTime;

/**
 * 社区主题管理员操作日志，加（减）积分、信誉、金币
 * @author GamVan Studio by 我容易么我
 */
public class ClubTopicLog extends ClubTopicLogItem {
    private static final long serialVersionUID = 1L;
    /* 用户信誉、金币、积分变量 */
    private double userCredit2=0, userMoney2=0, userMark2=0; 
	private String message = ""; //收集信息
	
    /* 格式化当前时间 */
    private static String now = FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    private static ClubUsers cu = new ClubUsers();
    private ClubTopicLogImpl ctlim = new ClubTopicLogImpl();
    
    private static final Logger logger = 
		Logger.getLogger(ClubTopicLog.class.getName());

	/**
	 * 执行日志记录
	 * @return boolean
	 * com.gamvan.club.topic
	 */
	public boolean executeLog(){
		boolean bea = false;
		if(topicID<0){
			message = "log is error";
			return false;
		}
        this.userMark2 = this.userMark;
        this.userCredit2 = this.userCredit;
        this.userMoney2 = this.userMoney;
		try{
            ClubTopicLogItem ctli = null;
            ctli = selectLogTU(topicID, topicReID, topicLogByUserID);
			if(ctli!=null){
                //this.userMark = this.userMark2 - ctli.getUserMark();
                //this.userCredit = this.userCredit2 - ctli.getUserCredit();
                //this.userMoney = this.userMoney2- ctli.getUserMoney();
                this.userID = ctli.getUserID();
                this.topicLogID = ctli.getTopicLogID();
				//更新日至前还原至前的操作
				cu.userUpdate(userID, -ctli.getUserMark(), -ctli.getUserMoney(), -ctli.getUserCredit(), 0, 0); 
                this.userMark = this.userMark2;
                this.userCredit = this.userCredit2;
                this.userMoney = this.userMoney2;
                bea = topicLogUpdate(topicLogID);
			}else{
				bea = topicLogAdd();
			}
		}catch(Exception e){
            logger.error(e.toString());
			message = e.toString();
		}		
		return bea;
	}
	
	
	/**
	 * 更新日志相关信息
	 * @param id
	 * @return boolean
	 * com.gamvan.club.topic
	 */
	public boolean topicLogUpdate(int id){
		boolean bea =false;
		try{
    		ctlim.setTopic(topic);
    		ctlim.setUserID(userID);
    		ctlim.setUserName(userName);
    		ctlim.setTopicID(topicID);
    		ctlim.setTopicLogTxt(topicLogTxt);
    		ctlim.setTopicLogByUserID(topicLogByUserID);
    		ctlim.setTopicLogByUserName(topicLogByUserName);
            ctlim.setTopicLogByUserIP(topicLogByUserIP);
            ctlim.setTopicLogByDateTime(now);
            ctlim.setUserCredit(userCredit);
            ctlim.setUserMark(userMark);
            ctlim.setUserMoney(userMoney);
            ctlim.setTopicLogSo(topicLogSo);
            ctlim.setTopicLogByUserList(topicLogByUserList);
            ctlim.setTopicLogList(topicLogList);
            ctlim.setTopicReID(topicReID);
            ctlim.topicLogUpdate(id);
			bea = true;
			message = "日志记录成功！";
		}catch(Exception e){
			logger.error(e.toString());
			message = "更新日志出错\n" + e.toString();
			bea = false;
		}		
		return bea;
	}
	
	/**
	 * 查找日志根据帖子ID，和操作用户ID,只判断属于自己的日志是否存在。
	 * @param tid
	 * @param reid
	 * @param uid
	 * @return
	 * com.gamvan.club.topic
	 */
	public ClubTopicLogItem selectLogTU(int tid, int reid, int uid){
        ClubTopicLogItem ctli = null;
        if(reid>0){
        	ctli = ctlim.topicLogInfo(reid, 1, uid, topicLogSo); //查询回复帖子ID日志
        }else{
        	ctli = ctlim.topicLogInfo(tid, 0, uid, topicLogSo); //查询主题帖子ID日志
        }
		return ctli;		
	}
    
    
    
	/**
	 * 添加日志
	 * @return
	 * com.gamvan.club.topic
	 */
    public boolean topicLogAdd(){
    	boolean bea = false;
    	try{
    		ctlim.setTopic(topic);
    		ctlim.setUserID(userID);
    		ctlim.setUserName(userName);
    		ctlim.setTopicID(topicID);
    		ctlim.setTopicLogTxt(topicLogTxt);
    		ctlim.setTopicLogByUserID(topicLogByUserID);
    		ctlim.setTopicLogByUserName(topicLogByUserName);
            ctlim.setTopicLogByUserIP(topicLogByUserIP);
            ctlim.setTopicLogByDateTime(now);
            ctlim.setUserCredit(userCredit);
            ctlim.setUserMark(userMark);
            ctlim.setUserMoney(userMoney);
            ctlim.setTopicLogSo(topicLogSo);
            ctlim.setTopicLogByUserList(topicLogByUserList);
            ctlim.setTopicLogList(topicLogList);
            ctlim.setTopicReID(topicReID);
            ctlim.setCcID(ccID);
            ctlim.topicLogAdd();
    		bea = true;
    		message = "本次操作已被记录";
    	}catch(Exception e){
    		logger.error(e.toString());
    		message = e.toString();
    		bea = false;
    	}
    	return bea;
    }
    
    /**
     * 删除日志
     * @param id
     * com.gamvan.club.topic
     */
	public void topicLogDel(int id){
		if(ctlim.topicLogDel(id)){
			message = "日志删除成功！";
		}else{
			message = "日志删除失败！";
		}
	}
	/**
	 * 批量删除日志
	 * @param ids
	 * com.gamvan.club.topic
	 */
	public void topicLogDels(String[] ids){
		if(ctlim.topicLogDels(ids)){
			message = "日志删除成功！";
		}else{
			message = "日志删除失败！";
		}
	}
	
	/**
	 * 按照主题批量删除日志
	 * @param topicid
	 * @return
	 * com.gamvan.club.dao
	 */
	public void topicLogDel_topicID(int topicid){
		if(ctlim.topicLogDel_topicID(topicid)){
			message = "日志删除成功！";
		}else{
			message = "日志删除失败！";
		}
	}

    public List topicLogList(int page, int pageNum){
    	return ctlim.topicLogList(page, pageNum, ccID, -1, -1);
    }
    
    public int topicLogCount(int page, int pageNum){
    	return ctlim.topicLogCount(ccID, -1, -1);
    }
    
    public double getUserCredit2() {
        return userCredit2;
    }

    public void setUserCredit2(double userCredit2) {
        this.userCredit2 = userCredit2;
    }

    public double getUserMark2() {
        return userMark2;
    }

    public void setUserMark2(double userMark2) {
        this.userMark2 = userMark2;
    }

    public double getUserMoney2() {
        return userMoney2;
    }

    public void setUserMoney2(double userMoney2) {
        this.userMoney2 = userMoney2;
    }

    public String getMessage() {
        return message;
    }
}
