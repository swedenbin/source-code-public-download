/*
 * Created on 2005年1月5日, 下午3:49
 * Last modified on 2006-1-24
 * Powered by GamVan.com
 */
package com.gamvan.club.topic;

import java.util.List;

import com.gamvan.club.classed.ClubClassInfo;
import com.gamvan.club.dao.impl.ClubTopicImpl;
import com.gamvan.club.dao.impl.ClubTopicListImpl;
import com.gamvan.club.item.ClubClassItem;
import com.gamvan.club.item.ClubTopicItem;
import com.gamvan.club.item.ClubTopicReItem;
import com.gamvan.club.message.ClubMessageSend;
import com.gamvan.club.user.ClubUsers;
import com.gamvan.tools.FormatDateTime;

/**
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicManage extends ClubTopicItem{
    private static final long serialVersionUID = 1L;
    private String act = new String();
    private double userMark=0, userMoney=0, userCredit=0;
    private String ccName="";
    private String message = new String();
    private String message2 = new String();
    private String userName, byUser, saveLink;
    private String postMsg = "0";
    private String userMessage = "";
    
    /* 日至相关变量声明 */
    private int byUserID=0;
    private String byUserIP="";
	private String topicLogTxt = ""; //日志备注
	private String topic="";
	private String topicLogSo="";
	private boolean topicLogList = false;
    private short topicLogByUserList=0; //日志信息是否显示在网页底部
    
    /* 判断是对主题操作还是对回复操作，以确定是更新哪张数据表的内容 */
    private boolean isRe = false; 

    /* 格式化当前时间 */
    private static final String now = FormatDateTime.formatDateTime("yyyy-MM-dd HH:mm:ss");
    private static final ClubUsers cu = new ClubUsers();
    private static final ClubTopicDel ctd = new ClubTopicDel();
    private static final ClubTopicImpl ctim = new ClubTopicImpl();
    private static final ClubTopicListImpl ctlim = new ClubTopicListImpl();
    private String moveTxt = "";
    
    
    public void topicDos(String[] ids){
        int id = 0;
        for(int i=0; i<ids.length; i++){
            id = Integer.parseInt(ids[i]);
            topicID = id;
            topicDo(id);
        }
    }
    
    public void topicDo(int id){
    	if(isRe){
    		topicReID = id;
    	}else{
    		topicID = id;
    	}
    	getTopicInfo();
        if(act.equals("1")){
            topicIsPass(id, true);
        }
        else if(act.equals("2")){
            topicIsPass(id, false);
        }
        else if(act.equals("3")){ //标记删除
        	topicLogSo = "删除主题";    
        	if(isRe){
        		topicLog(0, id);    //写入日志
        	}else{
        		topicLog(id, 0);    //写入日志
        	}
        	ctd.topicGarbage(id, isRe, (byte)1);
        	//message = ctd.getMessage();
        }
        else if(act.equals("4")){//还原标记删除
        	topicLogSo = "还原主题";                    
        	if(isRe){
        		topicLog(0, id);    //写入日志
        	}else{
        		topicLog(id, 0);    //写入日志
        	}
        	ctd.topicGarbage(id, isRe, (byte)0);
        	//message = ctd.getMessage();
        }
        else if(act.equals("5")){
            ctd.setIsRe(this.isRe);
            ctd.topicDel(id);
            message = ctd.getMessage();
        }
        else{
            message = "请选择您要操作的内容";
        }
    }
    
    /**
     * 认证主题
     * @param id
     * @param ispass
     * 2005-12-27 10:37:49 Made In GamVan
     * com.gamvan.club.topic
     */
    public void topicIsPass(int id, boolean ispass){
        int i = 0;
        try{
            if(id==-1){
                i = ctim.topicUpdateIsPass(-1, -1, ispass);
            }else{
                if(isRe){
                    i = ctim.topicUpdateIsPass(0, id, ispass);
                }else{
                    i = ctim.topicUpdateIsPass(id, 0, ispass);
                }  
            }
            message = i + " 条主题被更新！";
        }catch(Exception e){
            message = e.toString();
            e.printStackTrace();
        }
    }
    
    
    /**
     * 
     * @param page
     * @param pageNum
     * @param isPass 0所有未认证主题  1所有已认证主题 -1全部主题
     * @return
     * 2005-11-5 20:38:14 Made In GamVan
     * com.gamvan.club.topic
     */
    public List topicList(int page, int pageNum, int isPass){
        List list = null;
        try{
        	Boolean topicpass;
            if(isPass==1){
                topicpass = new Boolean(true);
            }
            else if(isPass==0){
            	topicpass = new Boolean(false);
            }else{
            	topicpass = null;
            }
            ctlim.setTopicIsDel(topicIsDel);
            ctlim.setCcID(ccID);
        	if(isRe){
        		list = ctlim.topicReAllList(page, pageNum, topicpass, " order by topicReID desc");
        	}else{
        		list = ctlim.topicAllList(page, pageNum, topicpass, " order by topicID desc");
        	}        
        }catch(Exception e){
            message = e.toString();
        }
        return list;
    }
    
    public int topicCount(int isPass){
        int i = 0;
        try{
        	Boolean topicpass;
            if(isPass==1){
                topicpass = new Boolean(true);
            }
            else if(isPass==0){
            	topicpass = new Boolean(false);
            }else{
            	topicpass = null;
            }
            ctlim.setCcID(ccID);
            ctlim.setTopicIsDel(topicIsDel);
        	if(isRe){
        		i = ctlim.topicReAllCount(topicpass,"");
        	}else{
        		i = ctlim.topicAllCount(topicpass,"");
        	}
        }catch(Exception e){
            message = e.toString();
        }
        return i;
    }
    
    
    public boolean topicLog(int tid, int reid){
    	boolean bea = false;
    	try{
    		//日至对象
	        ClubTopicLog ctl = new ClubTopicLog();
	        ctl.setTopicID(tid);
            ctl.setTopicReID(reid);
	        ctl.setTopic(topic);
	        ctl.setUserName(userName);
	        ctl.setUserID(userID);
	        ctl.setTopicLogByUserName(byUser);
	        ctl.setTopicLogByUserID(byUserID);
	        ctl.setTopicLogByUserIP(byUserIP);
	        if(!topicLogTxt.equals("")&&!moveTxt.equals("")){
	        	topicLogTxt += "<br/>";
	        }
	        ctl.setTopicLogTxt(topicLogTxt+moveTxt);
	        ctl.setUserCredit(userCredit);
	        ctl.setUserMark(userMark);
	        ctl.setUserMoney(userMoney);
	        ctl.setTopicLogSo(topicLogSo);
	        ctl.setTopicLogList(topicLogList);
	        ctl.setTopicLogByUserList(topicLogByUserList);
	        ctl.setCcID(ccID);
	        bea = ctl.executeLog();
	        message2 = ctl.getMessage();
            bea = true;
    	}catch(Exception e){
    		message2 = e.toString();
    	}
    	message += message2;
    	return bea;
    }
    
    
    public void getTopicInfo(){
        if(topicReID>0){
            ClubTopicReItem ctit = null;
            ctit = ctim.topicReInfo(topicReID);
            this.topicPro = ctit.getTopicPro(); //获取主题属性
            this.userName = ctit.getUserName();
            this.userID = ctit.getUserID();
            this.topic = ctit.getTopic();
            this.topicLayer = ctit.getTopicLayer();
            this.topicIsDel = ctit.getTopicIsDel();
            this.ccID = ctit.getCcID();
        }else{
            ClubTopicItem ctit = null;
            ctit = ctim.topicInfo(topicID);
            this.topicPro = ctit.getTopicPro(); //获取主题属性
            this.userName = ctit.getUserName();
            this.userID = ctit.getUserID();
            this.topic = ctit.getTopic();
            this.topicLayer = ctit.getTopicLayer();
            this.topicIsDel = ctit.getTopicIsDel();
            this.ccID = ctit.getCcID();
        }
    }

	/**
	 * 
	 * @param act
	 * @return
	 * com.gamvan.club.topic
	 */
    public boolean topicManage(String act){
        boolean bea = false;
        getTopicInfo();
        if(topicIsDel==0){
            if(act.equals("manage")){ // log
                topicLogSo = "奖/惩";
                bea = topicLog(topicID, topicReID); 
                if(bea){
                    bea = cu.userUpdate(userID, userMark, userMoney, userCredit, 0, 0);
                    if(!bea){
                        this.message = cu.getMessage();
                    }
                }
                this.message = message2;    
            }
            
            else if(act.equals("del")){
            	if(topicReID>0){
            		ctd.topicGarbage(topicReID, true, (byte)1, userMark, userMoney, userCredit);
            	}else{
            		ctd.topicGarbage(topicID, false, (byte)1, userMark, userMoney, userCredit);
            	}
				topicLogSo = "删除主题";                    
				bea = topicLog(topicID, topicReID);    //写入日志  
				if(bea){
					message2 = this.topic + "<br /><br />主题删除操作成功！<br /><br />";
				}else{
					message2 = this.topic + "<br /><br />主题删除操作失败！<br /><br />";
				}
				this.message += this.message2;
            }
            
            else if(act.equals("best")){
                if(this.topicPro!=1){
                    bea = topicFieldUpdate(topicID, "topicPro", 1);
                    if(bea){
                        topicLogSo = "精品归档";                    
                        bea = topicLog(topicID, topicReID); //写入日志   
                        if(bea){ //判断日志是否正确写入
                            bea = cu.userUpdate(userID, userMark, userMoney, userCredit, 3, 0);
                            if(bea){ //判断用户参数是否正确更新
                                this.message = this.topic + "<br /><br />主题已被加为精品！<br /><br />";
                            }
                        }
                        this.message += this.message2;
                        
                    }else{
                        this.message= "您的操作触发一个美丽的意外，指令将不被执行，请重新尝试！";
                    }
                }else{
                    message = this.topic + "<br /><br />主题已经是精品文章，请不要重复操作！<br /><br />";
                }
            }
            
            else if(act.equals("nobest")){
                if(topicPro==1){
                    bea = topicFieldUpdate(topicID, "topicPro", 0);
                    if(bea){
                        topicLogSo = "解除精品";                  
                        bea = topicLog(topicID, topicReID); //写入日志
                        if(bea){  //判断日志是否正确写入
                            bea = cu.userUpdate(userID, userMark, userMoney, userCredit, 3, 0);
                            if(bea){  //判断用户参数是否正确更新
                                this.message = this.topic + "<br /><br />文章精品属性已被取消！<br /><br />";
                            }
                        }
                        this.message += message2;
                    }else{
                        message= "您的操作触发一个美丽的意外，指令将不被执行，请重新尝试！";
                    }
                }else{
                    message = this.topic + "<br /><br />该主题属性已经不是精品，请不要重复操作！<br /><br />";
                }
            }else if(act.equals("move")){
                    bea = topicMove(topicID, moveCCID);
                    if(bea){    
                        //topicLogSo = 已定义
                        bea = topicLog(topicID, topicReID); //写入日志     
                        if(bea){
                            bea = cu.userUpdate(userID, userMark, userMoney, userCredit, 3, 0);
                            if(bea){
                                this.message = this.topic + "<br /><br />文章移动成功！<br /><br />";
                            }
                        }
                        this.message += message2;
                    }else{
                        //message= "您的操作触发一个美丽的意外，指令将不被执行，请重新尝试！";
                    }
            }else if(act.equals("top")){
                    bea = topicFieldUpdate(topicID, "topicOrder", topicOrder);
                    if(bea){
                    	if(topicOrder>0){
                    		topicLogSo = "文章置顶";
                    	}else{
                    		topicLogSo = "解除置顶";
                    	}
                        bea = topicLog(topicID, topicReID); //写入日志
                        if(bea){  //判断日志是否正确写入
                            bea = cu.userUpdate(userID, userMark, userMoney, userCredit, 3, 0);
                            if(bea){
                                message = this.topic + "<br /><br />置顶操作成功！<br /><br />";
                            }
                        }
                        this.message += message2;
                    }else{
                        message= "您的操作触发一个美丽的意外，指令将不被执行，请重新尝试！";
                    }
            }
            
        }else{
            message= "您所请求的操作的文章不存在！";
        }
        /* 判断是否用短消息通知用户 */
        StringBuffer sb = new StringBuffer();
        if(postMsg.equals("1")){
        	sb.append("您社区的贴子被管理员[b]<");
        	sb.append(topicLogSo);
        	sb.append(">[/b]");
        	if(!topicLogTxt.equals("")){
        		sb.append("，原因：");
        		sb.append(topicLogTxt);
        	}
        	sb.append("\n[url=clubPage.jsp?ccStyle=1&tID=");
        	sb.append(topicID);
        	sb.append("&reID=");
        	sb.append(topicReID);        	
        	sb.append("]贴子主题为：");
        	sb.append(topic);
        	sb.append("[/url]");
        	sb.append("\n\n因此而涉及到您在社区的各项指数变化情况如下：");
        	sb.append("\n积分：");
        	if(userMark>0){sb.append("+");}
        	sb.append(userMark);
        	sb.append("\n金币：");
        	if(userMoney>0){sb.append("+");}
        	sb.append(userMoney);
        	sb.append("\n信誉：");
        	if(userCredit>0){sb.append("+");}
        	sb.append(userCredit);
        	if(topicLogByUserList==1){
        		sb.append("\n执行此项操作的管理员为：");
        		sb.append(byUser);
            	if(!userMessage.equals("")){
            		sb.append("\n以下是管理员给您的留言：[quote=");
            		sb.append(byUser);
            		sb.append("]");
            		sb.append(userMessage); 
            		sb.append("[/quote]");
            	}
        	}
        	sb.append("\n事件发生时间：");
        	sb.append(now);
        	sb.append("\n\n------系统邮件无需回复------");
    		ClubMessageSend cms = new ClubMessageSend ();
    		cms.setIsPost(1);
    		cms.setCmSendUser("勤杂工");
    		cms.setCmSendID(0);
    		cms.setCmTopic("社区提醒：您的某篇贴子被社区管理员管理！");
    		cms.setCmContent(sb.toString());
    		cms.setCmUserIp("127.0.0.1");
    		cms.setCmIsSend(true);
    		cms.setCmOrder((short)0);
    		cms.setCmReID(0);
    		cms.sendMessages(userName);
        }        
        return bea;
    }
    
    
    /**
     * 
     * @param tID
     * @param moveID
     * @return
     * 2005-11-5 21:06:16 Made In GamVan
     * com.gamvan.club.topic
     */
    public boolean topicMove(int tID, int moveID){
        boolean bea = false;
        int ccidd;
        int ccid1=0, ccid2=0;
        int ccidd1=0;
        ClubClassInfo cci = new ClubClassInfo();
        ClubClassItem ccit = null;
        cci.setCcID(moveID);
        ccit = cci.getClubClassInfo();
        moveTxt = "从 " + ccName + " 移动到 " + ccit.getCcName();
        topicLogSo = "移动主题";
        ccidd = ccit.getCcIDD();
        if(ccidd>0){
            ccit = null;
            cci.setCcID(ccidd);
            ccit = cci.getClubClassInfo();
            ccid1 = ccidd;
            ccidd1 = ccit.getCcIDD();
            if(ccidd1>0){
                ccid2 = ccidd1;
            }
        }
        try{
        	ctim.topicMove(tID, moveCCID, ccid1, ccid2, byUser, now, saveLink);         
            bea = true;
            message= "主题移动成功！";
        }catch(Exception e){
            message= "您的操作触发一个美丽的意外，将不被执行，请重新尝试！<br/>"
                + e.toString();
            bea = false;
        }
        return bea;
    }
    
    /**
     * 对单独字段更新
     * @param tID
     * @param num
     * @param what
     * @return
     */
    public boolean topicFieldUpdate(int tid, String field, int num){
        boolean bea = false;
        StringBuffer hql = new StringBuffer();
        try{
            if(topicReID>0){
            	hql.append(" where topicReID=");
            	hql.append(topicReID);
                ctim.topicFieldUpdate_re(hql.toString(), field, num);
            }else{
            	hql.append(" where topicID=");
            	hql.append(tid);
            	ctim.topicFieldUpdate(hql.toString(), field, num);
            }
            bea = true;
        }catch(Exception e){
            message="抱歉！由于系统运行出现一个美丽的错误，您的操作将不能被执行，请重新尝试！";
            bea = false;
        }
        return bea;
    }
    
   /*
    public boolean topicIsDel(int tid, int reid, byte b){
    	boolean bea = false;
    	try{
    		if(reid>0){
    			ctd.topicGarbage(reid, true, b);
    			//ctim.topicIsDelUpdate_re(reid, b);
    			//ccim.contentReDel_(reid, b); //标记删除内容
    		}else{
    			//ctim.topicIsDelUpdate(tid, b);
    			ctd.topicGarbage(tid, false, b);
    		}
    		bea = true;
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return bea;
    }
    */
    
    /**
     * 针对主题表 按发帖用户ID更新帖子单独字段
     * @param userid
     * @param num
     * @param what 0更新topicPro, 1更新topicOrder, 2更新topicIsDel
     * @return
     */
    public boolean topicFieldUpdate_userid (int userid, int num, int what){
        boolean bea = false;
        StringBuffer hql = new StringBuffer("");
        try{
        	hql.append(" where userID=");
        	hql.append(userid);
            if(what==0){
            	ctim.topicFieldUpdate(hql.toString(), "topicPro", num);
            }else if(what==1){
            	ctim.topicFieldUpdate(hql.toString(), "topicOrder", num);
            }else if(what==2){
            	
            	//ctim.topicFieldUpdate(hql.toString(), "topicIsDel", (byte)num);
            }
            bea = true;
        }catch(Exception e){
            message="抱歉！由于系统运行出现一个美丽的错误，您的操作将不能被执行，请重新尝试！";
            bea = false;
        }
        return bea;
    }
    /**
     * 针对回复表 按发帖用户ID更新帖子单独字段
     * @param userid
     * @param num
     * @param what 0更新topicPro, 1更新topicOrder, 2更新topicIsDel
     * @return
     * 2005-12-27 12:33:18 Made In GamVan
     * com.gamvan.club.topic
     */
    public boolean topicFieldUpdateRe_userid (int userid, int num, int what){
        boolean bea = false;
        StringBuffer hql = new StringBuffer("");
        try{
        	hql.append(" where userID=");
        	hql.append(userid);
            if(what==0){
            	ctim.topicFieldUpdate_re(hql.toString(), "topicPro", num);
            }else if(what==1){
            	ctim.topicFieldUpdate_re(hql.toString(), "topicOrder", num);
            }else if(what==2){
            	
            	//ctim.topicFieldUpdate_re(hql.toString(), "topicIsDel", (byte)num);
            }
            bea = true;
        }catch(Exception e){
            message="抱歉！由于系统运行出现一个美丽的错误，您的操作将不能被执行，请重新尝试！";
            bea = false;
        }
        return bea;
    }
    
    
    /*
    public static void main(String args[]){
        com.gamvan.conn.ConnClub.init();
        ClubTopicManage ctm= new ClubTopicManage();
        ctm.topicIsDel(8617,0,(byte)1);
        com.gamvan.conn.ConnClub.closeSession2();
    }
    */

    public String getMessage(){
        return this.message;
    }
    public String getByUser() {
        return byUser;
    }

    public void setByUser(String byUser) {
        this.byUser = byUser;
    }

    public int getByUserID() {
        return byUserID;
    }

    public void setByUserID(int byUserID) {
        this.byUserID = byUserID;
    }

    public String getByUserIP() {
        return byUserIP;
    }

    public void setByUserIP(String byUserIP) {
        this.byUserIP = byUserIP;
    }

    public String getCcName() {
        return ccName;
    }

    public void setCcName(String ccName) {
        this.ccName = ccName;
    }

    public String getMessage2() {
        return message2;
    }

    public void setMessage2(String message2) {
        this.message2 = message2;
    }

    public String getSaveLink() {
        return saveLink;
    }

    public void setSaveLink(String saveLink) {
        this.saveLink = saveLink;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public short getTopicLogByUserList() {
        return topicLogByUserList;
    }

    public void setTopicLogByUserList(short topicLogByUserList) {
        this.topicLogByUserList = topicLogByUserList;
    }

    public boolean getTopicLogList() {
        return topicLogList;
    }

    public void setTopicLogList(boolean topicLogList) {
        this.topicLogList = topicLogList;
    }

    public String getTopicLogSo() {
        return topicLogSo;
    }

    public void setTopicLogSo(String topicLogSo) {
        this.topicLogSo = topicLogSo;
    }

    public String getTopicLogTxt() {
        return topicLogTxt;
    }

    public void setTopicLogTxt(String topicLogTxt) {
        this.topicLogTxt = topicLogTxt;
    }

    public double getUserCredit() {
        return userCredit;
    }

    public void setUserCredit(double userCredit) {
        this.userCredit = userCredit;
    }

    public double getUserMark() {
        return userMark;
    }

    public void setUserMark(double userMark) {
        this.userMark = userMark;
    }

    public double getUserMoney() {
        return userMoney;
    }

    public void setUserMoney(double userMoney) {
        this.userMoney = userMoney;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setIsRe(boolean isRe) {
        this.isRe = isRe;
    }

    public void setAct(String act) {
        this.act = act;
    }

	public void setPostMsg(String postMsg) {
		this.postMsg = postMsg;
	}

	public void setUserMessage(String userMessage) {
		this.userMessage = userMessage;
	}
}
 
