package com.gamvan.club.topic;
import com.gamvan.tools.EncodeString;

/**
 * 贴子特殊类型显示层相关
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ClubTopicType {
    double gvUserCredit=0, gvUserMark=0, gvUserMoney=0;
    private int topicType = 0;
    private double topicTypeNum = 0;
    private double userTypeNum = 0;
    
    public String encoderType(String str){
        StringBuffer temp = new StringBuffer();
        String txt = new String("");
        if(topicType==1){
           if(userTypeNum<topicTypeNum && userTypeNum!=-1 && userTypeNum!=-2){
                temp.append("<table width=\"80%\" border=\"0\" cellpadding=\"2\" cellspacing=\"1\" class=\"bg1\">");
                temp.append("<tr class=\"tab1\"><td>");
                temp.append("<img border=\"0\" alt=\"积分贴 " + topicTypeNum + "\" src=\"/club/GVimgs/topicPro/mark.gif\" align=\"absmiddle\" /> <strong>积分浏览贴</strong>");
                temp.append("</td></tr>");
                temp.append("<tr class=\"tab3\"><td>");
                temp.append("浏览本贴隐藏内容所需积分>="+topicTypeNum+",您的积分不够，无法浏览本贴隐藏内容！");
                temp.append("</td></tr>");
                temp.append("</table>");
                str = EncodeString.ubbPattern(str,"\\[GVtype\\](.*?)\\[/GVtype\\]",temp.toString());
                //str = String.valueOf(temp);
           }else{
                str = str.replaceAll("\\[GVtype\\]","");
                str = str.replaceAll("\\[/GVtype\\]","");
           }
           topicType=0;
        }else if(topicType==2){
    		if(userTypeNum==-1){
          		txt = "<li>您是帖子的主人，所以无需支付今币！</li>";
    		}else if(userTypeNum==-2){
   				txt = "<li>社区为您开通特殊权限，您无需支付今币！</li>";
    		}
            if(userTypeNum<0){
                temp.append("<table width=\"280\" border=\"0\" cellpadding=\"2\" cellspacing=\"1\" class=\"bg1\">");
                temp.append("<tr class=\"tab1\"><td>");
                temp.append("<img border=\"0\" alt=\"购买帖,所需今币 " + topicTypeNum + "\" src=\"/club/GVimgs/topicPro/money.gif\" align=\"absmiddle\" /> <strong>购买贴</strong>");
                temp.append("</td></tr>");
                temp.append("<tr class=\"tab3\"><td>");
                temp.append("<li>浏览本帖隐藏内容需要您花费 <strong>"+String.valueOf(topicTypeNum)+"</strong> 枚金币！</li>");
                temp.append("<span style=\"color:blue\">"+txt+"</span>");
                temp.append("</td></tr>");
                temp.append("</table>");
                str = str.replaceAll("\\[GVtype\\]","");
                str = str.replaceAll("\\[/GVtype\\]","");
                str = temp + str;
           }else{ 
                temp.append("<script language=\"javascript\">function typePostMsg(){var ot=event.srcElement; ot.gvSubmitType.value=\"正在提交...\";");
                temp.append("ot.gvSubmitType.disabled=true;}</script>");
                
                temp.append("<table width=\"280\" border=\"0\" cellpadding=\"2\" cellspacing=\"1\" class=\"bg1\">");
                temp.append("<form action=\"\" method=\"post\" onSubmit=\"return typePostMsg();\"><tr class=\"tab1\"><td>");
                temp.append("<img border=\"0\" alt=\"购买帖,所需今币 " + topicTypeNum + "\" src=\"/club/GVimgs/topicPro/money.gif\" align=\"absmiddle\" /> <strong>购买贴</strong>");
                temp.append("</td></tr>");
                temp.append("<tr class=\"tab3\"><td>");
                temp.append("<li>浏览本帖隐藏内容需要您花费 <strong>"+String.valueOf(topicTypeNum)+"</strong> 枚今币！</li>");
                temp.append("<li>您已经支付过 <strong>"+String.valueOf(userTypeNum)+"</strong> 枚今币！</li>");
                temp.append("<div align=\"center\"><input name=\"gvSubmitType\" type=\"submit\" value=\"确定购买\" class=\"btn\"></div>");
                temp.append("</td></tr></form>");
                temp.append("</table>");
                if(userTypeNum<topicTypeNum){
                    str = EncodeString.ubbPattern(str,"\\[GVtype\\](.*?)\\[/GVtype\\]",temp.toString());
                    //str = str.replace(str,temp);
                }else{
                    str = str.replaceAll("\\[GVtype\\]","");
                    str = str.replaceAll("\\[/GVtype\\]","");
                }
           }
           topicType=0;
        }else if(topicType==4){
        		if(userTypeNum==-1){
              		txt = "您是帖子主人无需回复";
        		}else if(userTypeNum==-2){
       				txt = "社区为您开通特殊权限，您无需回复。";
        		}
                if(userTypeNum<0){
                    temp.append("<table width=\"280\" border=\"0\" cellpadding=\"2\" cellspacing=\"1\" class=\"bg1\">");
                    temp.append("<tr class=\"tab1\" align=\"center\"><td>");
                    temp.append("<strong>本贴隐藏内容回复后可见！</strong>");
                    temp.append("</td></tr>");
                    temp.append("<tr class=\"tab3\" align=\"center\"><td>");
                    temp.append("<span style=\"color:blue\">"+txt+"</span>");
                    temp.append("</td></tr>");
                    temp.append("</table>");	
                    str = str.replaceAll("\\[GVtype\\]","");
                    str = str.replaceAll("\\[/GVtype\\]","");
                    str = temp + str;
                }else{
                	if(topicTypeNum>=0){ //indexOf返回值 
                        str = str.replaceAll("\\[GVtype\\]","");
                        str = str.replaceAll("\\[/GVtype\\]","");
                	}else{
	                    temp.append("<table width=\"280\" border=\"0\" cellpadding=\"2\" cellspacing=\"1\" class=\"bg1\">");
	                    temp.append("<tr class=\"tab1\" align=\"center\"><td>");
	                    temp.append("<strong>本贴隐藏内容回复后可见！</strong>");
	                    temp.append("</td></tr>");
	                    temp.append("</table>");
	                    str = EncodeString.ubbPattern(str,"\\[GVtype\\](.*?)\\[/GVtype\\]",temp.toString());
                	}
                }
           topicType=0;
        }
       return str; 
    }


    public void setTopicType(int topicType){
        this.topicType = topicType;
    }
    public void setTopicTypeNum(double topicTypeNum){
        this.topicTypeNum = topicTypeNum;
    }
    public void setUserTypeNum(double userTypeNum){
        this.userTypeNum = userTypeNum;
    }
}
