package com.gamvan.conn;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Session;

/**
 * 
 * @author GamVan by 我容易么我
 * Powered by GamVan.com
 */
public class ConnClub{
    private static SessionFactory sessionFactory = null;
    public static final ThreadLocal localSession = new ThreadLocal();
    
    public static void init() throws HibernateException {
    	if(sessionFactory==null){
	        sessionFactory = 
	            new Configuration().configure().buildSessionFactory();
    	}
    }

    /*test
    public static void main(String args[]){
        ConnClub.getSession();
        System.out.print(ConnClub.getMessage());
        
    }
    */
    
    public static Session getSession(){
        Session session = (Session)localSession.get();
        if(session==null){
            session = sessionFactory.openSession();
            localSession.set(session);
        }
        return session;
    }
    
    public static void closeSession() throws HibernateException {
        /*
        Session session = (Session)localSession.get();
        if (session != null){
            message += "<br> sessionclose ";
            session.close();
            localSession.set(null);
        }
        */
    }
    
    public static void closeSession2() throws HibernateException {    
        Session session = (Session)localSession.get();
        localSession.set(null);
        if (session != null){
            session.close(); 
        }
    }
}