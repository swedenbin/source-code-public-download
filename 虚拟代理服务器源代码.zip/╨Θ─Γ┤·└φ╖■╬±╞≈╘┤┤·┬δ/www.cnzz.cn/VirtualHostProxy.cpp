// VirtualHostProxy.cpp 
//
// Virtual Host Proxy Server
// (c) Franck JEANNIN 1999 - fjeannin@linkguard.com
//
// Simulate multiple Web servers on one single Windows 95/98 machine 
//
// Does not support HTTP 1.1 (HTTP 1.0 only)
// Use high level MFC socket classes: CSocket
//

#include "stdafx.h"
#include <afxsock.h>        // MFC socket extensions
#include <conio.h>

#define BUFFERSIZE 10000
#define SERVERNAMEMAXSIZE 256

#define PROXYPORT 5060

#define SERVERADDRESS "127.0.0.1"
#define SERVERPORT 80

char Buffer[BUFFERSIZE+SERVERNAMEMAXSIZE];

int main(int argc, char* argv[])
{
	CSocket Proxy;
	CSocket Client;
	CSocket Server;

	// initialize MFC
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		printf("Fatal Error: MFC initialization failed\nPress any key\n");
		getch();
		return -1;
	}

	// initialize Socket support
	if (!AfxSocketInit())
	{
		printf("Fatal Error: Socket initialization failed\nPress any key\n");
		getch();
		return -1;
	}
	
	// create Proxy socket
	if (!Proxy.Create(PROXYPORT))
	{
		printf("Fatal Error: Proxy socket creation failed\nError %d\n\nPress any key\n",GetLastError());
		getch();
		return -1;
	}
	
	if (!Proxy.Listen(1))
	{
		printf("Fatal Error: Proxy socket activation failed\nError %d\n\nPress any key\n",GetLastError());
		getch();
		return -1;
	}
	else
	{
		printf("Virtual Host Proxy Server started on port %d\n(c) Franck JEANNIN 1999\n\n",PROXYPORT);
	}

	while(1)
	{
		if (!Proxy.Accept(Client))
		{
			printf("Fatal Error: Client connection to Proxy failed\nError %d\n\nPress any key\n",GetLastError());
			getch();
			return -1;
		}

		int n = Client.Receive(Buffer,BUFFERSIZE);
		
		if (n == -1)
		{
			printf("Fatal Error: Client transmission to Proxy failed\nError %d\n\nPress any key\n",GetLastError());
			getch();
			return -1;
		}

		Buffer[n] = 0;
		printf("Received from client: %s\n",Buffer);

		// calls to http://www.a.com/mypage.htm are transformed to calls to http://127.0.0.1/www.a.com/mypage.htm
		char* p = strstr(Buffer,"//");

		if (p)
		{
			p += 2;
			memmove(p+sizeof(SERVERADDRESS),p,n);
			memcpy(p,SERVERADDRESS,sizeof(SERVERADDRESS)-1);
			*(p+sizeof(SERVERADDRESS)-1) = '/';
			n += sizeof(SERVERADDRESS);
		}

		if (!Server.Create())
		{
			printf("Fatal Error: Server socket creation failed\nError %d\n\nPress any key\n",GetLastError());
			getch();
			return -1;
		}
		
		if (!Server.Connect(SERVERADDRESS,SERVERPORT))
		{
			printf("Fatal Error: Server socket connection to HTTP server failed\nError %d\n\nPress any key\n",GetLastError());
			getch();
			return -1;
		}
		
		n = Server.Send(Buffer,n);

		if (n == -1)
		{
			printf("Fatal Error: Proxy transmission to Server failed\nError %d\n\nPress any key\n",GetLastError());
			getch();
			return -1;
		}

		Buffer[n] = 0;
		printf("Sent to server: %s\n",Buffer);

		while ( (n = Server.Receive(Buffer,BUFFERSIZE)) != 0)
		{

			if (n == -1)
			{
				printf("Fatal Error: Server transmission to Proxy failed\nError %d\n\nPress any key\n",GetLastError());
				getch();
				return -1;
			}

			Buffer[n] = 0;
			printf("Received from server: %s\n",Buffer);

			n = Client.Send(Buffer,n);

			if (n == -1)
			{
				printf("Fatal Error: Proxy transmission to Server failed\nError %d\n\nPress any key\n",GetLastError());
				getch();
				return -1;
			}

			Buffer[n] = 0;
			printf("Sent to Client: %s\n",Buffer);
		}		

		printf("Closing Client & Server sockets\n");
		Client.Close();
		Server.Close();
	}

	return 0;
}

